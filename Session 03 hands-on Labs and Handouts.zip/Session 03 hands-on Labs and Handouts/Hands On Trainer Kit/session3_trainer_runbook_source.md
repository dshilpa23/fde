# Session 3 Hands-on Trainer Runbook

## Coding-Agent Foundations & Spec-Driven Rule Engine

Claude Code harness engineering for a healthcare infusion benefit workflow slice  
Prepared for: Healthcare FDE Academy | Fractal format | Version 1.0 | 27 July 2026

## About this document

This document is for the trainer, not for learners. It explains exactly how Session 3 should run in VS Code with Claude Code, what is already prepared, what is built live, what learners practice, and what output the trainer should expect at each step. I have written it as a teaching runbook, not just a checklist, because the trainer needs to carry a story through the four hours. The session is deliberately small on code volume and heavy on engineering discipline. That is the point. If learners do not leave this session with a working `CLAUDE.md`, a real spec, failing tests, and one controlled rule slice, Session 4 becomes much harder.

## 1. Why Session 3 exists

Session 3 is the foundation session for the hands-on track. The course should not teach Claude Code as a “cool prompt tool”. It should teach Claude Code as a controlled engineering cockpit for Forward Deployed Engineers working in healthcare.

The central idea is simple:

> Prompting gets one answer. Harness engineering improves every future answer.

The trainer should carry one story from start to finish:

An FDE joins a healthcare operations team that is drowning in infusion benefit workflow exceptions. The team is not asking for “AI” in the abstract. They need a safe way to convert messy operational rules into something inspectable, testable, and reusable. Claude Code can accelerate the work, but only after the FDE creates the harness around it: project memory, source boundaries, specs, tests, and review gates.

That story matters because the class should feel the difference between two ways of working:

- weak approach: ask Claude Code to build a healthcare rules engine and hope the output is good
- FDE approach: define what the system is allowed to know, write the contract, create failing tests, then let Claude Code implement inside that boundary

In this session, learners take a small healthcare workflow problem and build the minimum structure needed for Claude Code to help safely:

- project memory through `CLAUDE.md`
- project rules through `.claude/rules`
- a written spec
- a decision table
- executable tests
- one thin rule-engine implementation
- a review and handoff package for Session 4

I would not try to build a full API, database, or Docker image here. That looks impressive for five minutes, then the class starts debugging plumbing instead of learning the method. Session 3 should stay focused on how a mature FDE sets up an agent-assisted project before real build pressure starts.

## 2. The teaching story in one page

The session opens with a deliberately bad request:

> “Build me a healthcare rules engine for infusion benefit workflow.”

Most engineers can make Claude Code produce something from that. The training point is that producing code is not the same as producing safe enterprise software. The trainer should let learners spot what is missing before showing the method.

The story then moves in five beats:

1. The request is ambiguous. The FDE slows it down.
2. The workflow is decoded into facts, statuses, and forbidden outputs.
3. The project harness is created so Claude Code has memory and boundaries.
4. The expected behavior becomes executable through tests.
5. Claude Code implements one small slice and the trainer reviews the evidence.

The payoff is not a large application. The payoff is that learners see a repeatable way to use Claude Code without losing engineering control.

Session 4 can then say: “Now that the harness exists, let us expand the rule engine into a service.”

## 3. What is in scope and out of scope

### In scope for Session 3

- Claude Code project setup inside VS Code or terminal
- `CLAUDE.md` as the project constitution
- `.claude/rules` for healthcare safety, testing, and spec-driven work
- a small infusion benefit workflow problem
- decision-table based rule design
- failing tests before implementation
- one pure Python rule-engine slice
- manual test run using `pytest`
- optional hook concept for automated test checks
- trainer-led review of unsafe agent behavior

### Out of scope for Session 3

- FastAPI endpoint
- SQLite or PostgreSQL
- Docker build
- cloud deployment
- full rule catalog
- frontend
- ML model
- RAG
- runtime LLM or agent workflow

Those pieces come later. Session 4 expands this exact repo pattern into the full rule-based service with API, persistence, routing, and local packaging.

## 4. The healthcare problem slice

The working example is an infusion benefit workflow routing problem.

Operations teams receive benefit workflow cases with information such as benefit verification status, prior authorization status, documentation status, urgency, and payer response source. Today, many of these cases are reviewed manually because the routing logic is scattered across BRDs, spreadsheets, and operational judgment.

For Session 3, the system does not make a clinical or coverage decision. It only routes administrative workflow cases into safe operational statuses.

Tell the problem in plain English before showing code:

“A patient is ready for an infusion appointment, but operations cannot schedule blindly. Benefits may not be verified. Prior authorization may still be pending. Documentation may be incomplete. Some cases are clean enough to move to scheduling; others must go to the right work queue. The system we build today only helps with that routing decision.”

The key distinction:

- `READY_TO_SCHEDULE` means administrative prerequisites look complete
- it does not mean treatment is clinically approved
- it does not mean coverage has been finally approved
- it does not replace a clinical, payer, or compliance owner

Allowed statuses for this session:

- `READY_TO_SCHEDULE`
- `BENEFIT_NOT_VERIFIED`
- `PA_PENDING`
- `DOCS_INCOMPLETE`
- `NEEDS_REVIEW`

Hard boundary:

> The rule engine must never return `APPROVED`, `DENIED`, or any wording that sounds like a clinical decision.

This is the first serious healthcare teaching moment. The agent can write code quickly, but the FDE must decide what the system is allowed to say.

## 5. What the trainer receives

The trainer package should be delivered as:

```text
Session_03_Coding_Agent_Foundations/
  00_trainer_runbook/
    Session_3_Trainer_Runbook.docx
    trainer_practice_checklist.md
    troubleshooting_guide.md

  01_project_starter/
    session_3_rule_engine/
      CLAUDE.md
      README.md
      pyproject.toml
      .claude/
        rules/
          healthcare_safety_rules.md
          testing_rules.md
          spec_driven_development.md
        settings.json
      specs/
        001_rule_engine_slice.md
      templates/
        decision_table.csv
        acceptance_criteria.md
      src/
        infusion_rules/
          __init__.py
          rules.py
          service.py
      tests/
        test_rules.py
        test_service.py
        test_safety_language.py

  02_project_completed_reference/
    session_3_rule_engine_completed/

  03_claude_code_prompts/
    01_scout_repo_no_edits.md
    02_create_failing_tests.md
    03_implement_smallest_rule_core.md
    04_self_review_against_spec.md
    05_fix_harness_not_just_code.md

  04_sample_inputs_outputs/
    sample_inputs/
    expected_outputs/

  05_learner_assignment/
    learner_assignment.md
    submission_checklist.md
    evaluation_rubric.md
```

The starter repo must run before class. I would ask the trainer to rehearse the build at least once, ideally two days before delivery. Claude Code behavior can vary slightly, so the trainer should know the intended path and the fallback path.

## 6. What is already built when class starts

The starter repo is intentionally small. Learners should be able to inspect the full surface area in a few minutes.

Already prepared:

- Python package skeleton under `src/infusion_rules`
- empty or partially stubbed rule functions
- a decision table with four clear routing cases
- acceptance criteria in plain English
- `CLAUDE.md` with initial project purpose and commands
- `.claude/rules` files for healthcare safety, testing, and spec discipline
- pytest structure
- sample input and expected output JSON files
- prompt pack for Claude Code

Not pre-built:

- final rule logic
- complete test coverage
- self-review notes
- learner’s additional rule

The trainer should resist the temptation to over-scaffold. If everything is already done, learners only watch a demo. If nothing is scaffolded, they spend the afternoon fighting setup. The middle path is the right one.

## 7. What learners should understand before touching Claude Code

Before the first prompt is pasted, learners should understand three ideas.

First, Claude Code is not the source of truth. It can inspect files, write tests, implement functions, and review diffs, but it cannot invent healthcare policy. The source of truth is the spec, the decision table, and the boundaries captured in project rules.

Second, tests are not only for bugs. In this session, tests are part of the prompt. They tell Claude Code what behavior must exist and what behavior must never appear.

Third, every repeated correction should become part of the harness. If the trainer has to say “do not use clinical approval language” once, that is feedback. If the trainer has to say it twice, it belongs in `healthcare_safety_rules.md` and in a failing test.

The trainer should make this explicit. Otherwise learners may think the session is about memorizing prompts. It is not. It is about creating the conditions under which a coding agent can safely help.

## 8. Four-hour teaching flow

### 0:00-0:20 | Open the problem

Trainer frames the session:

“We are not using Claude Code to automate clinical judgment. We are using Claude Code to help build a deterministic administrative routing slice. The FDE job is to create the harness around the agent before asking it to write code.”

Story move:

“Imagine the operations lead says: we have too many infusion benefit cases stuck in manual review. Can Claude help us automate this? A weak answer is yes. A stronger FDE answer is: maybe, but first we need to know which decision we are automating, which decision we are not allowed to automate, and what proof the team will accept.”

Show the bad prompt:

```text
Build me a healthcare rules engine for infusion benefit workflow.
```

Ask learners what is missing:

- Which workflow?
- Which inputs?
- Which outputs?
- Which statuses are allowed?
- What must go to human review?
- What evidence proves correctness?
- What must the system never say?

Trainer should not rush this. The missing questions are the point of the opening. Mature engineers usually recognize the danger quickly once the healthcare boundary is named.

### 0:20-0:50 | Claude Code operating model

Use the deck section on operating stack, project memory, permissions, and the core loop.

Trainer message:

“A coding agent is not the authority. The authority is the source material, the spec, and the tests. Claude Code is useful when it works inside those boundaries.”

Introduce the loop:

```text
Explore -> Plan -> Implement -> Verify -> Review
```

This loop is reused in every later build session.

Explain the loop like this:

- Explore: Claude reads before touching files
- Plan: Claude proposes file scope and implementation sequence
- Implement: Claude changes only the approved files
- Verify: tests and sample outputs prove the slice
- Review: the FDE checks whether the implementation still respects healthcare boundaries

The trainer should say plainly: “If we skip Explore and Plan, Claude Code may still produce working code. It just may solve the wrong problem.”

### 0:50-1:20 | Decode the healthcare workflow

Open `templates/decision_table.csv`.

Explain each column:

- `benefit_status`
- `prior_auth_status`
- `documentation_status`
- `urgency`
- `expected_status`
- `reason_code`
- `next_action`
- `clinical_decision`

Trainer note:

This is where learners often jump ahead and ask “Can we just let the model infer this?” Hold the line. Session 3 is about deterministic administrative routing. If a rule is not in the table, it is not allowed to appear in code.

Mini-discussion:

Ask learners to classify each output:

- Is this an administrative routing status?
- Does this sound like clinical approval?
- Who would own the decision in a real healthcare organization?

The answer is more important than the syntax. This is where the FDE mindset becomes visible.

### 1:20-1:30 | Short break

### 1:30-2:00 | Harness engineering setup

Open `CLAUDE.md` and `.claude/rules`.

Trainer explains:

“Harness engineering means we stop repeating the same instruction manually. If the instruction matters, we put it into project memory, a rule file, a test, a hook, or a review step.”

Important example:

If Claude Code invents an `APPROVED` status, do not only say:

```text
No, do not use APPROVED.
```

Instead, improve the harness:

```text
Remove APPROVED.
Update healthcare_safety_rules.md so future changes cannot introduce APPROVED.
Add a test proving no response can imply clinical approval.
```

That is the mindset shift.

Make the harness concrete:

- `CLAUDE.md` is the project memory
- `.claude/rules` is the recurring behavior guide
- `specs/001_rule_engine_slice.md` is the current contract
- `templates/decision_table.csv` is the source of allowed behavior
- `tests/` is the executable proof
- optional hooks are the automated guardrails

The line I would use in class:

“A prompt is disposable. A harness is reusable.”

### 2:00-2:20 | Trainer uses Prompt 1: scout, no edits

Paste this into Claude Code:

```text
Read CLAUDE.md, .claude/rules, specs/001_rule_engine_slice.md, templates/decision_table.csv, and tests/.

Do not edit files.

Return:
1. what behavior is already specified
2. which files are likely to change
3. what tests are missing
4. any assumptions that need domain review
5. the command that will prove the slice
```

Expected Claude Code response should mention:

- rule behavior comes from the decision table
- likely files: `src/infusion_rules/rules.py`, `src/infusion_rules/service.py`, and tests
- missing tests for all routing statuses and forbidden clinical language
- unknown cases should route to `NEEDS_REVIEW`
- proof command: `python -m pytest -q tests`

Trainer intervention:

If Claude proposes FastAPI, database, Docker, or extra frameworks, stop and ask:

```text
Which acceptance criterion requires that?
```

Expected repair:

Claude should narrow back to the pure Python rule slice.

Why this step matters:

The first prompt teaches learners to slow Claude Code down. Many people use coding agents like a code generator. FDEs use them like a junior engineer who must first read the repo, explain the plan, and name assumptions.

### 2:20-2:50 | Trainer uses Prompt 2: create failing tests

Paste:

```text
Use templates/decision_table.csv and specs/001_rule_engine_slice.md.

Write pytest tests first.

Cover:
- READY_TO_SCHEDULE
- BENEFIT_NOT_VERIFIED
- PA_PENDING
- DOCS_INCOMPLETE
- unknown or incomplete cases route to NEEDS_REVIEW
- no output may imply clinical approval

Do not implement the rules yet.
Run python -m pytest -q tests and show the failing tests.
```

Expected output:

```text
FAILED tests/test_rules.py::test_ready_to_schedule
FAILED tests/test_rules.py::test_benefit_not_verified
FAILED tests/test_rules.py::test_prior_authorization_pending
FAILED tests/test_rules.py::test_docs_incomplete
FAILED tests/test_safety_language.py::test_no_clinical_approval_language
```

Teaching point:

Failing tests are not a problem. They are the contract becoming executable.

Add one explanation before moving on:

“If Claude Code writes implementation before tests, it can make the code and test agree with each other while both drift away from the business rule. Writing tests first keeps the decision table in charge.”

### 2:50-3:20 | Trainer uses Prompt 3: implement smallest rule core

Paste:

```text
Implement the smallest rule core needed to pass the tests.

Scope:
- src/infusion_rules/rules.py
- src/infusion_rules/service.py
- tests only if a test has a syntax issue

Do not add FastAPI.
Do not add a database.
Do not add Docker.
Do not introduce APPROVED, DENIED, or clinical decision language.

Return exactly these fields from the service:
- status
- reason_code
- next_action
- audit_evidence
- clinical_decision

Run python -m pytest -q tests and summarize the result.
```

Expected output:

```text
5 passed
```

or:

```text
7 passed
```

depending on how many tests the starter includes.

Trainer should say:

“We do not trust the agent because it says tests passed. We trust the local command we run ourselves.”

Then run manually:

```bash
python -m pytest -q tests
```

If tests fail, do not panic. Use the failure as teaching material:

- Did the implementation violate the decision table?
- Did the test expect the wrong field?
- Did Claude introduce a status not allowed by the spec?
- Did the service output sound like approval?

The trainer should debug one failure in front of the room if it appears. That is often more valuable than a perfectly smooth demo.

### 3:20-3:35 | Check sample input and output

Run the sample manually through the package.

Example command:

```bash
python -m infusion_rules.service sample_inputs/benefit_not_verified.json
```

Expected output:

```json
{
  "status": "BENEFIT_NOT_VERIFIED",
  "reason_code": "BENEFIT_NOT_VERIFIED",
  "next_action": "Route to benefit verification queue",
  "audit_evidence": {
    "benefit_status": "not_verified",
    "source": "payer_response"
  },
  "clinical_decision": false
}
```

If the exact CLI is not built in the starter, the trainer can run the equivalent pytest case. Do not burn class time debugging command-line polish.

Explain the JSON output:

- `status` tells operations where the case goes
- `reason_code` makes the decision searchable and auditable
- `next_action` tells the user what to do next
- `audit_evidence` shows which input facts drove the route
- `clinical_decision: false` protects the boundary

This is the point where learners usually understand why the output is intentionally boring. Boring is good here. Boring can be audited.

### 3:35-3:50 | Trainer uses Prompt 4: self-review against the spec

Paste:

```text
Review your diff against specs/001_rule_engine_slice.md and templates/decision_table.csv.

Do not edit unless you find a correctness issue.

Report:
1. which rule each test proves
2. any source assumption introduced
3. any behavior not covered by tests
4. any output that could be misread as clinical approval
5. what should be handed off to Session 4
```

Expected response:

- maps tests back to the decision table
- confirms no clinical decision language
- calls out unknown cases as `NEEDS_REVIEW`
- recommends Session 4 expansion into API, persistence, queue, and full rule catalog

Trainer should emphasize:

“A passing test suite is necessary, but it is not the whole review. The final question is: did we build the thing we said we would build, and did we avoid the thing we said we would not build?”

### 3:50-4:00 | Wrap and assign learner task

Trainer closes with:

“Today we did not build much code. We built the way code should be built with an agent. Session 4 now has a clean starting point.”

Connect back to the opening:

At the start, the request was vague: “Build me a healthcare rules engine.” By the end, learners have turned that into a controlled project memory, a source-ranked decision table, tests, implementation, and review evidence. That is the FDE move.

Learner assignment:

Add one new rule:

```text
If urgency is true and documentation is complete, route to NEEDS_REVIEW with reason code URGENT_REVIEW.
```

Learners submit:

- updated decision table or spec
- one new test
- implementation change
- pytest output
- one paragraph explaining what Claude Code generated and what they reviewed manually

## 9. Exact sample inputs and expected outputs

### Input: benefit not verified

```json
{
  "case_id": "CASE-1001",
  "member_id": "M-2044",
  "benefit_status": "not_verified",
  "prior_auth_status": "not_required",
  "documentation_status": "complete",
  "urgency": "standard",
  "source": "payer_response"
}
```

Expected:

```json
{
  "status": "BENEFIT_NOT_VERIFIED",
  "reason_code": "BENEFIT_NOT_VERIFIED",
  "next_action": "Route to benefit verification queue",
  "audit_evidence": {
    "benefit_status": "not_verified",
    "source": "payer_response"
  },
  "clinical_decision": false
}
```

### Input: prior authorization pending

```json
{
  "case_id": "CASE-1002",
  "member_id": "M-1188",
  "benefit_status": "verified",
  "prior_auth_status": "pending",
  "documentation_status": "complete",
  "urgency": "standard",
  "source": "pa_portal"
}
```

Expected:

```json
{
  "status": "PA_PENDING",
  "reason_code": "PRIOR_AUTH_PENDING",
  "next_action": "Route to prior authorization follow-up queue",
  "audit_evidence": {
    "prior_auth_status": "pending",
    "source": "pa_portal"
  },
  "clinical_decision": false
}
```

### Input: documentation incomplete

```json
{
  "case_id": "CASE-1003",
  "member_id": "M-6671",
  "benefit_status": "verified",
  "prior_auth_status": "not_required",
  "documentation_status": "incomplete",
  "urgency": "standard",
  "source": "clinical_packet"
}
```

Expected:

```json
{
  "status": "DOCS_INCOMPLETE",
  "reason_code": "DOCUMENTATION_INCOMPLETE",
  "next_action": "Request missing documentation before scheduling",
  "audit_evidence": {
    "documentation_status": "incomplete",
    "source": "clinical_packet"
  },
  "clinical_decision": false
}
```

### Input: ready to schedule

```json
{
  "case_id": "CASE-1004",
  "member_id": "M-9012",
  "benefit_status": "verified",
  "prior_auth_status": "not_required",
  "documentation_status": "complete",
  "urgency": "standard",
  "source": "workflow_intake"
}
```

Expected:

```json
{
  "status": "READY_TO_SCHEDULE",
  "reason_code": "ADMIN_REQUIREMENTS_MET",
  "next_action": "Route to scheduling queue",
  "audit_evidence": {
    "benefit_status": "verified",
    "prior_auth_status": "not_required",
    "documentation_status": "complete"
  },
  "clinical_decision": false
}
```

## 10. Optional hook demonstration

Hooks are useful, but they should not become the main event. I would show the idea and keep a manual fallback.

Introduce hooks as an advanced control, not a magic feature:

“If we trust ourselves to remember every check, we will eventually forget one. Hooks are a way to make some checks automatic. In this session, the hook is simple: after code changes, run tests.”

Example `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "python -m pytest -q tests"
          }
        ]
      }
    ]
  }
}
```

Trainer line:

“If a check matters every time, automate it. If the hook fails on a learner machine, run the same command manually. The learning objective is the guardrail, not hook debugging.”

## 11. Common trainer interventions

The trainer should expect Claude Code to occasionally be too helpful. That is not a failure. It is the classroom moment where learners see why the FDE stays in control.

### Claude adds `APPROVED`

Ask:

```text
Approved by whom? Where is that allowed in the spec?
```

Expected correction:

- remove `APPROVED`
- use `READY_TO_SCHEDULE`
- add or keep safety test blocking clinical approval language

### Claude proposes FastAPI

Ask:

```text
Which Session 3 acceptance criterion requires an API?
```

Expected correction:

- keep pure Python package
- leave API for Session 4

### Claude invents payer policy

Ask:

```text
Where is that policy sourced?
```

Expected correction:

- remove invented policy
- route unknown case to `NEEDS_REVIEW`
- add assumption to review notes

### Claude edits too many files

Ask:

```text
Show me the approved file scope again.
```

Expected correction:

- revert unnecessary edits
- touch only `rules.py`, `service.py`, and relevant tests

## 12. Trainer rehearsal checklist

Before class, trainer should confirm:

- VS Code opens the starter repo cleanly
- Claude Code is available and authenticated
- Python virtual environment can be created
- dependencies install without errors
- `python -m pytest -q tests` runs
- failing tests fail for the expected reason
- completed reference repo passes tests
- sample input/output files match the expected statuses
- optional hooks are tested once, but trainer has manual fallback

If any of these fail, fix before class. Session 3 has enough live judgment already; environment issues should not become the lesson.

## 13. Learner assignment

Learners add one rule after class.

Rule:

```text
If urgency is urgent and documentation is complete, route to NEEDS_REVIEW with reason code URGENT_REVIEW.
```

They must update:

- decision table or spec
- test file
- rule implementation
- review note

Submission:

- screenshot or copied output from `python -m pytest -q tests`
- sample input JSON
- actual output JSON
- short note: “What Claude Code did, what I checked, and what I changed in the harness.”

Evaluation:

- rule is sourced in spec or decision table
- tests prove the rule
- unknown cases still route to `NEEDS_REVIEW`
- no clinical decision language appears
- learner can explain the agent workflow used

## 14. Handoff to Session 4

Session 3 ends with a controlled starting point:

- project memory
- project rules
- decision table
- acceptance criteria
- tests
- first rule slice
- prompt pack
- known open assumptions

Session 4 picks this up and turns it into the full P1 rule-based service. That is where API, persistence, review queue, more rules, and local packaging belong.

Trainer should make the handoff explicit:

“Next session, we are not starting over. We are taking this harness and putting a real service around it.”
