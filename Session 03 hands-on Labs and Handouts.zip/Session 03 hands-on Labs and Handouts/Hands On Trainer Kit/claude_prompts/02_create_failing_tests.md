Use templates/decision_table.csv and specs/001_rule_engine_slice.md.

Write pytest tests first.

Cover:
- READY_TO_SCHEDULE
- BENEFIT_NOT_VERIFIED
- PA_PENDING
- DOCS_INCOMPLETE
- unknown or incomplete cases route to NEEDS_REVIEW
- no output may imply clinical approval

Do not implement the rules yet.
Run python -m pytest -q tests and show the failing tests.

