Read CLAUDE.md, .claude/rules, specs/001_rule_engine_slice.md, templates/decision_table.csv, and tests/.

Do not edit files.

Return:
1. what behavior is already specified
2. which files are likely to change
3. what tests are missing
4. any assumptions that need domain review
5. the command that will prove the slice

