Claude introduced behavior that is not allowed by the spec.

Do not only patch the immediate code.

First identify what failed in the harness:
- missing instruction in CLAUDE.md
- missing .claude/rules entry
- missing test
- missing acceptance criterion
- unclear source authority

Then propose:
1. the code correction
2. the harness correction
3. the test that prevents the same issue from returning

Wait for approval before editing.

