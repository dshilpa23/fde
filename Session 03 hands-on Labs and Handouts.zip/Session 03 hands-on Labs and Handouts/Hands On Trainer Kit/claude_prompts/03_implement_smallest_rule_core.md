Implement the smallest rule core needed to pass the tests.

Scope:
- src/infusion_rules/rules.py
- src/infusion_rules/service.py
- tests only if a test has a syntax issue

Do not add FastAPI.
Do not add a database.
Do not add Docker.
Do not introduce APPROVED, DENIED, or clinical decision language.

Return exactly these fields from the service:
- status
- reason_code
- next_action
- audit_evidence
- clinical_decision

Run python -m pytest -q tests and summarize the result.

