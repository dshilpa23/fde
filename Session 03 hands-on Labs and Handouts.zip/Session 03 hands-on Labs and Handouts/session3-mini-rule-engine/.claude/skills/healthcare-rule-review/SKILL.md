# Healthcare Rule Review

Use this skill when reviewing a routing-rule change in this repo.

## Review Steps

1. Read `docs/spec.md` and `docs/decision_table.md`.
2. Inspect the diff and list changed files.
3. Confirm the new behavior maps to one decision-table row.
4. Confirm the rule includes a stable reason code.
5. Confirm evidence fields identify the inputs used.
6. Confirm the rule does not automate clinical approval, coverage approval, or denial.
7. Run `python -m pytest tests/test_routing.py`.

## Output Format

Return:

- `Ready for Session 4` or `Fix before build`
- files changed
- tests added or changed
- behavior changed
- healthcare boundary preserved
- command output used as evidence
- risks or open questions
