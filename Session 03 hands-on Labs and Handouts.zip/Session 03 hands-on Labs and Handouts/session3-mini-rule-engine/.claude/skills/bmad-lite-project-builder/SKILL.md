---
name: bmad-lite-project-builder
description: Use this skill to guide an AI coding agent through a BMAD-inspired project workflow without installing BMAD: analyze the problem, write a small spec, choose the solution approach, implement in the smallest safe slice, run tests, and perform adversarial review. Best for classroom projects, rule engines, workflow automation, and coding-agent exercises where learners must build from structured context instead of vague prompts.
---

# BMAD Lite Project Builder

Use this skill when the user wants to build or change a project from a vague idea, workflow note, issue, decision table, or mini spec.

This is a lightweight classroom adaptation of BMAD-style phased delivery. It does not require BMAD installation. It follows the same discipline: build structured context before implementation.

## Core Rule

Do not implement until the current phase has enough evidence to move forward.

If the request is already small and clear, keep the workflow lightweight. Still preserve the phase order.

## Phase 1: Analysis

Goal: understand the problem before planning.

Produce:

- problem statement
- user or workflow owner
- triggering event
- trusted inputs
- uncertain inputs
- decision boundary
- harm if wrong
- assumptions and open questions

Stop and ask for clarification when:

- the workflow owner is unclear
- the requested decision could harm a person, customer, patient, or regulated process
- the agent would need to infer policy from vague text
- a human-review boundary is ambiguous

## Phase 2: Planning

Goal: lock the what before the how.

Produce a short spec contract:

- why this change matters
- capabilities to add or change
- constraints
- non-goals
- success signal
- acceptance criteria
- failure cases

For rule engines, include:

- event
- required inputs
- output shape
- reason codes
- evidence fields
- escalation boundary

## Phase 3: Solutioning

Goal: decide how to build before editing files.

Produce:

- files likely to change
- tests to add or update
- smallest useful implementation slice
- commands to run
- risks
- rollback or re-scope signal

Prefer deterministic code for business rules. Do not add LLM calls, network calls, or external dependencies unless the spec explicitly requires them and the user approves.

## Phase 4: Implementation

Goal: build one verified slice.

Follow this loop:

1. Add or update the focused tests first.
2. Run the focused tests and confirm the failure is for the expected reason.
3. Implement only the smallest rule or behavior needed.
4. Run focused tests.
5. Inspect the diff.
6. Run broader tests only if the change touches shared behavior.

Keep changes scoped. If the diff touches files outside the plan, pause and explain why before continuing.

## Phase 5: Adversarial Review

Goal: find what is missing before accepting the change.

Review as if at least one issue exists. Look for:

- unsafe automation
- missing test
- unclear reason code
- missing evidence field
- behavior not covered by the spec
- diff outside the requested scope
- human-review boundary weakened
- command output missing or not credible

Human filtering is required. If a finding is a false positive, say why and dismiss it.

## Required Final Output

Return:

- phase summary: Analysis -> Planning -> Solutioning -> Implementation -> Review
- files changed
- tests added or changed
- behavior changed
- command output used as evidence
- healthcare or safety boundary preserved
- adversarial findings
- final decision: `Ready for handoff` or `Fix before handoff`

## Classroom Shortcut

For the Session 3 mini rule-engine repo, read these files before implementation:

- `CLAUDE.md`
- `.claude/rules/rule_engine.md`
- `docs/spec.md`
- `docs/decision_table.md`
- `docs/pivot_rubric.md`

Use this focused test command:

```bash
python -m pytest tests/test_routing.py
```
