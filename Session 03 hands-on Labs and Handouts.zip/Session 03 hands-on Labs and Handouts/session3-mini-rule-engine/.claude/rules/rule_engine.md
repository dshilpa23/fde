# Rule Engine Path Rules

Applies to `src/rule_engine/**` and `tests/**`.

- Keep routing deterministic. Do not call external APIs or LLMs from the rule engine.
- Every route result must include `route`, `reason_code`, and `evidence`.
- Evidence should use input field names, not vague prose.
- Add an expected-route test and a forbidden-route test for each new rule.
- If a requirement affects clinical or coverage decisions, stop and escalate.
