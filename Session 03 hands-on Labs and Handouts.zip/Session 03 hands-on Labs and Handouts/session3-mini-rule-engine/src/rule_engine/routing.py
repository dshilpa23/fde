from dataclasses import dataclass


@dataclass(frozen=True)
class Referral:
    payer: str | None
    required_documents: tuple[str, ...]
    attached_documents: tuple[str, ...]
    coverage_decision_requested: bool = False


@dataclass(frozen=True)
class RouteResult:
    route: str
    reason_code: str
    evidence: tuple[str, ...]


def route_referral(referral: Referral) -> RouteResult:
    """Route a referral without making clinical or coverage decisions."""
    if referral.coverage_decision_requested:
        return RouteResult(
            route="human_review",
            reason_code="HUMAN_REVIEW_REQUIRED",
            evidence=("coverage_decision_requested",),
        )

    if referral.payer is None or referral.payer.strip().lower() == "unknown":
        return RouteResult(
            route="request_payer_details",
            reason_code="PAYER_UNKNOWN",
            evidence=("payer",),
        )

    missing_documents = set(referral.required_documents) - set(referral.attached_documents)
    if missing_documents:
        return RouteResult(
            route="missing_info_queue",
            reason_code="MISSING_REQUIRED_DOCUMENT",
            evidence=("required_documents", "attached_documents"),
        )

    return RouteResult(
        route="benefit_check",
        reason_code="READY_FOR_BENEFIT_CHECK",
        evidence=("payer", "required_documents", "attached_documents"),
    )
