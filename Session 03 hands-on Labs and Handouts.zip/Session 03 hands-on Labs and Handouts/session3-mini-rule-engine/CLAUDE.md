# Project Memory

You are helping build a deterministic healthcare referral routing rule engine.

## Non-Negotiables

- Do not automate clinical approval, coverage approval, or coverage denial.
- Clinical or coverage decisions must return `HUMAN_REVIEW_REQUIRED`.
- Every route must include a stable reason code.
- Every route must include evidence fields that explain which inputs were used.
- Write or update tests before implementation when behavior changes.
- Prefer the smallest useful diff and run focused tests before claiming completion.

## Useful Commands

```bash
python -m pytest tests/test_routing.py
python -m pytest
```

## Review Standard

Before completion, report:

- files changed
- tests added or changed
- behavior changed
- healthcare boundary preserved
- command output used as evidence
- risks or open questions
