# Session 3 Mini Project: Spec-Driven Rule Engine

This mini repo supports slides 24-33 of Session 3. It shows how a healthcare FDE can use agent controls, project memory, rules, hooks, specs, tests, and review gates before accepting agent-written code.

The goal is intentionally small: route an infusion referral based on structured facts. The agent may help build the rule engine, but it must preserve the healthcare boundary: clinical or coverage decisions escalate to a human owner.

## What This Repo Demonstrates

- `CLAUDE.md`: short project memory for the agent.
- `.claude/rules/`: path-specific guidance close to the code.
- `.claude/settings.json`: a hook example that runs focused tests at stop time.
- `.claude/skills/healthcare-rule-review/SKILL.md`: reusable review workflow.
- `docs/spec.md`: boring, testable spec.
- `docs/decision_table.md`: the rules learners convert into tests.
- `docs/pivot_rubric.md`: pause, clarify, or escalate signals.
- `src/rule_engine/routing.py`: tiny deterministic rule engine.
- `tests/`: focused tests that prove behavior and boundaries.
- `missions/`: hands-on instructions for slides 24-33.

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[test]"
pytest
```

If dependencies are already available, you can usually run:

```bash
python -m pytest
```

## Live Demo Path

1. Open `CLAUDE.md` and `.claude/rules/rule_engine.md`.
2. Show `.claude/settings.json` as the hook example from slide 25.
3. Open `docs/decision_table.md` and `docs/spec.md`.
4. Run `pytest` to show the current verified baseline.
5. Use `missions/01_missing_info_rule.md` for the learner hands-on.
6. Use `.claude/skills/healthcare-rule-review/SKILL.md` for the review step.

## Healthcare Boundary

This repo does not automate clinical approval, coverage approval, or denial. It only routes work, returns reason codes, and records evidence fields so a human owner can review the decision path.
