# Pivot Rubric

| Signal | Decision | Action |
|---|---|---|
| A focused test keeps failing for the same reason after two attempts | Pause | Stop the agent and re-read the failure before re-prompting. |
| The diff touches files outside the spec's scope | Pause | Reject the diff, ask why, then re-scope. |
| A requirement can be read two different ways | Clarify | Ask the agent to list the questions that decide scope. |
| The change would affect a human-review or safety boundary | Escalate | Stop and bring in the accountable reviewer. |
| The agent proposes auto-approving or denying coverage | Escalate | Stop implementation and preserve human review. |
