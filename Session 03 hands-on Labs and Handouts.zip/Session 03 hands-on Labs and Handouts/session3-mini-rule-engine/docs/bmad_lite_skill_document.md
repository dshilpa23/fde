# BMAD Lite Skill Document

This document converts the BMAD Method ideas into a lightweight classroom skill learners can use without installing BMAD.

It is inspired by the public BMAD documentation, especially:

- BMAD's description as an AI-driven development framework for ideation, planning, and agentic implementation.
- The workflow map's four phases: Analysis, Planning, Solutioning, and Implementation.
- The idea that structured documents become progressive context for later agent work.
- The Analysis guidance that vague thinking creates vague downstream requirements.
- The Solutioning guidance that technical decisions should be explicit before implementation.
- The Adversarial Review pattern: review must actively look for missing or unsafe issues, while humans filter false positives.

Sources:

- https://docs.bmad-method.org/
- https://docs.bmad-method.org/reference/workflow-map/
- https://docs.bmad-method.org/explanation/analysis-phase/
- https://docs.bmad-method.org/explanation/why-solutioning-matters/
- https://docs.bmad-method.org/explanation/adversarial-review/

## Skill Name

`bmad-lite-project-builder`

## Use Case

Use this skill when learners want an AI coding agent to help build a small project safely from a vague idea, workflow note, issue, or mini spec.

It is especially useful for the Session 3 mini rule-engine repo because it turns the workshop path into an agent workflow:

Decode -> Spec -> Solution -> Build -> Review

## What Learners Should Ask

Example prompt:

```text
Use the bmad-lite-project-builder skill to build the missing-info routing rule from docs/decision_table.md.
Start with analysis and do not implement until the spec and tests are clear.
```

Another example:

```text
Use bmad-lite-project-builder on this project. I want to add a new routing rule for referrals where the payer is missing.
Produce analysis, spec, implementation plan, tests, smallest diff, and review note.
```

## Required Learner Artifacts

The skill should make the agent produce:

1. Analysis summary
2. Spec contract
3. Solution plan
4. Implementation checklist
5. Tests and command output
6. Adversarial review note

## Phase Mapping

| BMAD Lite Phase | Session 3 Language | Purpose |
|---|---|---|
| Analysis | Decode | Understand problem, users, inputs, risk, and boundaries |
| Planning | Spec | Lock the what before the how |
| Solutioning | Steer | Decide technical approach, files, tasks, checks |
| Implementation | Verify | Build small, run tests, review evidence |

## Classroom Teaching Note

Do not present this as "we installed BMAD." Say:

> "This is a BMAD-inspired lightweight skill. It uses the same discipline of progressive context and phased delivery, but it is packaged locally for this classroom project."

## Recommended Slide Placement

Use this around slides 24-33:

- Before slide 24: introduce the skill as the roadmap.
- Slide 24: show skills advise and hooks enforce.
- Slide 28: show the spec contract created by the skill.
- Slide 32: learners invoke the skill for the live mission.
- Slide 33: use the skill's adversarial review output as the demo standard.

## Copy Into A Skill

The actual skill file has already been created at:

`.claude/skills/bmad-lite-project-builder/SKILL.md`
