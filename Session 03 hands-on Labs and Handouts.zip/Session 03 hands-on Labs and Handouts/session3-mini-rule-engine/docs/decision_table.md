# Decision Table

| Condition | Expected route | Reason code | Evidence fields |
|---|---|---|---|
| Coverage decision is requested | `human_review` | `HUMAN_REVIEW_REQUIRED` | `coverage_decision_requested` |
| Payer is unknown or missing | `request_payer_details` | `PAYER_UNKNOWN` | `payer` |
| Required documents are missing | `missing_info_queue` | `MISSING_REQUIRED_DOCUMENT` | `required_documents`, `attached_documents` |
| Payer is known and required documents are attached | `benefit_check` | `READY_FOR_BENEFIT_CHECK` | `payer`, `required_documents`, `attached_documents` |

Rules are evaluated from top to bottom. Human-review boundary checks always win.
