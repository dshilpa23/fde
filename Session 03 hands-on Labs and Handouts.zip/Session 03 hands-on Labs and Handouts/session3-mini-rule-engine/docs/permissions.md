# Permission Guidance

Use this when discussing slide 26.

## Allow

- Local reads inside the project.
- Focused test commands.
- Lint commands.
- Edits inside this mini repo.

## Ask

- Writes outside the project.
- Network calls.
- Installing packages.
- Broad refactors.

## Deny

- Real patient data.
- Secrets or credentials.
- Production systems.
- Automated clinical or coverage decisions.
