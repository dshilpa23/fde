# Spec: Infusion Referral Routing

## Event

A new infusion referral enters the work queue.

## Inputs

| Field | Type | Valid values |
|---|---|---|
| `payer` | string or null | payer name, `"unknown"`, or null |
| `required_documents` | list of strings | documents expected for the referral |
| `attached_documents` | list of strings | documents attached to the referral |
| `coverage_decision_requested` | boolean | true or false |

## Output Shape

```json
{
  "route": "string",
  "reason_code": "string",
  "evidence": ["field_name"]
}
```

## Escalation Boundary

The system may route, hold, or request missing information. It must not approve or deny clinical or coverage decisions.

If `coverage_decision_requested` is true, the route must be `human_review`.

## Failure Case

If payer is unknown or missing, the system must hold the referral and request payer details.
