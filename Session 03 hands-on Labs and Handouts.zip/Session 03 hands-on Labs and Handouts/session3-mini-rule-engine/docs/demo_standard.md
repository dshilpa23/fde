# Demo Standard

| What learners show | Why it matters | Pass signal |
|---|---|---|
| Decision table | The workflow is understood | Rules and boundaries are clear |
| Failing test | The requirement is observable | Failure matches the missing rule |
| Small diff | The change is reviewable | Only intended files changed |
| Passing check | Behavior is verified | Command output is visible |
| Human boundary | Healthcare-sensitive decisions stay accountable | Clinical and coverage decisions still escalate |
