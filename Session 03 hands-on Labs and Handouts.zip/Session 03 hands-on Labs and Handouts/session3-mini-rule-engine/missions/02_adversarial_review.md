# Mission 2: Adversarial Review

Use this mission after the live build.

## Pair Swap

Swap screens with another pair and try to find one issue:

- unsafe automation
- missing test
- unclear reason code
- missing evidence field
- diff outside the requested scope

## Review Note

Return:

```text
Decision: Ready for Session 4 / Fix before build
Finding:
Evidence:
Required fix:
```

Vague feedback does not count. The note must point to a file, test, command output, or decision-table row.
