# Mission 1: Failing Test, Small Rule, Review Diff

Use this mission during slides 32-33.

## Step 1: Create The Failing Test

Ask the agent:

```text
Using docs/decision_table.md, add tests for the missing-info routing rule.

Rules:
- write tests before implementation
- include expected route and forbidden route
- include reason code checks
- run only tests/test_routing.py
- stop after tests fail for the right reason
```

For a classroom demo, temporarily comment out the missing-document block in `src/rule_engine/routing.py`, then run the test to show the failure.

## Step 2: Implement The Smallest Rule

Ask the agent:

```text
Implement only the missing-info routing rule needed to pass the new tests.
Do not change unrelated rules.
Keep the output contract the same.
Run the focused tests and show the result.
```

## Step 3: Review The Diff Against The Spec

Ask the agent:

```text
Review your diff against docs/spec.md and docs/decision_table.md.
Return:
1. files changed
2. tests added
3. behavior changed
4. healthcare boundary preserved
5. command output used as evidence
6. risks or open questions
```

## Learner Output

Each pair should show:

- one failing test that failed for the right reason
- one small implementation diff
- one passing focused test output
- one review note: `Ready for Session 4` or `Fix before build`
