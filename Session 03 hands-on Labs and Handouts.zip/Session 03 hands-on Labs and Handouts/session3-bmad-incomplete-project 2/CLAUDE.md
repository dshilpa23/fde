# Project Memory

You are helping build a deterministic healthcare referral routing helper.

## Rules

- Do not automate clinical approval, coverage approval, or coverage denial.
- Every final route should include `route`, `reason_code`, and `evidence`.
- Prefer small changes with focused tests.
- Use `docs/intake_request.md`, `docs/spec_draft.md`, and `docs/decision_table_draft.md` before implementation.

## Focused Command

```bash
python -m pytest tests/test_routing.py
```

## Completion Standard

Before claiming completion, return:

- files changed
- tests added or changed
- behavior changed
- command output
- healthcare boundary preserved
- risks or open questions
