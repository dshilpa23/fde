# Incomplete Project: Referral Routing Workbench

This project is intentionally incomplete. Use it to practice a BMAD Lite workflow:

Analysis -> Planning -> Solutioning -> Implementation -> Adversarial Review

The goal is not to jump straight into code. The goal is to inspect the project, identify what is missing, turn the vague request into a testable spec, add tests, implement the smallest safe rule, and review the result.

## Vague Stakeholder Ask

> Referrals are getting stuck because intake teams do not always know where to send them. Build a small routing helper that moves referrals faster and keeps sensitive decisions safe.

## Known Gaps

- The spec is incomplete.
- The decision table has missing reason codes.
- One healthcare boundary is not protected yet.
- Tests do not cover missing documents.
- The implementation currently routes too many cases to benefit check.

## Learner Mission

Use the local skill:

```text
Use the bmad-lite-project-builder skill on this repo.

Analyze the vague stakeholder ask and the current files.
Do not implement yet.
Return the missing information, spec contract, solution plan, tests to add, and review risks.
```

Then continue:

```text
Now implement the smallest safe missing-info routing rule.
Write or update tests first.
Preserve the healthcare boundary.
Run python -m pytest tests/test_routing.py and show the output.
```

## Baseline Command

```bash
python3 -m pytest tests/test_routing.py
```

The starting project is expected to be incomplete. Learners should use failures and missing tests as evidence.
