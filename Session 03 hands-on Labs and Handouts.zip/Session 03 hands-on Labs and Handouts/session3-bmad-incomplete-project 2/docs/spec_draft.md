# Spec Draft

## Event

A new infusion referral arrives.

## Inputs

| Field | Type | Notes |
|---|---|---|
| `payer` | string or null | May be unknown |
| `required_documents` | list | Expected documents |
| `attached_documents` | list | Documents actually attached |
| `coverage_decision_requested` | boolean | Safety-sensitive |

## Output Shape

```json
{
  "route": "string",
  "reason_code": "string",
  "evidence": ["field_name"]
}
```

## Missing Pieces For Learners

- Define exact behavior when required documents are missing.
- Define reason code for missing documents.
- Confirm coverage decisions always escalate to human review.
- Add tests that prove the forbidden route is not used.
