# Decision Table Draft

This table is intentionally incomplete.

| Condition | Expected route | Reason code | Evidence fields | Status |
|---|---|---|---|---|
| Payer is known and all required documents are attached | `benefit_check` | `READY_FOR_BENEFIT_CHECK` | `payer`, `required_documents`, `attached_documents` | Implemented |
| Payer is unknown or missing | `request_payer_details` | `PAYER_UNKNOWN` | `payer` | Implemented |
| Required documents are missing | `missing_info_queue` | TBD | TBD | Missing |
| Coverage decision is requested | `human_review` | `HUMAN_REVIEW_REQUIRED` | `coverage_decision_requested` | Needs verification |

Learners should complete the missing row before implementation.
