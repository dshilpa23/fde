# Review Checklist

Use this after implementation.

- Does the behavior map to one decision-table row?
- Is there an expected-route test?
- Is there a forbidden-route test?
- Is the reason code stable?
- Are evidence fields present?
- Does a coverage decision still route to human review?
- Did the diff stay focused?
- Is focused command output visible?
