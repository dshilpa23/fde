# Intake Request

The referral intake team wants a lightweight routing helper.

Current complaint:

> We spend too much time deciding where referrals should go. If a referral has enough information, send it to benefit check. If it is missing information, send it to the right queue. If the request is actually asking for a coverage decision, keep a human in charge.

Open questions:

- What counts as enough information?
- Which missing document should produce which reason code?
- What evidence should the system return?
- Which decisions must never be automated?
