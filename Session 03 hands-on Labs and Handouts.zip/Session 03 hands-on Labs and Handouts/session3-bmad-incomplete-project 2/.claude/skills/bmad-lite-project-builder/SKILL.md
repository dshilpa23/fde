---
name: bmad-lite-project-builder
description: Use this skill to guide an AI coding agent through a BMAD-inspired project workflow without installing BMAD: analyze the problem, write a small spec, choose the solution approach, implement in the smallest safe slice, run tests, and perform adversarial review. Best for classroom projects, rule engines, workflow automation, and coding-agent exercises where learners must build from structured context instead of vague prompts.
---

# BMAD Lite Project Builder

Use this skill when the user wants to build or change a project from a vague idea, workflow note, issue, decision table, or mini spec.

This is a lightweight classroom adaptation of BMAD-style phased delivery. It does not require BMAD installation. It follows the same discipline: build structured context before implementation.

## Core Rule

Do not implement until the current phase has enough evidence to move forward.

## Phase 1: Analysis

Produce:

- problem statement
- user or workflow owner
- triggering event
- trusted inputs
- uncertain inputs
- decision boundary
- harm if wrong
- assumptions and open questions

Stop and ask for clarification when the human-review boundary is ambiguous.

## Phase 2: Planning

Produce a short spec contract:

- capability to add or change
- constraints
- non-goals
- success signal
- acceptance criteria
- failure cases
- reason codes
- evidence fields

## Phase 3: Solutioning

Produce:

- files likely to change
- tests to add or update
- smallest useful implementation slice
- focused command to run
- risks
- pause, clarify, or escalate signals

## Phase 4: Implementation

Follow this loop:

1. Add or update focused tests first.
2. Run focused tests and confirm the failure is for the expected reason.
3. Implement only the smallest behavior needed.
4. Run focused tests.
5. Inspect the diff.

## Phase 5: Adversarial Review

Look for:

- unsafe automation
- missing test
- unclear reason code
- missing evidence field
- behavior not covered by the spec
- diff outside requested scope
- human-review boundary weakened

## Required Final Output

Return:

- phase summary
- files changed
- tests added or changed
- behavior changed
- command output used as evidence
- healthcare boundary preserved
- adversarial findings
- final decision: `Ready for handoff` or `Fix before handoff`
