# Rule Engine Rules

Applies to `src/rule_engine/**` and `tests/**`.

- Keep routing deterministic.
- No external APIs or LLM calls inside routing code.
- Add both expected-route and forbidden-route assertions for new routing behavior.
- Stop and escalate if the task asks the system to approve or deny coverage.
