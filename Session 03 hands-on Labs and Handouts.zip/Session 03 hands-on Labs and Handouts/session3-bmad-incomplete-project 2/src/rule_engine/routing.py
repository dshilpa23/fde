from dataclasses import dataclass


@dataclass(frozen=True)
class Referral:
    payer: str | None
    required_documents: tuple[str, ...]
    attached_documents: tuple[str, ...]
    coverage_decision_requested: bool = False


@dataclass(frozen=True)
class RouteResult:
    route: str
    reason_code: str
    evidence: tuple[str, ...]


def route_referral(referral: Referral) -> RouteResult:
    """Route a referral. This implementation is intentionally incomplete."""
    if referral.payer is None or referral.payer.strip().lower() == "unknown":
        return RouteResult(
            route="request_payer_details",
            reason_code="PAYER_UNKNOWN",
            evidence=("payer",),
        )

    # TODO: Coverage decision requests must preserve human review.
    # TODO: Missing required documents should route to missing_info_queue.

    return RouteResult(
        route="benefit_check",
        reason_code="READY_FOR_BENEFIT_CHECK",
        evidence=("payer", "required_documents", "attached_documents"),
    )
