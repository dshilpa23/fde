from rule_engine import Referral, route_referral


def test_routes_ready_referral_to_benefit_check():
    referral = Referral(
        payer="Commercial",
        required_documents=("prior_authorization", "benefits_form"),
        attached_documents=("prior_authorization", "benefits_form"),
    )

    result = route_referral(referral)

    assert result.route == "benefit_check"
    assert result.reason_code == "READY_FOR_BENEFIT_CHECK"
    assert result.evidence == ("payer", "required_documents", "attached_documents")


def test_missing_payer_requests_payer_details():
    referral = Referral(
        payer="unknown",
        required_documents=("prior_authorization",),
        attached_documents=("prior_authorization",),
    )

    result = route_referral(referral)

    assert result.route == "request_payer_details"
    assert result.reason_code == "PAYER_UNKNOWN"
    assert result.route != "benefit_check"


def test_coverage_decision_escalates_to_human_review():
    referral = Referral(
        payer="Commercial",
        required_documents=("prior_authorization",),
        attached_documents=("prior_authorization",),
        coverage_decision_requested=True,
    )

    result = route_referral(referral)

    assert result.route == "human_review"
    assert result.reason_code == "HUMAN_REVIEW_REQUIRED"
    assert result.route != "benefit_check"


def test_missing_documents_routes_to_missing_info_queue():
    referral = Referral(
        payer="Commercial",
        required_documents=("prior_authorization", "benefits_form"),
        attached_documents=("prior_authorization",),
    )

    result = route_referral(referral)

    assert result.route == "missing_info_queue"
    assert result.reason_code == "MISSING_REQUIRED_DOCUMENT"
    assert result.route != "benefit_check"
    assert "required_documents" in result.evidence
    assert "attached_documents" in result.evidence
