# Graph Report - .  (2026-07-30)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 46 nodes · 49 edges · 10 communities (5 shown, 5 thin omitted)
- Extraction: 84% EXTRACTED · 16% INFERRED · 0% AMBIGUOUS · INFERRED: 8 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- route_referral
- BMAD Lite Project Builder
- Spec Draft
- Incomplete Project: Referral Routing Workbench
- Project Memory
- rule_engine.md
- decision_table_draft.md
- intake_request.md
- review_checklist.md
- session3-bmad-incomplete-project

## God Nodes (most connected - your core abstractions)
1. `route_referral()` - 9 edges
2. `BMAD Lite Project Builder` - 8 edges
3. `Referral` - 7 edges
4. `Incomplete Project: Referral Routing Workbench` - 5 edges
5. `Spec Draft` - 5 edges
6. `Project Memory` - 4 edges
7. `RouteResult` - 3 edges
8. `test_routes_ready_referral_to_benefit_check()` - 3 edges
9. `test_missing_payer_requests_payer_details()` - 3 edges
10. `test_coverage_decision_escalates_to_human_review()` - 3 edges

## Surprising Connections (you probably didn't know these)
- `test_coverage_decision_escalates_to_human_review()` --calls--> `Referral`  [INFERRED]
  tests/test_routing.py → src/rule_engine/routing.py
- `test_missing_documents_routes_to_missing_info_queue()` --calls--> `Referral`  [INFERRED]
  tests/test_routing.py → src/rule_engine/routing.py
- `test_missing_payer_requests_payer_details()` --calls--> `Referral`  [INFERRED]
  tests/test_routing.py → src/rule_engine/routing.py
- `test_routes_ready_referral_to_benefit_check()` --calls--> `Referral`  [INFERRED]
  tests/test_routing.py → src/rule_engine/routing.py
- `test_coverage_decision_escalates_to_human_review()` --calls--> `route_referral()`  [INFERRED]
  tests/test_routing.py → src/rule_engine/routing.py

## Import Cycles
- None detected.

## Communities (10 total, 5 thin omitted)

### Community 0 - "route_referral"
Cohesion: 0.40
Nodes (8): Route a referral. This implementation is intentionally incomplete., Referral, route_referral(), RouteResult, test_coverage_decision_escalates_to_human_review(), test_missing_documents_routes_to_missing_info_queue(), test_missing_payer_requests_payer_details(), test_routes_ready_referral_to_benefit_check()

### Community 1 - "BMAD Lite Project Builder"
Cohesion: 0.22
Nodes (8): BMAD Lite Project Builder, Core Rule, Phase 1: Analysis, Phase 2: Planning, Phase 3: Solutioning, Phase 4: Implementation, Phase 5: Adversarial Review, Required Final Output

### Community 2 - "Spec Draft"
Cohesion: 0.33
Nodes (5): Event, Inputs, Missing Pieces For Learners, Output Shape, Spec Draft

### Community 3 - "Incomplete Project: Referral Routing Workbench"
Cohesion: 0.33
Nodes (5): Baseline Command, Incomplete Project: Referral Routing Workbench, Known Gaps, Learner Mission, Vague Stakeholder Ask

### Community 4 - "Project Memory"
Cohesion: 0.40
Nodes (4): Completion Standard, Focused Command, Project Memory, Rules

## Knowledge Gaps
- **23 isolated node(s):** `Rule Engine Rules`, `Core Rule`, `Phase 1: Analysis`, `Phase 2: Planning`, `Phase 3: Solutioning` (+18 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **5 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Are the 4 inferred relationships involving `route_referral()` (e.g. with `test_coverage_decision_escalates_to_human_review()` and `test_missing_documents_routes_to_missing_info_queue()`) actually correct?**
  _`route_referral()` has 4 INFERRED edges - model-reasoned connections that need verification._
- **Are the 4 inferred relationships involving `Referral` (e.g. with `test_coverage_decision_escalates_to_human_review()` and `test_missing_documents_routes_to_missing_info_queue()`) actually correct?**
  _`Referral` has 4 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Rule Engine Rules`, `Core Rule`, `Phase 1: Analysis` to the rest of the system?**
  _23 weakly-connected nodes found - possible documentation gaps or missing edges._