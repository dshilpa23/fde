"""Idempotent tiktoken cache setup for the UAIS gateway's embedding models.

`tiktoken` normally fetches its encoding file from
`openaipublic.blob.core.windows.net` on first use. That's a network call to a public
blob host most corporate networks either block outright or route through TLS
inspection that breaks the download -- and it happens silently inside
`AzureOpenAIEmbeddings`/`tiktoken.get_encoding()`, so it looks like an embeddings call
failure rather than what it actually is.

This ensures the `cl100k_base` encoding is cached locally under the hashed filename
tiktoken expects, downloading it once and skipping the download on every later call.

Usage as a library (call this before constructing any embeddings client):
    from setup_tiktoken_cache import ensure_tiktoken_cache
    ensure_tiktoken_cache()  # sets TIKTOKEN_CACHE_DIR and returns its absolute path

Usage as a script:
    python setup_tiktoken_cache.py [--dir tiktoken_cache]
"""
from __future__ import annotations

import argparse
import os
import urllib.request

CL100K_BASE_URL = "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken"
# This is not an arbitrary rename -- tiktoken's blobfile cache keys files by
# sha1(url).hexdigest(), and this is that hash for CL100K_BASE_URL. tiktoken looks up
# the cache by this exact filename, so it must match byte-for-byte.
CL100K_BASE_CACHE_FILENAME = "9b5ad71b2ce5302211f9c61530b329a4922fc6a4"


def ensure_tiktoken_cache(cache_dir: str = "tiktoken_cache") -> str:
    """Create/populate `cache_dir` with the cl100k_base encoding if not already present.

    Idempotent: if the hashed cache file already exists, no network call is made.
    Always sets TIKTOKEN_CACHE_DIR to the resolved absolute path before returning.
    """
    abs_cache_dir = os.path.abspath(cache_dir)
    target_path = os.path.join(abs_cache_dir, CL100K_BASE_CACHE_FILENAME)

    if not os.path.exists(target_path):
        os.makedirs(abs_cache_dir, exist_ok=True)
        with urllib.request.urlopen(CL100K_BASE_URL, timeout=30) as response:
            data = response.read()
        # write to a temp name first so a killed/interrupted download can't leave
        # a truncated file sitting at the exact name tiktoken trusts as complete
        tmp_path = target_path + ".part"
        with open(tmp_path, "wb") as f:
            f.write(data)
        os.replace(tmp_path, target_path)

    os.environ["TIKTOKEN_CACHE_DIR"] = abs_cache_dir
    return abs_cache_dir


def main() -> int:
    parser = argparse.ArgumentParser(description="Set up the tiktoken cl100k_base cache")
    parser.add_argument("--dir", default="tiktoken_cache", help="Cache directory (default: tiktoken_cache)")
    args = parser.parse_args()

    target_path = os.path.join(os.path.abspath(args.dir), CL100K_BASE_CACHE_FILENAME)
    already_cached = os.path.exists(target_path)

    try:
        cache_dir = ensure_tiktoken_cache(args.dir)
    except Exception as exc:
        print(f"FAILED to set up tiktoken cache: {exc.__class__.__name__}: {exc}")
        return 1

    print("SUCCESS")
    print(f"cache_dir: {cache_dir}")
    print(f"cached file: {'already present, skipped download' if already_cached else 'downloaded'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
