"""Standalone working example: call UHG's AI DOJO / UAIS Gen AI Gateway end-to-end.

Bakes in every fix from SKILL.md Sections 4-5:
  - azure_ad_token_provider (not api_key) for the Authorization: Bearer header
  - an explicit certifi CA bundle for the TLS/SSL_CERT_FILE issue
  - process_timeout=30 for cold pwsh starts
  - retry-with-backoff for the gateway's known intermittent flakiness

Two gateway tiers are supported -- pick one with --gateway (default: standard). See
SKILL.md Section 7 for the full standard/reasoning reference table; if you're on a
different UAIS enrollment, replace the project_id values in GATEWAY_CONFIGS with your own.

Usage:
    python uais_chat_example.py --prompt "What is a prime number?"
    python uais_chat_example.py --gateway reasoning --prompt "What is a prime number?"
"""
from __future__ import annotations

import argparse
import time

import certifi
import httpx
from azure.identity import AzureCliCredential, get_bearer_token_provider
from openai import AzureOpenAI

API_VERSION = "2025-01-01-preview"
TOKEN_SCOPE = "https://cognitiveservices.azure.com/.default"

GATEWAY_CONFIGS = {
    "standard": dict(
        azure_endpoint="https://api.uhg.com/api/cloud/api-management/ai-gateway/1.0",
        azure_deployment="gpt-4.1-mini_2025-04-14",
        model="gpt-4.1-mini",
        project_id="a82c5b9d-be3d-487a-858a-96b616963921",
        timeout=30.0,
    ),
    "reasoning": dict(
        azure_endpoint="https://api.uhg.com/api/cloud/api-management/ai-gateway-reasoning/1.0",
        azure_deployment="gpt-5.4-mini_2026-03-17",
        model="gpt-5.4-mini",
        project_id="cebcbf08-69a0-4c1c-b8d8-ad45f2e8c5ef",
        timeout=60.0,  # reasoning-tier calls take noticeably longer
    ),
}

_TRANSIENT_GATEWAY_ERROR = "Invalid HTTP request received"
_MAX_TRANSIENT_RETRIES = 3


def build_client(cfg: dict) -> AzureOpenAI:
    credential = AzureCliCredential()
    token_provider = get_bearer_token_provider(credential, TOKEN_SCOPE)
    return AzureOpenAI(
        api_version=API_VERSION,
        azure_endpoint=cfg["azure_endpoint"],
        azure_ad_token_provider=token_provider,
        azure_deployment=cfg["azure_deployment"],
        default_headers={
            "projectId": cfg["project_id"],
            "x-idp": "azuread",
        },
        http_client=httpx.Client(verify=certifi.where()),
        timeout=cfg["timeout"],
        max_retries=2,
    )


def call_with_retry(fn, *, max_retries: int = _MAX_TRANSIENT_RETRIES, backoff: float = 1.5):
    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            if _TRANSIENT_GATEWAY_ERROR not in str(exc) or attempt == max_retries:
                raise
            time.sleep(backoff * (attempt + 1))
    raise last_exc  # pragma: no cover -- unreachable, satisfies type checkers


def main() -> int:
    parser = argparse.ArgumentParser(description="UAIS gateway chat-completion smoke test")
    parser.add_argument("--prompt", default="Hi, what is a prime number?")
    parser.add_argument(
        "--gateway",
        choices=sorted(GATEWAY_CONFIGS),
        default="standard",
        help="Which gateway tier/deployment to call (default: standard)",
    )
    args = parser.parse_args()

    cfg = GATEWAY_CONFIGS[args.gateway]
    client = build_client(cfg)

    try:
        response = call_with_retry(
            lambda: client.chat.completions.create(
                model=cfg["model"],
                messages=[{"role": "user", "content": args.prompt}],
            )
        )
    except Exception as exc:
        print(f"FAILED: {exc.__class__.__name__}: {exc}")
        print("\nSee SKILL.md Section 6 (Troubleshooting quick-reference) for this exact error.")
        return 1

    print(response.choices[0].message.content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
