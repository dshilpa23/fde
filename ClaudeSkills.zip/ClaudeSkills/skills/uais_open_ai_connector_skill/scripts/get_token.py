"""Standalone sanity check: can this machine get a UAIS bearer token at all?

Run this BEFORE trying a full chat completion -- it isolates auth (this script)
from the gateway request-shape gotchas covered in uais_chat_example.py / SKILL.md.

Usage:
    python get_token.py
"""
from __future__ import annotations

import datetime

from azure.identity import AzureCliCredential

TOKEN_SCOPE = "https://cognitiveservices.azure.com/.default"


def main() -> int:
    # AzureCliCredential pulls the token straight from `az login`'s cached session
    # (run `az account show` to confirm you're signed into an Enabled UAIS_* subscription).
    credential = AzureCliCredential()

    try:
        token = credential.get_token(TOKEN_SCOPE)
    except Exception as exc:
        print(f"FAILED to acquire a token: {exc.__class__.__name__}")
        print(str(exc))
        print("\nSee SKILL.md Section 6 (Troubleshooting quick-reference) for this exact error.")
        return 1

    expires_at = datetime.datetime.fromtimestamp(token.expires_on, tz=datetime.timezone.utc)
    print("SUCCESS")
    print(f"token (first 24 chars): {token.token[:24]}...")
    print(f"expires_on (unix):      {token.expires_on}")
    print(f"expires_on (UTC):       {expires_at.isoformat()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
