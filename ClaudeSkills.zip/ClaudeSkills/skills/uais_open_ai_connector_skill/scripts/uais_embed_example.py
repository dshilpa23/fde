"""Standalone working example: call UHG's AI DOJO / UAIS Gen AI Gateway embeddings endpoint.

Bakes in every fix from SKILL.md Sections 4-5-8:
  - ensure_tiktoken_cache() before constructing the client, so tiktoken never needs a
    network call to openaipublic.blob.core.windows.net
  - AzureCliCredential (sourced from your `az login` session) + azure_ad_token_provider
    (not api_key) for the Authorization: Bearer header
  - an explicit certifi CA bundle for the TLS/SSL_CERT_FILE issue
  - retry-with-backoff for the gateway's known intermittent flakiness (401s included --
    see SKILL.md Section 5)

Two embedding deployments are supported -- pick one with --deployment (default:
text-embedding-ada-002_2). If you're on a different UAIS enrollment, replace the
project_id value in EMBED_CONFIGS with your own.

Usage:
    python uais_embed_example.py --text "Hello world!"
    python uais_embed_example.py --deployment text-embedding-3-small_1 --text "Hello world!"
"""
from __future__ import annotations

import argparse
import time

import certifi
import httpx
from azure.identity import AzureCliCredential, get_bearer_token_provider
from openai import AzureOpenAI

from setup_tiktoken_cache import ensure_tiktoken_cache

API_VERSION = "2025-01-01-preview"
TOKEN_SCOPE = "https://cognitiveservices.azure.com/.default"
AZURE_ENDPOINT = "https://api.uhg.com/api/cloud/api-management/ai-gateway/1.0"
PROJECT_ID = "a82c5b9d-be3d-487a-858a-96b616963921"

# Deployment name -> model name, as configured in the UAIS gateway
EMBED_CONFIGS = {
    "text-embedding-ada-002_2": "text-embedding-ada-002",
    "text-embedding-3-small_1": "text-embedding-3-small",
}

_TRANSIENT_GATEWAY_ERROR_MARKERS = ("Invalid HTTP request received", "502", "Authorization failed")
_MAX_TRANSIENT_RETRIES = 3


def build_client(deployment: str) -> AzureOpenAI:
    credential = AzureCliCredential()
    token_provider = get_bearer_token_provider(credential, TOKEN_SCOPE)
    return AzureOpenAI(
        api_version=API_VERSION,
        azure_endpoint=AZURE_ENDPOINT,
        azure_ad_token_provider=token_provider,
        azure_deployment=deployment,
        default_headers={
            "projectId": PROJECT_ID,
            "x-idp": "azuread",
        },
        http_client=httpx.Client(verify=certifi.where()),
        timeout=30.0,
        max_retries=2,
    )


def call_with_retry(fn, *, max_retries: int = _MAX_TRANSIENT_RETRIES, backoff: float = 1.5):
    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            transient = any(marker in str(exc) for marker in _TRANSIENT_GATEWAY_ERROR_MARKERS)
            if not transient or attempt == max_retries:
                raise
            time.sleep(backoff * (attempt + 1))
    raise last_exc  # pragma: no cover -- unreachable, satisfies type checkers


def main() -> int:
    parser = argparse.ArgumentParser(description="UAIS gateway embeddings smoke test")
    parser.add_argument("--text", default="Hello world!")
    parser.add_argument(
        "--deployment",
        choices=sorted(EMBED_CONFIGS),
        default="text-embedding-ada-002_2",
        help="Which embedding deployment to call (default: text-embedding-ada-002_2)",
    )
    parser.add_argument(
        "--cache-dir",
        default="tiktoken_cache",
        help="tiktoken cache directory, created if missing (default: tiktoken_cache)",
    )
    args = parser.parse_args()

    ensure_tiktoken_cache(args.cache_dir)

    model = EMBED_CONFIGS[args.deployment]
    client = build_client(args.deployment)

    try:
        response = call_with_retry(
            lambda: client.embeddings.create(model=model, input=[args.text])
        )
    except Exception as exc:
        print(f"FAILED: {exc.__class__.__name__}: {exc}")
        print("\nSee SKILL.md Section 6 (Troubleshooting quick-reference) for this exact error.")
        return 1

    vector = response.data[0].embedding
    print(f"dims={len(vector)}")
    print(vector[:8], "...")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
