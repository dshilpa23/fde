# uais_open_ai_connector_skill

Connect to UHG's AI DOJO / United AI Studio (UAIS) Gen AI Gateway from Python using
your own Azure AD sign-in — no static API key required.

See [SKILL.md](SKILL.md) for the full write-up, troubleshooting table, and background on
every gotcha below. This README is just the execution steps.

## Prerequisites

- Azure CLI (`az`) installed and you're signed into your UHG account — the scripts here use
  `AzureCliCredential`, sourced directly from your `az login` session. (PowerShell 7 + `Az.Accounts`
  works too if you swap in `DefaultAzureCredential`; see SKILL.md intro.)
- Python 3.9+

Check you're signed in:

```bash
az account show
```

If that fails, run `az login` (or `Connect-AzAccount` in `pwsh`) first — see SKILL.md §1.

## 1. Set up a virtual environment and install dependencies

macOS/Homebrew Python blocks global `pip install`, so use a venv:

```bash
python3 -m venv .venv
.venv/bin/pip install --upgrade pip azure-identity openai python-dotenv certifi httpx
```

## 2. Sanity-check token acquisition

```bash
.venv/bin/python scripts/get_token.py
```

Expect `SUCCESS` with a token preview and expiry timestamp. If this fails, check
SKILL.md §6 (Troubleshooting quick-reference) before moving on — don't debug the
gateway call until this step passes on its own.

## 3. Set your AI DOJO project ID

Open `scripts/uais_chat_example.py` and replace `YOUR_PROJECT_ID` with your own
project ID from the UAIS portal (this is specific to your enrollment — don't reuse
someone else's, it's how the gateway attributes usage).

## 4. Run the full gateway test

```bash
.venv/bin/python scripts/uais_chat_example.py --prompt "Hi, what is a prime number?"
```

On success this prints the model's response. The gateway is known to intermittently
return `400 Invalid HTTP request received` / `502 Bad Gateway` on valid requests
(SKILL.md §5) — the script already retries these with backoff, so a transient failure
followed by a retry succeeding is expected, not a bug.

## Calling embedding models

Embedding calls need one extra one-time step: a local `tiktoken` cache, so `tiktoken` never
needs a network call to `openaipublic.blob.core.windows.net` (blocked/broken on many corporate
networks). This is handled automatically:

```bash
.venv/bin/python scripts/uais_embed_example.py --text "Hello world!"
```

This creates `tiktoken_cache/` next to the script on first run (skipped on later runs) before
calling the gateway. See SKILL.md §8 for the full write-up, including the `langchain_openai`
gotcha (must pass `azure_ad_token=` explicitly, not via env vars).

## Scripts

- `scripts/get_token.py` — standalone token sanity check (step 2 alone).
- `scripts/uais_chat_example.py` — full chat-completion example (steps 3-4), accepts
  `--prompt "your question"`.
- `scripts/setup_tiktoken_cache.py` — idempotent tiktoken cache setup, importable as
  `ensure_tiktoken_cache()` or runnable standalone.
- `scripts/uais_embed_example.py` — full embeddings example, accepts `--text "your text"` and
  `--deployment`.
- `scripts/uais_embed_test.ipynb` — notebook version of the embeddings example with a
  cosine-similarity sanity check.
