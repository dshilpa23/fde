---
name: uais_open_ai_connector_skill
description: Use when someone needs to connect to UHG's AI DOJO / United AI Studio (UAIS) Gen AI Gateway with an Azure AD user token — getting a bearer token via AzureCliCredential/DefaultAzureCredential, or fixing "DefaultAzureCredential failed to retrieve a token", "Failed to invoke PowerShell", a TLS certificate error against api.uhg.com, or "access_token is missing" from the gateway. Also covers calling embedding models (AzureOpenAIEmbeddings) with an idempotent local tiktoken cache. Triggers on "UAIS token", "AI DOJO", "connect to UHG AI gateway", "get a bearer token", "AI DOJO Gen AI Certificate", "United AI Studio", "embeddings", "tiktoken cache", "AzureOpenAIEmbeddings", "cl100k_base".
---

# uais_open_ai_connector_skill

Step-by-step, no-assumptions guide to getting a working Azure AD bearer token and calling UHG's
AI DOJO / United AI Studio (UAIS) Gen AI Gateway from Python. Every step and every error message
below was hit and fixed for real against the live gateway — this isn't theoretical.

There is no static API key in this pattern. Auth is your own live Azure AD sign-in, and a
credential class mints a fresh short-lived token (~1 hour) from it on demand.

This skill's scripts use `AzureCliCredential` specifically (sourced straight from your `az login`
session) rather than `DefaultAzureCredential`'s multi-source fallback chain (env vars → managed
identity → Azure CLI → Azure PowerShell → ...) — it's more predictable about which identity gets
used, and fails with a direct "run az login" message instead of a long list of every source it
tried. If you need the fallback-chain behavior instead (e.g. on a machine without `az` but with
`pwsh`/`Az.Accounts`), swap in `DefaultAzureCredential(process_timeout=30)` — the setup in §1
below still applies either way.

## 1. One-time machine setup

You need ONE working Azure AD sign-in source on your machine.

**Recommended path:**

```powershell
# 1. Install PowerShell 7 (pwsh) -- one-time. This step needs admin/UAC elevation;
#    run it from a terminal opened "as Administrator", or via your company's software portal.
winget install --id Microsoft.PowerShell

# 2. Open a NEW pwsh window (not the old Windows PowerShell 5.1!) and install Az.Accounts
#    for pwsh's own module path. Windows PowerShell 5.1 and pwsh 7 have SEPARATE module
#    paths -- installing the module in one does NOT make it visible to the other.
pwsh
Install-Module -Name Az.Accounts -Scope CurrentUser -Repository PSGallery -Force -AllowClobber

# 3. Sign in (this pops a browser for your UHG AAD login + MFA)
Connect-AzAccount
# If prompted to pick a subscription, any UAIS_* subscription in tenant "UHG" works --
# the token you get is a user-identity token for the resource you request, it is not
# scoped to whichever subscription you happened to pick.
```

If step 2 fails with `Install-NuGetClientBinaries ... NullReferenceException`, that's
`Install-Module` trying to interactively prompt to bootstrap the NuGet provider and failing
because there's no interactive host. Fix it directly, then retry step 2:
```powershell
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force
```

**Alternative:** `az login` via Azure CLI (`winget install --id Microsoft.AzureCLI`) works too —
functionally equivalent to the `pwsh` path above; pick whichever you already have installed.

## 2. Python dependencies

```bash
pip install azure-identity openai python-dotenv certifi httpx
```

## 3. Get a token

```python
from azure.identity import AzureCliCredential

# Pulls the token straight from your `az login` session -- run `az account show` first
# to confirm you're signed into an Enabled UAIS_* subscription.
credential = AzureCliCredential()
token = credential.get_token("https://cognitiveservices.azure.com/.default")

print(token.token)       # bearer token string, valid ~1 hour
print(token.expires_on)  # unix timestamp it expires
```

Run this on its own first (see `scripts/get_token.py`) — it isolates auth from the two gateway
request-shape gotchas in the next section, so you know which layer you're debugging.

## 4. Call the gateway correctly

Two real bugs to avoid, both found and fixed this session:

1. **Pass the token as `azure_ad_token` / `azure_ad_token_provider`, NOT `api_key`.** The OpenAI
   SDK sends `api_key` via an `api-key:` header, but the gateway expects an
   `Authorization: Bearer` header. Using `api_key=` gets you `401 - access_token is missing`
   even with a perfectly valid token.
2. **Pin a proper CA bundle if your machine overrides TLS certs for corporate inspection**
   (e.g. an `SSL_CERT_FILE` pointing at a Zscaler bundle). That kind of override often *replaces*
   the public root CAs rather than adding to them, so any host it doesn't intercept — this
   gateway, for some of us — fails with `certificate verify failed: unable to get local issuer
   certificate`. Fix: pass an explicit `http_client` using `certifi`'s public CA bundle.

Full working example (also in `scripts/uais_chat_example.py`):

Two gateway tiers are confirmed working for this enrollment — pick one by setting `GATEWAY`:

```python
import httpx
import certifi
from openai import AzureOpenAI
from azure.identity import AzureCliCredential, get_bearer_token_provider

# Pick one:
GATEWAY = "standard"   # gpt-4.1-mini, faster/cheaper, general-purpose
# GATEWAY = "reasoning"  # gpt-5.4-mini, reasoning-tier, slower per call

CONFIGS = {
    "standard": dict(
        azure_endpoint="https://api.uhg.com/api/cloud/api-management/ai-gateway/1.0",
        azure_deployment="gpt-4.1-mini_2025-04-14",
        model="gpt-4.1-mini",
        project_id="a82c5b9d-be3d-487a-858a-96b616963921",
        timeout=30.0,
    ),
    "reasoning": dict(
        azure_endpoint="https://api.uhg.com/api/cloud/api-management/ai-gateway-reasoning/1.0",
        azure_deployment="gpt-5.4-mini_2026-03-17",
        model="gpt-5.4-mini",
        project_id="cebcbf08-69a0-4c1c-b8d8-ad45f2e8c5ef",
        timeout=60.0,  # reasoning-tier calls take noticeably longer
    ),
}
cfg = CONFIGS[GATEWAY]

credential = AzureCliCredential()
token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")

client = AzureOpenAI(
    api_version="2025-01-01-preview",
    azure_endpoint=cfg["azure_endpoint"],
    azure_ad_token_provider=token_provider,        # NOT api_key=
    azure_deployment=cfg["azure_deployment"],
    default_headers={
        "projectId": cfg["project_id"],  # yours may differ -- see §7
        "x-idp": "azuread",
    },
    http_client=httpx.Client(verify=certifi.where()),  # fixes the TLS issue above
    timeout=cfg["timeout"],
    max_retries=2,
)

response = client.chat.completions.create(
    model=cfg["model"],
    messages=[{"role": "user", "content": "Hi, what is a prime number?"}],
)
print(response.choices[0].message.content)
```

Both project IDs above are specific to this enrollment's UAIS setup, not universal — the
gateway/deployment/project ID must be a matched set (see §7).

`get_bearer_token_provider` (used above) auto-refreshes the token for you across a long-running
process — prefer it over a one-shot `.get_token()` call if your code will make more than one
request.

## 5. Expect the gateway itself to be flaky

This specific gateway tier (AI DOJO / training) intermittently returns `400 Invalid HTTP request
received` or `502 Bad Gateway` on perfectly valid, identical requests — observed roughly a 15-50%
single-attempt failure rate in testing, and confirmed **not** caused by a bad/corrupted token
(repeated token fetches were checked byte-identical). This is on the gateway's side, not
something a client fix can eliminate — wrap calls in a retry with backoff instead:

**`401 - Authorization failed. Verify that the access token is valid.` can ALSO be this same
transient flakiness, not just a disabled subscription (§6/§7).** Confirmed directly: an
embeddings call (`text-embedding-ada-002_2`) failed with this exact 401 five consecutive times
across three different client paths (raw `httpx`, the `openai` SDK's `AzureOpenAI` client, and
`langchain_openai`'s `AzureOpenAIEmbeddings`) — including a fresh token each time and a *working*
`az account show`/active-subscription check — while a chat-completions
call on the same token/project succeeded the whole time. Retrying the identical failing request
minutes later, with no code or config change, returned `200`. Do not assume a deployment is
dead or unprovisioned from 401s alone: retry with backoff first (below), and only escalate to
"check the UAIS portal for provisioning" if it still fails after several retries over a few
minutes.

```python
import time

def call_with_retry(fn, *, max_retries=3, backoff=1.5):
    last_exc = None
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            transient = (
                "Invalid HTTP request received" in str(exc)
                or "502" in str(exc)
                or "Authorization failed" in str(exc)  # 401 — can be transient too, see above
            )
            if not transient or attempt == max_retries:
                raise
            time.sleep(backoff * (attempt + 1))
    raise last_exc
```

If a call still fails after retries on something non-critical (e.g. composing a final summary
after a write already succeeded), fall back to a deterministic message instead of aborting —
don't let a flaky closing LLM call undo or hide a transaction that already completed
successfully.

## 6. Troubleshooting quick-reference

| Error message | Cause | Fix |
|---|---|---|
| `DefaultAzureCredential failed to retrieve a token from the included credentials` | Nothing signed in yet | Do §1 above (`Connect-AzAccount` or `az login`) |
| `AzureCliCredential.get_token failed: Please run 'az login' to setup account.` | `az` not signed in, or the CLI session expired | Run `az login`, then `az account show` to confirm |
| `AzurePowerShellCredential: Failed to invoke PowerShell` | Only relevant if using `DefaultAzureCredential`/`pwsh` instead of `AzureCliCredential`: `pwsh` not installed, `Az.Accounts` not installed *for pwsh specifically*, or a cold-start timeout | Install `pwsh` + `Az.Accounts` inside `pwsh`; use `process_timeout=30` |
| `Install-NuGetClientBinaries ... NullReferenceException` | `Install-Module` needs the NuGet provider bootstrapped first and can't prompt non-interactively | `Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force` |
| `certificate verify failed: unable to get local issuer certificate` | A corporate TLS-inspection cert bundle (e.g. `SSL_CERT_FILE`) doesn't include the public CA for this host | Pass `http_client=httpx.Client(verify=certifi.where())` |
| `401 - access_token is missing` | Token passed as `api_key=` instead of `azure_ad_token=`/`azure_ad_token_provider=` | Switch to `azure_ad_token_provider=` |
| `401 - Authorization failed. Verify that the access token is valid.` | Usually your active `az`/Azure CLI subscription is **Disabled** (check `az account show`) — but this exact message has also been observed as pure transient gateway flakiness (§5) on a perfectly valid, provisioned deployment, resolving itself on retry a few minutes later with zero code/config change | First check `az account show` and switch to an Enabled `UAIS_*` subscription if needed; if that's already fine, retry with backoff (§5) before concluding the deployment isn't provisioned |
| `400 Invalid HTTP request received` / `502 Bad Gateway` (intermittent, on an otherwise-identical request) | Known gateway-side flakiness on this tier | Retry with backoff (§5); not fixable client-side |
| `az: command not found` / `where az` fails | Azure CLI not installed — only relevant if you chose the CLI path over `pwsh` | Install it, or switch to the `pwsh` + `Az.Accounts` path instead |

## 7. Reference values (yours may differ)

Confirmed working for this enrollment — two gateway tiers, each a matched set of
endpoint/deployment/model/project ID (don't mix fields across rows):

| | Standard tier | Reasoning tier |
|---|---|---|
| **Endpoint** | `https://api.uhg.com/api/cloud/api-management/ai-gateway/1.0` | `https://api.uhg.com/api/cloud/api-management/ai-gateway-reasoning/1.0` |
| **Deployment** | `gpt-4.1-mini_2025-04-14` | `gpt-5.4-mini_2026-03-17` |
| **Model (request body)** | `gpt-4.1-mini` | `gpt-5.4-mini` |
| **Project ID** | `a82c5b9d-be3d-487a-858a-96b616963921` | `cebcbf08-69a0-4c1c-b8d8-ad45f2e8c5ef` |
| **Typical latency** | fast | noticeably slower per call — use `timeout=60.0`+ |

- **API version (both tiers):** `2025-01-01-preview`
- **Token scope (both tiers):** `https://cognitiveservices.azure.com/.default`
- **Project ID:** specific to your own AI DOJO / UAIS enrollment — find yours in the UAIS
  portal's "Code Generator" for the service you want. Don't reuse someone else's; it's how
  the gateway attributes usage. The two above are this enrollment's own IDs, one per tier.
- **Azure subscription:** `AzureCliCredential`/`az login` picks whichever subscription is
  currently active in your CLI context. If you have more than one UAIS_* subscription and get
  `401 - Authorization failed. Verify that the access token is valid.`, check
  `az account show` — a **Disabled** subscription as the active one causes this even though the
  gateway doesn't use the subscription ID directly. Switch to an **Enabled** one with
  `az account set --subscription <id>`. Confirmed working: `UAIS_AI_ML_Training_Prod`
  (`e7c4e434-1831-463a-a7f6-2866847fe4c5`).

## 8. Calling embedding models (tiktoken cache)

`AzureOpenAIEmbeddings`/`AzureOpenAI.embeddings.create(...)` both use `tiktoken` under the hood
to count/split tokens. On first use, `tiktoken` fetches its `cl100k_base` encoding file from
`openaipublic.blob.core.windows.net` — a public blob host many corporate networks block or break
via TLS inspection. That failure happens silently inside the embeddings call, so it looks like a
gateway/auth problem rather than what it actually is.

**Fix: cache the encoding locally, once, and reuse it on every later call.** Always set this up
*before* constructing an embeddings client — treat it as a hard prerequisite step, not an
optional optimization:

```python
import os
import urllib.request

CACHE_DIR = os.path.abspath("tiktoken_cache")
# tiktoken keys its cache by sha1(url).hexdigest() of the encoding's source URL --
# this exact filename is that hash for cl100k_base.tiktoken's public URL.
CACHE_FILE = os.path.join(CACHE_DIR, "9b5ad71b2ce5302211f9c61530b329a4922fc6a4")

if not os.path.exists(CACHE_FILE):          # idempotent -- skip the download if already cached
    os.makedirs(CACHE_DIR, exist_ok=True)
    url = "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken"
    urllib.request.urlretrieve(url, CACHE_FILE)

os.environ["TIKTOKEN_CACHE_DIR"] = CACHE_DIR
```

`scripts/setup_tiktoken_cache.py` wraps this exact logic as `ensure_tiktoken_cache()` — import and
call it first, or run it standalone (`python setup_tiktoken_cache.py`) to pre-populate the cache.

**Full working example** (also in `scripts/uais_embed_example.py`), using `AzureCliCredential` +
the same TLS/certifi fix from §4:

```python
import certifi
import httpx
from azure.identity import AzureCliCredential, get_bearer_token_provider
from openai import AzureOpenAI

from setup_tiktoken_cache import ensure_tiktoken_cache

ensure_tiktoken_cache()  # must run before the first embeddings call

credential = AzureCliCredential()
token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")

client = AzureOpenAI(
    api_version="2025-01-01-preview",
    azure_endpoint="https://api.uhg.com/api/cloud/api-management/ai-gateway/1.0",
    azure_ad_token_provider=token_provider,        # NOT api_key= -- same gotcha as §4
    azure_deployment="text-embedding-ada-002_2",
    default_headers={
        "projectId": "a82c5b9d-be3d-487a-858a-96b616963921",  # yours may differ -- see §7
        "x-idp": "azuread",
    },
    http_client=httpx.Client(verify=certifi.where()),
)

response = client.embeddings.create(model="text-embedding-ada-002", input=["Hello world!"])
print(len(response.data[0].embedding))  # 1536
```

**If you're using `langchain_openai.AzureOpenAIEmbeddings` instead:** it reads
`AZURE_OPENAI_API_KEY`/`api_key` into `openai_api_key`, which the SDK sends as an `api-key:`
header — not `Authorization: Bearer`. With `openai_api_type="azure_ad"` the gateway expects a
bearer token, so setting the token via env vars/`api_key=` gets you `401 - access_token is
missing` even with a perfectly valid token. Pass it explicitly instead:

```python
from langchain_openai.embeddings import AzureOpenAIEmbeddings

api_key = credential.get_token("https://cognitiveservices.azure.com/.default").token
openai_client = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-ada-002_2",
    model="text-embedding-ada-002",
    api_version="2025-01-01-preview",
    azure_endpoint="https://api.uhg.com/api/cloud/api-management/ai-gateway/1.0",
    openai_api_type="azure_ad",
    azure_ad_token=api_key,        # explicit -- NOT via AZURE_OPENAI_API_KEY/api_key env vars
    validate_base_url=False,
    default_headers={"projectId": "a82c5b9d-be3d-487a-858a-96b616963921", "x-idp": "azuread"},
)
embeddings = openai_client.embed_query("Hello world!")
```

Confirmed embedding deployments for this enrollment (same `projectId` as the standard chat tier
in §7):

| Deployment | Model (request body) | Dims |
|---|---|---|
| `text-embedding-ada-002_2` | `text-embedding-ada-002` | 1536 |
| `text-embedding-3-small_1` | `text-embedding-3-small` | 1536 |

## Scripts in this skill

- `scripts/get_token.py` — standalone token sanity-check (§3 alone).
- `scripts/uais_chat_example.py` — standalone full chat-completion example (§4 + §5), runnable
  with `python uais_chat_example.py --prompt "your question"` after filling in your own project
  ID.
- `scripts/setup_tiktoken_cache.py` — idempotent tiktoken cache setup (§8), importable as
  `ensure_tiktoken_cache()` or runnable standalone.
- `scripts/uais_embed_example.py` — standalone full embeddings example (§8), runnable with
  `python uais_embed_example.py --text "your text"` after filling in your own project ID.
- `scripts/uais_embed_test.ipynb` — notebook version of the embeddings example with a
  cosine-similarity sanity check across two deployments.
