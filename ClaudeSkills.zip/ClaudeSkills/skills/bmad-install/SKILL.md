---
name: bmad-install
description: >
  Installs the BMAD method (bmad-method) at the project level when no BMAD
  skill/config already exists there. Trigger on "bmad install", "install bmad",
  "/bmad install", or when a "/bmad" command is invoked in a project that has
  no local BMAD setup yet. Checks for an existing project-level BMAD skill
  (.claude/skills/bmad* or a .bmad-core/ directory) before installing, to
  avoid clobbering an existing setup, then runs npm install against UHG's
  internal Artifactory registry.
---

# bmad-install

Installs `bmad-method` for the current project, but only if BMAD isn't
already set up at the project level.

## Step 1 — Check for an existing project-level BMAD setup

Before installing anything, check the current project (not global `~/.claude/skills/`) for:

1. A project-level skill directory matching `bmad*` under `.claude/skills/`
2. A `.bmad-core/` directory in the project root
3. `bmad-method` already listed in the project's `package.json` dependencies

```bash
ls .claude/skills/ 2>/dev/null | grep -i bmad
ls -d .bmad-core 2>/dev/null
grep -l bmad-method package.json 2>/dev/null
```

If any of these exist, **do not reinstall** — tell the user BMAD is already
set up at the project level and ask if they want to reinstall/upgrade anyway.

## Step 2 — Install

If nothing was found, run the install using UHG's internal registry:

```bash
npm install bmad-method@6.10.0 
```

Run this from the project root (the directory with `package.json`, or the
current working directory if there is no `package.json` yet — `npm install`
will create one on demand if the user confirms that's intended).

## Step 3 — Confirm

After install, verify it landed:

```bash
npm ls bmad-method
```

Report success/failure to the user. Do not proceed to run any BMAD-generated
commands (e.g. `/bmad analyze ...`) until the install is confirmed working —
surface install errors (registry auth, network, version not found) rather
than silently falling back to a different registry or version.
