# Example: Classic RAG — Internal Product FAQ Assistant

Illustrates the **simplest justified architecture** — most of the workflow's
value here is in what it *rejects*, not what it adds.

## Scenario
A SaaS company wants employees to query an internal product FAQ (400 short
articles, single language, single tenant, no access restrictions, updated
weekly by the docs team).

## Stage 1: Discover (abridged)

**Business Analyst verdict:** RAG is needed — corpus (400 articles, ~2000
words avg) is too large for a static system prompt and changes weekly.
System classification: **answers questions only**, no actions.

**Corpus Analyst findings:**
- 400 markdown articles, already well-structured with H1/H2 headers
- No duplicates, no conflicting content, no sensitive data, no access restrictions
- No suspicious content flags
- Recommended chunking tier: **3 (Document-Based)** — headers are clean and consistent

## Stage 2: Decide

**RAG Strategist:** Candidates considered: Classic RAG, Hybrid RAG, Agentic RAG.

| Architecture | Fit | Verdict |
|---|---|---|
| Classic RAG | High — single-source, well-structured, mostly single-passage-answerable | **Selected** |
| Hybrid RAG | Corpus has few exact-match-critical terms (no product codes/IDs) | Rejected — added complexity, minimal recall gain in testing |
| Agentic RAG | Justification test: 0/4 conditions hold | Rejected |

**Retrieval Contract:**
- Chunking: Tier 3, 512 tokens, 10% overlap, context path breadcrumbs
- Embedding: `text-embedding-3-small` (cost-effective, corpus is small)
- Search: vector-only (hybrid rejected above), Top-K=5, threshold 0.75
- Reranking: **No** — corpus small enough that Precision@5 already meets target without it

**Agentic RAG Architect:** Justification test 0/4 → deterministic pipeline confirmed.

## Stage 3: Evaluate & Secure

**Evaluation targets:** Faithfulness ≥0.75, Answer Relevancy ≥0.80 (standard
thresholds — no domain-specific tightening needed, low-stakes content).

**Security:** Single-tenant, no PII, no access restrictions → threat model is
short: indirect prompt injection is still checked (any doc could theoretically
be edited maliciously by a compromised docs-team account) but permission
bypass and cross-tenant threats are not applicable.

## Stage 7: Final Status
`READY FOR PRODUCTION REVIEW` after golden dataset (100 questions) passed
all four core metrics and `test_prompt_injection.py` / `test_rag_poisoning.py`
came back clean.

## Why this example matters
The discipline here is **restraint** — three different architectures were
considered and two were explicitly rejected with evidence, rather than
defaulting to whatever's more sophisticated-sounding.
