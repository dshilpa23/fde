# Example: Corrective RAG — Multi-Source Research Assistant

## Scenario
A research team wants to query across an internal paper repository (2,000
PDFs, wildly variable quality — some are well-OCR'd, some are scanned with
poor OCR, some are pre-prints with inconsistent structure) plus fall back to
web search when internal coverage is thin.

## Stage 1: Discover (abridged)

**Business Analyst verdict:** RAG needed. Classification: answers questions
(synthesizes research), no autonomous actions.

**Corpus Analyst findings — the key finding driving the architecture:**
- OCR quality highly variable: sample review found ~15% of scanned PDFs have
  meaningfully corrupted text extraction
- This means retrieval will sometimes surface *technically matched but
  actually garbled* content — a distinct failure mode from "no relevant doc exists"
- Recommended: retrieval quality cannot be trusted uniformly across this corpus

## Stage 2: Decide

**RAG Strategist:**

| Architecture | Fit | Verdict |
|---|---|---|
| Classic/Hybrid RAG alone | Would surface garbled OCR content as if it were reliable evidence | Rejected — corpus quality variance too high to trust blindly |
| Corrective RAG | Directly addresses "is this evidence actually usable" as an explicit grading step | **Selected** |
| Graph RAG | Considered for cross-paper citation relationships, but construction quality check on a 50-paper sample showed only 62% relationship-extraction precision (below the 85% gate) | **Rejected** — see graph-rag-guide.md construction quality check |

**Retrieval Engineer + Agentic RAG Architect (combined, since CRAG has a
lightweight retry loop):**

Justification test for *any* agentic behavior: 2/4 conditions hold
(dynamic source selection — internal vs. web fallback; retrieval must repeat
based on intermediate findings — CRAG's retry). Bounded agentic behavior
justified, but narrow: only the CRAG grade→retry→fallback loop, nothing broader.

```python
# Simplified flow, per rag-pattern-catalog.md § 8 Corrective RAG
results = retrieve(query)
grades = grade_relevance_batch(query, results)  # catches garbled-OCR false positives
high_confidence = [r for r, g in zip(results, grades) if g == "relevant"]

if not high_confidence:
    route = "EXTERNAL_API_TOOL"  # fall back to web search
else:
    route = "CLASSIC_RETRIEVAL"  # proceed with internal evidence
```

Bounds: max 1 retry (rewrite + re-search internal corpus) before falling back
to web search — not unbounded retries.

## Stage 3: Evaluate & Secure

**Evaluation Scientist:** Added a specific metric not in the standard set —
"grading accuracy": does the CRAG grader correctly flag garbled-OCR chunks as
low-confidence? Test set built specifically from the 15% known-garbled sample
identified in the corpus audit.

**Security:** Web search fallback introduces a new surface — external search
results are also untrusted content, wrapped the same as internal retrieval
per `context-engineering-guide.md`. `EXTERNAL_API_TOOL` route requires the
same trust-boundary treatment as retrieved documents, not elevated trust just
because it's a "tool" rather than "retrieval."

## Stage 4: Adversarial Review finding
"Can the grading LLM itself be fooled by convincingly-formatted garbled
text?" → led to adding a secondary heuristic check (OCR confidence score from
the ingestion pipeline, stored as chunk metadata) alongside the LLM grade,
rather than relying on the LLM grader alone.

## Stage 7: Final Status
`READY FOR PRODUCTION REVIEW` — CRAG grading accuracy on the garbled-OCR test
set reached 91%, web fallback bounded and tested, Graph RAG correctly
rejected rather than force-fit.

## Why this example matters
Shows Corrective RAG selected for a *specific, evidenced* reason (variable
corpus quality) rather than generically, and shows Graph RAG being
**rejected** after a real construction-quality check rather than assumed
to be beneficial because the corpus has citations.
