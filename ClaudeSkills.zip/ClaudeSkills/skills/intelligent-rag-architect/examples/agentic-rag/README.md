# Example: Agentic RAG — IT Troubleshooting Assistant with Remediation

## Scenario
An internal IT support assistant needs to diagnose issues across: knowledge
base articles (unstructured docs), live system telemetry (structured API),
and ticket history (semi-structured) — then optionally execute a fix, but
only with human approval since remediation actions can affect production systems.

## Stage 1: Discover (abridged)

**Business Analyst verdict:** RAG needed.
**Classification: this system EXECUTES actions** (not just answers/recommends)
— triggers the highest scrutiny tier. Human approval explicitly required
before any remediation action per Business Analyst's approval-requirement identification.

## Stage 2: Decide

**Agentic RAG Architect — Justification test:**
```
[x] Dynamic source selection required — evidence: whether to check KB docs,
    live telemetry, or ticket history depends on the specific symptom described,
    not knowable in advance
[x] Retrieval must repeat based on intermediate findings — evidence: diagnosis
    is inherently iterative (check symptom → form hypothesis → check telemetry
    to confirm/deny → refine)
[x] System must select and use tools — evidence: telemetry API query,
    ticket history search, and (if approved) remediation script execution
    are all distinct tool calls
[x] Workflow cannot be fully defined in advance — evidence: the diagnostic
    path genuinely branches based on what's found at each step
```
4/4 → **Agentic RAG strongly justified** (contrast with most examples in this
catalog, where it's correctly rejected).

**Minimal dynamic decision set** (kept deliberately narrow, not "everything is agentic"):
1. Which source to check next given current symptom + evidence gathered
2. Whether enough evidence exists to propose a diagnosis, or another round is needed
3. Whether the proposed fix requires human approval (answer: always, for this system)

**Routing graph:**
```
User reports symptom
    │
    ▼
CLASSIC_RETRIEVAL (check KB for known issues matching symptom)
    │
    ▼
Enough evidence for diagnosis?
    NO → STRUCTURED_DATA_TOOL (query live telemetry) → loop back, max 3 iterations
    YES → proceed
    │
    ▼
Diagnosis formed. Remediation available?
    NO → DIRECT_RESPONSE (explain diagnosis, no fix available)
    YES → HUMAN_APPROVAL_REQUIRED (never skipped, regardless of confidence)
```

**Bounds (agentic-rag-patterns.md):**
| Control | Value | Why |
|---|---|---|
| Max steps | 6 | Diagnosis loop capped at 3 telemetry checks + retrieval + approval + response |
| Max tool calls | 5 | Telemetry API has rate limits |
| Timeout | 25s | IT staff expect near-real-time diagnosis |
| Human approval gate | Always for remediation | Non-negotiable per Business Analyst finding — no route bypasses this |

## Stage 3: Evaluate & Secure

**Level 4 (Agentic) evaluation added** — not just Levels 1-3:
- Route-selection accuracy target ≥0.90 against a labeled set of known symptom→route mappings
- Human-approval compliance: 100% (tested explicitly — see Stage 4 finding below)
- Recovery from tool failure: telemetry API down → graceful "I can't access
  live systems right now" rather than hallucinating telemetry data

**Security Architect — Excessive Agency is the primary threat here:**
Tool scoping: the remediation-execution tool is a **separate, more
restrictively-scoped credential** than the read-only telemetry/KB tools —
so even a successful prompt injection that tricks the agent into "deciding"
to remediate still can't execute without the separate approval-gated credential.

## Stage 4: Adversarial Review finding (the important one)
Reviewer's attack: *"Can tools execute without proper approval?"* — traced
the actual code path and found the original design checked for approval in
the main routing logic, but the retry-after-tool-failure path had a bug where
it could re-attempt remediation without re-checking approval state.
**This is exactly the kind of gap `test_prompt_injection.py`'s
`unauthorized_tool_invocation` payload and manual path-tracing are designed
to catch.** Fixed: approval check moved to execute directly in front of the
tool call itself, not in the routing layer, so no code path can reach it unchecked.

## Stage 6: Build & Test — failure classification example
A test failure occurred: "diagnosis was wrong for a network latency issue."
Classified as **Tool-execution failure**, not Generation failure — the
telemetry tool was called with the wrong metric name (a stale parameter
schema), so the agent reasoned correctly from wrong data. Fixed the tool
schema, not the prompt — matching the discipline in
`evaluation-framework.md § Failure Taxonomy`.

## Stage 7: Final Status
`READY FOR CONTROLLED PILOT` — full agentic bounds tested including
adversarial approval-bypass attempts, but rolled out to a pilot IT team
first given the production-system-touching nature of remediation actions.

## Why this example matters
This is the one example where Agentic RAG passes its justification test
convincingly — contrast with how skeptically it's treated everywhere else in
this catalog. It also shows the Adversarial Reviewer catching a genuine
approval-bypass bug that a purely metrics-focused review would have missed
entirely, because the bug only showed up by tracing code paths, not by
running the happy-path test suite.
