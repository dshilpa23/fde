# Example: Hybrid RAG + Metadata-Filtered — Enterprise Support Ticket Assistant

## Scenario
A B2B software company wants support agents to search 50,000 historical
support tickets and product docs, where tickets reference exact **product
SKUs, error codes (e.g. `ERR-4471`), and customer account IDs** — terms
vector search alone tends to miss or under-rank.

## Stage 1: Discover (abridged)

**Business Analyst verdict:** RAG needed. Classification: answers questions,
occasionally recommends actions ("try X fix") — no autonomous execution.

**Corpus Analyst findings:**
- Mixed sources: Zendesk tickets (semi-structured), Confluence docs (well-structured),
  PDF release notes (needs conversion)
- Heavy use of exact identifiers: SKUs, error codes, account IDs
- Some duplicate ticket content (customers re-reporting same issue)
- No sensitive PII beyond account IDs, which are access-scoped by team

## Stage 2: Decide

**RAG Strategist:**

| Architecture | Fit | Verdict |
|---|---|---|
| Classic RAG (vector-only) | Tested on a sample: error-code queries like "ERR-4471" scored Recall@5 = 0.31 — vector search doesn't preserve exact-match sensitivity for codes | Rejected |
| Hybrid RAG | Same sample with BM25 added: Recall@5 = 0.89 for the same error-code queries | **Selected** |
| Metadata-Filtered (layered on Hybrid) | Support team needs to scope by product line | **Also selected**, layered on top |

**Retrieval Engineer — Retrieval Contract:**
- Chunking: Tier 3 (Document-Based) for Confluence/release notes; Tier 1
  (Fixed-Size, 400 tokens) for ticket threads, which lack heading structure
- Embedding: `text-embedding-3-small`
- Indexing: pgvector + PGroonga (existing PostgreSQL stack, avoids new infra)
- Search: Hybrid, adaptive weighting — `specific_term` query type (detected
  via regex for error-code patterns) flips weighting to 20% semantic / 80% keyword
- Metadata filter: `product_line` field, enforced at DB query level
- Reranking: **No** initially — re-evaluate if Precision@5 on the golden set
  doesn't clear 0.70 after hybrid + metadata filtering alone

## Stage 3: Evaluate & Secure

**Golden dataset composition emphasis:** heavy weighting toward
`terminology_mismatch` and specific-term queries, since that's the corpus's
actual failure mode (per Corpus Analyst finding), not generic simple-retrieval questions.

**Security:** `permission_filter_correctness` test is critical here —
support agents scoped to one product line must never see another's tickets
(potential customer data crossover). `test_permissions.py` run with a
product-line matrix, not just a user matrix.

## Stage 4: Adversarial Review finding
Reviewer flagged: "Metadata filter enforcement — where exactly is
`product_line` checked?" Retrieval Engineer's first draft filtered
post-retrieval in application code. **Revised** to filter at the DB query
level per `references/rag-pattern-catalog.md § 15 Access-Aware Retrieval`.

## Stage 7: Final Status
`READY FOR CONTROLLED PILOT` — metrics and security tests pass, but
`tested_at_production_volume` was still pending (only tested against a
5,000-ticket sample, not the full 50,000) at time of writing.

## Why this example matters
Shows the Corpus Analyst's finding (exact-identifier-heavy content) directly
driving the architecture decision — not a default assumption that "hybrid is
usually better," but a measured Recall@5 comparison that justified it.
