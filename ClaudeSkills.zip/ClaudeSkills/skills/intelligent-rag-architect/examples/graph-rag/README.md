# Example: Graph RAG — Supply Chain Compliance Investigator

## Scenario
A manufacturing company wants to answer questions like "Which suppliers used
by subsidiaries of Vendor X had compliance violations in the last 2 years?" —
genuinely multi-hop questions across a corpus of supplier contracts,
compliance reports, and corporate ownership records.

## Stage 1: Discover (abridged)

**Business Analyst verdict:** RAG needed. Classification: answers questions
(compliance research), decisions have real regulatory weight → high accuracy bar.

**Corpus Analyst findings:**
- 3 structured sources: supplier contracts (docs), compliance incident
  reports (docs), corporate ownership records (already a relational DB)
- Relationships are the actual substance of most real queries — this isn't
  incidental entity presence, the business need IS the relationship graph

## Stage 2: Decide

**RAG Strategist — Graph RAG justification test:**
```
[x] Relationships between entities are more important than isolated passages
    — evidence: sample of 20 real analyst questions, 17/20 required tracing
    ownership/supplier relationships, not just single-document lookup
[x] Multi-hop reasoning required across connected data
    — evidence: same sample, avg 2.3 hops needed (Vendor → Subsidiary → Supplier → Incident)
[x] Graph available or reliably constructible
    — evidence: corporate ownership records already relational; contracts and
    compliance reports need entity/relationship extraction
```
3/3 → **Graph RAG justified**, not a default assumption.

**Construction quality check (per graph-rag-guide.md, mandatory before proceeding):**
Ran extraction on 20-document sample, human-validated the extracted
relationships. **Result: 88% precision** — clears the 85% gate. Proceeded to
full graph construction.

**Architecture chosen:** Option C, Hybrid Vector + Graph (Neo4j + existing
vector index), per `graph-rag-guide.md § 4`. Rejected pure RDF triple store
(Option B) — no existing ontology infrastructure to justify the added rigor.

**Retrieval Engineer:**
- Entity extraction: LLM-based, prompted per `graph-rag-guide.md § 5`
- Entity resolution: embedding-similarity clustering (supplier names have
  significant variant-naming: "Acme Corp" vs "Acme Corporation" vs "ACME")
- Traversal bound: max_hops=3 (compliance chains rarely exceed this in testing)
- Passages always returned alongside graph paths for citation — never graph
  structure alone, per `graph-rag-guide.md § 6` "always pair graph paths with
  source passages"

## Stage 3: Evaluate & Secure

**Evaluation Scientist:** Added Graph RAG-specific metrics per
`graph-rag-guide.md § 13`: multi-hop accuracy, relationship precision, path
faithfulness, AND single-hop regression check (confirmed simple lookups
didn't get worse after adding graph complexity).

**Security — this is the standout finding for this example:**
Security Architect flagged: a malicious or simply *incorrect* compliance
report could get its claims extracted as graph edges and treated as fact in
later multi-hop answers ("Company X officially has no violations" — false,
but now baked into the graph as an edge). **Control implemented:**
relationship extraction from any document is tagged with the source
document's authority level; low-authority-source relationships get flagged
for human review before being added to the graph, per
`graph-rag-guide.md § 12` and `security-framework.md § RAG Poisoning`.

## Stage 4: Adversarial Review finding
"What happens when the ownership DB and the extracted-from-documents graph
disagree?" — this wasn't addressed in the first draft. **Revised:**
structured-source relationships (from the ownership DB) are marked
higher-authority than document-extracted relationships; conflicts are
surfaced in the answer rather than silently resolved.

## Stage 7: Final Status
`READY FOR CONTROLLED PILOT` — full metrics pass, but rolled out first to a
small compliance team before broader access given the regulatory stakes.

## Why this example matters
This is the one case in the catalog where Graph RAG's three-condition test
actually passed AND the construction-quality gate passed — showing what
"justified" looks like in practice, not just in theory. Contrast with
`corrective-rag/README.md`, where Graph RAG was considered and correctly rejected.
