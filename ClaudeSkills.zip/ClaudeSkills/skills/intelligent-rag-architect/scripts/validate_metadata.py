#!/usr/bin/env python3
"""
validate_metadata.py — enforce the metadata-completeness MUST DO from SKILL.md
non-negotiables and retrieval-engineer.md's retrieval contract.

Validates a JSONL file of chunk records against the required metadata fields.
Every chunk must have: source, section_path or chunk_index, and (if
multi-tenant) tenant_id. This is the automated checkpoint referenced in
agents/corpus-analyst.md and the "Metadata failure" category in
references/evaluation-framework.md's failure taxonomy.

Input format: one JSON object per line, matching schemas/retrieval-result.schema.json
(the "metadata" sub-object specifically).

Usage:
    python validate_metadata.py --input chunks.jsonl
    python validate_metadata.py --input chunks.jsonl --require-tenant-id
    python validate_metadata.py --input chunks.jsonl --strict   # exit 1 on any failure

Exit codes:
    0  all chunks pass validation (or --strict not set and only warnings found)
    1  validation failures found and --strict set
    2  input file invalid / unreadable
"""

import argparse
import json
import sys
from pathlib import Path

REQUIRED_FIELDS = ["chunk_id", "document_id", "content"]
REQUIRED_METADATA_FIELDS = ["source"]
RECOMMENDED_METADATA_FIELDS = ["section_path", "date", "embed_model"]


def validate_chunk(chunk: dict, line_no: int, require_tenant_id: bool) -> list:
    """Returns a list of issue dicts for this chunk. Empty list = clean."""
    issues = []

    for field in REQUIRED_FIELDS:
        if field not in chunk or not chunk[field]:
            issues.append({
                "line": line_no, "chunk_id": chunk.get("chunk_id", "UNKNOWN"),
                "severity": "ERROR", "field": field,
                "message": f"Missing required field '{field}'",
            })

    metadata = chunk.get("metadata", {})
    if not isinstance(metadata, dict):
        issues.append({
            "line": line_no, "chunk_id": chunk.get("chunk_id", "UNKNOWN"),
            "severity": "ERROR", "field": "metadata",
            "message": "metadata field is missing or not an object",
        })
        return issues  # can't check sub-fields if metadata itself is broken

    for field in REQUIRED_METADATA_FIELDS:
        if field not in metadata or not metadata[field]:
            issues.append({
                "line": line_no, "chunk_id": chunk.get("chunk_id", "UNKNOWN"),
                "severity": "ERROR", "field": f"metadata.{field}",
                "message": f"Missing required metadata field '{field}'",
            })

    for field in RECOMMENDED_METADATA_FIELDS:
        if field not in metadata or not metadata[field]:
            issues.append({
                "line": line_no, "chunk_id": chunk.get("chunk_id", "UNKNOWN"),
                "severity": "WARNING", "field": f"metadata.{field}",
                "message": f"Missing recommended metadata field '{field}'",
            })

    if require_tenant_id and not metadata.get("tenant_id"):
        issues.append({
            "line": line_no, "chunk_id": chunk.get("chunk_id", "UNKNOWN"),
            "severity": "ERROR", "field": "metadata.tenant_id",
            "message": "Missing tenant_id — required for multi-tenant permission filtering "
                       "(see references/security-framework.md § Access-Control Bypass)",
        })

    score = chunk.get("score")
    if score is not None and not (0 <= score <= 1):
        issues.append({
            "line": line_no, "chunk_id": chunk.get("chunk_id", "UNKNOWN"),
            "severity": "ERROR", "field": "score",
            "message": f"score={score} is outside [0,1] — did you forget to normalise? "
                       f"See references/enterprise-rag-ingestion.md § size bias problem.",
        })

    return issues


def main():
    parser = argparse.ArgumentParser(description="Validate chunk metadata completeness before ingestion.")
    parser.add_argument("--input", required=True, help="JSONL file of chunk records.")
    parser.add_argument("--require-tenant-id", action="store_true",
                         help="Fail chunks missing tenant_id (use for multi-tenant systems).")
    parser.add_argument("--strict", action="store_true",
                         help="Exit with code 1 if any ERROR-severity issue is found.")
    parser.add_argument("--output", help="Optional path to write a JSON issue report.")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: input file not found: {input_path}", file=sys.stderr)
        sys.exit(2)

    all_issues = []
    total_chunks = 0

    try:
        with open(input_path, "r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                total_chunks += 1
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError as e:
                    all_issues.append({
                        "line": line_no, "chunk_id": "UNKNOWN",
                        "severity": "ERROR", "field": "__parse__",
                        "message": f"Invalid JSON: {e}",
                    })
                    continue
                all_issues.extend(validate_chunk(chunk, line_no, args.require_tenant_id))
    except OSError as e:
        print(f"ERROR: could not read input file: {e}", file=sys.stderr)
        sys.exit(2)

    errors = [i for i in all_issues if i["severity"] == "ERROR"]
    warnings = [i for i in all_issues if i["severity"] == "WARNING"]

    print(f"Validated {total_chunks} chunks: {len(errors)} errors, {len(warnings)} warnings.")
    for issue in errors:
        print(f"  ERROR   line {issue['line']} [{issue['chunk_id']}]: {issue['message']}")
    for issue in warnings:
        print(f"  WARNING line {issue['line']} [{issue['chunk_id']}]: {issue['message']}")

    if args.output:
        Path(args.output).write_text(json.dumps({
            "total_chunks": total_chunks,
            "error_count": len(errors),
            "warning_count": len(warnings),
            "issues": all_issues,
        }, indent=2), encoding="utf-8")
        print(f"Report written to: {args.output}")

    if args.strict and errors:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
