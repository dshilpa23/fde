#!/usr/bin/env python3
"""
test_abstention.py — dedicated test runner for the Abstention & Clarification
pattern (rag-pattern-catalog.md § 13).

Runs your RAG pipeline against the "unsupported" and "ambiguous" categories
from the golden dataset specifically, and checks it abstains/asks for
clarification rather than confidently answering. This is intentionally
separate from evaluate_generation.py because abstention correctness is
security/trust critical enough to warrant its own focused pass/fail gate
rather than being buried in an aggregate score.

Input:
  --golden       golden-set JSON (only unsupported/ambiguous cases are used)
  --pipeline-command  Shell command: receives question on stdin, returns
                       JSON {"behavior": "ANSWER"|"ABSTAIN"|"CLARIFICATION_REQUIRED", "answer": str}

Usage:
    python test_abstention.py --golden golden_set.json --pipeline-command "python run_my_rag.py"

Exit codes:
    0  all abstention/clarification cases handled correctly
    1  one or more cases answered confidently when they should not have
    2  invalid input
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

TARGET_CATEGORIES = {"unsupported", "ambiguous"}


def call_pipeline(pipeline_command: str, question: str) -> dict:
    try:
        result = subprocess.run(
            pipeline_command, shell=True, input=question, capture_output=True,
            text=True, timeout=60,
        )
    except subprocess.TimeoutExpired:
        return {"error": "pipeline command timed out"}
    if result.returncode != 0:
        return {"error": f"pipeline command failed: {result.stderr}"}
    raw = result.stdout.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"error": f"pipeline returned non-JSON: {raw[:200]}"}


def run_tests(golden: list, pipeline_command: str) -> dict:
    target_cases = [c for c in golden if c["query_type"] in TARGET_CATEGORIES]
    if not target_cases:
        return {"error": "No unsupported/ambiguous cases found in golden dataset. "
                          "Run generate_golden_set.py or add cases manually."}

    results = []
    for case in target_cases:
        response = call_pipeline(pipeline_command, case["question"])
        if "error" in response:
            results.append({
                "case_id": case["case_id"], "query_type": case["query_type"],
                "expected": case["expected_behavior"], "actual": "ERROR",
                "correct": False, "error": response["error"],
            })
            continue

        actual_behavior = response.get("behavior", "ANSWER")
        expected_behavior = case["expected_behavior"]
        correct = actual_behavior == expected_behavior

        results.append({
            "case_id": case["case_id"], "query_type": case["query_type"],
            "expected": expected_behavior, "actual": actual_behavior,
            "correct": correct,
            "answer_given": response.get("answer", "") if actual_behavior == "ANSWER" else None,
        })

    correct_count = sum(1 for r in results if r["correct"])
    return {
        "total": len(results), "correct": correct_count,
        "accuracy": correct_count / len(results) if results else 0,
        "results": results,
        "false_confidence_cases": [
            r for r in results
            if not r["correct"] and r["actual"] == "ANSWER"
        ],
    }


def main():
    parser = argparse.ArgumentParser(description="Test abstention/clarification correctness on unsupported and ambiguous questions.")
    parser.add_argument("--golden", required=True)
    parser.add_argument("--pipeline-command", required=True,
                         help="Shell command: question on stdin -> JSON {behavior, answer} on stdout.")
    parser.add_argument("--output")
    args = parser.parse_args()

    golden_path = Path(args.golden)
    if not golden_path.exists():
        print(f"ERROR: golden dataset not found: {golden_path}", file=sys.stderr)
        sys.exit(2)

    try:
        golden = json.loads(golden_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: invalid JSON: {e}", file=sys.stderr)
        sys.exit(2)

    report = run_tests(golden, args.pipeline_command)
    if "error" in report:
        print(f"ERROR: {report['error']}", file=sys.stderr)
        sys.exit(2)

    print(f"Abstention/Clarification test: {report['correct']}/{report['total']} correct "
          f"({report['accuracy']:.1%})\n")

    for r in report["results"]:
        status = "✓" if r["correct"] else "✗"
        print(f"  {status} [{r['case_id']}] {r['query_type']}: "
              f"expected={r['expected']}, actual={r['actual']}")

    if report["false_confidence_cases"]:
        print(f"\n  ⚠ HIGH RISK: {len(report['false_confidence_cases'])} case(s) answered "
              f"CONFIDENTLY when they should have abstained/clarified — this is the exact "
              f"failure mode evaluation-framework.md § Silent Failures warns about.")
        for c in report["false_confidence_cases"]:
            print(f"    [{c['case_id']}]: \"{c.get('answer_given', '')[:100]}...\"")

    if args.output:
        Path(args.output).write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nFull report written to: {args.output}")

    target = 0.90  # per evaluation-framework.md abstention_correctness threshold
    passed = report["accuracy"] >= target
    print(f"\nOVERALL: {'PASS' if passed else 'FAIL'} (target: {target:.0%})")
    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
