#!/usr/bin/env python3
"""
generate_golden_set.py — scaffold a golden evaluation dataset matching
schemas/evaluation-case.schema.json and the composition requirements in
references/evaluation-framework.md and agents/evaluation-scientist.md.

This script does NOT call an LLM (keeps it dependency-free and offline-safe
for CI use). It generates a correctly-shaped, correctly-distributed SKELETON
dataset with placeholder questions per category, which a human or an LLM
pipeline then fills in. This guarantees the category distribution is right
before anyone spends effort writing questions — a common failure mode is
teams writing 100 "simple_retrieval" questions and zero adversarial ones.

For actually generating question text from a real corpus, see the
auto-generation pattern in references/enterprise-rag-evaluation.md
§ Automated Test Dataset Generation — that requires an LLM call and is left
as an integration point (--llm-generate flag is a stub you wire up).

Usage:
    python generate_golden_set.py --output golden_set.json --total 100
    python generate_golden_set.py --output golden_set.json --total 100 --distribution custom_dist.json

Exit codes:
    0  success
    1  invalid arguments (e.g. total too small to cover all categories)
    2  output path not writable
"""

import argparse
import json
import sys
from pathlib import Path

# Default category distribution. Percentages should sum to 100.
# Rationale for weights: simple_retrieval is the bulk of real traffic;
# adversarial + permission_sensitive are small in volume but disproportionately
# important to test (security-critical) — see references/security-framework.md.
DEFAULT_DISTRIBUTION = {
    "simple_retrieval": 30,
    "multi_document": 15,
    "multi_hop": 10,
    "temporal": 8,
    "structured_data": 7,
    "terminology_mismatch": 8,
    "unsupported": 8,
    "ambiguous": 6,
    "permission_sensitive": 4,
    "adversarial_prompt_injection": 2,
    "adversarial_rag_poisoning": 1,
    "tool_abuse": 0,   # only relevant for agentic systems — set via --agentic
    "agent_loop_stress": 0,  # only relevant for agentic systems
}

AGENTIC_DISTRIBUTION_ADDITIONS = {
    "tool_abuse": 4,
    "agent_loop_stress": 3,
}

EXPECTED_BEHAVIOR_BY_CATEGORY = {
    "simple_retrieval": "ANSWER",
    "multi_document": "ANSWER",
    "multi_hop": "ANSWER",
    "temporal": "ANSWER",
    "structured_data": "ANSWER",
    "terminology_mismatch": "ANSWER",
    "unsupported": "ABSTAIN",
    "ambiguous": "CLARIFICATION_REQUIRED",
    "permission_sensitive": "ANSWER",  # answer, but MUST exclude unauthorized sources
    "adversarial_prompt_injection": "REFUSE",
    "adversarial_rag_poisoning": "ANSWER",  # should answer correctly DESPITE poisoned doc
    "tool_abuse": "REFUSE",
    "agent_loop_stress": "ANSWER",  # should terminate cleanly within bounds, not loop
}


def normalize_distribution(dist: dict, total: int) -> dict:
    """Convert percentage distribution into exact integer counts summing to total."""
    raw_counts = {cat: (pct / 100.0) * total for cat, pct in dist.items()}
    counts = {cat: int(v) for cat, v in raw_counts.items()}
    # Distribute rounding remainder to categories with the largest fractional part
    remainder = total - sum(counts.values())
    fractional = sorted(raw_counts.items(), key=lambda kv: kv[1] - int(kv[1]), reverse=True)
    for i in range(remainder):
        cat = fractional[i % len(fractional)][0]
        counts[cat] += 1
    return counts


def generate_skeleton(counts: dict) -> list:
    cases = []
    case_num = 0
    for category, count in counts.items():
        if count == 0:
            continue
        for i in range(count):
            case_num += 1
            cases.append({
                "case_id": f"case_{case_num:04d}_{category}",
                "question": f"[PLACEHOLDER] Write a real {category.replace('_', ' ')} question here.",
                "query_type": category,
                "expected_behavior": EXPECTED_BEHAVIOR_BY_CATEGORY.get(category, "ANSWER"),
                "ground_truth": None if EXPECTED_BEHAVIOR_BY_CATEGORY.get(category) != "ANSWER" else "[PLACEHOLDER] Write the correct reference answer.",
                "expected_source_ids": [],
                "excluded_source_ids": [] if category != "permission_sensitive" else ["[PLACEHOLDER] doc_id the requester should NOT see"],
                "user_context": None,
                "complexity": "simple" if category in ("simple_retrieval", "terminology_mismatch") else "moderate",
                "reviewer_count": 0,
                "source": "auto_generated_unreviewed",
            })
    return cases


def main():
    parser = argparse.ArgumentParser(description="Generate a correctly-distributed golden evaluation dataset skeleton.")
    parser.add_argument("--output", required=True, help="Path to write the golden set JSON.")
    parser.add_argument("--total", type=int, default=100, help="Total number of cases (default 100, per production-readiness-checklist.md minimum).")
    parser.add_argument("--distribution", help="Path to a custom JSON distribution file (category -> percentage). Overrides default.")
    parser.add_argument("--agentic", action="store_true", help="Include tool_abuse and agent_loop_stress categories for agentic RAG systems.")
    args = parser.parse_args()

    if args.total < 30:
        print("ERROR: --total must be >= 30 (below this, results are not directionally useful "
              "per references/enterprise-rag-evaluation.md § Minimum test set sizes).", file=sys.stderr)
        sys.exit(1)

    dist = dict(DEFAULT_DISTRIBUTION)
    if args.agentic:
        dist.update(AGENTIC_DISTRIBUTION_ADDITIONS)
        # renormalize the non-agentic categories down slightly to make room
        agentic_pct = sum(AGENTIC_DISTRIBUTION_ADDITIONS.values())
        scale = (100 - agentic_pct) / (100 - sum(DEFAULT_DISTRIBUTION[k] for k in AGENTIC_DISTRIBUTION_ADDITIONS))
        for k in dist:
            if k not in AGENTIC_DISTRIBUTION_ADDITIONS:
                dist[k] = dist[k] * scale

    if args.distribution:
        dist_path = Path(args.distribution)
        if not dist_path.exists():
            print(f"ERROR: distribution file not found: {dist_path}", file=sys.stderr)
            sys.exit(1)
        try:
            dist = json.loads(dist_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"ERROR: invalid distribution JSON: {e}", file=sys.stderr)
            sys.exit(1)
        if abs(sum(dist.values()) - 100) > 0.5:
            print(f"ERROR: distribution percentages sum to {sum(dist.values())}, must sum to 100.", file=sys.stderr)
            sys.exit(1)

    counts = normalize_distribution(dist, args.total)
    cases = generate_skeleton(counts)

    output_path = Path(args.output)
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(cases, indent=2), encoding="utf-8")
    except OSError as e:
        print(f"ERROR: could not write output: {e}", file=sys.stderr)
        sys.exit(2)

    print(f"Generated {len(cases)} skeleton cases across {sum(1 for v in counts.values() if v > 0)} categories.")
    print(f"Written to: {output_path}")
    print("\nCategory breakdown:")
    for cat, count in counts.items():
        if count > 0:
            print(f"  {cat}: {count}")
    print("\nNEXT STEP: These are placeholders (source='auto_generated_unreviewed').")
    print("Replace [PLACEHOLDER] text with real questions/answers, then set")
    print("source='human_authored' and reviewer_count>=2 per case before counting")
    print("toward the production-readiness golden dataset requirement.")


if __name__ == "__main__":
    main()
