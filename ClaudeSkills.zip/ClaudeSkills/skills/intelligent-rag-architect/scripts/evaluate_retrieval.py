#!/usr/bin/env python3
"""
evaluate_retrieval.py — Level 2 (Retrieval) evaluation per
references/evaluation-framework.md.

Computes Precision@K, Recall@K, MRR, nDCG@K, permission-filter correctness,
and Hit Rate against a golden dataset with known expected_source_ids.

This script is retriever-agnostic: you provide a JSON file of actual
retrieval results per case (produced by running YOUR retriever against
each golden question), and this script scores them against the golden
dataset's expected_source_ids / excluded_source_ids.

Input files:
  --golden       golden-set JSON matching schemas/evaluation-case.schema.json
  --results      JSON: {case_id: [retrieved_source_id, ...]} in rank order

Usage:
    python evaluate_retrieval.py --golden golden_set.json --results retrieval_results.json
    python evaluate_retrieval.py --golden golden_set.json --results retrieval_results.json --k 5 10 20

Exit codes:
    0  success (metrics computed, thresholds may or may not be met — see output)
    1  input files invalid or mismatched case IDs
"""

import argparse
import json
import sys
from pathlib import Path

# Thresholds per references/enterprise-rag-evaluation.md and evaluation-framework.md
THRESHOLDS = {
    "precision_at_5": 0.70,
    "recall_at_20": 0.80,
    "mrr": 0.70,
    "ndcg_at_10": 0.75,
    "hit_rate": 0.90,
    "permission_filter_correctness": 1.00,  # must be exactly 100%
}


def precision_at_k(retrieved: list, relevant: set, k: int) -> float:
    if k == 0:
        return 0.0
    top_k = retrieved[:k]
    if not top_k:
        return 0.0
    return len(set(top_k) & relevant) / len(top_k)


def recall_at_k(retrieved: list, relevant: set, k: int) -> float:
    if not relevant:
        return None  # undefined — no ground truth to recall
    top_k = retrieved[:k]
    return len(set(top_k) & relevant) / len(relevant)


def mrr_single(retrieved: list, relevant: set) -> float:
    for rank, doc_id in enumerate(retrieved, start=1):
        if doc_id in relevant:
            return 1.0 / rank
    return 0.0


def ndcg_at_k(retrieved: list, relevant: set, k: int) -> float:
    """Binary relevance nDCG (1 if relevant, 0 if not) — extend to graded
    relevance if your golden set carries relevance scores rather than a
    flat relevant/not-relevant set."""
    import math

    def dcg(items):
        return sum(
            (1 if doc_id in relevant else 0) / math.log2(i + 2)
            for i, doc_id in enumerate(items)
        )

    top_k = retrieved[:k]
    actual_dcg = dcg(top_k)
    ideal_order = list(relevant)[:k] + [None] * max(0, k - len(relevant))
    ideal_dcg = dcg([d for d in ideal_order if d is not None])
    return actual_dcg / ideal_dcg if ideal_dcg > 0 else 0.0


def permission_filter_check(retrieved: list, excluded: set) -> bool:
    """Returns True (PASS) only if zero excluded sources appear in results."""
    return len(set(retrieved) & excluded) == 0


def evaluate(golden: list, results: dict, ks: list) -> dict:
    per_case = []
    missing_results = []

    for case in golden:
        case_id = case["case_id"]
        if case_id not in results:
            missing_results.append(case_id)
            continue

        retrieved = results[case_id]
        relevant = set(case.get("expected_source_ids") or [])
        excluded = set(case.get("excluded_source_ids") or [])

        case_metrics = {"case_id": case_id, "query_type": case["query_type"]}

        for k in ks:
            case_metrics[f"precision_at_{k}"] = precision_at_k(retrieved, relevant, k)
            r = recall_at_k(retrieved, relevant, k)
            if r is not None:
                case_metrics[f"recall_at_{k}"] = r
            case_metrics[f"ndcg_at_{k}"] = ndcg_at_k(retrieved, relevant, k)

        if relevant:
            case_metrics["mrr"] = mrr_single(retrieved, relevant)
            case_metrics["hit"] = any(d in relevant for d in retrieved)

        if excluded:
            case_metrics["permission_filter_pass"] = permission_filter_check(retrieved, excluded)

        per_case.append(case_metrics)

    return {"per_case": per_case, "missing_results": missing_results}


def aggregate(per_case: list, ks: list) -> dict:
    agg = {}
    for k in ks:
        p_vals = [c[f"precision_at_{k}"] for c in per_case if f"precision_at_{k}" in c]
        r_vals = [c[f"recall_at_{k}"] for c in per_case if f"recall_at_{k}" in c]
        n_vals = [c[f"ndcg_at_{k}"] for c in per_case if f"ndcg_at_{k}" in c]
        if p_vals:
            agg[f"precision_at_{k}"] = sum(p_vals) / len(p_vals)
        if r_vals:
            agg[f"recall_at_{k}"] = sum(r_vals) / len(r_vals)
        if n_vals:
            agg[f"ndcg_at_{k}"] = sum(n_vals) / len(n_vals)

    mrr_vals = [c["mrr"] for c in per_case if "mrr" in c]
    if mrr_vals:
        agg["mrr"] = sum(mrr_vals) / len(mrr_vals)

    hit_vals = [c["hit"] for c in per_case if "hit" in c]
    if hit_vals:
        agg["hit_rate"] = sum(hit_vals) / len(hit_vals)

    perm_vals = [c["permission_filter_pass"] for c in per_case if "permission_filter_pass" in c]
    if perm_vals:
        agg["permission_filter_correctness"] = sum(perm_vals) / len(perm_vals)
        agg["permission_filter_failures"] = [
            c["case_id"] for c in per_case
            if c.get("permission_filter_pass") is False
        ]

    return agg


def check_thresholds(agg: dict) -> dict:
    results = {}
    key_map = {
        "precision_at_5": "precision_at_5",
        "recall_at_20": "recall_at_20",
        "mrr": "mrr",
        "ndcg_at_10": "ndcg_at_10",
        "hit_rate": "hit_rate",
        "permission_filter_correctness": "permission_filter_correctness",
    }
    for threshold_key, agg_key in key_map.items():
        if agg_key in agg:
            actual = agg[agg_key]
            target = THRESHOLDS[threshold_key]
            results[threshold_key] = {
                "actual": round(actual, 4), "target": target,
                "pass": actual >= target,
            }
    return results


def main():
    parser = argparse.ArgumentParser(description="Evaluate retrieval quality against a golden dataset.")
    parser.add_argument("--golden", required=True, help="Golden dataset JSON.")
    parser.add_argument("--results", required=True, help="Retrieval results JSON: {case_id: [source_id, ...]}")
    parser.add_argument("--k", nargs="+", type=int, default=[5, 10, 20], help="K values to compute (default: 5 10 20).")
    parser.add_argument("--output", help="Optional path to write full JSON report.")
    args = parser.parse_args()

    golden_path = Path(args.golden)
    results_path = Path(args.results)

    for p in (golden_path, results_path):
        if not p.exists():
            print(f"ERROR: file not found: {p}", file=sys.stderr)
            sys.exit(1)

    try:
        golden = json.loads(golden_path.read_text(encoding="utf-8"))
        results = json.loads(results_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    if not isinstance(golden, list):
        print("ERROR: golden dataset must be a JSON array of cases.", file=sys.stderr)
        sys.exit(1)
    if not isinstance(results, dict):
        print("ERROR: results file must be a JSON object of {case_id: [source_ids]}.", file=sys.stderr)
        sys.exit(1)

    eval_output = evaluate(golden, results, args.k)
    agg = aggregate(eval_output["per_case"], args.k)
    threshold_check = check_thresholds(agg)

    print(f"Evaluated {len(eval_output['per_case'])}/{len(golden)} cases "
          f"({len(eval_output['missing_results'])} missing results).\n")

    print("=== Aggregate Metrics ===")
    for key, val in agg.items():
        if isinstance(val, float):
            print(f"  {key}: {val:.4f}")

    print("\n=== Threshold Check ===")
    all_pass = True
    for key, check in threshold_check.items():
        status = "PASS" if check["pass"] else "FAIL"
        if not check["pass"]:
            all_pass = False
        print(f"  [{status}] {key}: {check['actual']} (target: {check['target']})")

    if agg.get("permission_filter_failures"):
        print(f"\n  ⚠ SECURITY: permission_filter_correctness < 100% — "
              f"{len(agg['permission_filter_failures'])} case(s) leaked unauthorized sources: "
              f"{agg['permission_filter_failures']}")

    if eval_output["missing_results"]:
        print(f"\n  ⚠ Missing results for: {eval_output['missing_results']}")

    if args.output:
        Path(args.output).write_text(json.dumps({
            "per_case": eval_output["per_case"],
            "aggregate": agg,
            "threshold_check": threshold_check,
            "missing_results": eval_output["missing_results"],
        }, indent=2), encoding="utf-8")
        print(f"\nFull report written to: {args.output}")

    print(f"\nOVERALL: {'ALL THRESHOLDS PASS' if all_pass else 'THRESHOLDS NOT MET'}")
    sys.exit(0)


if __name__ == "__main__":
    main()
