#!/usr/bin/env python3
"""
evaluate_generation.py — Level 3 (Generation) evaluation per
references/evaluation-framework.md and references/enterprise-rag-evaluation.md.

Scores generated answers for Faithfulness, Answer Relevancy, and Abstention
Correctness using an LLM-as-judge. This script defines the judge PROMPTS and
scoring/aggregation logic; you wire in your actual LLM client via the
--llm-command flag (a shell command that receives a prompt on stdin and
returns the judge's raw text response on stdout) so this stays provider-agnostic.

IMPORTANT — self-grading bias (security-framework.md / evaluation-framework.md):
Do not use the same model as both generator and judge. Pass the JUDGE model
via --llm-command; it should differ from whatever generated the answers.

Input:
  --golden    golden-set JSON matching schemas/evaluation-case.schema.json
  --answers   JSON: {case_id: {"answer": str, "context": [str, ...], "behavior": str}}

Usage:
    python evaluate_generation.py --golden golden_set.json --answers gen_results.json \\
        --llm-command "python my_judge_wrapper.py"

Exit codes:
    0  success
    1  invalid input
    2  judge command failed
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

THRESHOLDS = {
    "faithfulness": 0.75,
    "answer_relevancy": 0.80,
    "abstention_correctness": 0.90,
    "hallucination_rate_max": 0.05,  # this one is a MAX, not a min
}

FAITHFULNESS_PROMPT = """You are evaluating whether a generated answer is faithful to its source context.
Faithfulness means every factual claim in the answer is supported by the context.
Do not reward vague answers that avoid claims — score based on claims actually made.

Context:
{context}

Answer:
{answer}

Score faithfulness from 0.0 to 1.0 (1.0 = every claim supported, 0.0 = fabricated).
Respond with ONLY a JSON object: {{"score": <float>, "unsupported_claims": [<string>, ...]}}"""

ANSWER_RELEVANCY_PROMPT = """You are evaluating whether a generated answer actually addresses the question asked.
An answer can be factually correct but still irrelevant if it doesn't address what was asked.

Question:
{question}

Answer:
{answer}

Score relevancy from 0.0 to 1.0 (1.0 = fully addresses the question, 0.0 = off-topic).
Respond with ONLY a JSON object: {{"score": <float>, "reasoning": "<brief reason>"}}"""

ABSTENTION_PROMPT = """You are evaluating whether a system correctly abstained or answered.

Question: {question}
Expected behavior: {expected_behavior}
System's actual behavior: {actual_behavior}
System's answer (if any): {answer}

Was this the CORRECT behavior given the expected_behavior?
Respond with ONLY a JSON object: {{"correct": <true/false>, "reasoning": "<brief reason>"}}"""


def call_judge(llm_command: str, prompt: str) -> dict:
    """Runs the judge LLM via shell command, prompt on stdin, JSON response on stdout."""
    try:
        result = subprocess.run(
            llm_command, shell=True, input=prompt, capture_output=True,
            text=True, timeout=60,
        )
    except subprocess.TimeoutExpired:
        return {"error": "judge command timed out"}

    if result.returncode != 0:
        return {"error": f"judge command failed: {result.stderr}"}

    raw = result.stdout.strip()
    # Strip markdown code fences if the judge wrapped its JSON in them
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"error": f"judge returned non-JSON: {raw[:200]}"}


def evaluate_case(case: dict, answer_record: dict, llm_command: str) -> dict:
    case_id = case["case_id"]
    expected_behavior = case["expected_behavior"]
    actual_behavior = answer_record.get("behavior", "ANSWER")
    answer = answer_record.get("answer", "")
    context = answer_record.get("context", [])

    metrics = {"case_id": case_id, "query_type": case["query_type"]}

    # Abstention correctness always computed — cheapest, most diagnostic check
    abstention_prompt = ABSTENTION_PROMPT.format(
        question=case["question"], expected_behavior=expected_behavior,
        actual_behavior=actual_behavior, answer=answer or "(no answer given)",
    )
    abstention_result = call_judge(llm_command, abstention_prompt)
    if "error" not in abstention_result:
        metrics["abstention_correct"] = abstention_result.get("correct", False)
    else:
        metrics["abstention_error"] = abstention_result["error"]

    # Only run faithfulness/relevancy if the system actually answered
    if expected_behavior == "ANSWER" and actual_behavior == "ANSWER" and answer:
        faith_prompt = FAITHFULNESS_PROMPT.format(
            context="\n\n".join(context), answer=answer,
        )
        faith_result = call_judge(llm_command, faith_prompt)
        if "error" not in faith_result:
            metrics["faithfulness"] = faith_result.get("score")
            metrics["unsupported_claims"] = faith_result.get("unsupported_claims", [])
            metrics["hallucinated"] = len(metrics["unsupported_claims"]) > 0
        else:
            metrics["faithfulness_error"] = faith_result["error"]

        rel_prompt = ANSWER_RELEVANCY_PROMPT.format(
            question=case["question"], answer=answer,
        )
        rel_result = call_judge(llm_command, rel_prompt)
        if "error" not in rel_result:
            metrics["answer_relevancy"] = rel_result.get("score")
        else:
            metrics["answer_relevancy_error"] = rel_result["error"]

    return metrics


def aggregate(per_case: list) -> dict:
    agg = {}

    faith_vals = [c["faithfulness"] for c in per_case if isinstance(c.get("faithfulness"), (int, float))]
    if faith_vals:
        agg["faithfulness"] = sum(faith_vals) / len(faith_vals)

    rel_vals = [c["answer_relevancy"] for c in per_case if isinstance(c.get("answer_relevancy"), (int, float))]
    if rel_vals:
        agg["answer_relevancy"] = sum(rel_vals) / len(rel_vals)

    abstention_vals = [c["abstention_correct"] for c in per_case if "abstention_correct" in c]
    if abstention_vals:
        agg["abstention_correctness"] = sum(abstention_vals) / len(abstention_vals)

    hallucinated_flags = [c["hallucinated"] for c in per_case if "hallucinated" in c]
    if hallucinated_flags:
        agg["hallucination_rate"] = sum(hallucinated_flags) / len(hallucinated_flags)

    return agg


def check_thresholds(agg: dict) -> dict:
    results = {}
    for key in ("faithfulness", "answer_relevancy", "abstention_correctness"):
        if key in agg:
            target = THRESHOLDS[key]
            results[key] = {"actual": round(agg[key], 4), "target": target, "pass": agg[key] >= target}
    if "hallucination_rate" in agg:
        target = THRESHOLDS["hallucination_rate_max"]
        results["hallucination_rate"] = {
            "actual": round(agg["hallucination_rate"], 4), "target_max": target,
            "pass": agg["hallucination_rate"] <= target,
        }
    return results


def main():
    parser = argparse.ArgumentParser(description="Evaluate generation quality against a golden dataset using an LLM judge.")
    parser.add_argument("--golden", required=True)
    parser.add_argument("--answers", required=True, help="JSON: {case_id: {answer, context, behavior}}")
    parser.add_argument("--llm-command", required=True,
                         help="Shell command that reads a prompt on stdin and writes JSON judge output to stdout. "
                              "MUST be a different model than the one that generated the answers.")
    parser.add_argument("--output")
    args = parser.parse_args()

    golden_path, answers_path = Path(args.golden), Path(args.answers)
    for p in (golden_path, answers_path):
        if not p.exists():
            print(f"ERROR: file not found: {p}", file=sys.stderr)
            sys.exit(1)

    try:
        golden = json.loads(golden_path.read_text(encoding="utf-8"))
        answers = json.loads(answers_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    per_case = []
    for case in golden:
        case_id = case["case_id"]
        if case_id not in answers:
            print(f"  WARNING: no answer record for {case_id}, skipping.", file=sys.stderr)
            continue
        per_case.append(evaluate_case(case, answers[case_id], args.llm_command))

    agg = aggregate(per_case)
    threshold_check = check_thresholds(agg)

    print(f"Evaluated {len(per_case)}/{len(golden)} cases.\n")
    print("=== Aggregate Metrics ===")
    for key, val in agg.items():
        print(f"  {key}: {val:.4f}")

    print("\n=== Threshold Check ===")
    all_pass = True
    for key, check in threshold_check.items():
        status = "PASS" if check["pass"] else "FAIL"
        if not check["pass"]:
            all_pass = False
        target_str = check.get("target", check.get("target_max"))
        print(f"  [{status}] {key}: {check['actual']} (target: {target_str})")

    if args.output:
        Path(args.output).write_text(json.dumps({
            "per_case": per_case, "aggregate": agg, "threshold_check": threshold_check,
        }, indent=2), encoding="utf-8")
        print(f"\nFull report written to: {args.output}")

    print(f"\nOVERALL: {'ALL THRESHOLDS PASS' if all_pass else 'THRESHOLDS NOT MET'}")
    sys.exit(0)


if __name__ == "__main__":
    main()
