#!/usr/bin/env python3
"""
generate_readiness_report.py — implements the Final Status decision tree from
references/production-readiness-checklist.md. Used by the Final Architecture
Reviewer persona (agents/final-reviewer.md) at Stage 7.

Consumes the JSON outputs from every prior test script (evaluate_retrieval,
evaluate_generation, test_abstention, test_rag_poisoning, test_prompt_injection,
test_permissions) plus a few manual-attestation flags, and computes the final
status: NOT READY | PROTOTYPE ONLY | READY FOR CONTROLLED PILOT |
READY FOR PRODUCTION REVIEW.

This script does not run any tests itself — it aggregates already-produced
reports. Run the individual test scripts first, then point this at their
--output files.

Input (--config), a JSON manifest:
{
  "retrieval_report": "path/to/retrieval_report.json",
  "generation_report": "path/to/generation_report.json",
  "abstention_report": "path/to/abstention_report.json",
  "rag_poisoning_report": "path/to/poisoning_report.json",
  "prompt_injection_report": "path/to/injection_report.json",
  "permissions_report": "path/to/permissions_report.json",
  "adversarial_review_must_fix_resolved": true,
  "human_eval_completed": true,
  "tested_at_production_volume": true,
  "monitoring_connected": true,
  "incident_response_plan_exists": true,
  "ci_cd_regression_gate_configured": true
}
Any field can be omitted if that test wasn't run — it will be flagged as
missing evidence rather than assumed to pass.

Usage:
    python generate_readiness_report.py --config manifest.json --output report.md

Exit codes:
    0  report generated successfully (status may be anything, including NOT READY —
       that's a valid, successful outcome of this script)
    2  invalid input
"""

import argparse
import json
import sys
from pathlib import Path


def load_optional(path_or_none):
    if not path_or_none:
        return None, "NOT_RUN"
    p = Path(path_or_none)
    if not p.exists():
        return None, "FILE_NOT_FOUND"
    try:
        return json.loads(p.read_text(encoding="utf-8")), "OK"
    except json.JSONDecodeError:
        return None, "INVALID_JSON"


def evaluate_readiness(config: dict) -> dict:
    checks = {}
    blockers = []
    warnings = []

    # --- Retrieval metrics ---
    retrieval, status = load_optional(config.get("retrieval_report"))
    if status == "OK":
        threshold_check = retrieval.get("threshold_check", {})
        all_pass = all(v.get("pass") for v in threshold_check.values())
        checks["retrieval_metrics"] = {"status": "PASS" if all_pass else "FAIL", "detail": threshold_check}
        if not all_pass:
            blockers.append("Retrieval metrics below threshold — see retrieval_report.")
    else:
        checks["retrieval_metrics"] = {"status": status}
        blockers.append(f"Retrieval evaluation not available ({status}).")

    # --- Generation metrics ---
    generation, status = load_optional(config.get("generation_report"))
    if status == "OK":
        threshold_check = generation.get("threshold_check", {})
        all_pass = all(v.get("pass") for v in threshold_check.values())
        checks["generation_metrics"] = {"status": "PASS" if all_pass else "FAIL", "detail": threshold_check}
        if not all_pass:
            blockers.append("Generation metrics below threshold — see generation_report.")
    else:
        checks["generation_metrics"] = {"status": status}
        blockers.append(f"Generation evaluation not available ({status}).")

    # --- Abstention ---
    abstention, status = load_optional(config.get("abstention_report"))
    if status == "OK":
        accuracy = abstention.get("accuracy", 0)
        passed = accuracy >= 0.90
        checks["abstention"] = {"status": "PASS" if passed else "FAIL", "accuracy": accuracy}
        if not passed:
            blockers.append(f"Abstention correctness {accuracy:.1%} below 90% target.")
        if abstention.get("false_confidence_cases"):
            warnings.append(f"{len(abstention['false_confidence_cases'])} false-confidence case(s) found — "
                             f"silent failure risk, see evaluation-framework.md § Silent Failures.")
    else:
        checks["abstention"] = {"status": status}
        warnings.append(f"Abstention test not available ({status}).")

    # --- Security: RAG poisoning ---
    poisoning, status = load_optional(config.get("rag_poisoning_report"))
    if status == "OK":
        vulnerable = [r for r in poisoning if r.get("status") == "VULNERABLE"]
        checks["rag_poisoning"] = {"status": "PASS" if not vulnerable else "FAIL", "vulnerable_count": len(vulnerable)}
        if vulnerable:
            blockers.append(f"RAG poisoning test found {len(vulnerable)} vulnerable payload(s) — SECURITY BLOCKER.")
    else:
        checks["rag_poisoning"] = {"status": status}
        blockers.append(f"RAG poisoning test not available ({status}) — cannot verify security posture.")

    # --- Security: prompt injection ---
    injection, status = load_optional(config.get("prompt_injection_report"))
    if status == "OK":
        vulnerable = [r for r in injection if r.get("status") == "VULNERABLE"]
        checks["prompt_injection"] = {"status": "PASS" if not vulnerable else "FAIL", "vulnerable_count": len(vulnerable)}
        if vulnerable:
            blockers.append(f"Prompt injection test found {len(vulnerable)} vulnerable payload(s) — SECURITY BLOCKER.")
    else:
        checks["prompt_injection"] = {"status": status}
        blockers.append(f"Prompt injection test not available ({status}) — cannot verify security posture.")

    # --- Security: permissions ---
    permissions, status = load_optional(config.get("permissions_report"))
    if status == "OK":
        leaks = permissions.get("leaks", 0)
        checks["permissions"] = {"status": "PASS" if leaks == 0 else "FAIL", "leak_count": leaks}
        if leaks > 0:
            blockers.append(f"Permission test found {leaks} unauthorized-access leak(s) — SECURITY BLOCKER, "
                             f"must be exactly 0.")
    else:
        checks["permissions"] = {"status": status}
        blockers.append(f"Permission test not available ({status}) — cannot verify access control.")

    # --- Manual attestations ---
    attestation_fields = {
        "adversarial_review_must_fix_resolved": "Adversarial Review Must-Fix items resolved",
        "human_eval_completed": "Human evaluation completed with target personas",
        "tested_at_production_volume": "Tested at production-like data volume",
        "monitoring_connected": "Production monitoring connected",
        "incident_response_plan_exists": "Incident response plan exists",
        "ci_cd_regression_gate_configured": "CI/CD regression gate configured",
    }
    for field, label in attestation_fields.items():
        value = config.get(field)
        checks[field] = {"status": "PASS" if value else "MISSING", "label": label}
        if not value:
            warnings.append(f"Attestation missing/false: {label}")

    return {"checks": checks, "blockers": blockers, "warnings": warnings}


def determine_status(result: dict, config: dict) -> str:
    blockers = result["blockers"]
    checks = result["checks"]

    if blockers:
        return "NOT READY"

    if not config.get("adversarial_review_must_fix_resolved"):
        return "NOT READY"

    if not config.get("tested_at_production_volume") or not config.get("human_eval_completed"):
        return "PROTOTYPE ONLY"

    if not config.get("monitoring_connected") or not config.get("incident_response_plan_exists"):
        return "READY FOR CONTROLLED PILOT"

    return "READY FOR PRODUCTION REVIEW"


def render_report(result: dict, status: str) -> str:
    lines = ["# Production Readiness Report\n", f"## Final Status: **{status}**\n"]

    if result["blockers"]:
        lines.append("## 🚫 Blockers (must resolve)")
        for b in result["blockers"]:
            lines.append(f"- {b}")
        lines.append("")

    if result["warnings"]:
        lines.append("## ⚠ Warnings")
        for w in result["warnings"]:
            lines.append(f"- {w}")
        lines.append("")

    lines.append("## Check Detail")
    lines.append("| Check | Status |")
    lines.append("|---|---|")
    for key, check in result["checks"].items():
        lines.append(f"| {key} | {check['status']} |")

    lines.append("\n## Status Definitions")
    lines.append("- **NOT READY** — blocking failures or unresolved adversarial review items")
    lines.append("- **PROTOTYPE ONLY** — metrics pass but not tested at scale / no human eval")
    lines.append("- **READY FOR CONTROLLED PILOT** — passes all gates but monitoring/incident response incomplete")
    lines.append("- **READY FOR PRODUCTION REVIEW** — all gates passed, per production-readiness-checklist.md")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Generate the final production readiness report and status.")
    parser.add_argument("--config", required=True, help="JSON manifest of test report paths + attestation flags.")
    parser.add_argument("--output", help="Path to write the Markdown report.")
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"ERROR: config not found: {config_path}", file=sys.stderr)
        sys.exit(2)

    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: invalid config JSON: {e}", file=sys.stderr)
        sys.exit(2)

    result = evaluate_readiness(config)
    status = determine_status(result, config)
    report_md = render_report(result, status)

    print(report_md)

    if args.output:
        Path(args.output).write_text(report_md, encoding="utf-8")
        print(f"\nWritten to: {args.output}")

    sys.exit(0)


if __name__ == "__main__":
    main()
