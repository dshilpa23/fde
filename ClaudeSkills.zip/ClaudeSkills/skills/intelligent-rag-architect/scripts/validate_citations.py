#!/usr/bin/env python3
"""
validate_citations.py — implements rag-pattern-catalog.md § 12 Citation Validation.

Checks that inline citations ([1], [2], ...) in a generated answer actually
correspond to sources that support the specific claim they're attached to —
not just that the citation number exists and points to *a* real source.

This is citation CORRECTNESS, distinct from citation PRESENCE. An answer can
have perfect citation presence (every claim has a [n]) and still fail this
check if the cited source doesn't actually say what the claim says.

Input:
  --answer      Text file or string containing the generated answer with [n] citations
  --sources     JSON: {"1": "source text...", "2": "source text...", ...}
  --llm-command Shell command, prompt on stdin -> JSON {"supported": bool} on stdout

Usage:
    python validate_citations.py --answer answer.txt --sources sources.json \\
        --llm-command "python my_judge_wrapper.py"

Exit codes:
    0  all citations valid
    1  one or more citations invalid (spoofed/misattributed)
    2  invalid input
"""

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

CITATION_PATTERN = re.compile(r"\[(\d+)\]")

VALIDATION_PROMPT = """Does the source text support the specific claim? Answer strictly —
the source must actually state or directly imply the claim, not just be topically related.

Claim: {claim}

Source: {source}

Respond with ONLY a JSON object: {{"supported": <true/false>, "reasoning": "<brief reason>"}}"""


def extract_claims_with_citations(answer: str) -> list:
    """Split the answer into sentences, pair each with any [n] citations it contains."""
    # Simple sentence split — good enough for citation-claim pairing.
    sentences = re.split(r"(?<=[.!?])\s+", answer.strip())
    claims = []
    for sentence in sentences:
        citation_ids = CITATION_PATTERN.findall(sentence)
        if citation_ids:
            claim_text = CITATION_PATTERN.sub("", sentence).strip()
            claims.append({"claim": claim_text, "citation_ids": citation_ids})
    return claims


def call_judge(llm_command: str, prompt: str) -> dict:
    try:
        result = subprocess.run(
            llm_command, shell=True, input=prompt, capture_output=True,
            text=True, timeout=60,
        )
    except subprocess.TimeoutExpired:
        return {"error": "judge command timed out"}
    if result.returncode != 0:
        return {"error": f"judge command failed: {result.stderr}"}
    raw = result.stdout.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"error": f"judge returned non-JSON: {raw[:200]}"}


def validate(answer: str, sources: dict, llm_command: str) -> dict:
    claims = extract_claims_with_citations(answer)
    results = []

    for claim_record in claims:
        claim = claim_record["claim"]
        citation_ids = claim_record["citation_ids"]

        # Check citation exists (presence) before checking correctness
        missing_sources = [cid for cid in citation_ids if cid not in sources]
        if missing_sources:
            results.append({
                "claim": claim, "citation_ids": citation_ids,
                "supported": False,
                "reasoning": f"Citation(s) {missing_sources} reference sources that don't exist — "
                             f"this is a fabricated citation, not just a weak one.",
            })
            continue

        combined_source = "\n".join(sources[cid] for cid in citation_ids)
        prompt = VALIDATION_PROMPT.format(claim=claim, source=combined_source)
        judge_result = call_judge(llm_command, prompt)

        if "error" in judge_result:
            results.append({
                "claim": claim, "citation_ids": citation_ids,
                "supported": None, "reasoning": f"Judge error: {judge_result['error']}",
            })
        else:
            results.append({
                "claim": claim, "citation_ids": citation_ids,
                "supported": judge_result.get("supported", False),
                "reasoning": judge_result.get("reasoning", ""),
            })

    unsupported = [r for r in results if r["supported"] is False]
    errored = [r for r in results if r["supported"] is None]

    return {
        "total_claims_with_citations": len(results),
        "supported_count": len(results) - len(unsupported) - len(errored),
        "unsupported_count": len(unsupported),
        "error_count": len(errored),
        "all_valid": len(unsupported) == 0 and len(errored) == 0,
        "results": results,
    }


def main():
    parser = argparse.ArgumentParser(description="Validate that inline citations actually support their claims.")
    parser.add_argument("--answer", required=True, help="Path to a text file containing the answer, or the answer text itself.")
    parser.add_argument("--sources", required=True, help="JSON file: {citation_id: source_text}")
    parser.add_argument("--llm-command", required=True, help="Judge LLM shell command.")
    parser.add_argument("--output")
    args = parser.parse_args()

    answer_path = Path(args.answer)
    answer_text = answer_path.read_text(encoding="utf-8") if answer_path.exists() else args.answer

    sources_path = Path(args.sources)
    if not sources_path.exists():
        print(f"ERROR: sources file not found: {sources_path}", file=sys.stderr)
        sys.exit(2)

    try:
        sources = json.loads(sources_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: invalid sources JSON: {e}", file=sys.stderr)
        sys.exit(2)

    report = validate(answer_text, sources, args.llm_command)

    print(f"Claims with citations: {report['total_claims_with_citations']}")
    print(f"  Supported: {report['supported_count']}")
    print(f"  Unsupported (SPOOFED/WRONG): {report['unsupported_count']}")
    print(f"  Judge errors: {report['error_count']}")

    for r in report["results"]:
        if r["supported"] is False:
            print(f"\n  ✗ UNSUPPORTED: \"{r['claim'][:80]}...\" cites {r['citation_ids']}")
            print(f"    Reason: {r['reasoning']}")

    if args.output:
        Path(args.output).write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nFull report written to: {args.output}")

    print(f"\nOVERALL: {'ALL CITATIONS VALID' if report['all_valid'] else 'INVALID CITATIONS FOUND'}")
    sys.exit(0 if report["all_valid"] else 1)


if __name__ == "__main__":
    main()
