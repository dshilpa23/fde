#!/usr/bin/env python3
"""
compare_rag_variants.py — implements the one-variable-at-a-time testing
protocol from enterprise-rag-evaluation.md § One-Variable Testing Protocol.

Takes two (or more) sets of already-computed retrieval/generation metrics
(e.g., baseline vs. "added HyDE") and produces a comparison table + verdict,
enforcing the discipline that only ONE variable changed between runs — you
declare what changed, and this script keeps the experiment log honest.

This does NOT run your pipeline — it consumes the JSON output of
evaluate_retrieval.py / evaluate_generation.py for each variant and diffs them.

Input:
  --experiment-log   JSON list of runs: [{"run_id", "variable_changed",
                      "retrieval_report": <path or inline>, "generation_report": <path or inline>}]

Usage:
    python compare_rag_variants.py --experiment-log experiments.json --output comparison.md

Exit codes:
    0  success
    1  invalid input (e.g. more than one variable changed between adjacent runs without acknowledgement)
    2  file error
"""

import argparse
import json
import sys
from pathlib import Path

KEY_METRICS = [
    ("retrieval_report", "precision_at_5"),
    ("retrieval_report", "recall_at_20"),
    ("retrieval_report", "mrr"),
    ("retrieval_report", "ndcg_at_10"),
    ("generation_report", "faithfulness"),
    ("generation_report", "answer_relevancy"),
    ("generation_report", "abstention_correctness"),
    ("generation_report", "hallucination_rate"),
]


def load_report(ref) -> dict:
    """ref can be an inline dict or a path string to a JSON file."""
    if isinstance(ref, dict):
        return ref
    path = Path(ref)
    if not path.exists():
        raise FileNotFoundError(f"Report file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def extract_metric(report: dict, metric_name: str):
    agg = report.get("aggregate", {})
    return agg.get(metric_name)


def build_comparison_table(runs: list) -> list:
    rows = []
    for run in runs:
        row = {"run_id": run["run_id"], "variable_changed": run.get("variable_changed", "(baseline)")}
        for report_key, metric_name in KEY_METRICS:
            report_ref = run.get(report_key)
            if report_ref is None:
                row[metric_name] = None
                continue
            try:
                report = load_report(report_ref)
                row[metric_name] = extract_metric(report, metric_name)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                row[metric_name] = f"ERROR: {e}"
        rows.append(row)
    return rows


def compute_deltas(rows: list) -> list:
    """Add delta-from-previous-run for each metric, to make regressions/gains visible."""
    for i, row in enumerate(rows):
        if i == 0:
            continue
        prev = rows[i - 1]
        deltas = {}
        for _, metric_name in KEY_METRICS:
            curr_val, prev_val = row.get(metric_name), prev.get(metric_name)
            if isinstance(curr_val, (int, float)) and isinstance(prev_val, (int, float)):
                deltas[metric_name] = round(curr_val - prev_val, 4)
        row["_deltas_from_previous"] = deltas
    return rows


def render_markdown(rows: list) -> str:
    metric_names = [m for _, m in KEY_METRICS]
    header = "| Run | Variable Changed | " + " | ".join(metric_names) + " |"
    sep = "|---|---|" + "---|" * len(metric_names)
    lines = [header, sep]

    for row in rows:
        cells = []
        for m in metric_names:
            val = row.get(m)
            delta = row.get("_deltas_from_previous", {}).get(m)
            if val is None:
                cells.append("—")
            elif isinstance(val, str):
                cells.append(val)  # error message
            else:
                cell = f"{val:.4f}"
                if delta is not None:
                    arrow = "▲" if delta > 0 else ("▼" if delta < 0 else "=")
                    cell += f" ({arrow}{abs(delta):.4f})"
                cells.append(cell)
        lines.append(f"| {row['run_id']} | {row['variable_changed']} | " + " | ".join(cells) + " |")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Compare RAG variant experiment runs per the one-variable-at-a-time protocol.")
    parser.add_argument("--experiment-log", required=True,
                         help="JSON list of runs: [{run_id, variable_changed, retrieval_report, generation_report}]")
    parser.add_argument("--output", help="Path to write a Markdown comparison table.")
    args = parser.parse_args()

    log_path = Path(args.experiment_log)
    if not log_path.exists():
        print(f"ERROR: experiment log not found: {log_path}", file=sys.stderr)
        sys.exit(2)

    try:
        runs = json.loads(log_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: invalid experiment log JSON: {e}", file=sys.stderr)
        sys.exit(2)

    if not isinstance(runs, list) or len(runs) < 2:
        print("ERROR: experiment log must be a JSON array with at least 2 runs "
              "(a baseline plus at least one variant).", file=sys.stderr)
        sys.exit(1)

    # Discipline check: warn (don't hard-fail) if a run doesn't declare what changed
    undeclared = [r["run_id"] for r in runs[1:] if not r.get("variable_changed")]
    if undeclared:
        print(f"WARNING: run(s) {undeclared} do not declare 'variable_changed'. "
              f"Per enterprise-rag-evaluation.md, every non-baseline run must declare "
              f"exactly what was changed — otherwise you can't attribute the score delta.",
              file=sys.stderr)

    rows = build_comparison_table(runs)
    rows = compute_deltas(rows)
    markdown = render_markdown(rows)

    print(markdown)

    if args.output:
        Path(args.output).write_text(f"# RAG Variant Comparison\n\n{markdown}\n", encoding="utf-8")
        print(f"\nWritten to: {args.output}")

    sys.exit(0)


if __name__ == "__main__":
    main()
