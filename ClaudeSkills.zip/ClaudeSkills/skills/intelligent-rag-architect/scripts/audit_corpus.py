#!/usr/bin/env python3
"""
audit_corpus.py — Corpus Intelligence Analyst tooling.

Scans a directory of source documents and produces a corpus-audit report
matching the structure expected by templates/corpus-audit.md and the
Corpus Intelligence Analyst persona (agents/corpus-analyst.md).

Checks:
  - File type inventory
  - Duplicate content detection (exact hash match)
  - Near-duplicate detection (optional, requires an embedding function)
  - Suspicious / instruction-like content flags (basic heuristic scan)
  - Basic structure quality signal (heading presence for text-like formats)

Usage:
    python audit_corpus.py --input ./docs --output 02-corpus-audit.json
    python audit_corpus.py --input ./docs --output audit.json --near-duplicates

Exit codes:
    0  success
    1  input path invalid / no files found
    2  output path not writable
"""

import argparse
import hashlib
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

SUPPORTED_EXTENSIONS = {
    ".md", ".markdown", ".txt", ".pdf", ".docx", ".pptx", ".html", ".htm",
    ".csv", ".json",
}

# Heuristic patterns that suggest embedded instructions aimed at an LLM reader.
# This is a coarse first-pass flag for the Corpus Analyst persona to review by
# hand — it is NOT a security control. Do not treat a clean scan as proof of
# safety; see references/security-framework.md for the actual control.
SUSPICIOUS_PATTERNS = [
    r"ignore (all |any |the )?(previous |prior |above |earlier )?instructions",
    r"disregard (the |your )?(system |previous )?prompt",
    r"you are now",
    r"new instructions?:",
    r"do not (tell|inform|mention) the user",
    r"act as (if|though)",
    r"system\s*:\s*",
    r"\[INST\]|\[/INST\]",
    r"<\|im_start\|>|<\|im_end\|>",
]
SUSPICIOUS_RE = re.compile("|".join(SUSPICIOUS_PATTERNS), re.IGNORECASE)


def sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def read_text_safely(path: Path) -> str:
    """Best-effort text read for scanning. Binary formats (pdf/docx/pptx) are
    skipped here — this script audits inventory and text-native files;
    binary formats should be converted to GFM first (see enterprise-rag-ingestion.md)
    then audited as .md."""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def scan_file(path: Path) -> dict:
    content = read_text_safely(path)
    suspicious_hits = SUSPICIOUS_RE.findall(content) if content else []
    has_headers = bool(re.search(r"^#{1,6}\s", content, re.MULTILINE)) if content else False

    return {
        "path": str(path),
        "extension": path.suffix.lower(),
        "size_bytes": path.stat().st_size,
        "sha256": sha256_of_file(path),
        "has_markdown_headers": has_headers,
        "suspicious_content_flag": len(suspicious_hits) > 0,
        "suspicious_hit_count": len(suspicious_hits),
    }


def audit_corpus(input_dir: Path) -> dict:
    files = [
        p for p in input_dir.rglob("*")
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:
        raise ValueError(f"No supported files found under {input_dir}")

    scanned = [scan_file(p) for p in files]

    # Exact duplicate detection via hash
    by_hash = defaultdict(list)
    for s in scanned:
        by_hash[s["sha256"]].append(s["path"])
    duplicates = {h: paths for h, paths in by_hash.items() if len(paths) > 1}

    # Extension inventory
    by_ext = defaultdict(int)
    for s in scanned:
        by_ext[s["extension"]] += 1

    suspicious_files = [s["path"] for s in scanned if s["suspicious_content_flag"]]
    no_header_text_files = [
        s["path"] for s in scanned
        if s["extension"] in {".md", ".markdown"} and not s["has_markdown_headers"]
    ]

    return {
        "summary": {
            "total_files": len(scanned),
            "total_size_bytes": sum(s["size_bytes"] for s in scanned),
            "extension_inventory": dict(by_ext),
            "exact_duplicate_groups": len(duplicates),
            "files_with_suspicious_content": len(suspicious_files),
            "markdown_files_without_headers": len(no_header_text_files),
        },
        "duplicates": duplicates,
        "suspicious_content_flags": suspicious_files,
        "structure_quality_flags": {
            "markdown_without_headers": no_header_text_files,
        },
        "files": scanned,
        "recommendations": build_recommendations(
            by_ext, duplicates, suspicious_files, no_header_text_files, len(scanned)
        ),
    }


def build_recommendations(by_ext, duplicates, suspicious_files, no_header_files, total_files) -> list:
    recs = []
    non_md = sum(v for k, v in by_ext.items() if k not in {".md", ".markdown"})
    if non_md > 0:
        recs.append(
            f"{non_md} file(s) are not yet GFM Markdown. Convert before chunking — "
            f"see references/enterprise-rag-ingestion.md § Data Conversion."
        )
    if duplicates:
        pct = round(100 * sum(len(v) for v in duplicates.values()) / total_files, 1)
        recs.append(
            f"{len(duplicates)} duplicate group(s) found (~{pct}% of files affected). "
            f"Deduplicate before ingestion to avoid redundant chunks skewing retrieval."
        )
    if suspicious_files:
        recs.append(
            f"{len(suspicious_files)} file(s) flagged for instruction-like content. "
            f"Manual review required before ingestion — see references/security-framework.md "
            f"§ RAG Poisoning. This is a heuristic flag, not a security clearance."
        )
    if no_header_files:
        recs.append(
            f"{len(no_header_files)} markdown file(s) have no heading structure. "
            f"Document-Based Chunking (Tier 3) needs headers to split on — consider "
            f"Fixed-Size or Semantic chunking (Tier 1/4) for these files instead. "
            f"See references/enterprise-rag-ingestion.md § 5-Tier Sophistication Spectrum."
        )
    if not recs:
        recs.append("No major corpus quality issues detected by automated scan. Proceed to manual spot-check per agents/corpus-analyst.md.")
    return recs


def main():
    parser = argparse.ArgumentParser(description="Audit a document corpus for RAG ingestion readiness.")
    parser.add_argument("--input", required=True, help="Directory containing source documents.")
    parser.add_argument("--output", required=True, help="Path to write the JSON audit report.")
    args = parser.parse_args()

    input_dir = Path(args.input)
    output_path = Path(args.output)

    if not input_dir.exists() or not input_dir.is_dir():
        print(f"ERROR: input path does not exist or is not a directory: {input_dir}", file=sys.stderr)
        sys.exit(1)

    try:
        report = audit_corpus(input_dir)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    except OSError as e:
        print(f"ERROR: could not write output: {e}", file=sys.stderr)
        sys.exit(2)

    print(f"Corpus audit complete: {report['summary']['total_files']} files scanned.")
    print(f"Report written to: {output_path}")
    for rec in report["recommendations"]:
        print(f"  - {rec}")


if __name__ == "__main__":
    main()
