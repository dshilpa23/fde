<!-- Auto-extracted template. Source of truth: agents/retrieval-engineer.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Retrieval Contract

## Document Processing
- Source formats → converter: ...
- Chunking tier + parameters: [tier, chunk_size, overlap] — justified by corpus audit

## Metadata Schema
| Field | Type | Purpose |
|---|---|---|

## Embedding
- Model: ... — justified by: [domain fit / cost / MTEB score]
- Dimension: ...

## Indexing
- Vector index: [HNSW/IVF, DB choice] — justified by: [scale, existing stack]
- Keyword index: [BM25/PGroonga/tsvector]

## Retrieval Pipeline
- Query transformation: [none / HyDE / query expansion] — why
- Search type: [vector-only / hybrid] — weighting: [semantic%/keyword%] — why
- Stage 1 filter (if hierarchical): ...
- Top-K: ... — why this number
- Similarity threshold: ... — why (note size-bias risk if using fixed cosine cutoff)
- Reranking: [yes/no] — why (see reranking decision tree)

## Evidence Threshold
- Minimum evidence required before generation proceeds: ...
- Abstention trigger: ...
