<!-- Auto-extracted template. Source of truth: agents/agentic-rag-architect.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Agentic RAG Decision

## Justification Test
[ ] Dynamic source selection required — evidence: ...
[ ] Request decomposition required — evidence: ...
[ ] Retrieval must repeat based on intermediate findings — evidence: ...
[ ] Workflow cannot be fully defined in advance — evidence: ...

Verdict: [AGENTIC JUSTIFIED / DETERMINISTIC SUFFICIENT]

## If Deterministic: Recommended Pipeline
[Simple sequential design — no further agentic design needed]

## If Agentic: Minimal Dynamic Decision Set
- Decision 1: [what] — why it can't be deterministic
- Decision 2: [what] — why it can't be deterministic

## Routing Graph
[Route] → [trigger condition] → [next step]

## Bounds (all required, no exceptions)
| Control | Limit |
|---|---|
| Max steps | |
| Max retries | |
| Max retrieval calls | |
| Max tool calls | |
| Token budget | |
| Cost budget | |
| Timeout | |
| Loop detection | [method] |
| Duplicate-query detection | [method] |

## Human Approval Gates
- [Action] requires approval because [risk]

## Fallback / Safe Termination
- On bound exceeded: [behavior]
- On tool failure: [behavior]

## Observability
Logged per execution: route selected, queries issued, sources retrieved/rejected,
tools called + arguments, validation results, approval state, final evidence used.
NOT logged/exposed: raw internal chain-of-thought reasoning.
