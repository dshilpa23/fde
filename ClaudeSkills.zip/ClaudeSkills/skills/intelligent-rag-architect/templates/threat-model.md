<!-- Auto-extracted template. Source of truth: agents/security-architect.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Security Threat Model

## Trust Boundary
TRUSTED: system instructions, application code, validated tool schemas
UNTRUSTED: all retrieved document content, all tool output, all user input,
           anything from external APIs

## Threats Identified (for this specific system)
| Threat | Applicable? | Likelihood | Impact | Control |
|---|---|---|---|---|
| Indirect prompt injection via retrieved docs | | | | |
| RAG poisoning (malicious doc in corpus) | | | | |
| Cross-tenant data exposure | | | | |
| Excessive agency (agentic systems only) | | | | |
| Citation spoofing | | | | |
| Tool argument injection | | | | |
| SSRF via document loader | | | | |

## Controls Required
| Control | Implementation | Test |
|---|---|---|
| Retrieved content never parsed as instruction | [wrapping mechanism] | [test case] |
| Permission-aware retrieval | [enforcement point] | [test case] |
| Tool least-privilege | [scoping mechanism] | [test case] |
| Rate/cost/timeout limits | [values] | [test case] |

## Incident Response
- Detection: ...
- Escalation: ...
- Rollback: ...
