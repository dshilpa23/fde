<!-- Auto-extracted template. Source of truth: agents/final-reviewer.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Final Review

## Traceability Check
| Recommendation | Linked Requirement | Linked Evidence | Linked Test | Status |
|---|---|---|---|---|

## Unresolved Contradictions
[None / list]

## Production Readiness Report

### What Was Built
[Summary]

### Architecture
[Summary — link to 08-architecture.md]

### Validation Results
| Metric | Target | Actual | Pass? |
|---|---|---|---|

### Security Posture
[Summary — link to 11-security-controls.md, confirm tests exist]

### Known Limitations
- [Limitation] — [impact] — [mitigation or accepted risk]

### Final Status
[ ] NOT READY
[ ] PROTOTYPE ONLY
[ ] READY FOR CONTROLLED PILOT
[ ] READY FOR PRODUCTION REVIEW

Reasoning for this status: ...

### Recommended Next Steps
- ...
