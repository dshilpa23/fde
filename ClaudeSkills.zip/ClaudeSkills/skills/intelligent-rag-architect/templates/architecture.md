# RAG System Architecture — [Project Name]

> Produced at end of Stage 2, after RAG Strategist, Retrieval Engineer,
> Context Engineer, and Agentic RAG Architect artifacts are reconciled.

## 1. Problem Summary
[One paragraph, pulled from 01-problem-definition.md]

## 2. Corpus Summary
[One paragraph, pulled from 02-corpus-audit.md]

## 3. Selected Architecture
**Type:** [e.g., "Hybrid RAG + Metadata-Filtered + Temporal, hierarchical two-stage retrieval"]
**Rejected alternatives:** [list with one-line reason each]

## 4. System Diagram (text)

```
User Query
    │
    ▼
[Query Rewriting + Query Expansion]  (if applicable)
    │
    ▼
[HyDE Generation]  (if applicable)
    │
    ▼
[Stage 1: Document-Level Filter]  — vector summary match OR keyword match
    │
    ▼
[Stage 2: Chunk-Level Hybrid Scoring]  — semantic + keyword, normalized, weighted
    │
    ▼
[Reranking]  (only if justified — see retrieval contract)
    │
    ▼
[Self-Reflective Gap Analysis]  (if applicable) → up to 2 follow-up searches
    │
    ▼
[Context Assembly]  — token budget, ordering, dedup, trust-boundary wrapping
    │
    ▼
[Generation]  — grounded answer with citations
    │
    ▼
[Citation Validation]
    │
    ▼
[Abstention Check]  — if evidence insufficient, abstain instead of answering
    │
    ▼
Final Response
```

[If Agentic: insert routing decision point before Stage 1, with bounded execution loop]
[If Graph RAG: insert graph traversal in parallel with Stage 2]

## 5. Component Details
| Component | Choice | Justification |
|---|---|---|
| Vector DB | | |
| Embedding model | | |
| Chunking strategy | | |
| Search type | | |
| Reranking | | |

## 6. Data Flow — Ingestion
[Reference enterprise-rag-ingestion.md pipeline, note any project-specific deviations]

## 7. Security Posture Summary
[One paragraph — link to 10-security-threat-model.md]

## 8. Evaluation Summary
[One paragraph — link to 09-evaluation-plan.md]

## 9. Open Questions / Risks Carried Forward
- [Anything flagged but not yet resolved, to track through remaining stages]
