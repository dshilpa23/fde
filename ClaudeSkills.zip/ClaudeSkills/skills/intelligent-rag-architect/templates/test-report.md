<!-- Template for individual test-run failure reports during Stage 6 (Build & Test). -->
<!-- One of these per significant test failure investigated. Source discipline: -->
<!-- agents/implementation-engineer.md § Failure Classification and -->
<!-- references/evaluation-framework.md § Failure Taxonomy. -->

# Test Failure Report — [test_id / case_id]

## Symptom
[What was observed — e.g., "Answer stated refund window is 60 days; ground truth is 30 days"]

## Failure Classification
Selected from the taxonomy (references/evaluation-framework.md § Failure Taxonomy):

```
[ ] Parsing failure                [ ] Context-construction failure
[ ] Chunking failure               [ ] Generation failure
[ ] Metadata failure               [ ] Citation failure
[ ] Query-understanding failure    [ ] Abstention failure
[ ] Retrieval failure              [ ] Tool-selection failure
[ ] Filtering failure              [ ] Tool-execution failure
[ ] Reranking failure              [ ] Permission failure
                                    [ ] Security failure
                                    [ ] Agent-planning failure
                                    [ ] Agent-loop failure
                                    [ ] Evaluation-data failure
```

**Selected category:** [one]

## Diagnostic Trace
[Show the actual evidence: what was retrieved, what context was assembled,
what the LLM was actually given. This is what makes the classification
above defensible rather than a guess.]

- Retrieved chunks: [list chunk_ids and scores]
- Context assembled: [was the correct evidence actually in context?]
- Generation input: [what did the LLM actually see?]

## Root Cause
[One sentence, tied directly to the diagnostic trace above.]

## Fix Applied
[What was changed — and confirm it matches the failure category. E.g., a
Retrieval failure should be fixed in the retrieval contract, not the prompt.]

## Regression Test Added
[ ] Yes — added to golden dataset as case_id: [...]
[ ] No — [why not, if applicable]

## Verification
Re-ran the specific case after the fix: [PASS / FAIL]
Re-ran the full golden dataset to check for regressions elsewhere: [PASS / FAIL]
