<!-- Auto-extracted template. Source of truth: agents/business-analyst.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Problem Definition

## Users & Tasks
- Primary users: ...
- Tasks they need to accomplish: ...
- Decisions they make based on system output: ...

## System Classification
[ ] Answers questions only
[ ] Recommends actions (human decides)
[ ] Executes actions (needs approval gates)

## Success Criteria
- [Specific, measurable outcome 1]
- [Specific, measurable outcome 2]

## Supported Question Types
- ...

## Explicitly Unsupported / Out of Scope
- ...

## Is RAG Actually Needed?
Verdict: [YES / NO / PARTIAL]
Reasoning: ...
If NO or PARTIAL — recommended alternative: [static context / deterministic query / rules engine]

## Human Approval Requirements
- Action X requires approval because ...
