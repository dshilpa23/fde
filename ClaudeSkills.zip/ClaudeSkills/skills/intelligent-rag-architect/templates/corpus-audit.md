<!-- Auto-extracted template. Source of truth: agents/corpus-analyst.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Corpus Audit

## Inventory
| Source | Format | Volume | Update Frequency | Structure Quality |
|---|---|---|---|---|

## Data Quality Findings
- Duplicates: ...
- Stale/superseded content: ...
- Conflicting information: ...
- Sensitive/regulated data present: [Y/N — detail]
- Access restrictions needed: ...

## Suspicious Content Flags
- [Any instruction-like text found in documents — pass to Security Architect]

## Recommended Parsing Strategy
- [Format] → [converter/approach]

## Recommended Chunking Tier
Tier: [1-5]
Reasoning: ...

## Anticipated Retrieval Problems
- [Problem] → [why it will happen] → [who needs to handle it]
