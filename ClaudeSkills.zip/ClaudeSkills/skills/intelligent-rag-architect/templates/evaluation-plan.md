<!-- Auto-extracted template. Source of truth: agents/evaluation-scientist.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Evaluation Plan

## Level 1: Corpus/Ingestion
| Metric | Target | Method |
|---|---|---|

## Level 2: Retrieval
| Metric | Target | Method |
|---|---|---|
| Recall@20 | ≥0.80 | labeled relevance judgments |
| Precision@5 | ≥0.70 | labeled relevance judgments |

## Level 3: Generation
| Metric | Target | Method |
|---|---|---|
| Faithfulness | ≥0.75 | RAGAS / DeepEval |
| Context Recall | ≥0.80 | RAGAS |

## Level 4: Agentic (if applicable)
| Metric | Target | Method |
|---|---|---|

## Golden Dataset Composition
| Question type | Count | Source |
|---|---|---|
| Simple retrieval | | |
| Multi-hop | | |
| Temporal | | |
| Adversarial (prompt injection) | | |
| Permission-sensitive | | |
| Unsupported (should abstain) | | |

## Acceptance Criteria (must ALL pass before production)
- [ ] All Level 2-3 metrics meet threshold
- [ ] Hallucination rate < 5%
- [ ] Human evaluation completed with target personas
- [ ] Regression suite passes on every PR
