<!-- Auto-extracted template. Source of truth: agents/implementation-engineer.md -->
<!-- If you edit the persona's artifact structure, update it there, not here. -->

# Implementation Plan

## Build Sequence
| Step | Deliverable | Depends On | Test Before Proceeding |
|---|---|---|---|
| 1. Corpus inspection | | | |
| 2. Data preparation | | | |
...

## Task Breakdown
- [ ] Task 1 — [contract this satisfies]
- [ ] Task 2 — [contract this satisfies]

## Test Plan
| Test | Type | Pass Criteria |
|---|---|---|

## Observability Plan
- Logged events: ...
- Dashboards/alerts: ...
