<div align="center">

# 🧠 Intelligent RAG Architect

**A portable AI skill that designs, builds, evaluates, and secures production-grade RAG systems — including Graph RAG and Agentic RAG.**

Not a checklist. A structured, evidence-gated engineering workflow that argues with itself before it lets you ship.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Scripts: stdlib only](https://img.shields.io/badge/dependencies-zero-brightgreen)](scripts/)
[![Personas](https://img.shields.io/badge/personas-11-blue)](agents/)
[![Reference guides](https://img.shields.io/badge/reference%20guides-11-blue)](references/)

[Quick Start](#-quick-start) •
[How It Works](#-how-it-works) •
[Why It's Different](#-why-its-different) •
[Repository Map](#-repository-map) •
[Scripts](#-runnable-tooling) •
[Examples](#-worked-examples)

</div>

---

## The problem this solves

Most RAG advice is one of two things: a shallow "load, chunk, embed, retrieve"
tutorial, or a wall of unstructured best practices with no mechanism to
actually apply them. Meanwhile, real RAG failures are boring and specific —
a bad chunk boundary, an unfiltered permission, a citation that doesn't
actually say what it claims — and they get misdiagnosed because nothing
forces you to separate *retrieval* problems from *generation* problems
before reaching for a fix.

**Intelligent RAG Architect** is an AI engineering skill that runs a disciplined,
BMad-inspired engineering workflow instead. The assistant sequentially adopts 11
specialist personas — business analyst, corpus auditor, RAG strategist,
retrieval engineer, context engineer, agentic architect, evaluation
scientist, security architect, adversarial reviewer, implementation
engineer, final reviewer — each producing a written, evidence-backed
artifact before the next one begins.

The system's default posture is **skepticism**. It will not recommend Graph
RAG because your corpus happens to contain named entities. It will not
recommend Agentic RAG because it sounds more sophisticated. Both have to
clear an explicit, evidence-based bar — and the skill ships the bar, not
just the advice to use one.

---

## ⚡ Quick Start

### 1. Install the skill

```bash
git clone https://github.com/ranjan-sumit/intelligent-rag-architect-skill.git
```

Use the repository as a skill folder in your AI assistant's skill/plugin
mechanism, or run the scripts directly. See [full install instructions](#-installation) below.

### 2. Just describe what you need

```
"Design a RAG system for our internal support ticket search. We have
50,000 tickets referencing exact error codes, and support agents should
only see tickets from their own product line."
```

The assistant will state which personas it's invoking, work through the relevant
stages, and push back on unjustified complexity — e.g. explicitly rejecting
Agentic RAG or Graph RAG if your use case doesn't clear the bar.

### 3. Or run the tooling standalone

Every script is dependency-free stdlib Python. Wire your own LLM in via a
`--llm-command` flag and they run anywhere, including CI:

```bash
python3 scripts/audit_corpus.py --input ./my_docs --output audit.json
python3 scripts/generate_golden_set.py --output golden.json --total 100
python3 scripts/test_permissions.py --users users.json \
    --query-command "python run_query.py" --all-doc-ids all_docs.json
python3 scripts/generate_readiness_report.py --config manifest.json --output report.md
```

---

## 🎯 Why It's Different

| | Typical RAG advice | Intelligent RAG Architect |
|---|---|---|
| **Architecture choice** | "Try RAG" | Explicit necessity check — rejects RAG if a deterministic query or static context would do |
| **Graph RAG** | Recommended if the corpus has entities | Requires a 3-condition justification test **and** a measured >85% extraction-precision gate before proceeding |
| **Agentic RAG** | Default because it's more capable | Requires 2-of-4 justified conditions; the skill actively names "agentic theater" as an anti-pattern to catch |
| **Debugging a bad answer** | "Try a better prompt" | An 18-category failure taxonomy — you classify the failure *before* touching the LLM |
| **Security** | A checklist item: "consider prompt injection" | Runnable red-team scripts: `test_prompt_injection.py`, `test_rag_poisoning.py`, `test_permissions.py` — with exit codes that block CI |
| **"Is this production ready?"** | A vibe | A gated status (`NOT READY` → `PROTOTYPE ONLY` → `CONTROLLED PILOT` → `PRODUCTION REVIEW`) computed from actual test evidence, not attestation alone |
| **Citations** | "Add sources" | Citation *correctness* validation — checks the cited passage actually supports the specific claim, not just that a citation number exists |

---

## 🔬 How It Works

The skill runs through **sequential role-play, not parallel agents.**
Each persona reads its own mandate, produces a written artifact, and hands
off explicitly — a disciplined paper trail, not a vibe-based conversation.

```mermaid
flowchart TD
    A["🔍 STAGE 1 — Discover<br/>Business Analyst + Corpus Analyst"] --> B
    B["🏗️ STAGE 2 — Decide<br/>RAG Strategist + Retrieval Engineer<br/>+ Context Engineer + Agentic RAG Architect"] --> C
    C["📊 STAGE 3 — Evaluate & Secure<br/>Evaluation Scientist + Security Architect"] --> D
    D["⚔️ STAGE 4 — Challenge<br/>Adversarial Reviewer"] --> E{Must-Fix<br/>found?}
    E -- yes --> B
    E -- no --> F["📋 STAGE 5 — Plan<br/>Implementation Engineer"]
    F --> G["🛠️ STAGE 6 — Build & Test<br/>Failure-classified implementation"]
    G --> H["✅ STAGE 7 — Final Review<br/>Final Reviewer + Adversarial Reviewer"]
    H --> I{{"NOT READY · PROTOTYPE ONLY<br/>CONTROLLED PILOT · PRODUCTION REVIEW"}}
```

The workflow **scales to the task** — a full 7-stage run is for real system
builds. A quick pattern question ("what's HyDE?") gets answered directly
from `references/rag-pattern-catalog.md`, no ceremony required. See
`SKILL.md § Scaling the Workflow to Task Size`.

---

## 📁 Repository Map

```
intelligent-rag-architect/
│
├── SKILL.md ─────────────── Orchestrator. Always loaded. Routes to everything below.
│
├── agents/ ──────────────── 11 persona mandates (sequential role-play)
│   ├── business-analyst.md          "Is RAG even needed?"
│   ├── corpus-analyst.md            "What's actually in this data?"
│   ├── rag-strategist.md            "Which of 20 architectures fits?"
│   ├── retrieval-engineer.md        "Concrete chunking/embedding/search params"
│   ├── context-engineer.md          "What exactly enters the prompt?"
│   ├── agentic-rag-architect.md     "Does this genuinely need an agent?"
│   ├── evaluation-scientist.md      "How do we know it's good?"
│   ├── security-architect.md        "How does this get attacked?"
│   ├── adversarial-reviewer.md      "Prove it. I'll try to break it."
│   ├── implementation-engineer.md   "Build it, in the right order."
│   └── final-reviewer.md            "Is it actually ready?"
│
├── references/ ──────────── Loaded on demand — the real depth (~16.5K words)
│   ├── rag-selection-guide.md              20 architectures, evidence-based use/don't-use
│   ├── graph-rag-guide.md                  Full KG-RAG: construction, retrieval, security
│   ├── rag-pattern-catalog.md              15 patterns at full depth + 25 quick-reference
│   ├── agentic-rag-patterns.md             Justification test, bounded execution, anti-patterns
│   ├── context-engineering-guide.md        Trust boundary, token budget, 11-item risk catalogue
│   ├── evaluation-framework.md             4-level evaluation + 18-category failure taxonomy
│   ├── security-framework.md               Full threat catalogue, controls, test templates
│   ├── production-readiness-checklist.md   The final gate, as a decision tree
│   └── enterprise-rag-{ingestion,retrieval,evaluation}.md   Implementation-depth layer
│
├── schemas/ ─────────────── JSON Schema for every structured artifact
│   └── context-packet · retrieval-result · citation · evaluation-case · agent-trace
│
├── scripts/ ─────────────── 12 scripts, zero dependencies, ~2,300 lines, all tested
│   └── see § Runnable Tooling below
│
├── templates/ ───────────── 12 fillable artifact templates (synced with agents/)
│
└── examples/ ────────────── 5 worked architectures — genuinely different outcomes
    ├── classic-rag/         Simplest justified case — two alternatives explicitly rejected
    ├── hybrid-rag/          Vector-only measured at Recall@5=0.31 on error codes → hybrid picked
    ├── corrective-rag/      Graph RAG considered and rejected (62% extraction precision < 85% gate)
    ├── graph-rag/           Graph RAG justified, gate passed (88% precision), built
    └── agentic-rag/         The one case where Agentic RAG clears all 4 justification conditions
```

---

## 🛠 Runnable Tooling

Every script in `scripts/` is stdlib-only Python 3 — no `pip install`
required, safe to drop straight into CI. Each supports `--help` and uses
exit codes `0` (pass) / `1` (check failed) / `2` (invalid input).

| Script | Stage | What it actually checks |
|---|---|---|
| `audit_corpus.py` | Discover | File inventory, exact-duplicate detection, suspicious-content heuristic scan |
| `validate_metadata.py` | Decide | Every chunk has required metadata before ingestion proceeds |
| `generate_golden_set.py` | Evaluate | Scaffolds a golden dataset with a **correct category distribution**, not just random questions |
| `evaluate_retrieval.py` | Evaluate | Precision@K, Recall@K, MRR, nDCG, **permission-filter correctness** |
| `evaluate_generation.py` | Evaluate | Faithfulness, Answer Relevancy, Abstention correctness via your own LLM judge |
| `validate_citations.py` | Evaluate | Does the cited passage *actually* support the specific claim it's attached to? |
| `test_abstention.py` | Evaluate | Focused gate: does the system stay quiet when it should, on unsupported/ambiguous questions? |
| `test_rag_poisoning.py` | Secure | Injects a poisoned document, checks the pipeline doesn't repeat its false claims or obey embedded instructions |
| `test_prompt_injection.py` | Secure | Direct override, role-play bypass, encoding bypass, unauthorized tool calls |
| `test_permissions.py` | Secure | Full user × query matrix — checks **zero** unauthorized-document leaks, not "mostly zero" |
| `compare_rag_variants.py` | Build & Test | Enforces the one-variable-at-a-time experiment discipline, with delta arrows |
| `generate_readiness_report.py` | Final Review | Aggregates every report above into the final status — **hard-blocks on missing security evidence**, even if metrics look great |

<details>
<summary><strong>See a real example: catching a permission leak</strong></summary>

```bash
$ python3 test_permissions.py --users users.json \
    --query-command "python run_query.py" --all-doc-ids all_docs.json

Running permission matrix: 2 user(s) x 5 probe(s) = 10 test(s)...

  ✗ CRITICAL LEAK: user=alice query="Show me all documents...."
      Unauthorized docs leaked: ['doc_3', 'doc_secret_tenant_a']

Clean: 4  Leaks: 6  Harness errors: 0
Permission filter correctness: 40.00% (target: 100%)

CRITICAL: unauthorized document access detected. This BLOCKS production
readiness per production-readiness-checklist.md.
Exit code: 1
```

This isn't hypothetical — it's the actual output from testing a
deliberately-broken mock pipeline during this skill's own development.

</details>

---

## 📚 Worked Examples

Five architectures, five genuinely different outcomes — because if the
workflow recommended the same design for every use case, the workflow would
have failed:

| Example | Architecture chosen | The deciding evidence |
|---|---|---|
| [`classic-rag/`](examples/classic-rag/) | Classic RAG | Hybrid and Agentic both explicitly considered and rejected — corpus doesn't need either |
| [`hybrid-rag/`](examples/hybrid-rag/) | Hybrid + Metadata-Filtered | Vector-only scored Recall@5 = 0.31 on error-code queries; hybrid scored 0.89 |
| [`corrective-rag/`](examples/corrective-rag/) | Corrective RAG | 15% of corpus has corrupted OCR — Graph RAG considered, rejected at 62% extraction precision |
| [`graph-rag/`](examples/graph-rag/) | Graph RAG (Hybrid Vector+Graph) | 3/3 justification conditions met, 88% extraction precision cleared the gate |
| [`agentic-rag/`](examples/agentic-rag/) | Agentic RAG, tightly bounded | 4/4 justification conditions met — the one case in this catalog where it's clearly warranted |

---

## 🧭 Design Principles

- **The simplest architecture that meets requirements wins, by default.**
  Every advanced pattern has an explicit `§ When NOT to use` section, and
  the personas are written to apply it before reaching for it.
- **Retrieved content is always untrusted data, never an instruction.**
  Every control in `references/security-framework.md` implements this one rule.
- **Evaluation and security plans exist before implementation is finalized** —
  not bolted on after the fact.
- **A control without a test is a claim, not a guarantee.** Every `test_*.py`
  script exists because a checklist item isn't evidence.
- **Never change more than one variable per evaluation run.**
  `compare_rag_variants.py` enforces this mechanically, with delta arrows
  showing exactly what each change bought you.
- **A single unauthorized-document leak blocks production readiness.**
  `permission_filter_correctness` must be exactly 100% — not "high."

---

## 🚫 What This Deliberately Does Not Do

- **No true parallel autonomous subagents.** The skill is designed to execute as
  one sequential reasoning process. The "multi-agent" design here is
  disciplined **sequential role-play with explicit handoffs** — not
  concurrent agents debating in real time.
- **No embedded LLM calls in the Python scripts.** `--llm-command` /
  `--query-command` / `--pipeline-command` flags let you wire in your own
  model, keeping every script provider-agnostic and safe to run in CI
  without embedding credentials.
- **No "production ready" verdict from metrics alone.**
  `generate_readiness_report.py` hard-blocks on missing security test
  evidence — even if every generation metric clears its threshold.

---

## 📦 Installation

<details>
<summary><strong>Skill-enabled AI assistants</strong></summary>

1. Download or clone this repository.
2. Zip the `intelligent-rag-architect/` folder (the one containing
   `SKILL.md` at its root), or upload the folder directly depending on your
   client's skill-upload mechanism.
3. Add it as a skill. Skill-enabled assistants read `SKILL.md`'s frontmatter to know when to
   trigger it, then loads `agents/`, `references/`, `templates/`,
   `schemas/`, and `scripts/` on demand as the workflow proceeds.

</details>

<details>
<summary><strong>Codex or local skill path</strong></summary>

Place the `intelligent-rag-architect/` directory under your project's skills
path. `SKILL.md`'s YAML frontmatter (`name`, `description`) is what the
assistant uses to decide when to invoke it.

</details>

<details>
<summary><strong>Standalone scripts</strong></summary>

Every script in `scripts/` is a normal, dependency-free Python 3 file. Run
them directly in CI or locally:

```bash
python3 scripts/audit_corpus.py --input ./my_docs --output audit.json
python3 scripts/evaluate_retrieval.py --golden golden.json --results results.json
python3 scripts/generate_readiness_report.py --config manifest.json --output report.md
```

</details>

---

## 🤝 Contributing

This skill is intentionally opinionated. If a threshold, pattern
recommendation, or architectural default looks wrong, open an issue with
the evidence — the skill's own design principle (see
`agents/adversarial-reviewer.md`) is that every recommendation should be
challengeable and revisable, not treated as fixed.

## License

[MIT](LICENSE)

---

<div align="center">

Built as a portable AI skill. Read [`SKILL.md`](SKILL.md) for the full
orchestration logic, or just start a conversation and describe what you're building.

</div>
