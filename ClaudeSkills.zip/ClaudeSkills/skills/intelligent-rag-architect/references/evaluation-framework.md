# Evaluation Framework — 4 Levels

Used by: **Evaluation Scientist** persona (Stage 3), **Implementation Engineer**
(failure classification, Stage 6).

For metric thresholds, RAGAS/DeepEval code, and golden dataset construction
mechanics, see `enterprise-rag-evaluation.md` — this file focuses on the
4-level separation and failure taxonomy that make diagnosis possible.

---

## Why Separate Into 4 Levels

A single "is the answer good?" score cannot tell you *where* to fix the
system. Separating evaluation by pipeline stage makes root-causing mechanical
instead of guesswork.

```
Level 1: Corpus/Ingestion  →  Is the data itself good?
Level 2: Retrieval          →  Did we find the right evidence?
Level 3: Generation         →  Did we use the evidence correctly?
Level 4: Agentic (if used)  →  Did the agent make the right decisions?
```

A failure at Level 3 (generation) cannot be fixed by improving Level 2
(retrieval) — but they produce identical-looking symptoms ("wrong answer")
without this separation.

---

## Level 1: Corpus / Ingestion Evaluation

| Metric | What it checks | Method |
|---|---|---|
| Parsing quality | Did format conversion preserve meaning? | Sample manual review of GFM output vs. source |
| Table preservation | Are tables still structured, not flattened prose? | Sample review |
| Metadata completeness | Does every chunk have source/date/section? | Automated: `assert all(c.metadata for c in chunks)` |
| Duplicate detection | Is the same content indexed multiple times? | Embedding similarity clustering across corpus |
| Version detection | Are superseded documents flagged/excluded? | Metadata audit |
| OCR quality (if scanned docs) | Is extracted text accurate? | Sample review against source images |
| Sensitive-data identification | Is PII/regulated data flagged appropriately? | Automated PII scanner + manual spot-check |
| Chunk coherence | Does each chunk read as a complete thought? | Sample human review |
| Chunk boundary quality | Are chunks split at sensible structural points? | Sample human review |

---

## Level 2: Retrieval Evaluation

Requires labeled relevance judgments (which documents/chunks are ground-truth
relevant per query).

| Metric | Formula | Target |
|---|---|---|
| Recall@K | Relevant in top-K / total relevant | ≥0.80 @K=20 |
| Precision@K | Relevant in top-K / K | ≥0.70 @K=5 |
| Hit rate | % queries with ≥1 relevant result in top-K | ≥0.90 |
| MRR | Mean(1/rank of first relevant result) | ≥0.70 |
| nDCG@10 | Position-weighted graded relevance | ≥0.75 |
| Expected-document retrieval | Did the known-correct document appear at all? | ≥0.90 |
| Expected-section retrieval | Did the known-correct section appear (hierarchical)? | ≥0.85 |
| Metadata-filter correctness | Did filters correctly include/exclude? | 100% (binary correctness required) |
| Version-selection correctness | Was the current (not stale) version returned? | 100% |
| Permission-filter correctness | Zero unauthorized documents returned | 100% (security-critical) |
| Retrieval diversity | Are results topically varied, not near-duplicates? | Qualitative + duplicate-rate metric |
| Retrieval latency | Time from query to ranked results | P95 <2000ms |

Code for Precision@K, Recall@K, MRR: see `enterprise-rag-evaluation.md § Pure
Retrieval Metrics`.

---

## Level 3: Generation Evaluation

See `enterprise-rag-evaluation.md § The 6 Canonical Metrics` for full
definitions, thresholds, and RAGAS/DeepEval implementation.

| Metric | Target |
|---|---|
| Faithfulness | ≥0.75 |
| Groundedness | ≥0.75 (regulated domains) |
| Answer Relevancy | ≥0.80 |
| Correctness (vs. ground truth) | ≥0.75 |
| Completeness | Qualitative + human eval |
| Citation presence | 100% for factual claims |
| Citation correctness | ≥0.90 (see `rag-pattern-catalog.md § 12`) |
| Claim-to-evidence alignment | Per-claim faithfulness check |
| Unsupported-claim rate | <5% |
| Abstention correctness | ≥0.90 on out-of-scope test set |
| Clarification correctness | Qualitative human eval on ambiguous test set |
| Format compliance | 100% (schema validation) |
| Safety compliance | 100% (policy test set) |

---

## Level 4: Agentic Evaluation (only if Agentic RAG is in use)

| Metric | What it checks | Target |
|---|---|---|
| Route-selection accuracy | Did the router pick the right route? | ≥0.90 vs. labeled test set |
| Tool-selection accuracy | Right tool for the task? | ≥0.90 |
| Tool-argument correctness | Were tool calls parameterized correctly? | ≥0.95 |
| Task-success rate | Did the full multi-step task complete correctly? | Domain-specific target |
| Step efficiency | Steps used vs. minimum necessary | Track trend, flag outliers |
| Retry efficiency | Did retries actually resolve the issue? | >50% retry success rate |
| Loop rate | % of executions that hit loop detection | <1% (near-zero expected) |
| Human-approval compliance | Were all required gates actually triggered? | 100% (security-critical) |
| Permission compliance | Did the agent respect access boundaries? | 100% (security-critical) |
| Recovery from tool failure | Graceful degradation on tool error? | Qualitative + test cases |
| Cost per successful task | $ spent per completed task | Track trend, set budget alert |
| Latency per successful task | Time to complete | P95 within SLA |

---

## Failure Taxonomy (mandatory classification before fixing anything)

When any test fails, classify it into exactly one category before changing
code. This is the single most important discipline in the whole framework —
skipping it leads to "just try a different model" debugging, which wastes
time and often doesn't fix the actual problem.

```
LEVEL 1 (Ingestion)          LEVEL 2 (Retrieval)          LEVEL 3 (Generation)
─────────────────────        ─────────────────────        ─────────────────────
Parsing failure               Retrieval failure             Generation failure
Chunking failure               Filtering failure             Citation failure
Metadata failure               Reranking failure             Abstention failure

                              LEVEL 2.5 (Query)             LEVEL 3.5 (Context)
                              ─────────────────────         ─────────────────────
                              Query-understanding failure    Context-construction failure

LEVEL 4 (Agentic)             LEVEL 5 (Security)            LEVEL 6 (Evaluation itself)
─────────────────────        ─────────────────────         ─────────────────────
Tool-selection failure         Permission failure             Evaluation-data failure
Tool-execution failure         Security failure               (bad golden dataset entry)
Agent-planning failure
Agent-loop failure
```

**Diagnostic questions per category:**

| Category | Diagnostic question |
|---|---|
| Parsing failure | Does the GFM output match the source document's meaning? |
| Chunking failure | Is the relevant content split across chunks awkwardly, or is a chunk too big/small? |
| Metadata failure | Is required metadata (date, source, permission) missing or wrong on the chunk? |
| Query-understanding failure | Did query rewriting/expansion correctly capture user intent? |
| Retrieval failure | Was the relevant chunk even in the candidate set before ranking? |
| Filtering failure | Did metadata/permission/temporal filters wrongly exclude or include? |
| Reranking failure | Did reranking demote a relevant result below the cutoff? |
| Context-construction failure | Was relevant evidence retrieved but dropped/truncated/buried during assembly? |
| Generation failure | Was correct evidence present in context but the LLM ignored or misused it? |
| Citation failure | Is the cited source real but doesn't actually support the specific claim? |
| Abstention failure | Did the system answer confidently with insufficient evidence, or abstain when it had enough? |
| Tool-selection failure | Did the agent pick the wrong tool/route for this query type? |
| Tool-execution failure | Was the right tool picked but called with wrong arguments, or did it error? |
| Agent-planning failure | Did the agent's step sequence fail to reach a state where it had enough evidence? |
| Agent-loop failure | Did the agent repeat the same action without making progress? |
| Permission failure | Did an unauthorized document/action get through despite access controls? |
| Security failure | Did the system follow an instruction embedded in untrusted content? |
| Evaluation-data failure | Is the golden dataset entry itself wrong (bad ground truth, mislabeled relevance)? |

**Rule:** Do not change the LLM, the prompt, or the embedding model until the
failure category is identified. A generation failure and a retrieval failure
produce an identical-looking "wrong answer" from the outside but require
completely different fixes.
