# 03 — Evaluation Reference

Covers: the 4 canonical metrics → golden dataset → RAGAS/DeepEval → CI/CD pipeline
→ failure mode diagnostics → human eval → root cause analysis.

---

## The Two Failure Surfaces

RAG fails in exactly two places. Measure them separately.

```
RETRIEVAL FAILURES            GENERATION FAILURES
─────────────────             ───────────────────
Wrong documents retrieved  →  Hallucination (answer not in context)
Right doc, wrong rank      →  Answer ignores retrieved context
Missing documents entirely →  Off-topic response
Stale / outdated content   →  Verbosity / irrelevance

Metrics: Context Precision    Metrics: Faithfulness
         Context Recall                Answer Relevancy
```

---

## Why Traditional NLP Metrics Fail for RAG

Do not use BLEU or ROUGE for RAG evaluation. They measure surface-level text
overlap against a reference string — they cannot assess whether an answer is
factually grounded in retrieved context, or whether it actually answers the question.

```
BLEU / ROUGE → surface n-gram overlap → irrelevant for RAG correctness
RAG metrics  → semantic grounding, retrieval coverage → what actually matters
```

Teams migrating from NLP pipelines: establish BLEU/ROUGE baselines only as a
historical reference point, then switch to the metrics below.

---

## The 6 Canonical RAG Metrics (2026 Standard)

| Metric | What it measures | Target | Failure signal |
|---|---|---|---|
| **Faithfulness** | Are all claims in the answer supported by retrieved context? (per-claim check) | ≥ 0.75 | Hallucination |
| **Groundedness** | What fraction of sentences in the answer are grounded in context? (per-sentence) | ≥ 0.75 | Subtle ungrounded claims |
| **Answer Relevancy** | Does the answer actually address the question? | ≥ 0.80 | Off-topic / verbose |
| **Context Precision** | Of what was retrieved, how much was relevant? | ≥ 0.70 | Noisy retrieval |
| **Context Recall** | Of what was needed, how much was retrieved? | ≥ 0.80 | Missing documents |
| **Verbosity** | Is the response appropriately concise? | Domain-specific | Padding / over-explanation |

**Faithfulness vs. Groundedness — the distinction matters:**
- Faithfulness = "Did the LLM make things up?" — checks claims against context at answer level
- Groundedness = "Are individual sentences supported?" — per-sentence granularity
- A response can have high faithfulness (no fabricated facts) but low groundedness
  (many sentences that technically aren't traceable to a specific retrieved passage)
- Measure both in regulated domains (healthcare, legal, BFSI)

**Hallucination Rate** (computed metric, distinct from faithfulness):
```python
def hallucination_rate(answers: list[str], contexts: list[list[str]], judge_llm) -> float:
    """Fraction of answers containing at least one hallucinated claim."""
    hallucinated = sum(
        1 for ans, ctx in zip(answers, contexts)
        if not all_claims_grounded(ans, ctx, judge_llm)
    )
    return hallucinated / len(answers)
# Target: < 5% hallucination rate in production
```

**Verbosity** (optional, tune to use case):
```python
# Simple proxy: response token count vs. query complexity score
verbosity_score = len(response.split()) / expected_length(query)
# > 2.0 = likely verbose; tune threshold per domain
```

**Priority order for implementation:**
1. Faithfulness first — hallucination is the highest-risk failure
2. Answer Relevancy second — catches off-topic responses
3. Groundedness — add for regulated domains
4. Context Precision + Recall — add when optimising retrieval specifically
5. Verbosity — optional, tune to use case requirements

**Minimum test set sizes:**
- 30 examples — directionally useful
- 100 examples — statistically reliable scores
- 500+ examples — enables slicing by query type / domain / complexity

---

## Failure Mode Diagnostic Map

Use metric combinations to identify *root cause*, not just symptoms.

| Pattern | Root Cause | Fix |
|---|---|---|
| Low Faithfulness + High Context Recall | LLM generation problem | Improve prompt / switch model |
| High Faithfulness + Low Context Recall | Retrieval gap | Fix chunking, HyDE, hybrid search |
| Low Context Precision + Low Faithfulness | Noisy retrieval poisoning generation | Tighten similarity threshold, add metadata filters |
| All metrics low | Pipeline misconfigured | Start from ingestion audit |
| Good metrics, bad user feedback | Wrong eval questions | Rebuild golden dataset with real users |
| Faithfulness stable, Recall drops after update | New chunk quality is worse | Audit ingestion for the updated documents |

### ⚠️ The Silent Failure Problem

RAG systems that are not thoroughly evaluated produce **silent failures** — answers
that appear coherent and confident but are subtly wrong. A legal RAG can score
0.91 faithfulness on an offline eval set while missing a key statute on multi-hop
questions in production, because context recall was never measured.

Rule: **Never rely on a single metric.** Faithfulness staying high while recall
drops is a retrieval regression, not a success — the LLM is answering confidently
from partial context.

---

## Golden Dataset Construction

The foundation of all evaluation. Build this before running any metrics.

**Step 1: Source questions from real users / stakeholders**
- Cover all major use cases (80% of query types)
- Include: simple, complex, multi-part, misspelled, date-filtered queries
- Include edge cases: empty result scenarios, cross-document multi-hop

**Step 2: Create reference answers**
- Human-written ground truth answers per question
- Annotate which documents / chunks are the expected sources
- Keep a "do not include" list (documents that should NOT appear)

**Step 3: Validate the golden set**
- At least 2 human reviewers agree on each reference answer
- Cover each major document category / domain in the corpus
- Refresh when corpus changes significantly

**Template:**
```python
golden_dataset = [
    {
        "question": "What is the refund policy for enterprise subscriptions?",
        "ground_truth": "Enterprise subscriptions can be refunded within 30 days...",
        "expected_source_ids": ["doc_42", "doc_87"],
        "query_type": "policy",
        "complexity": "simple"
    },
    # ...
]
```

---

## RAGAS Integration (Exploration & Development)

Use RAGAS during development and for establishing baselines.

```python
from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    context_precision,
    context_recall,
)
from datasets import Dataset

# Build eval dataset from golden set + your RAG pipeline outputs
eval_data = Dataset.from_dict({
    "question":     [q["question"]    for q in golden_dataset],
    "contexts":     [retrieve(q["question"]) for q in golden_dataset],  # your pipeline
    "answer":       [generate(q["question"]) for q in golden_dataset],  # your pipeline
    "ground_truth": [q["ground_truth"] for q in golden_dataset],
})

results = evaluate(
    eval_data,
    metrics=[faithfulness, answer_relevancy, context_precision, context_recall]
)

print(results)
# faithfulness: 0.82 ✅  answer_relevancy: 0.79 ❌  context_recall: 0.74 ❌
```

**Interpreting output:**
```
faithfulness ≥ 0.75   ✅ pass | ❌ fail → hallucination problem
answer_relevancy ≥ 0.80 ✅ pass | ❌ fail → generation problem
context_precision ≥ 0.70 ✅ pass | ❌ fail → retrieval noisy
context_recall ≥ 0.80   ✅ pass | ❌ fail → retrieval missing docs
```

---

## Pure Retrieval Metrics

Use these when specifically debugging the retrieval component.
Requires labeled relevance judgments (which documents are ground-truth relevant).

| Metric | Formula | Target | Use when |
|---|---|---|---|
| Precision@K | Relevant in top-K / K | ≥ 0.70 @K=5 | Narrow-domain KB |
| Recall@K | Relevant in top-K / total relevant | ≥ 0.80 @K=20 | Broad corpus |
| MRR | Mean(1 / rank of first relevant) | ≥ 0.70 | Ranking quality matters |
| NDCG@10 | Graded relevance, position-weighted | ≥ 0.75 | Ranking with partial relevance |

```python
def precision_at_k(retrieved_ids: list, relevant_ids: set, k: int) -> float:
    top_k = retrieved_ids[:k]
    return len(set(top_k) & relevant_ids) / k

def recall_at_k(retrieved_ids: list, relevant_ids: set, k: int) -> float:
    top_k = retrieved_ids[:k]
    return len(set(top_k) & relevant_ids) / len(relevant_ids)

def mrr(retrieved_ids: list, relevant_ids: set) -> float:
    for rank, doc_id in enumerate(retrieved_ids, start=1):
        if doc_id in relevant_ids:
            return 1.0 / rank
    return 0.0
```

---

## Automated Test Dataset Generation

Don't have a golden dataset yet? Generate one from your existing indexed documents.

```python
def generate_eval_dataset_from_index(documents: list[dict], n_questions: int, llm) -> list[dict]:
    """Generate question-answer pairs from indexed documents using LLM."""
    dataset = []
    for doc in sample(documents, n_questions):
        response = llm.generate(f"""Read this document excerpt and generate:
1. A realistic user question that this text answers
2. The correct answer, grounded only in this text

Document: {doc['content']}

Return JSON: {{"question": "...", "ground_truth": "...", "source_id": "{doc['id']}"}}""")
        dataset.append(json.loads(response))
    return dataset

# Start with 50 auto-generated, then human-review and curate to 100+
# Auto-generation catches obvious cases; human review catches nuance
```

---

## Pointwise vs. Pairwise Evaluation

**Pointwise** — judge scores a single response on a numerical scale (0–5).
Use for: establishing absolute baselines, regression detection, CI/CD gates.

```python
# Example pointwise prompt for LLM-as-judge
POINTWISE_PROMPT = """Rate this RAG response on a scale of 0-5 for {criterion}:
Question: {question}
Context: {context}
Response: {response}
Score (0-5) and brief reason:"""
```

**Pairwise** — judge compares two responses and picks the better one.
Use for: A/B testing chunking strategies, comparing embedding models, model selection.

```python
PAIRWISE_PROMPT = """Compare these two RAG responses to the same question.
Question: {question}
Context: {context}
Response A: {response_a}
Response B: {response_b}
Which is better (A/B/tie) and why?"""
```

**Caution on LLM judge self-grading bias:** Never use the same model as both
generator and evaluator. If GPT-4o generated the answer, use Claude or Gemini
as the judge — and vice versa. Same-model judging inflates scores systematically.

---

## Toolchain Lifecycle

Use the right tool for each stage — don't use one tool for everything.

```
Development / Exploration   →  RAGAS
                               Fast iteration, metric baselines, easy setup

CI/CD Gate (pre-deploy)     →  DeepEval
                               pytest integration, regression detection,
                               auto-fail on metric drop

Production Monitoring       →  Patronus | Langfuse | Lynx
                               Trace-level hallucination detection,
                               real user query monitoring, drift alerts

Google Cloud / GCP stacks   →  Vertex AI Gen AI Evaluation Service
                               Prebuilt + custom metrics, Vertex AI Experiments
                               for storing & comparing runs over time
```

### DeepEval CI/CD Integration

```python
# test_rag.py — runs in CI pipeline on every PR
from deepeval import assert_test
from deepeval.test_case import LLMTestCase
from deepeval.metrics import (
    FaithfulnessMetric,
    AnswerRelevancyMetric,
    ContextualPrecisionMetric,
    ContextualRecallMetric,
)
import pytest

faithfulness_metric       = FaithfulnessMetric(threshold=0.75)
answer_relevancy_metric   = AnswerRelevancyMetric(threshold=0.80)
context_precision_metric  = ContextualPrecisionMetric(threshold=0.70)
context_recall_metric     = ContextualRecallMetric(threshold=0.80)

@pytest.mark.parametrize("test_case", load_golden_dataset())
def test_rag_pipeline(test_case):
    contexts = retrieve(test_case["question"])
    answer   = generate(test_case["question"], contexts)

    tc = LLMTestCase(
        input=test_case["question"],
        actual_output=answer,
        expected_output=test_case["ground_truth"],
        retrieval_context=contexts,
    )
    assert_test(tc, [
        faithfulness_metric,
        answer_relevancy_metric,
        context_precision_metric,
        context_recall_metric,
    ])
```

---

## One-Variable Testing Protocol (Google Cloud / Root Cause Method)

**Rule:** Change exactly one variable per evaluation run.
Multi-variable changes mask which modification caused the score shift.

```
Variables to test one at a time:
  □ Chunk size          (try: 256 / 512 / 800 / 1024 tokens)
  □ Chunk overlap       (try: 10% / 20% / 50%)
  □ Chunking strategy   (fixed → document-based → semantic)
  □ Embedding model     (try 2-3 models on your domain data)
  □ Similarity threshold
  □ Hybrid weight split (70/30 → 50/50 → 30/70)
  □ Top-K value         (5 / 10 / 20)
  □ LLM model / prompt for generation
  □ Summary generation model (for document-level index)
  □ Number of self-reflection follow-up searches (0 / 1 / 2)

Never change more than one at a time.
Record all scores in a comparison table before changing anything.
```

**Experiment log template:**
```
| Run | Variable Changed       | Faithfulness | Ans.Rel | Ctx.Prec | Ctx.Rec | Notes |
|-----|------------------------|-------------|---------|----------|---------|-------|
| 01  | Baseline               | 0.71        | 0.74    | 0.65     | 0.72    |       |
| 02  | chunk_size 512→800     | 0.73        | 0.76    | 0.68     | 0.78    | +     |
| 03  | Added HyDE             | 0.73        | 0.79    | 0.71     | 0.84    | ✅    |
```

---

## Human Evaluation Protocol

Automated metrics miss tone, clarity, and subtle ambiguity.
Run human eval after automated metrics hit target thresholds.

**When:** After automated scores pass thresholds; before production launch.
**Who:** Mix of technical + non-technical users matching target personas.
**How:**

1. Identify 3–5 user personas matching the RAG system's target users
2. Recruit representative sample (ideally sit with users for follow-up questions)
3. Score on: accuracy, clarity, completeness, tone appropriateness
4. Track: questions users rephrased (signals retrieval gap) + outright failures

**Human eval criteria (rate 1–5):**
```
□ Factual accuracy — is the answer correct?
□ Completeness — does it cover all aspects of the question?
□ Clarity — is the response easy to understand?
□ Source trustworthiness — do citations feel relevant?
□ Conciseness — is there unnecessary verbosity?
```

---

## Evaluation Cost Economics

LLM-as-judge (RAGAS / DeepEval) costs approximately **$0.001–$0.003 per test case**.
A 100-question golden set costs ~$0.10–$0.30 per full evaluation run.
Run evaluations freely during development; gate CI/CD runs on PR merge only.

**When human evaluation is essential (LLM-judge cannot replace):**
- Evaluating tone and brand voice
- Detecting subtle ambiguity in answers
- Regulated domains (legal, medical) — liability requires human sign-off
- When the LLM judge model is the same as the generation model (self-grading bias)
- Final user acceptance testing before production launch

---

## Alternative Evaluation Frameworks

| Framework | Strength | Use when |
|---|---|---|
| **RAGAS** | Easy setup, 4 core metrics, test data generation | Default choice for most teams |
| **DeepEval** | pytest native, CI/CD integration, 14+ metrics | Production CI/CD gating |
| **ARES** | Multi-dimensional scoring, prediction-powered inference | Needs ~150 human-annotated samples for calibration |
| **Vertex AI Eval** | GCP-native, prebuilt + custom metrics, experiment tracking | Already on GCP |
| **RGB** | Robustness evaluation across 4 RAG failure modes | Testing robustness, not just accuracy |
| **CRAG** | Multi-hop + aggregation questions, cross-document synthesis | Complex enterprise queries with cross-document reasoning |

> RAGAS for exploration → DeepEval for CI/CD → Patronus/Langfuse for production
> is the recommended lifecycle for most teams not on GCP.

---

## 7-Week Implementation Sequence

For teams starting from scratch:

```
Week 1  → Set up ingestion pipeline + hierarchical DB schema
Week 2  → Basic retrieval working (vector search only, no hybrid yet)
Week 3  → Add HyDE + hybrid search; establish RAGAS baseline
Week 4  → Add query expansion + self-reflective gap analysis
Week 5  → Build golden dataset (100 questions); run full eval suite
Week 6  → One-variable tuning loop until all 4 metrics hit targets
Week 7  → Human eval with target personas; configure DeepEval CI/CD gate
```

---

## EU AI Act Compliance Note

If deploying in Europe or to European customers:
- Document your evaluation methodology and metric thresholds
- Keep evaluation logs with timestamps (audit trail)
- Record human evaluation participants and sign-offs
- Maintain version history of your golden dataset
- RAGAS / DeepEval run logs count as technical documentation under Article 11

---

## Evaluation Checklist (Pre-Production Gate)

```
DATASET
□ Golden dataset: ≥ 100 questions, human-reviewed, covers all use cases
□ Includes: simple, complex, multi-part, misspelled, date-filtered, multi-hop queries
□ At least 2 human reviewers agreed on each reference answer
□ Auto-generated supplement reviewed and curated

METRICS — must all pass before launch
□ Faithfulness      ≥ 0.75
□ Groundedness      ≥ 0.75  (regulated domains)
□ Answer Relevancy  ≥ 0.80
□ Context Precision ≥ 0.70
□ Context Recall    ≥ 0.80
□ Hallucination Rate < 5%

RETRIEVAL
□ Retrieval latency P95 < 2000ms
□ Tested at production-like data volume (not just dev sample)
□ Embedding model version stored alongside every vector

INGESTION
□ Idempotent ingestion tested (re-run → no duplicates)
□ Incremental sync tested (document update → old chunks removed, new chunks added)
□ Raw document cleaning / GFM conversion verified

EDGE CASES
□ Empty result handling tested (graceful degradation, no crash)
□ Malformed document handling tested
□ Multi-tenant access control tested (user A cannot see user B's docs)
□ Date-filtered queries return correct temporal scope

PROCESS
□ One-variable experiment log completed (baseline → tuned, each change documented)
□ Human evaluation completed with target personas (technical + non-technical)
□ DeepEval CI/CD gate configured on main branch (auto-fail on metric regression)
□ Production monitoring connected (Langfuse / Patronus / Vertex AI Experiments)
□ EU AI Act documentation complete (if applicable)
```
