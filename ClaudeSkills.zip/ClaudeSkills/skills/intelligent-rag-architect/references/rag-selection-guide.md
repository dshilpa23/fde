# RAG Selection Guide — 20 Architectures

Used by: **RAG Architecture Strategist** persona (Stage 2).

For each architecture: what it is, when to use, when NOT to use. This is a
decision framework, not a pattern implementation guide — for implementation
detail on the 15 core patterns, see `rag-pattern-catalog.md`.

---

## 1. No RAG

**Use when:** Information is stable and fits safely in a system prompt. Task is
transformation, summarisation, classification, or generation with no external
knowledge dependency. Deterministic rules or a DB query answer it reliably.

**Do not use when:** Knowledge changes, is too large for context, or needs
per-query freshness.

---

## 2. Prompt-Context Approach

**Use when:** Knowledge is small enough to fit in context safely, changes
infrequently, citation/retrieval complexity would be overkill.

**Do not use when:** Corpus exceeds a few thousand tokens or updates frequently —
you'll pay context cost on every call for no benefit over retrieval.

---

## 3. Classic RAG

**Use when:** A question can be answered from one or a few retrieved passages.
Corpus is reasonably clean. One retrieval pass is usually sufficient.

**Do not use when:** Questions require synthesizing many documents, exact
keyword matching matters more than semantics, or multi-hop reasoning is needed.

---

## 4. Hybrid RAG

**Use when:** Exact terms, identifiers, product codes, policy numbers, or
domain-specific language matter. Vector-only retrieval demonstrably misses
keyword-sensitive queries in testing.

**Do not use when:** Corpus is purely conversational/narrative with no
codes/IDs/proper-noun-heavy content — the added complexity buys little.

---

## 5. Metadata-Filtered RAG

**Use when:** Access level, geography, department, version, product, date, or
confidentiality affects which documents are even eligible to return.

**Do not use when:** All documents are equally accessible/relevant to all users —
skip the filtering complexity.

---

## 6. Hierarchical / Parent-Child RAG

**Use when:** Small chunks retrieve well but complete answers need the larger
surrounding section. Documents have nested headings or long procedures.

**Do not use when:** Documents are already short and self-contained — the
two-level indexing overhead isn't earning its keep.

---

## 7. Multi-Query RAG

**Use when:** User questions contain multiple concepts, or user terminology
differs from document terminology (query expansion improves recall measurably).

**Do not use when:** Query vocabulary reliably matches document vocabulary —
added latency for no recall gain.

---

## 8. Decomposition RAG

**Use when:** A single question contains multiple subquestions that need
separate evidence collection, then combination.

**Do not use when:** Most queries are single-intent — decomposition adds latency
and complexity with no payoff.

---

## 9. Reranked RAG

**Use when:** Initial retrieval shows high recall but weak precision (right
documents are in the candidate set but not top-ranked). Similar documents
compete for the same query.

**Do not use when:** Hierarchical hybrid search with HyDE already gets you to
~90% quality — reranking adds ~5% for roughly 2x latency. Diminishing returns.
See `enterprise-rag-retrieval.md § Reranking — When to Use / Skip`.

---

## 10. Corrective RAG (CRAG)

**Use when:** Retrieved evidence quality is unpredictable — the system should
grade evidence relevance and retry, rewrite the query, or fall back to another
source (e.g., web search) when retrieval confidence is low.

**Do not use when:** Retrieval is already reliably high-quality — added grading
step is unnecessary latency.

**Architecture:** Retrieve → grade each chunk relevance (LLM or classifier) →
if all low-confidence: rewrite query and retry OR escalate to broader source →
if any high-confidence: proceed to generation.

---

## 11. Self-Reflective RAG (Self-RAG)

**Use when:** System needs explicit evidence grading, answer self-critique, and
controlled retries — and the added latency is justified by the accuracy requirement.

**Do not use when:** Latency SLA is tight (<2s) and single-pass retrieval already
meets quality bar.

**Architecture:** See `enterprise-rag-retrieval.md § Self-Reflective RAG` for full
implementation (gap analysis, max-2 follow-up searches).

---

## 12. Graph RAG / Knowledge Graph RAG (KG-RAG)

**Use when:** ALL of:
- Relationships between entities are more important than isolated passages
- The task requires multi-hop reasoning across connected data (e.g., "which
  vendors used by subsidiaries of Company X had contract disputes?")
- A graph is genuinely available OR can be reliably constructed from the corpus

**Do not use when:** The corpus merely *contains* named entities — that alone
is not justification. Most enterprise Q&A is answerable from passage retrieval
alone; Graph RAG's infra and construction cost is only worth it when the
*relationships themselves* are the answer, not just a feature of the text.

**Full implementation detail:** `graph-rag-guide.md`

---

## 13. Multimodal RAG

**Use when:** Relevant knowledge lives in images, diagrams, tables, audio,
video, or scanned documents where text extraction alone loses meaning
(e.g., a wiring diagram, a chart showing a trend, an audio recording of a meeting).

**Do not use when:** Visual/audio content is decorative or fully captured by
existing text descriptions — added multimodal embedding pipeline is unjustified cost.

---

## 14. Federated / Multi-Source RAG

**Use when:** Knowledge comes from separate systems with different permissions,
freshness requirements, schemas, or retrieval methods that should NOT be merged
into one index (e.g., HR system + engineering wiki + customer support tickets,
each with different access rules).

**Do not use when:** Sources can be safely unified into one index without losing
permission granularity or freshness guarantees — federation adds orchestration
complexity you don't need.

---

## 15. SQL / Structured-Data RAG

**Use when:** Answers depend on structured records, aggregates, transactions,
or numeric filtering ("What was Q3 revenue by region?"). Use a deterministic
query, not embedded facts.

**Do not use when:** The question needs narrative/unstructured context — SQL
can't answer "why did the customer churn," only "how many customers churned."

---

## 16. Temporal RAG

**Use when:** Knowledge changes over time and current/historical/effective-date/
version-specific answers are required ("what was the refund policy in 2023 vs now?").

**Do not use when:** Corpus has no meaningful temporal dimension — adds
unnecessary date-filtering complexity.

---

## 17. Personalised RAG

**Use when:** User role, preferences, history, permissions, or profile
materially affect retrieval and response — and privacy/access controls can be
explicitly enforced at the data layer.

**Do not use when:** All users should see the same answer to the same
question — personalisation adds risk (inconsistent answers, privacy exposure)
without benefit.

---

## 18. Cache-Assisted RAG

**Use when:** High query repetition (FAQs, common support questions) makes
caching retrieval + generation results cost-effective.

**Do not use when:** Queries are highly varied — cache hit rate will be too
low to justify the invalidation complexity.

---

## 19. Conversation-Aware / Memory-Augmented RAG

**Use when:** Multi-turn conversations need context from earlier turns folded
into retrieval (e.g., "what about last quarter?" referring to an earlier-named metric).

**Do not use when:** Each query is independent — memory adds context-poisoning
surface area for no benefit.

---

## 20. Agentic RAG

**Use when:** See `agentic-rag-patterns.md § Justification Test` — at least 2 of:
dynamic source selection, request decomposition, retrieval-based-on-intermediate-
findings, or workflow that cannot be fully defined in advance.

**Do not use when:** A deterministic pipeline (possibly combining several of
architectures 1-19 above) can solve the problem reliably. This is the single
most over-recommended architecture in the industry — hold it to a high bar.

---

## Quick Combination Note

Real systems often combine architectures — e.g., Hybrid + Metadata-Filtered +
Temporal is a common enterprise combination. This guide lists them separately
for decision clarity, but the RAG Strategist's output should specify the
**combination** that fits, not force a single label.
