# Agentic RAG Patterns

Used by: **Agentic RAG Architect** persona (Stage 2).

Default posture: **skeptical.** Agentic RAG is the most over-recommended
architecture in the industry. This reference exists to make it rigorous when
justified, and to make rejection easy and well-reasoned when not.

---

## Justification Test

Apply before designing anything. Count how many hold:

```
[ ] The system must dynamically choose among multiple knowledge sources
    (not just "search one index" — genuinely different sources with
    different retrieval methods)
[ ] The system must decompose complex, multi-part requests where the
    decomposition itself depends on the specific request (not a fixed template)
[ ] Retrieval must repeat based on intermediate findings — the system doesn't
    know what to search for next until it sees what the first search returned
[ ] The workflow genuinely cannot be fully defined in advance — a flowchart
    drawn today would be wrong for a meaningful fraction of real requests
```

**Fewer than 2 checked → reject agentic behaviour.** Use a deterministic
pipeline, possibly combining several patterns from `rag-pattern-catalog.md`
(e.g., Router-Based Retrieval + Self-RAG covers a lot of apparent "agentic"
need without open-ended autonomy).

**2+ checked → agentic behaviour is justified**, but design the *smallest*
set of dynamic decisions that need it — not a system where everything is agentic.

---

## Route Vocabulary (fixed, don't invent new ones per project)

```
DIRECT_RESPONSE          — no retrieval needed, answerable from context/instructions
CLASSIC_RETRIEVAL        — standard single-pass hybrid search
FILTERED_RETRIEVAL       — retrieval with metadata/permission/temporal filters
MULTI_QUERY_RETRIEVAL    — query expansion, parallel search, merge
DECOMPOSED_RETRIEVAL     — break into subquestions, retrieve each, combine
GRAPH_RETRIEVAL          — traverse knowledge graph (see graph-rag-guide.md)
STRUCTURED_DATA_TOOL     — SQL or structured query, not retrieval
EXTERNAL_API_TOOL        — live external data (stock price, order status, etc.)
MULTI_SOURCE_RETRIEVAL   — federated search across separate systems
CLARIFICATION_REQUIRED   — ambiguous request, ask the user
HUMAN_APPROVAL_REQUIRED  — high-stakes action, gate before proceeding
REFUSE                   — out of scope or against policy
```

Using a fixed vocabulary (rather than inventing new route names per project)
keeps the system auditable and makes the observability logs comparable across
projects.

---

## Bounded Execution — All Required, No Exceptions

Every agentic RAG system must define every one of these before implementation:

| Control | Purpose | Typical starting value |
|---|---|---|
| Max steps | Prevent runaway multi-step chains | 5-8 |
| Max retries | Prevent infinite retry loops | 2-3 |
| Max retrieval calls | Cap cost/latency from repeated search | 4-6 |
| Max tool calls | Cap cost/latency from repeated tool use | 5-10 |
| Token budget | Hard cap on context + generation tokens | Set per use case |
| Cost budget | Hard $ cap per request | Set per use case |
| Timeout | Wall-clock cap | 10-30s typical |
| Loop detection | Catch A→B→A→B cycles | Track visited-state hash |
| Duplicate-query detection | Don't re-run an identical search | Hash + cache within request |
| Evidence threshold | Minimum confidence before generating | Tie to Faithfulness target |

```python
class AgentBounds:
    max_steps: int = 6
    max_retries: int = 2
    max_retrieval_calls: int = 4
    max_tool_calls: int = 6
    token_budget: int = 8000
    cost_budget_usd: float = 0.10
    timeout_seconds: int = 20

    def check(self, state: "AgentState") -> Optional[str]:
        """Returns a violation reason, or None if within bounds."""
        if state.steps >= self.max_steps:
            return "MAX_STEPS_EXCEEDED"
        if state.retrieval_calls >= self.max_retrieval_calls:
            return "MAX_RETRIEVAL_CALLS_EXCEEDED"
        if state.elapsed_seconds >= self.timeout_seconds:
            return "TIMEOUT"
        if state.is_looping():  # e.g., same route+query hash seen 2x
            return "LOOP_DETECTED"
        return None
```

**On bound violation:** Always define explicit fallback behavior — never let
the system just stop with no response. Typical fallback: return best evidence
gathered so far with an explicit note that the search was incomplete, or abstain.

---

## Human Approval Gates

Required whenever the agent's action is:
- Irreversible (sending an email, executing a transaction, deleting data)
- High-stakes even if reversible (a medical or legal recommendation)
- Outside the system's core competency (anything the Business Analyst
  persona flagged as requiring approval in `01-problem-definition.md`)

```python
async def execute_with_approval(action: dict, approval_required: bool):
    if approval_required:
        return {"status": "PENDING_APPROVAL", "action": action,
                "message": f"This will {action['description']}. Approve?"}
    return await execute(action)
```

Never let an agent bypass an approval gate through a different route — audit
that all paths to a sensitive action go through the same gate.

---

## Observability Requirements

Log every execution with:

```json
{
  "route_selected": "DECOMPOSED_RETRIEVAL",
  "queries_issued": ["...", "..."],
  "sources_retrieved": ["doc_1", "doc_42"],
  "sources_rejected": ["doc_7 — below relevance threshold"],
  "tools_called": [{"name": "sql_query", "args": {...}, "result_summary": "..."}],
  "validation_results": {"citations_valid": true, "faithfulness_check": "passed"},
  "approval_state": "not_required",
  "final_evidence_used": ["doc_1#chunk_3", "doc_42#chunk_1"],
  "bounds_hit": null,
  "total_steps": 3,
  "total_cost_usd": 0.008
}
```

**Do NOT log or expose:** raw internal chain-of-thought reasoning text. Log
*decisions and evidence*, not the model's private deliberation. This satisfies
both the transparency requirement (users/auditors can see what happened) and
the "don't expose hidden chain-of-thought" principle in the main SKILL.md.

---

## Common Anti-Pattern: Agentic Theater

Signs the "agentic" design is theater rather than substance:
- Every query goes through the same route regardless of complexity
  (the router never actually routes differently)
- The agent "decides" things a simple if/else would decide identically
- No bound is ever actually hit in testing because the workflow is
  secretly deterministic underneath
- Retries never fire because the first attempt always succeeds (the retry
  logic is unexercised complexity)

If any of these show up during Stage 4 Adversarial Review, that's grounds to
send the design back to Stage 2 with a recommendation to simplify to a
deterministic pipeline.
