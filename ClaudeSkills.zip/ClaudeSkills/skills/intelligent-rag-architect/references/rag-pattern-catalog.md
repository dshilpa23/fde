# RAG Pattern Catalog

Used by: **Retrieval Engineer**, **Agentic RAG Architect** personas, and for direct
quick-answer questions ("what's HyDE?", "how does corrective RAG work?").

**Structure:** 15 patterns get full 10-section treatment (the patterns that carry
the most practical weight). All remaining patterns from the original spec get a
compact entry in § Quick Reference at the end — enough to make an informed
decision without bloat.

**Full-depth patterns:** Query Rewriting, HyDE, Hybrid Search, Parent-Child Retrieval,
Contextual/Late Chunking, Document Summary Indexing, Cross-Encoder Reranking,
Corrective RAG, Self-RAG, Multi-Hop/Decomposition, Router-Based Retrieval,
Citation Validation, Abstention & Clarification, Agentic Retrieval Graphs,
Access-Aware Retrieval.

---

## 1. Query Rewriting

**Problem solved:** Raw user queries are often malformed, ambiguous, or use
different vocabulary than the corpus ("how 2 train NN" vs. corpus language
"neural network training methodology").

**When to use:** Always, as a cheap first-pass filter — low cost, consistent
benefit. Especially valuable for consumer-facing or non-expert user bases.

**When not to use:** Never skip entirely, but keep it lightweight (single LLM
call) unless testing shows more sophisticated rewriting is needed.

**Architecture:** User query → lightweight LLM → cleaned/normalized query →
proceed to retrieval. Can run in parallel with HyDE generation.

**Benefits:** Catches typos, expands abbreviations, normalizes terminology,
near-zero added latency with a fast model.

**Costs:** One extra LLM call per query (~$0.0001-0.0005 with a cheap model).

**Failure modes:** Over-rewriting can drift from user intent — always show
the rewritten query in logs for debugging.

**Security implications:** Low risk, but validate rewritten query doesn't
inject anything into downstream SQL/graph queries if used there.

**Evaluation method:** A/B test retrieval recall with vs. without rewriting
on a set of known-malformed queries.

**Minimal implementation:**
```python
async def rewrite_query(raw_query: str, llm) -> str:
    prompt = f"""Rewrite this search query to be clear and well-formed,
preserving the original intent exactly. Fix typos and abbreviations.
Query: "{raw_query}"
Rewritten:"""
    return await llm.generate(prompt, max_tokens=100)
```

---

## 2. HyDE (Hypothetical Document Embeddings)

**Problem solved:** Embedding-space mismatch between short queries and long
documents — see full treatment in `enterprise-rag-retrieval.md § HyDE`.

**When to use:** Whenever queries are short/vague relative to document length
(the common case in enterprise search).

**When not to use:** Highly structured queries that already resemble document
language (e.g., exact product code lookups) — HyDE adds no value there.

**Architecture, implementation, evaluation:** See
`enterprise-rag-retrieval.md § [1] HyDE` for the full code and dual-embedding pattern.

**Cross-reference note:** This is the single highest-leverage pattern in the
entire catalog for enterprise Q&A systems — implement it by default unless
query type detection shows it's not needed.

---

## 3. Hybrid Search (Dense + Sparse)

**Problem solved:** Pure vector search under-weights exact terms (codes, IDs,
proper nouns); pure keyword search misses semantic paraphrases.

**When to use:** Almost always in production enterprise RAG — see
`rag-selection-guide.md § 4. Hybrid RAG`.

**When not to use:** Very small, purely conversational corpora where keyword
matching adds no signal over semantic search alone.

**Architecture, implementation:** See `enterprise-rag-retrieval.md § [3] Stage 2`
for the full normalized-score combination pattern and adaptive weighting.

**Failure modes:** Adding raw cosine + BM25 scores without normalization —
they have different distributions (see size-bias note in ingestion guide).

---

## 4. Parent-Child (Hierarchical) Retrieval

**Problem solved:** Small chunks retrieve precisely but lack surrounding
context; large chunks have context but retrieve imprecisely.

**When to use:** Long structured documents (manuals, contracts, technical
docs) where the answer's *evidence* is a small passage but *understanding*
requires the surrounding section.

**When not to use:** Short, already-atomic documents (FAQ entries, short
policy snippets) — no parent/child distinction needed.

**Architecture:**
```
Index small chunks (child) for precise retrieval matching
Store parent_id linking each child chunk to its containing section
On retrieval: search children, return parent section (or child + surrounding siblings)
```

**Implementation:** This is exactly the two-level `documents` + `document_chunks`
hierarchical schema in `enterprise-rag-ingestion.md § Database Schema` — the
document-level summary is one "parent" tier; you can add a middle tier
(section-level) for deeper hierarchies if documents are very long.

**Benefits:** Best of both worlds — retrieval precision + generation context completeness.

**Costs:** More complex schema, slightly higher storage (parent text duplicated
or referenced).

**Evaluation method:** Compare answer completeness scores (human eval) between
child-only vs. parent-returned context on long-document test questions.

---

## 5. Contextual / Late Chunking

**Problem solved:** Chunks lose reference to surrounding context ("it's more
than 3.85 million..." — what's "it"?).

**When to use:** Always for enterprise content with pronouns, cross-references,
or section dependencies — which is most enterprise content.

**Full implementation:** See `enterprise-rag-ingestion.md § Context Path
Breadcrumbs` and `§ Late Chunking` — covers both the AST-breadcrumb approach
and true late chunking (embedding chunks as an array together).

**Note:** These are two complementary techniques often confused as one:
- Context Path Breadcrumbs = prepending hierarchy text to each chunk (cheap, simple)
- Late Chunking = embedding all chunks together so vectors retain inter-chunk
  awareness (requires an embedding API that supports it, e.g., Jina AI)
Use both together for best results; breadcrumbs alone if the embedding API
doesn't support late chunking.

---

## 6. Document Summary Indexing

**Problem solved:** Searching every chunk in a large corpus is slow and noisy;
most queries only need information from a small subset of documents.

**When to use:** Corpora above roughly 500 documents, or whenever query
latency matters at scale.

**When not to use:** Small corpora (<100 documents) where the overhead of a
second index tier outweighs the search-space reduction benefit.

**Architecture:** Generate a concise (~150-200 token) LLM summary per document,
embed the summary separately, use it as a coarse Stage-1 filter before chunk-level
search. Full implementation: `enterprise-rag-ingestion.md § Document Summary Generation`.

**Benefits:** Dramatically reduces search space; enables the two-stage
hierarchical hybrid search pattern that's the backbone of the enterprise
retrieval design in this skill.

**Costs:** One extra LLM call per document at ingestion time (cheap with
Gemini Flash Lite / GPT-4o-mini — roughly $0.0001-0.00015/doc).

**Evaluation method:** Measure Stage-1 recall — does the true relevant
document survive the coarse filter? Target: >95% document-level recall before
tightening the filter threshold.

---

## 7. Cross-Encoder Reranking

**Problem solved:** Initial retrieval (bi-encoder) is fast but less precise
than a cross-encoder that jointly scores query+document pairs.

**When to use:** When initial retrieval shows high recall but weak precision
in your Precision@K metrics, AND latency budget allows ~200-500ms extra.

**When not to use:** When hierarchical hybrid search + HyDE already achieves
target precision — see the explicit go/no-go tree in
`enterprise-rag-retrieval.md § Reranking — When to Use / Skip`. This is a
"last resort, not a default" pattern.

**Implementation:** See `enterprise-rag-retrieval.md § [5] Reranking` for
both Cohere-hosted and self-hosted (sentence-transformers CrossEncoder) code.

**Failure mode:** Adding reranking as a default habit rather than a measured
response to a demonstrated precision problem — wastes latency budget.

---

## 8. Corrective RAG (CRAG)

**Problem solved:** Retrieved evidence may be irrelevant or insufficient, and
naively generating from bad evidence produces confident hallucination.

**When to use:** Retrieval quality is variable/unpredictable (heterogeneous
corpus, broad query types) and the cost of a wrong answer is high enough to
justify an evidence-grading step.

**When not to use:** Retrieval is already consistently high-quality (measured,
not assumed) — the grading step adds latency for marginal benefit.

**Architecture:**
```python
async def corrective_rag(query: str, retriever, llm):
    results = await retriever.search(query)

    # Grade each retrieved chunk's relevance
    grades = await asyncio.gather(*[
        grade_relevance(query, chunk, llm) for chunk in results
    ])

    high_confidence = [r for r, g in zip(results, grades) if g == "relevant"]

    if not high_confidence:
        # All evidence graded irrelevant — corrective action
        rewritten_query = await rewrite_for_retry(query, llm)
        results = await retriever.search(rewritten_query)
        # Or: escalate to a broader/different source (web search, different index)

    return high_confidence or results  # proceed with best available evidence
```

**Benefits:** Catches retrieval failures before they become generation
failures; provides a natural retry/escalation path.

**Costs:** One grading LLM call per retrieved chunk (can batch), plus
potential retry latency.

**Failure modes:** Grading LLM itself can be wrong (false "relevant" on
subtly off-topic content) — periodically audit the grader against human labels.

**Evaluation method:** Measure the delta in Context Precision with vs. without
CRAG grading on a test set with intentionally noisy retrieval.

---

## 9. Self-RAG (Self-Reflective RAG)

**Problem solved:** Single-pass retrieval misses information needed for
multi-hop or complex questions; the system doesn't know what it doesn't know.

**When to use:** Complex enterprise Q&A where multi-hop questions are common
and latency budget allows 1-2 extra retrieval rounds.

**Full implementation:** See `enterprise-rag-retrieval.md § [6] Self-Reflective
RAG` — gap analysis, max-2 follow-up searches, the ReAct-pattern connection.

**Distinction from Corrective RAG:** CRAG grades and retries when evidence is
*bad*. Self-RAG checks whether evidence is *complete* and fills gaps — they
solve different problems and can be combined (grade first, then check completeness).

---

## 10. Multi-Hop / Decomposition Retrieval

**Problem solved:** A question contains multiple subquestions requiring
separately-retrieved evidence that must then be combined
("Compare Q3 revenue growth between our top 2 regions by headcount").

**When to use:** Analytical/comparative questions are a meaningful fraction
of real user queries (check this in your golden dataset composition).

**When not to use:** Query set is dominated by single-fact lookups —
decomposition overhead isn't earning its keep.

**Architecture:**
```python
async def decomposed_retrieval(query: str, llm, retriever):
    subquestions = await decompose(query, llm)  # LLM breaks query into parts
    sub_results = await asyncio.gather(*[
        retriever.search(sq) for sq in subquestions
    ])
    combined_evidence = merge_and_dedupe(sub_results)
    return combined_evidence, subquestions  # keep subquestions for citation tracing
```

**Benefits:** Handles genuinely compound questions that single-pass retrieval cannot.

**Costs:** Decomposition LLM call + N parallel retrieval calls instead of 1.

**Evaluation method:** Specific test set of compound/comparative questions;
measure whether all sub-facts appear in the final context (a recall metric
per subquestion, not just overall).

---

## 11. Router-Based Retrieval

**Problem solved:** Different query types need different retrieval strategies
(a structured-data question needs SQL, a policy question needs document
retrieval) — a single fixed pipeline can't serve both well.

**When to use:** Corpus/system spans multiple source types (structured DB +
unstructured docs + APIs) or query types vary enough that one strategy
underserves some of them.

**When not to use:** Single homogeneous corpus and query type — routing adds
a classification step with no payoff.

**Architecture:**
```python
ROUTES = {
    "structured_data": query_sql_tool,
    "document_lookup": hybrid_document_retriever,
    "graph_relationship": graph_rag_retriever,
    "direct_answer": None,  # no retrieval needed
}

async def route_query(query: str, llm) -> str:
    classification = await llm.generate(f"""Classify this query's best retrieval route.
Routes: {list(ROUTES.keys())}
Query: {query}
Return only the route name.""")
    return classification.strip()
```

This is the same routing concept used in Agentic RAG — see
`agentic-rag-patterns.md` for the full bounded routing-graph version with
approval gates and observability.

**Benefits:** Right tool for the right question; avoids forcing structured
questions through unstructured retrieval or vice versa.

**Costs:** Router classification adds one LLM call; misclassification sends
queries down the wrong path.

**Evaluation method:** Route-selection accuracy against a labeled test set
of queries with known-correct routes.

---

## 12. Citation Validation

**Problem solved:** An LLM can produce citations that *look* valid ([1], [2])
but don't actually correspond to claims supported by that source — citation
presence is not the same as citation correctness.

**When to use:** Always, in any RAG system where users will trust cited
sources (which is most enterprise RAG).

**Architecture:**
```python
async def validate_citations(answer: str, sources: dict, llm) -> dict:
    """Check each citation actually supports its associated claim."""
    claims = extract_claims_with_citations(answer)  # regex or LLM-based
    validation_results = []

    for claim, citation_ids in claims:
        cited_text = " ".join(sources[cid]["text"] for cid in citation_ids)
        is_supported = await llm.generate(f"""Does this source support this claim?
Claim: {claim}
Source: {cited_text}
Answer YES or NO with brief reason.""")
        validation_results.append({
            "claim": claim, "citations": citation_ids,
            "supported": "YES" in is_supported
        })

    unsupported = [r for r in validation_results if not r["supported"]]
    return {"all_valid": len(unsupported) == 0, "unsupported_claims": unsupported}
```

**Benefits:** Catches citation spoofing (see `security-framework.md`) and
plain generation errors before the answer reaches the user.

**Costs:** One validation LLM call per claim — can be batched, or sampled
(validate 100% in eval, sample in production for cost).

**Evaluation method:** This IS an evaluation method — it's the direct
implementation of the "Citation Correctness" metric in `evaluation-framework.md`.

---

## 13. Abstention & Clarification

**Problem solved:** Systems that always attempt an answer will confidently
answer questions they have no evidence for. Systems that never ask for
clarification will guess at ambiguous questions.

**When to use:** Always — this is a baseline requirement, not an optional
pattern, for any production RAG system.

**Architecture:**
```python
async def generate_with_abstention(query: str, evidence: list, llm) -> dict:
    if not evidence or all(e["score"] < EVIDENCE_THRESHOLD for e in evidence):
        return {"type": "ABSTAIN",
                "message": "I don't have enough information to answer this confidently."}

    if is_ambiguous(query):  # multiple plausible interpretations
        return {"type": "CLARIFICATION_REQUIRED",
                "message": f"Did you mean {interpretation_a} or {interpretation_b}?"}

    answer = await generate_grounded_answer(query, evidence, llm)
    return {"type": "ANSWER", "content": answer}
```

**Benefits:** Prevents confident hallucination on out-of-scope or ambiguous
questions — directly reduces the highest-risk failure mode (Faithfulness failures).

**Costs:** Requires tuning the evidence threshold — too aggressive abstention
frustrates users, too lax lets hallucination through.

**Evaluation method:** Dedicated test set of genuinely unsupported and
ambiguous questions (see `evaluation-framework.md` golden dataset composition)
— measure abstention/clarification correctness specifically, separate from
answer quality on supported questions.

---

## 14. Agentic Retrieval Graphs

**Problem solved:** Some workflows genuinely need dynamic, multi-step
decision-making that can't be predetermined — but must remain bounded and
observable, not open-ended agent autonomy.

**When to use:** See the Justification Test in `agentic-rag-patterns.md` —
this pattern only applies once Agentic RAG itself is justified.

**Full implementation:** `agentic-rag-patterns.md` — routing vocabulary,
bounded execution controls, observability requirements.

---

## 15. Access-Aware Retrieval

**Problem solved:** Not all users should see all documents — retrieval must
respect permissions at the data layer, not as an afterthought filter.

**When to use:** Any multi-user enterprise system with differentiated access
(which is nearly all of them).

**When not to use:** Single-tenant, single-permission-level systems only.

**Architecture:** Enforce at the database query level, not in application
code post-retrieval — see `enterprise-rag-ingestion.md § Database Schema`
`document_user_access` table and its join in every retrieval query in
`enterprise-rag-retrieval.md § Stage 1`.

**Critical rule:** Never filter for permissions *after* retrieval — always
filter *during* the DB query. Post-filtering means the LLM (or at minimum
the retrieval logs) briefly held unauthorized content.

**Security implications:** This is a primary attack surface — see
`security-framework.md § Access-Control Bypass` and `§ Metadata-Filter Bypass`.

**Evaluation method:** Permission-filter correctness test suite — attempt
retrieval as User A for documents only User B should see; must return zero results.

---

## Quick Reference — All Other Patterns

Compact entries for patterns not given full treatment above. Each is a
decision point, not an implementation guide — combine with the patterns
above as needed.

| Pattern | One-line guidance |
|---|---|
| **Basic retrieve-then-generate** | The default baseline every other pattern improves on. Start here, add complexity only where evidence justifies it. |
| **Query expansion** | Generate query variants (synonyms, reformulations) before search. Cheap recall boost; combine with query rewriting. |
| **Multi-query retrieval** | Run several query variants in parallel, merge results. Good for vocabulary-mismatch-prone corpora. |
| **Semantic chunking** | Group by embedding similarity breaks rather than structure. Use for unstructured/mixed content; see Tier 4 in ingestion guide. |
| **Small-to-big retrieval** | Retrieve small precise chunks, expand to larger context on demand. Same family as Parent-Child. |
| **Multi-vector retrieval** | Multiple embeddings per document (e.g., one per paragraph + one summary). Use when a single vector underrepresents long documents. |
| **ColBERT-style late interaction** | Token-level embeddings with late interaction scoring. High precision, high storage cost — use for high-value narrow-domain search only. |
| **Reciprocal rank fusion** | Merge multiple ranked lists (e.g., dense + sparse) by rank position rather than raw score — avoids the score-normalization problem entirely. Simple and robust; consider as an alternative to weighted score combination. |
| **Context deduplication** | Remove near-duplicate chunks before sending to LLM — prevents wasted context budget and repetition. Always implement; low cost, clear benefit. |
| **Diversity-aware retrieval** | Explicitly favor topically diverse results (MMR — Maximal Marginal Relevance) over pure top-K similarity. Use when top-K tends to return near-duplicate passages. |
| **Version-aware retrieval** | Filter/prefer current version over superseded ones — part of Temporal RAG (see selection guide). |
| **Adaptive RAG** | Router that decides per-query whether to retrieve at all, and how much (single-pass vs. multi-hop). Essentially Router-Based Retrieval + Self-RAG combined. |
| **Knowledge-graph-assisted retrieval** | Lighter-weight than full Graph RAG — use graph only for entity disambiguation/expansion, not full multi-hop traversal. Good middle ground. |
| **SQL plus RAG** | Route structured questions to SQL, narrative questions to retrieval — see Router-Based Retrieval + SQL/Structured-Data RAG in selection guide. |
| **API plus RAG** | Same routing concept, target is a live API instead of a database — common for real-time data (stock prices, order status). |
| **Cache-assisted RAG** | See selection guide § 18 — cache full query→answer for high-repetition FAQs. |
| **Conversation-aware retrieval** | Fold recent conversation turns into the retrieval query — see selection guide § 19 (Memory-Augmented). |
| **Long-term memory plus RAG** | Persistent user-level memory across sessions, separate from document retrieval. Higher complexity — justify against actual multi-session use cases. |
| **Human-in-the-loop RAG** | Explicit approval gate before high-stakes answers are shown/acted on. Required for any action-executing system — see Business Analyst persona's approval-requirement identification. |
| **Retrieval with deterministic tools** | Prefer a direct function call (calculator, date logic, unit conversion) over retrieval when the answer is computable, not retrievable. |
| **Evidence-level confidence scoring** | Attach a confidence score to each piece of retrieved evidence, surfaced to the user or used to trigger abstention. Pairs naturally with Abstention & Clarification. |
| **Answer verification** | A second LLM pass that checks the generated answer against the evidence before returning it — heavier version of Citation Validation, checks the whole answer not just cited claims. |
| **Retrieval fallback strategies** | Defined behavior when retrieval returns nothing or low-confidence results — e.g., broaden search, try a different index, or abstain. Should be specified explicitly in the Retrieval Contract, not left implicit. |
