# 02 — Retrieval Reference

Covers: HyDE → two-stage hierarchical search → query expansion → self-reflective RAG
→ adaptive hybrid weights → reranking decision → production optimisations.

---

## The Retrieval Stack (in order of application)

```
Raw user query
    │
    ▼
[1] Query Expansion + HyDE          ← transform the query
    │
    ▼
[2] Stage 1: Document-Level Filter  ← coarse: reduce search space
    │
    ▼
[3] Stage 2: Chunk-Level Hybrid     ← fine: score & rank chunks
    │
    ▼
[4] Self-Reflective Gap Analysis    ← check completeness, re-search if needed
    │
    ▼
[5] (Optional) Reranking            ← only if retrieval is still weak
    │
    ▼
Ranked context → LLM generation
```

---

## [1] HyDE — Hypothetical Document Embeddings

**The problem:** User queries are short and vague ("quarterly results").
Documents are long and detailed. The embedding space gap causes misses.

**The fix:** Generate a hypothetical *answer* to the query, embed that instead.
The hypothetical answer lives in the same embedding space as real documents.

```python
async def generate_hyde(query: str, lightweight_llm) -> str:
    """Generate a hypothetical document that would answer the query."""
    prompt = f"""Write a short, factual paragraph that would directly answer:
"{query}"
Write as if it were extracted from a real document. Be specific."""
    return await lightweight_llm.generate(prompt)

# Usage
hyde_text   = await generate_hyde(query, gemini_flash)   # cheap model, ~$0.001
hyde_embed  = await embed(hyde_text)
query_embed = await embed(query)

# Use query_embed for Stage 1 (document summary matching)
# Use hyde_embed  for Stage 2 (chunk-level precision matching)
```

**Why two embeddings?** Query embedding matches document-level topic summaries well.
HyDE embedding matches chunk-level detail better. Use each where it fits.

---

## [2] Stage 1 — Document-Level Candidate Filter

Dramatically reduce the search space before touching chunks.
Documents qualify if they match **either** condition (OR logic = high recall).

```sql
-- Simplified view of Stage 1
WITH document_candidates AS (
    SELECT d.id
    FROM documents d
    JOIN document_user_access ua ON d.id = ua.document_id
    WHERE ua.user_id = :user_id
      AND (
          -- Semantic: query embedding vs document summary embedding
          (1 - (d.summary_embedding <=> :query_embedding)) > :similarity_threshold
          OR
          -- Keyword: BM25 / PGroonga full-text on entire document
          d.content &@~ :query_text
      )
    LIMIT :doc_search_limit   -- e.g. 50, dramatically narrows chunk search
)
```

**Key insight:** Most queries need information from a small subset of documents.
Stage 1 exploits this. Without it, you search every chunk in the corpus — slow and noisy.

---

## [3] Stage 2 — Chunk-Level Hybrid Scoring

Only chunks from Stage 1 candidate documents are scored here.

```sql
-- Simplified Stage 2
chunk_scores AS (
    SELECT
        c.*,
        -- Semantic score: HyDE embedding vs chunk embedding
        (1 - (c.embedding <=> :hyde_embedding))          AS semantic_score,
        -- Keyword score: BM25/PGroonga on chunk content
        CASE WHEN c.content &@~ :query_text
            THEN pgroonga_score(c.tableoid, c.ctid)
            ELSE 0
        END                                               AS keyword_score
    FROM document_chunks c
    WHERE c.document_id IN (SELECT id FROM document_candidates)
),
normalised AS (
    SELECT *,
        -- Normalise both to 0-1 before combining (different distributions!)
        semantic_score / NULLIF(MAX(semantic_score) OVER (), 0) AS norm_semantic,
        keyword_score  / NULLIF(MAX(keyword_score)  OVER (), 0) AS norm_keyword
    FROM chunk_scores
)
SELECT *,
    (:semantic_weight * norm_semantic + :keyword_weight * norm_keyword) AS combined_score
FROM normalised
ORDER BY combined_score DESC
LIMIT :top_k;
```

⚠️ **Never add raw cosine similarity + BM25 scores directly** — they have completely
different distributions. Always normalise to 0–1 ranges before combining.

---

## [4] Adaptive Hybrid Weights

Default: 70% semantic / 30% keyword.
Override based on query intent detected during expansion.

```python
def get_weights(query_type: str) -> dict:
    """Adaptive weighting by detected query intent."""
    return {
        "conceptual":    {"semantic": 0.8, "keyword": 0.2},  # "project status"
        "specific_term": {"semantic": 0.2, "keyword": 0.8},  # "JIRA-1234", "Project Phoenix"
        "mixed":         {"semantic": 0.5, "keyword": 0.5},
        "default":       {"semantic": 0.7, "keyword": 0.3},
    }.get(query_type, {"semantic": 0.7, "keyword": 0.3})
```

Query type detection is done during Step [1] Query Expansion (see below).

---

## [5] Query Expansion

Run before search. Use a lightweight/cheap LLM.

```python
from pydantic import BaseModel
from typing import Optional

class QueryExpansion(BaseModel):
    expanded_query: str           # cleaned, enriched version of raw query
    hyde_answer: str              # hypothetical document answer
    query_type: str               # "conceptual" | "specific_term" | "mixed"
    time_filter: Optional[dict]   # {"start": "2024-01-01", "end": "2024-03-31"}
    keywords: list[str]           # extracted search terms

async def expand_query(raw_query: str, llm) -> QueryExpansion:
    prompt = f"""Analyse this search query for a document retrieval system:
Query: "{raw_query}"

Return JSON with:
- expanded_query: cleaned query with synonyms and related terms
- hyde_answer: hypothetical paragraph that would answer this
- query_type: "conceptual" | "specific_term" | "mixed"
- time_filter: null or {{"start": "YYYY-MM-DD", "end": "YYYY-MM-DD"}}
- keywords: list of 3-6 key search terms"""

    return QueryExpansion.parse_raw(await llm.generate(prompt))
```

---

## [6] Self-Reflective RAG

After initial retrieval, evaluate whether the results are complete.
This catches multi-hop questions where a single search misses related documents.

```python
class GapAnalysis(BaseModel):
    needs_additional_searches: bool
    information_gaps: list[dict]   # [{query, hyde_answer, importance (1-10)}]

async def self_reflect(original_query: str, initial_results: list, llm) -> GapAnalysis:
    prompt = f"""You retrieved documents to answer: "{original_query}"
Results summary: {summarise(initial_results)}

Identify any critical information gaps. For each gap:
- followup_query: the search needed
- followup_hyde_answer: hypothetical answer
- importance: 1-10 (only flag ≥7)"""
    return GapAnalysis.parse_raw(await llm.generate(prompt))

async def orchestrated_search(query: str, user_id: str):
    expansion      = await expand_query(query, lightweight_llm)
    initial        = await hierarchical_search(expansion, user_id)
    gap_analysis   = await self_reflect(query, initial, lightweight_llm)

    all_results = list(initial)

    if gap_analysis.needs_additional_searches:
        high_importance = [g for g in gap_analysis.information_gaps if g["importance"] >= 7]
        followups = high_importance[:2]   # MAX 2 follow-up searches — diminishing returns beyond

        extra = await asyncio.gather(*[
            hierarchical_search(gap["followup_query"], user_id, hyde=gap["followup_hyde_answer"])
            for gap in followups
        ])
        all_results = combine_and_dedupe(all_results, *extra)

    return all_results
```

**The magic number is 2.** More than 2 follow-up searches: latency spikes, returns diminish fast.

This pattern is analogous to the **ReAct (Reason + Act)** agent loop (Yao et al., 2022)
but applied specifically to information retrieval rather than tool use.

---

## BM25 Standalone Implementation

When PGroonga is not available, implement BM25 in Python:

```python
from rank_bm25 import BM25Okapi

def hybrid_search_bm25(query: str, dense_results: list, top_k: int = 10) -> list:
    """Reciprocal Rank Fusion of dense + BM25 sparse results."""
    corpus = [r["text"] for r in dense_results]
    bm25 = BM25Okapi([doc.split() for doc in corpus])
    bm25_scores = bm25.get_scores(query.split())

    # Reciprocal Rank Fusion (RRF) — better than weighted sum for cross-system scores
    ranked = sorted(
        zip(dense_results, bm25_scores),
        key=lambda x: 0.6 * x[0]["score"] + 0.4 * x[1],
        reverse=True,
    )
    return [r for r, _ in ranked[:top_k]]
```

---

## Reranking — When to Use / Skip

```
Is retrieval already using HyDE + hierarchical hybrid + self-reflection?
  YES → Skip reranking. You're at 90%+ quality. Reranking adds ~5% for 2x latency.
  NO  → Add reranking: cross-encoders outperform bi-encoders for final scoring.

Is latency critical (< 2s SLA)?
  YES → Skip reranking.
  NO  → Consider reranking on top-20 candidates only.

Is retrieval quality still poor after tuning?
  YES → Add reranking as a last resort.
```

**If using reranking:**
```python
import cohere
co = cohere.Client("YOUR_KEY")

def rerank(query: str, results: list, top_n=5) -> list:
    docs = [r["text"] for r in results]
    reranked = co.rerank(query=query, documents=docs, top_n=top_n,
                          model="rerank-english-v3.0")
    return [results[r.index] for r in reranked.results]

# Alternative (self-hosted): cross-encoder/ms-marco-MiniLM-L-6-v2
from sentence_transformers import CrossEncoder
reranker = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
scores = reranker.predict([(query, r["text"]) for r in results])
```

---

## Temporal & Metadata Filtering

Always apply at DB level for performance — not post-retrieval.

```python
def build_filters(expansion: QueryExpansion) -> dict:
    filters = {}
    if expansion.time_filter:
        filters["source_updated_at__gte"] = expansion.time_filter["start"]
        filters["source_updated_at__lte"] = expansion.time_filter["end"]
    return filters

# Queries like "recent sales reports" → automatically scoped to date range
# Tenant isolation → document_user_access join (see schema in 01-ingestion.md)
```

---

## Citation Tracking

```python
def build_context_with_citations(results: list[dict], max_tokens=4000) -> tuple[str, list]:
    context_parts, used_sources, total = [], [], 0

    for i, doc in enumerate(sorted(results, key=lambda d: d["score"], reverse=True)):
        tokens = estimate_tokens(doc["text"])
        if total + tokens > max_tokens:
            break
        context_parts.append(f"[{i+1}] Source: {doc['source']}\n{doc['text']}")
        used_sources.append({"ref": i+1, **doc})
        total += tokens

    return "\n\n---\n\n".join(context_parts), used_sources
```

---

## Production Performance Checklist

| Optimisation | Impact | How |
|---|---|---|
| HNSW indexes | ~95% faster ANN search | `CREATE INDEX USING hnsw` (see 01-ingestion.md) |
| Materialised CTEs | Avoid recomputing candidate sets | `WITH MATERIALIZED` in PostgreSQL |
| Parallel follow-up searches | Self-reflection at no extra latency | `asyncio.gather()` |
| Embedding cache | Skip recompute for unchanged content | EmbeddingCache class (01-ingestion.md) |
| Stage 1 doc limit | Cap chunk search space | `LIMIT 50` on document candidates |
| Lightweight LLM for expansion | Cheap query prep | Gemini Flash / GPT-4o-mini |

**Target SLA:** Full pipeline (query → ranked context) under 2 seconds for
enterprise datasets up to millions of documents.

---

## Embedding Model Versioning

Embedding models improve rapidly. Plan for migration from day one.

```python
# Store embedding model version alongside every vector
# Schema addition:
ALTER TABLE document_chunks ADD COLUMN embed_model TEXT DEFAULT 'text-embedding-3-small-v1';
ALTER TABLE documents       ADD COLUMN embed_model TEXT DEFAULT 'text-embedding-3-small-v1';

# Migration strategy when upgrading model:
def migrate_embeddings(new_model: str, batch_size: int = 100):
    """Re-embed all chunks with new model. Run as background job."""
    chunks = db.get_all_chunks_with_old_model(current_model)
    for batch in batched(chunks, batch_size):
        new_embeds = embed_with_model(new_model, [c["content"] for c in batch])
        db.update_embeddings(batch, new_embeds, model_name=new_model)
    # Only cut over query routing after full migration completes
```

**Key rule:** Never couple embedding model name to application code.
Always pass it as a config value. This lets you A/B test models and migrate
without touching retrieval logic.

---

## Monitoring

```python
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class RAGMonitor:
    query_log: list = field(default_factory=list)

    def log(self, retrieval_ms: float, generation_ms: float, num_results: int):
        self.query_log.append({
            "ts": datetime.now().isoformat(),
            "retrieval_ms": retrieval_ms,
            "generation_ms": generation_ms,
            "num_results": num_results,
        })

    def report(self) -> dict:
        times = [q["retrieval_ms"] for q in self.query_log]
        return {
            "total_queries": len(self.query_log),
            "avg_retrieval_ms": sum(times) / max(len(times), 1),
            "p95_retrieval_ms": sorted(times)[int(len(times) * 0.95)] if times else 0,
        }
```

→ **Next:** Set up evaluation harness — load `03-evaluation.md`
