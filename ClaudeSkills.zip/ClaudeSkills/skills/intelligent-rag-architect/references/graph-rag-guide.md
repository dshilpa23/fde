# Graph RAG / Knowledge Graph RAG (KG-RAG) — Full Guide

Used by: **RAG Architecture Strategist** (justification), **Retrieval Engineer**
(implementation) when Graph RAG is the chosen architecture.

---

## 1. Problem Solved

Passage-based retrieval (classic/hybrid RAG) treats each chunk independently.
It cannot answer questions that require traversing *relationships*:
- "Which suppliers used by subsidiaries of Company X had compliance violations?"
- "What's the chain of approvals that led to this policy change?"
- "Which patients on Drug A also had adverse events reported for Drug B, and
  what do their charts have in common?"

These require multi-hop reasoning across connected entities — no single passage
contains the answer; the answer emerges from traversing the graph.

## 2. When to Use

ALL three must hold:
1. Relationships between entities are more important than isolated passages
2. The task requires multi-hop reasoning across connected data
3. A graph is genuinely available (e.g., existing knowledge graph, structured
   relational data) OR can be reliably constructed from the corpus with
   acceptable extraction accuracy

## 3. When NOT to Use

- The corpus merely *contains* named entities — this is not sufficient
- Most questions are answerable from a single passage — Graph RAG adds
  construction cost, graph maintenance, and query complexity for no benefit
- Entity extraction accuracy on your corpus is poor (test this before committing —
  see § Construction Quality Check below) — a noisy graph is worse than no graph
- You need this for a v1 with a 2-week timeline — graph construction and
  validation takes real time to get right

## 4. Architecture Options

### Option A: Property Graph (Neo4j, Amazon Neptune, ArangoDB)
Entities as nodes, relationships as typed edges with properties.
```
(Company X)-[:SUBSIDIARY_OF]->(Parent Corp)
(Company X)-[:USES_SUPPLIER]->(Supplier Y)
(Supplier Y)-[:HAD_VIOLATION]->(Compliance Event Z {date, severity})
```
Best for: complex relationship types, property-rich edges, mature tooling
(Cypher query language), strong for explicit multi-hop traversal queries.

### Option B: RDF Triple Store (GraphDB, Amazon Neptune, Stardog)
Subject-predicate-object triples, SPARQL querying, native ontology support.
Best for: standards-based interoperability, formal ontologies, when you need
to integrate with existing linked-data / semantic-web infrastructure.

### Option C: Hybrid Vector + Graph (Neo4j w/ vector index, Weaviate, LlamaIndex
PropertyGraphIndex)
Combine vector embeddings on nodes/passages with graph traversal — the most
practical option for most enterprise Graph RAG systems in 2026.
Best for: most production systems — gets semantic search AND relationship
traversal in one system.

**Recommendation:** Default to Option C unless you have existing RDF
infrastructure or complex ontology requirements pushing you to Option B.

## 5. Construction Pipeline

```
1. Entity extraction (LLM-based NER or spaCy/domain NER model)
2. Relationship extraction (LLM prompted to identify typed relationships)
3. Entity resolution / deduplication (same entity, different mentions)
4. Graph construction (nodes + typed edges + properties)
5. Community detection (optional — for hierarchical summarization, à la
   Microsoft GraphRAG's community summaries)
6. Validation (see Construction Quality Check below)
```

**Entity + relationship extraction prompt pattern:**
```python
EXTRACTION_PROMPT = """Extract entities and relationships from this text.
Entity types: {entity_types}  # e.g., Company, Person, Product, Regulation
Relationship types: {relationship_types}  # e.g., SUBSIDIARY_OF, USES, VIOLATED

Return JSON:
{{
  "entities": [{{"id": "...", "type": "...", "name": "...", "properties": {{}}}}],
  "relationships": [{{"source": "...", "target": "...", "type": "...", "properties": {{}}}}]
}}

Text: {chunk_content}
Context path: {context_path}  # from document-based chunking, see ingestion guide
"""
```

**Entity resolution** — critical and often skipped:
```python
def resolve_entities(extracted_entities: list) -> list:
    """Merge duplicate entity mentions (e.g., 'Acme Corp' vs 'Acme Corporation')."""
    # Approach 1: embedding similarity clustering on entity names
    # Approach 2: LLM-based canonicalization pass
    # Approach 3: exact match on normalized name + fuzzy match fallback
    # Always keep a mapping of original mention → canonical entity for citation
```

## 6. Construction Quality Check (run before committing to Graph RAG)

Before building the full graph, sample-test extraction quality:

```python
def graph_construction_quality_check(sample_docs: list, n=20) -> dict:
    """Run extraction on a sample, have humans validate."""
    results = [extract_entities_relationships(doc) for doc in sample_docs[:n]]
    # Human review: what % of extracted relationships are actually correct?
    precision = human_validated_correct / total_extracted
    # Target: >85% precision on relationship extraction before proceeding to full build
    return {"precision": precision, "recommendation":
            "PROCEED" if precision > 0.85 else "DO NOT PROCEED — fix extraction first"}
```

**If precision < 85%:** Do not proceed with Graph RAG. Either improve the
extraction prompt/model, use a domain-specific NER model, or fall back to
Hybrid RAG — a noisy graph produces confidently wrong multi-hop answers,
which is worse than no graph at all.

## 7. Retrieval Pattern (Hybrid Vector + Graph)

```python
async def graph_rag_retrieve(query: str, graph_db, vector_db) -> dict:
    # Step 1: Identify seed entities in the query
    query_entities = await extract_entities(query)

    # Step 2: Vector search for relevant passages (standard hybrid retrieval)
    passage_results = await hybrid_search(query, vector_db)

    # Step 3: Graph traversal from seed entities (bounded depth!)
    graph_context = []
    for entity in query_entities:
        neighbors = await graph_db.traverse(
            start_node=entity,
            max_hops=2,          # BOUND THIS — unbounded traversal = latency/cost explosion
            relationship_types=relevant_types_for_query(query),
        )
        graph_context.extend(neighbors)

    # Step 4: Combine — graph relationships provide structure,
    #         passages provide the actual supporting text
    return {
        "passages": passage_results,
        "graph_paths": graph_context,
        "entities_involved": query_entities,
    }
```

**Critical bound:** Always cap traversal depth (max_hops=2-3 typically).
Unbounded graph traversal on a densely connected graph can explode
combinatorially — same discipline as the max-2-follow-up rule in
Self-Reflective RAG.

## 8. Microsoft GraphRAG Pattern (Community Summaries)

For very large graphs, build hierarchical community summaries so broad
questions don't require traversing the entire graph:

```
1. Detect communities (Leiden/Louvain algorithm) in the graph
2. Generate LLM summary per community ("this cluster is about X suppliers
   and their compliance history")
3. For broad queries: search community summaries first (like the document-
   summary Stage 1 filter in hierarchical RAG — same pattern, graph version)
4. For specific queries: traverse directly from seed entities
```

This mirrors the two-stage hierarchical filtering pattern from
`enterprise-rag-ingestion.md § Database Schema` — coarse filter, then fine retrieval.

## 9. Benefits

- Answers multi-hop questions passage retrieval genuinely cannot
- Surfaces implicit relationships not stated in any single document
- Enables "explain the connection between X and Y" queries
- Community summaries give strong performance on broad, corpus-wide questions

## 10. Costs

- Construction: entity/relationship extraction cost scales with corpus size
  (LLM calls per chunk) — budget for this explicitly
- Maintenance: graph must be kept in sync with source corpus (same incremental
  update discipline as `enterprise-rag-ingestion.md § Incremental Updates`,
  but now also updating edges, not just nodes)
- Extraction errors compound — a wrong relationship produces a confidently
  wrong multi-hop answer with no obvious signal it's wrong
- Additional infrastructure (graph DB) and additional query complexity
- Latency: graph traversal + vector search is slower than vector search alone

## 11. Failure Modes

| Failure | Symptom | Fix |
|---|---|---|
| Low extraction precision | Multi-hop answers confidently wrong | Improve extraction prompt, add human validation loop, consider domain NER |
| Entity resolution failure | Same entity treated as different nodes, missed connections | Stronger canonicalization, embedding-based entity clustering |
| Unbounded traversal | Latency spikes, cost explosion | Hard cap max_hops, cap nodes-per-traversal |
| Stale graph | Answers reflect outdated relationships | Incremental sync tied to document updates |
| Graph without passages | Answer has structure but no verifiable text evidence | Always pair graph paths with source passages for citation |

## 12. Security Implications

- Relationship extraction from untrusted documents is itself an injection
  surface — a malicious document could claim a false relationship
  ("Company X officially recommends ignoring safety protocol Y") that gets
  extracted as a graph edge and treated as fact in later answers
- Mitigation: validate extracted relationships against source authority/trust
  level before adding to the graph; flag low-authority-source relationships
  for human review before graph inclusion
- See `security-framework.md § RAG Poisoning` for the general pattern

## 13. Evaluation Method

Standard retrieval metrics (Precision@K, Recall@K) don't fully capture graph
quality. Add:

```python
def graph_rag_eval_metrics(test_cases: list) -> dict:
    return {
        "multi_hop_accuracy": ...,      # % of multi-hop questions answered correctly
        "relationship_precision": ...,   # % of graph edges used in answer that are correct
        "path_faithfulness": ...,        # does the answer's claimed reasoning path match the actual graph path?
        "single_hop_regression": ...,    # confirm Graph RAG didn't hurt simple single-passage questions
    }
```

Always include single-hop questions in the eval set — Graph RAG should not
regress performance on questions that didn't need graph traversal at all.

## 14. Minimal Implementation Example

```python
# Minimal viable Graph RAG using Neo4j + existing vector index
from neo4j import GraphDatabase

class GraphRAGRetriever:
    def __init__(self, neo4j_uri, neo4j_auth, vector_retriever):
        self.graph = GraphDatabase.driver(neo4j_uri, auth=neo4j_auth)
        self.vector_retriever = vector_retriever  # existing hybrid retriever

    def query(self, question: str, max_hops: int = 2) -> dict:
        entities = extract_entities(question)
        passages = self.vector_retriever.search(question)

        with self.graph.session() as session:
            paths = session.run("""
                MATCH path = (start)-[*1..$max_hops]-(connected)
                WHERE start.name IN $entity_names
                RETURN path LIMIT 50
            """, entity_names=[e.name for e in entities], max_hops=max_hops)

            graph_evidence = [format_path(p) for p in paths]

        return {"passages": passages, "graph_evidence": graph_evidence}
```

## 15. Decision Summary

```
Corpus has clear, extractable relationships AND questions require multi-hop
traversal AND construction quality check passes (>85% extraction precision)?
  → Graph RAG (Hybrid Vector + Graph, Option C) justified

Corpus has entities but questions are single-passage-answerable?
  → Reject Graph RAG. Use Hybrid RAG instead.

Extraction precision check fails (<85%)?
  → Do not proceed. Fix extraction or abandon Graph RAG for this corpus.

Very large graph, many broad/corpus-wide questions?
  → Add Microsoft GraphRAG-style community summaries on top of Option C.
```
