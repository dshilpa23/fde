# 01 — Ingestion Reference

Covers: stack selection → data conversion → chunking → embeddings → DB schema → indexing.

---

## Stack Decision Tree

### Vector Database

```
Need fully managed / zero ops?
  YES → Pinecone (easiest) | Weaviate Cloud (richer schema)
  NO  → Continue

Need distributed at millions-of-docs scale?
  YES → Milvus (C++, K8s) | Weaviate self-hosted
  NO  → Continue

Existing PostgreSQL in stack?
  YES → pgvector extension  ← best for most enterprise (no sync overhead,
        + PGroonga for BM25    existing backup/security, complex filters free)
  NO  → Qdrant (Rust, Docker) ← best self-hosted performance otherwise

Prototyping only?
  YES → Chroma (in-process, zero config)
```

| DB | Best for | Performance | Cost |
|---|---|---|---|
| pgvector + PGroonga | Enterprise, existing PG | Excellent | Free |
| Qdrant | Self-hosted production | Excellent (Rust) | Free |
| Pinecone | Managed, rapid proto | Excellent | Pay-per-use |
| Weaviate | Complex schemas, GraphQL | Excellent (Go) | Free + Cloud |
| Milvus | Large-scale distributed | Excellent (C++) | Free |
| Supabase | Hosted PG + pgvector, fast setup | Excellent | Free tier + paid |
| Redis | Low-latency / in-memory vector search | Very good | Varies |
| Elasticsearch | Existing ES stack, dense-vector field | Very good | Varies |
| MongoDB Atlas | Existing Mongo, Atlas Vector Search | Good | Pay-per-use |
| Chroma | Local dev / embedded | Good | Free |

### Embedding Model

```
No cost constraint + highest quality?
  → text-embedding-3-large (OpenAI, 3072 dim, $0.13/1M tokens)

Balanced cost/quality (most production cases)?
  → text-embedding-3-small (OpenAI, 1536 dim, $0.02/1M tokens)
  → Cohere embed-v3.0 (1024 dim, $0.10/1M tokens) — strong for search

Self-hosted / no API cost?
  → all-mpnet-base-v2 (768 dim) — best open-source quality
  → all-MiniLM-L6-v2 (384 dim) — fastest, acceptable quality

Domain-specific corpus?
  → Code: microsoft/codebert-base
  → Medical: dmis-lab/biobert-v1.1
  → Legal: nlpaueb/legal-bert-base-uncased
  → Always verify on MTEB leaderboard: https://huggingface.co/spaces/mteb/leaderboard
```

**Key constraint:** Max chunk size ~512 tokens for optimal embedding quality.

**The Size Bias Problem (critical):** Longer texts consistently produce higher cosine
similarity scores against other embeddings, regardless of actual semantic relevance.
This means you **cannot use a fixed cosine threshold** (e.g., > 0.75) to determine
whether a match is "good enough" — the threshold shifts with chunk length.
Mitigation: normalise scores within each result set (see 02-retrieval.md § Stage 2)
and avoid mixing chunk sizes in the same collection.

---

## Data Conversion

**Rule:** All source formats must be converted to GFM Markdown before chunking.
LLMs and embeddings perform best on clean, structured plain text. GFM gives hierarchy without noise.

| Source | Recommended Converter |
|---|---|
| PDF | Gemini 2.5 Flash (layout-aware) or `pymupdf` + post-clean |
| Word/PPTX | Gotenberg (headless LibreOffice) |
| Notion / Confluence | OAuth connectors → native export API → GFM |
| HTML | `markdownify` or `trafilatura` |
| Scanned PDFs | OCR first (Tesseract / Azure Document Intelligence) → then convert |

---

## Chunking Strategy

### The 5-Tier Sophistication Spectrum

Moving down = higher quality but more cost and complexity.
**Document-Based sits at the Pareto frontier** for most enterprise systems.

```
Tier 1 → Fixed-Size          Simple, fast, predictable. MVP only.
Tier 2 → Recursive            Hierarchical separators, respects structure somewhat.
Tier 3 → Document-Based  ★   GFM boundary-aware. Best cost/quality tradeoff.
Tier 4 → Semantic             Embedding-grouped. Slower, better for mixed content.
Tier 5 → Agentic              LLM determines chunk boundaries. Highest quality, highest cost.
```

> ⚡ Practitioner rule: Ignore papers claiming 50% gains from exotic chunking on
> cherry-picked benchmarks. Real enterprise data is messy; proven methods win.

### Decision Tree

```
Document type?
  Structured (markdown, docs, books, legal) →  Document-Based (Tier 3)  ← default choice
  Unstructured (chat logs, transcripts)     →  Fixed-Size with 10% overlap (Tier 1)
  Semantically dense, highly mixed content  →  Semantic (Tier 4)
  Critical accuracy, budget available       →  Agentic (Tier 5)
  Storage not a concern, short queries      →  Sliding Window variant

Quality requirement?
  Production enterprise    → Document-Based + Context Path Breadcrumbs (see below)
  MVP / prototype          → Fixed-Size (512 tokens, 10% overlap)
  Maximum context fidelity → Sliding Window (50% overlap)
  Highest possible quality → Agentic chunking (LLM determines boundaries)
```

### Chunking Methods

**Tier 1 — Fixed-Size** — simple, predictable, fast.
```python
def fixed_size_chunking(text, chunk_size=512, overlap=50):
    words = text.split()
    return [' '.join(words[i:i+chunk_size])
            for i in range(0, len(words), chunk_size - overlap)]
```

**Tier 2 — Recursive** — splits hierarchically using separator priority order.
```python
from langchain.text_splitter import RecursiveCharacterTextSplitter
splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=100,
    separators=["\n\n", "\n", ". ", " ", ""],  # tries each in order
)
chunks = splitter.split_text(text)
```

**Tier 3 — Document-Based (Recommended for production)**
Split on GFM structural boundaries: H1/H2/H3 headers, code fences, table rows.
Preserves semantic units naturally. Same `RecursiveCharacterTextSplitter` but
feed it already-GFM-converted content so headers drive the splits.

**Tier 4 — Semantic** — embed sentences, group by cosine similarity breaks.
```python
# Using LangChain SemanticChunker (requires embedding model)
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai.embeddings import OpenAIEmbeddings
splitter = SemanticChunker(OpenAIEmbeddings(), breakpoint_threshold_type="percentile")
chunks = splitter.create_documents([text])
```

**Tier 5 — Agentic** — LLM reads the document and determines chunk boundaries.
```python
# Prompt pattern for agentic chunking
AGENTIC_CHUNK_PROMPT = """Read this document and identify the ideal chunk boundaries.
Each chunk should be semantically complete and self-contained.
Return a JSON list of {"start_char": int, "end_char": int, "topic": str}.
Document: {document}"""
# Use a lightweight model (GPT-4o-mini / Gemini Flash) to control cost
```
Cost note: Agentic chunking at $0.001–0.005 per document is 10–50x more expensive
than document-based but justified for high-value, complex documents.

**Sliding Window** — maximum context preservation, highest storage cost.
```python
def sliding_window(text, window=512, stride=256):
    words = text.split()
    return [' '.join(words[i:i+window])
            for i in range(0, len(words)-window+1, stride)]
```

### ⚠️ The Context Loss Problem & Fix

**Problem:** Chunking breaks references. "It's more than 3.85 million…" — what is "it"?
The chunk loses its connection to the parent document topic.

**Fix — Context Path Breadcrumbs:**
Build an AST from the markdown hierarchy and prepend it to every chunk.

```python
# If paragraph lives under H3 "Prehistory" → H2 "History" → H1 "Berlin" doc
context_path = "Berlin > History > Prehistory of Berlin"
chunk_with_context = f"{context_path}\n\n{chunk_content}"

# For nested folders, extend the path:
full_path = "SharePoint/Engineering/Q3 Reports > Berlin > History > Prehistory of Berlin"
chunk_with_context = f"{full_path}\n\n{chunk_content}"
```

Truncate the path from the left (drop outermost folders) when it gets too long.

### Late Chunking (Game-Changer for Embedding Quality)

Traditional approach embeds each chunk in isolation — loses inter-chunk context.
Late chunking flips the order: embed all chunks *together as an array* first,
then split. Each embedding retains awareness of surrounding content.

```python
# Traditional — each chunk embedded blind
embeddings = [embed(chunk) for chunk in chunks]  # ❌ context-blind

# Late chunking — embed the array together
embeddings = embed_array(chunks)  # ✅ inter-chunk context preserved
                                   # Jina AI embed API supports this natively
```

**When to use:** Always prefer for enterprise content where pronouns, references,
and section dependencies are common. Cost is identical; quality gain is significant.

---

## Database Schema

Use a **hierarchical two-level schema**. This is the key architectural decision
that enables two-stage retrieval (see 02-retrieval.md).

```sql
-- Level 1: Document summaries (coarse filter)
CREATE TABLE documents (
    id          BIGSERIAL PRIMARY KEY,
    title       TEXT NOT NULL,
    source      TEXT NOT NULL,          -- file path / URL / integration source
    content     TEXT NOT NULL,          -- full document text (for FTS)
    summary     TEXT NOT NULL,          -- LLM-generated, ~200 tokens
    summary_embedding VECTOR(1536) NOT NULL,
    source_updated_at TIMESTAMPTZ,
    metadata    JSONB,                  -- author, category, tags, tenant_id
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Level 2: Chunks (fine-grained retrieval)
CREATE TABLE document_chunks (
    id          BIGSERIAL PRIMARY KEY,
    document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,
    content     TEXT NOT NULL,          -- chunk text with context path prepended
    embedding   VECTOR(1536) NOT NULL,
    chunk_index INT NOT NULL,           -- position within document
    metadata    JSONB,                  -- section_path, page_num, etc.
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Access control (multi-tenant)
CREATE TABLE document_user_access (
    document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL,
    PRIMARY KEY (document_id, user_id)
);
```

**Document summaries** can be generated cheaply (Gemini Flash Lite / GPT-4o-mini).
A ~200-token summary per document is the coarse filter that eliminates irrelevant
documents before chunk-level search begins.

---

## Indexing

```sql
-- HNSW vector indexes (~95% faster than IVF for ANN search)
CREATE INDEX ON documents       USING hnsw (summary_embedding vector_cosine_ops);
CREATE INDEX ON document_chunks USING hnsw (embedding vector_cosine_ops);

-- Full-text search (BM25 / n-gram)
-- Option A: PostgreSQL built-in (tsvector)
CREATE INDEX ON documents       USING GIN (to_tsvector('english', content));
CREATE INDEX ON document_chunks USING GIN (to_tsvector('english', content));

-- Option B: PGroonga (better multilingual, fuzzy, tokenisation)
CREATE INDEX ON document_chunks USING pgroonga (content);

-- Metadata filters
CREATE INDEX ON documents       USING GIN (metadata);
CREATE INDEX ON document_user_access (user_id);
```

**Why hybrid indexes (vector + BM25/n-gram)?**
Multiple papers show BM25/n-gram alongside vector search yields significantly
better results than vector alone — especially for product codes, proper nouns,
and exact terminology that semantic embeddings under-weight.

**TokenNgram index** (lightweight alternative to full PGroonga setup):
```sql
-- Lightweight n-gram index for hybrid search
CREATE INDEX ON document_chunks USING GIN (
    to_tsvector('simple', content)  -- 'simple' = no stemming, good for codes/names
);
```

---

## Document Summary Generation

Every document in Level 1 needs a concise summary for Stage 1 filtering.
Use a cheap model. Prompt pattern:

```python
SUMMARY_PROMPT = """Summarise this document in 150-200 words.
Focus on: main topic, key entities, timeframe (if any), document type.
Be factual and information-dense. No preamble.

Document title: {title}
Document content: {content[:3000]}"""

# Cheap models suitable for summary generation:
# - Gemini 2.5 Flash Lite (~$0.0001/doc)
# - GPT-4o-mini (~$0.00015/doc)
# - Claude Haiku (~$0.00025/doc)
```

---

## Incremental Updates & Hierarchy Manager

Real enterprise corpora change daily. Don't re-ingest everything on every update.

```python
class HierarchyManager:
    """Track document → chunk lineage for incremental sync."""

    def sync_document(self, source_id: str, new_content: str):
        content_hash = hashlib.sha256(new_content.encode()).hexdigest()
        existing = db.get_document_by_source(source_id)

        if existing and existing["content_hash"] == content_hash:
            return  # No change, skip entirely

        if existing:
            # Content changed: delete old chunks, re-ingest
            db.delete_chunks_by_document(existing["id"])

        # Ingest fresh
        chunks  = chunk_document(new_content)
        ids     = [make_chunk_id(c) for c in chunks]
        embeds  = embed_array(chunks)   # late chunking
        summary = generate_summary(new_content)
        summary_embed = embed(summary)

        db.upsert_document(source_id, content_hash, summary, summary_embed)
        db.upsert_chunks(ids, chunks, embeds)

    def delete_document(self, source_id: str):
        """Cascade delete handles chunks via FK."""
        db.delete_document_by_source(source_id)
```

---

## Idempotent Ingestion Pattern

Always use deterministic chunk IDs. Re-running ingestion must be safe.

```python
import hashlib, uuid

def make_chunk_id(chunk_text: str) -> str:
    """Deterministic UUID from content hash — safe to re-upsert."""
    return str(uuid.UUID(hashlib.md5(chunk_text.encode()).hexdigest()))

# Checkpoint after ingestion
assert db.count("document_chunks") == len(set(ids)), "Deduplication failed"
```

---

## Embedding Cache

Avoid recomputing embeddings for unchanged content.

```python
class EmbeddingCache:
    def __init__(self, max_size=10_000):
        self.cache = {}
        self.max_size = max_size

    def get_or_compute(self, text: str, embed_fn) -> list[float]:
        key = hashlib.sha256(text.encode()).hexdigest()
        if key not in self.cache:
            if len(self.cache) >= self.max_size:
                self.cache.pop(next(iter(self.cache)))  # FIFO eviction
            self.cache[key] = embed_fn(text)
        return self.cache[key]
```

---

## Async Batch Ingestion

```python
import asyncio

async def process_documents_async(documents: list[str], batch_size=100):
    async def process_batch(batch):
        embeddings = await get_embeddings_async(batch)
        await upsert_to_db_async(batch, embeddings)

    batches = [documents[i:i+batch_size] for i in range(0, len(documents), batch_size)]
    await asyncio.gather(*[process_batch(b) for b in batches])
```

---

## Common Pitfalls

| Pitfall | Symptom | Fix |
|---|---|---|
| **Chunk size not evaluated on domain data** | Poor retrieval across the board | Benchmark 256/512/800/1024 on your actual corpus |
| **Wrong embedding model for domain** | Medical/legal/code queries miss | Use domain-specific model (biobert, codebert, legal-bert) |
| **No query rewriting / normalisation** | "how 2 train NN" finds nothing | Add query expansion step (see 02-retrieval.md) |
| **Missing metadata on chunks** | Can't filter by date/tenant/category | Always store: source, date, section_path, tenant_id |
| **Raw documents stored without cleaning** | Noise degrades embedding quality | Always convert → GFM before embedding |
| **Embedding model coupled to app code** | Migration to better model breaks everything | Abstract via embed_fn interface; version your indexes |
| **Not testing at production data volume** | Passes dev, breaks at scale | Load test with realistic corpus size before launch |
| **Ignoring empty result edge cases** | Crashes or silent failures | Implement graceful degradation (return "no results found" cleanly) |

---

## Alternative Architectures (awareness only)

These are valid for specific use cases but beyond the scope of this skill:

- **Microsoft GraphRAG** — graph-based entity relationships for complex multi-hop reasoning
  across very large enterprise knowledge graphs. Higher infra cost.
- **Salesforce Next Gen RAG (Enriched Index)** — metadata-enriched index with structured
  extraction at ingestion time. Strong for structured enterprise data.

For most teams: the hierarchical hybrid approach in this skill outperforms both on the
Pareto frontier (cost vs. quality vs. implementation effort).

→ **Next:** Build the retrieval pipeline — load `02-retrieval.md`
