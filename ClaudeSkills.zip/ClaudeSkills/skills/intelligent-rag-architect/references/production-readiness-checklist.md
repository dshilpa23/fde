# Production Readiness Checklist

Used by: **Final Architecture Reviewer** persona (Stage 7).

This is the last gate. Every box must be checked with evidence (a linked
artifact, test result, or log), not a verbal assurance.

---

## Traceability
```
□ Every recommendation in the architecture links to a requirement (01),
  corpus finding (02), test (17), or documented risk (10/14)
□ No unlinked/unjustified design decisions remain
□ All Stage 4 Adversarial Review Must-Fix items are resolved
```

## Architecture
```
□ RAG-necessity verdict documented (01-problem-definition.md)
□ RAG type selection has explicit evidence-based reasoning (04)
□ Graph RAG (if used) passed the construction quality check (>85% extraction precision)
□ Agentic RAG (if used) passed the justification test (2+ of 4 conditions)
□ Retrieval contract fully specified with justified parameters (05)
□ Context contract addresses all risks in context-engineering-guide.md (06)
```

## Evaluation
```
□ Golden dataset: ≥100 questions, human-reviewed, all question types represented
  (simple, multi-hop, temporal, adversarial, permission-sensitive, unsupported)
□ Level 1 (Corpus) metrics pass
□ Level 2 (Retrieval) metrics pass: Recall@20 ≥0.80, Precision@5 ≥0.70
□ Level 3 (Generation) metrics pass: Faithfulness ≥0.75, Answer Relevancy ≥0.80,
  Context Precision ≥0.70, Context Recall ≥0.80, Hallucination Rate <5%
□ Level 4 (Agentic, if applicable) metrics pass: route accuracy ≥0.90,
  permission compliance 100%
□ Human evaluation completed with target personas (technical + non-technical)
□ One-variable testing log exists showing tuning process, not just final numbers
```

## Security
```
□ Threat model complete and specific to this system (not generic boilerplate)
□ Every required control has a corresponding passing test
□ Permission-filter correctness: 100% in testing (zero unauthorized access)
□ Indirect prompt injection test passes (retrieved malicious instruction not followed)
□ Citation validation implemented and tested
□ Agentic bounds (if applicable) all defined and tested against violation
□ Human approval gates verified un-bypassable via alternate routes
□ Incident response plan exists
```

## Engineering
```
□ Idempotent ingestion tested (re-run → no duplicates)
□ Incremental sync tested (document update → correct chunk replacement)
□ Tested at production-like data volume, not just dev sample
□ Embedding model version stored alongside every vector; migration path documented
□ Empty-result and malformed-document edge cases handled gracefully
□ Retrieval latency P95 within SLA
□ Modular boundaries preserved (ingestion/retrieval/context/generation/security
  are separable, not tangled)
```

## Operations
```
□ Production monitoring connected (Langfuse/Patronus/Vertex AI Experiments or equivalent)
□ CI/CD regression gate configured (DeepEval or equivalent, auto-fail on metric drop)
□ Cost tracking in place with budget alerts
□ Historical evaluation results preserved for trend analysis
□ Known limitations documented explicitly (21-known-limitations.md)
```

## Compliance (if applicable)
```
□ EU AI Act documentation complete (evaluation methodology, thresholds, audit trail)
□ Regulated-domain sign-off obtained (legal/medical/financial as applicable)
□ Data retention and deletion policies implemented for ingested content
```

---

## Final Status Decision Tree

```
Any unresolved Adversarial Review Must-Fix items?
  YES → NOT READY

Level 2/3 metrics below threshold, OR security tests failing?
  YES → NOT READY

Metrics pass but tested only at small scale / no human eval yet?
  → PROTOTYPE ONLY

Metrics pass, human eval done, but limited production monitoring
  or no incident response plan yet?
  → READY FOR CONTROLLED PILOT

All boxes checked, monitoring live, regression gate configured?
  → READY FOR PRODUCTION REVIEW
```

**Never mark READY FOR PRODUCTION REVIEW based on Level 3 metrics alone.**
A system can pass every generation metric and still fail in production due
to a security gap, scale issue, or edge case never in the golden dataset.
