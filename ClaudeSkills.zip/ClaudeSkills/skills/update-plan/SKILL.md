---
name: update-plan
description: >
  Updates plan.md after an agent completes a task. Finds the right US section,
  runs its validation command, records observed outcomes (test counts, AUC, coverage,
  command output), ticks acceptance criteria checkboxes, updates Status/timestamps,
  and refreshes the Task Summary and Release Gates tables.
  Trigger when: a task finishes, user says "/update-plan", "mark US-N complete",
  "update the plan", "task done", "record outcomes", or "agent finished US-N".
  Always requires a US number (US-1 through US-6) or infers it from context.
---

# update-plan

Updates `plan.md` with observed outcomes after an agent finishes a task.
This is the single source of truth for tracking what actually happened vs. what was planned.

## When this skill is invoked

- User types `/update-plan` (with or without a US number)
- User says "mark US-1 complete", "task done", "update the plan for US-3", "record outcomes"
- An agent just finished implementing a task and needs to log results
- User pastes test output and wants it recorded

## Step 1 — Identify the task and plan file

1. Find `plan.md` in the current working directory. If not found, walk up to the nearest parent that has one. If still not found, tell the user and stop.
2. Determine which US task to update:
   - From the slash command argument: `/update-plan US-2` → US-2
   - From user message context: "just finished feature engineering" → US-1
   - If ambiguous, ask: "Which US task did you just complete? (US-1 through US-6)"
3. Read the full plan.md so you know the current state before editing.

## Step 2 — Collect evidence

Before updating anything, gather the actual observed evidence for this task.

### If the user already pasted output in the conversation
Extract from it:
- Test counts: `N passed`, `N failed`, `N error`
- AUC value (for US-2): look for a float like `0.81` near "AUC" or "ROC"
- Coverage % (for US-6): look for `TOTAL ... N%` in pytest-cov output
- Any error messages or warnings worth noting

### If output is NOT already in the conversation
Run the validation command for the completed task. Read it from the plan.md
under the task's `### Validation Command` block. Execute it and capture output.

Validation commands by task (fallback if plan.md is unavailable):
- US-1: `python -m pytest tests/test_features.py -m implementation -q`
- US-2: `python src/prior_auth_scorer/train.py` then `python -m pytest tests/test_model.py -m implementation -q`
- US-3: `python -m pytest tests/test_pipeline.py -q -k "band or score or load"`
- US-4: `python -m pytest tests/test_pipeline.py -q`
- US-5: `python -m pytest tests/test_repository_service.py -q`
- US-6: `python -m pytest --cov=prior_auth_scorer --cov-report=term-missing -q`

If the command fails, record the failure honestly — never fabricate passing output.

## Step 3 — Determine new status

Map test outcomes to status values:

| Condition | Status |
|-----------|--------|
| All AC checkboxes pass, validation command shows 0 failures | `COMPLETE` |
| Task started but not all tests pass yet | `IN PROGRESS` |
| Blocked because a dependency (prior US) is not complete | `BLOCKED` |
| Not yet started | `NOT STARTED` |

If any test failed or the validation command errored, status stays `IN PROGRESS` —
never mark a task `COMPLETE` when tests are failing.

## Step 4 — Edit plan.md

Make ALL of the following edits in a single Edit tool call per logical section.
Do not split edits across multiple calls when you can batch them.

### 4a — Task-specific section header fields

Find the task's section (e.g. `## US-2 — Model Training`).
Update these fields:

```
**Status:** IN PROGRESS          →  **Status:** COMPLETE
**Started At:** —                →  **Started At:** <ISO date from context or today>
**Completed At:** —              →  **Completed At:** <today's date YYYY-MM-DD>
```

Only set `Started At` if it is currently `—`. Never overwrite an existing start date.
Only set `Completed At` when status is becoming COMPLETE.

### 4b — Acceptance Criteria checkboxes

For each criterion the evidence confirms is satisfied, change:
```
- [ ] criterion text
```
to:
```
- [x] criterion text
```

Only tick boxes that the observed evidence directly confirms.
Leave unchecked any criterion you cannot verify from the output.
Never tick all boxes speculatively — "tests passed" only confirms what the tests cover.

### 4c — Agent Outcomes section

Replace the placeholder content under `### Agent Outcomes` with real values.
Keep the section structure intact — only replace the `—` and code block contents.

Example for US-1 (adapt fields per task):
```markdown
### Agent Outcomes

**Tests Passed:** 11 / 11
**Tests Failed:** 0
**Observed Output:**
```
(paste actual pytest output here — do not truncate if it fits)
```
**Notes / Issues Encountered:**
None — all 11 implementation tests passed on first run.

**Implementation Summary:**
Implemented build_feature_vector() using the payer/diagnosis/procedure maps already
loaded at module level. Age computed via relativedelta. Prior approval count capped
with min(). Leakage check runs before any extraction.
```

For US-2, also fill:
```
**Observed AUC:** 0.82
**Artifact Path:** models/scorer_v1.0.0.pkl
```

For US-3, also fill:
```
**model_version Observed:** v1.0.0
```

For US-4, also fill:
```
**Enrollment Gate Rejection Verified:** YES — returns PIPELINE_ERROR with 1 stage record
**4-Stage Success Verified:** YES — 4 PipelineStage records on READY_FOR_BENEFITS_REVIEW input
```

For US-5, also fill:
```
**Idempotency Verified (duplicate request returns stored result):** YES
**Append-Only Trigger Verified (UPDATE raises error):** YES
**Append-Only Trigger Verified (DELETE raises error):** YES
**PII Exclusion Verified:** YES — patient_name, date_of_birth, phone, email excluded from raw_payload
```

For US-6, also fill:
```
**Total Tests Passed:** 44 / 44
**Coverage %:** 87%
**Observed AUC:** 0.82
**API Endpoints Verified:** 7 / 7
**Submission ZIP Ready:** YES
```

### 4d — Task Summary table (top of plan.md)

After updating the task section, update the corresponding row in the summary table:

```markdown
| US-2 | Model Training | ML Engineer | G2, G8 | 15 | NOT STARTED |
```
→
```markdown
| US-2 | Model Training | ML Engineer | G2, G8 | 15 | COMPLETE |
```

Also update `**Overall Status:**` in the header:
- Any task IN PROGRESS → `IN PROGRESS`
- All tasks COMPLETE → `COMPLETE`
- Otherwise → `IN PROGRESS` if any task has started, else `NOT STARTED`

### 4e — Test Gate summary (just below Task Summary table)

Update these three lines with the latest observed values whenever you have them:
```
**Test Gate:** 0 / 44 passing
**Coverage:** unknown (blocked by NotImplementedError)
**AUC:** unknown (train.py not run)
```

### 4f — Release Gates table (bottom of plan.md)

For any gate whose evidence was just observed, fill in the `Observed` and `Pass?` columns:

| Gate | Observed | Pass? |
|------|----------|-------|
| Tests | 44 passed, 0 failed | YES |
| Coverage | 87% | YES |
| AUC | 0.82 | YES |

Only fill in gates with directly observed values. Leave `—` for gates not yet verified.

## Step 5 — Confirm to user

After edits are applied, print a short summary:

```
plan.md updated — US-2
  Status: NOT STARTED → COMPLETE
  Checkboxes: 7 / 7 ticked
  Observed AUC: 0.82 (PASS — ≥ 0.75)
  Tests: all implementation tests passed
  Release Gates updated: AUC row filled

Next unblocked task: US-3 (Scorer + Banding) — dependency on artifact now satisfied.
```

If tests failed, say so clearly:
```
plan.md updated — US-1
  Status: NOT STARTED → IN PROGRESS
  Tests: 8 / 11 passed (3 failed)
  Checkboxes: 6 / 9 ticked (3 unchecked — not verified)
  Next step: fix failing tests before marking COMPLETE.
```

## Rules

- **Never fabricate output.** If you did not observe it, write `—` or say "not yet run".
- **Never mark COMPLETE when tests fail.** Partial progress = IN PROGRESS.
- **Never overwrite a start date** that is already filled in.
- **Never touch test files** — this skill only edits plan.md.
- **One Edit call per section** where possible. Do not make 10 tiny edits.
- If the plan.md section structure has been changed by the user and your edit targets can't be found, report the mismatch and ask for clarification rather than guessing.

## Status values (canonical)

| Value | Meaning |
|-------|---------|
| `NOT STARTED` | No work done yet |
| `IN PROGRESS` | Implementation started; tests not all passing |
| `BLOCKED` | Cannot start — a prior dependency is NOT STARTED |
| `COMPLETE` | All AC checkboxes verified; validation command shows 0 failures |
