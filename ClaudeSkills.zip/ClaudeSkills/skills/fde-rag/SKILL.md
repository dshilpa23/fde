---
name: fde-rag
description: Answers questions using the FDE (Forward Deployed Engineer) Cohort 1 training corpus — session decks, the FDE Playbook parts, and lab guides — via a local BM25 retrieval index over "FDE Training". Use this whenever the user asks what the FDE training/curriculum/playbook says about a topic, references "FDE materials", or wants to check their approach against what was taught in a specific FDE session. Trigger proactively any time the user is doing project work and a relevant FDE framework likely applies (problem framing, architecture decisions, RAG/agentic design, reliability, HITL, evaluation, governance) — even if they don't explicitly ask to search the FDE materials.
---

# FDE RAG

Retrieval over the FDE Cohort 1 training corpus (~27 PDFs: session decks, FDE
Playbook parts I–XI, and lab guides) copied into:

```
/Users/shilpa.vangati@optum.com/Library/CloudStorage/OneDrive-UHG/Documents/FDE Training
```

The index is **lexical (BM25)**, not embeddings — this network blocks
huggingface.co, so no model downloads are possible or needed. BM25 works well
here because the corpus is keyword-rich slide/training content. No network
calls are made at query time.

See [references/session-map.md](references/session-map.md) for which session
covers which topic — use it to pick good keyword queries and to tell the user
which session/Playbook part a finding comes from.

## Step 1 — Query the index

Run the existing query script with the training folder's own venv:

```bash
"/Users/shilpa.vangati@optum.com/Library/CloudStorage/OneDrive-UHG/Documents/FDE Training/.rag_venv/bin/python" \
  "/Users/shilpa.vangati@optum.com/Library/CloudStorage/OneDrive-UHG/Documents/FDE Training/rag/query.py" \
  "<question>" [top_k]
```

`top_k` defaults to 6 if omitted. Output is JSON:

```json
{"question": "...", "results": [{"score": 24.57, "source": "FDE_Session ...pdf", "text": "..."}]}
```

If a query returns no/weak results, rephrase using vocabulary the decks would
actually use (check the session map) rather than giving up after one try.

## Step 2 — Synthesize an answer

Answer the user's actual question from the retrieved `text` chunks — don't just
dump the JSON. Always cite the `source` filename for each claim, and name the
session number when it's inferable (via the session map) so the user can go
find the original slide.

If the retrieved chunks don't actually answer the question, say so rather than
filling the gap with general knowledge — this is meant to reflect what the FDE
training specifically said.

## Step 3 — Keep the index fresh (only if needed)

If the user adds, removes, or edits files under `FDE Training/` (excluding the
`rag/` subfolder itself), rebuild the index before trusting query results:

```bash
"/Users/shilpa.vangati@optum.com/Library/CloudStorage/OneDrive-UHG/Documents/FDE Training/.rag_venv/bin/python" \
  "/Users/shilpa.vangati@optum.com/Library/CloudStorage/OneDrive-UHG/Documents/FDE Training/rag/ingest.py"
```

This overwrites `rag/bm25_index.pkl`. Only do this when the corpus has
actually changed — it's a few seconds of work but no need to run it on every
query.
