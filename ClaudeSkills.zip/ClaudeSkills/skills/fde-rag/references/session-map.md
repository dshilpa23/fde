# FDE Cohort 1 — Session Topic Map

| # | Topic | Key source files |
|---|---|---|
| 1 | FDE role, domain context, discovery toolkit | `FDE_Session 1_The FDE Lens- Role, Domain& the Discovery Toolkit_Share.pdf` |
| 2 | Problem framing, readiness, platform foundations | `FDE_Session 2_Problem Framing_Readiness_Platform_Foundations-Share.pdf`, `1_FDE_Problem Framing Frameworks.pdf`, `2_FDE_Problem Analysis.pdf`, `3_FDE_Problem-Solving Frameworks.pdf`, `4_FDE_Human Centric Design...pdf`, `5_The FDE Playbook-part II.pdf` |
| 3 | Spec-driven rules / BMAD skill best practices | `Session-3_bmad_skill_best_practices_for_learners.pdf` |
| 4 | P1 build/ship (mini project) — no PDF, recordings only | — |
| 5 | Architecture decisions & TDD with agents | `FDE_Session_5_Architecture Decision_ & TDD with Agents.pdf`, `The FDE Playbook_part V.pdf` |
| 6 | ML service build, validation, safe release | `FDE_Session_6_ML Service Build, Validation & Safe Release_Final.pdf`, `The FDE Playbook_Part VI.pdf` |
| 7 | Reliability, ML monitoring, security baseline | `FDE_Session_7_Reliability, ML Monitoring_Security Baseline.pdf`, `The FDE Playbook_Part VII.pdf` |
| 8 | Agentic architecture, context engineering, RAG | `FDE_Session 8_Agentic Architecture_Context Engineering_RAG_Final.pdf`, `Session-8_rag_architect_and_ragas_best_practices_for_learners.pdf`, `The FDE Playbook_Part VIII.pdf` |
| 9 | RAG to controlled agent execution | `FDE_Session_9_RAG_to_Controlled_Agent_Execution.pdf`, `The FDE Playbook_Part IX.pdf` |
| 10 | Human-in-the-loop integration, production operations | `FDE_Session_10_HITL_Integration_Production_Operations.pdf`, `The FDE Playbook_Part X.pdf` |
| 11 | Agent evaluation (P3), cost, observability, HIPAA | `FDE_Session_11_P3 Agent Evaluation, Cost Observability & HIPAA.pdf`, `1. The FDE Playbook_Part XI.pdf` |
| 12 | Governance, feedback loops, adoption, stakeholder influence | `FDE_Session_12_Governance, Feedback Loops, Adoption and Stakeholder Influence_.pdf` |
| Labs | Capstone walkthrough, mini-project implementation guides | `Capstone Walkthrough 1.pdf`, `Mini Project 2 Learner Implementation Guide V1.pdf`, `Mini-project_3_Learner_Implementation_Guide.pdf` |

Use this map to pick good BM25 queries (BM25 is lexical — match the vocabulary
the decks actually use) and to tell the user which session a finding comes from.
