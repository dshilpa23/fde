---
name: fde-project-lens
description: Analyzes a project (or a specific decision within one) using the FDE (Forward Deployed Engineer) Cohort 1 curriculum as a structured lens — problem framing, architecture & TDD, ML build/release safety, reliability/security, agentic/RAG architecture, HITL integration, evaluation & cost/compliance, and governance/adoption. Use whenever the user asks to analyze, review, sanity-check, or find gaps in a project "using FDE skills/frameworks", asks "what would the FDE playbook say about this", or wants their project checked against what the FDE training taught. Always pulls grounding from the fde-rag skill rather than inventing FDE content.
---

# FDE Project Lens

Applies the FDE curriculum as an analytical lens to a real project. This skill
provides the *workflow*; it does not hardcode FDE content — all FDE guidance
must come from live retrieval via the `fde-rag` skill (BM25 index over
`FDE Training/`), so findings stay grounded in what was actually taught rather
than generic best practices.

## Step 1 — Scope

Confirm (or infer from context) what's being analyzed: the whole project, a
specific module, or a specific decision (e.g. "should we add a cache here",
"is this agent's evaluation setup sound"). Don't run the full framework sweep
below on a narrow question — jump straight to the 1–2 relevant categories.

## Step 2 — Pick relevant FDE framework categories

Use the session-topic map from the `fde-rag` skill
(`~/.claude/skills/fde-rag/references/session-map.md`) to decide which
categories apply. Typical mapping:

- New/unclear problem, stakeholder alignment → Session 1–2 (discovery, problem framing)
- Spec/rules-driven build approach → Session 3
- Architecture decisions, testing strategy → Session 5
- ML service build/release safety → Session 6
- Reliability, monitoring, security posture → Session 7
- Agentic architecture, RAG/context design → Session 8–9
- Human review steps, production ops → Session 10
- Evaluation, cost, observability, compliance (e.g. HIPAA/PHI) → Session 11
- Governance, feedback loops, stakeholder adoption → Session 12

Only apply categories that are actually relevant to what's in scope — for a
small script or narrow question, 2–3 categories is normal; don't force all of
them.

## Step 3 — Look at the project

Read the relevant project files/structure (README, key modules, configs,
tests) to understand current state for each in-scope category. Don't guess at
what the project does — check it.

## Step 4 — Retrieve FDE guidance per category

For each in-scope category, invoke `fde-rag` (its query script) with a
question phrased in the vocabulary that category's session actually uses, per
the session map. Collect the cited source chunks.

## Step 5 — Report findings

For each category, produce:
- **What the project currently does** (from Step 3)
- **What the FDE material recommends** (from Step 4, cited by source file/session)
- **Gap or risk**, if any — be specific and actionable, not generic

Keep the overall report proportional to what's in scope: a narrow question
gets a short, focused answer; a full-project review gets one section per
relevant category. Don't pad with categories that don't apply just for
coverage.
