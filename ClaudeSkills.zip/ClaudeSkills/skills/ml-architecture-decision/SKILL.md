---
name: ml-architecture-decision
description: >
  Produces a structured ML architecture-decision artifact (./ml_architecture_decision.md) for
  TABULAR classification and regression problems only — recommends problem type, target handling,
  model family with interpretability-vs-performance reasoning (Linear/Logistic -> Decision Tree ->
  Bagging/Random Forest -> Boosting -> XGBoost progression), preprocessing (imputation, encoding,
  scaling, outlier treatment, PCA), class-imbalance strategy, and evaluation metrics. Use before
  writing any model-building code — whenever the user says "what model should I use", "how should
  I approach this dataset", "design the ML approach", "which algorithm for this problem", "help me
  choose a model", "architect this ML solution", pastes a business problem plus a data sample, or
  gives a CSV path and asks what to build. If a CSV path is given, profiles it for real (dtypes,
  missingness %, cardinality, class balance) rather than guessing from description alone. Do NOT
  use for NLP, computer vision, time series, deep learning, clustering, or reinforcement learning —
  this skill is scoped to tabular classification/regression, matching this user's healthcare-cost-
  prediction (PMPM, inpatient charges, readmission risk) domain and Databricks training material.
---

# ML Architecture Decision

Recommends a tabular ML approach and writes it as a machine-readable + human-readable artifact
that the independent `ml-implementation` skill later reads. The two skills share no code — only
this file-naming convention.

## Scope guard

Tabular classification and regression only. If the user's data is text, images, audio, sequences/
time series, or the ask is clustering/dimensionality-reduction-as-the-goal/reinforcement learning/
deep learning — say so explicitly and stop; do not force-fit this skill's guidance onto it.

## Reference map — load only what the current step needs

| Need | Load |
|---|---|
| Classification model comparison, FDE selection guide, precision/recall tradeoffs, imbalance guidance | `references/classification-model-selection.md` |
| Regression model comparison, MAE/MSE/RMSE/R² guidance, FDE selection guide | `references/regression-model-selection.md` |
| The unified interpretability-vs-performance model-family ladder (both problem types) | `references/tabular-model-family-progression.md` |
| Bias/variance, train-vs-test overfitting heuristic, drift caveats | `references/bias-variance-and-evaluation.md` |
| Blank artifact skeleton to fill in | `assets/ml_architecture_decision.template.md` |

## Workflow

**Step 1 — Get a real data profile.**
If the user gives a CSV path, always run:
```
python3 scripts/profile_dataset.py <csv_path> --target <column>
```
Never eyeball a pasted `.head()`/`.dtypes()` output when an actual file is available — the profiler
computes real missingness %, cardinality, and class balance / distribution stats. If no file is
available, ask for one, or explicitly state you're relying on the user's verbal description and flag
this in the artifact's `confidence` field (verbal-only descriptions cap confidence at `medium`).

**Step 2 — Classify the problem.**
Apply the profiler's target classification: object/low-cardinality-integer target (≤ ~20 uniques or
2 uniques) → classification (`binary` if exactly 2 classes, else `multiclass`); numeric with high
uniqueness/continuous spread → regression. State the rule you applied, don't just assert the answer.

**Step 3 — Pick model family with reasoning.**
Load `references/tabular-model-family-progression.md` and present the house progression (simple/
interpretable baseline → Decision Tree → ensembles → XGBoost). Ask or infer where on that ladder
the user's need sits — explainability to a clinician/reviewer vs. raw predictive accuracy vs. a
production/enterprise pipeline — and cite the matching section of `classification-model-selection.md`
or `regression-model-selection.md` to justify the specific model chosen at that rung.

**Step 4 — Preprocessing plan.**
- Imputation: mode for categorical columns, median for numerical columns with missingness (per the
  profile's `columns[*].missing_pct`).
- Encoding: one-hot for nominal categories; ordinal only for columns with a genuine order (ask the
  user to confirm the order rather than assuming) — flag any ambiguous column as an open item.
- Scaling: StandardScaler if a linear/distance-based model is anywhere in the recommended progression.
- Outlier treatment: IQR capping for continuous features/targets; explicitly skip for binary targets.
- PCA: only recommend if dimensionality/multicollinearity actually warrants it — do not default to
  "yes" just because it's available.

**Step 5 — Class imbalance (classification only).**
Use the profiler's `imbalance_ratio` to decide between none / `class_weight='balanced'` / oversample
/ undersample / SMOTE, per the imbalance guidance in `classification-model-selection.md`. Leave
`imbalance_handling: none` for regression — never populate it otherwise.

**Step 6 — Evaluation metrics.**
Classification: accuracy, precision, recall, F1, ROC-AUC, confusion matrix. Regression: MAE, MSE,
RMSE, R². Always include the train-vs-test gap heuristic (> 3% ⇒ flag overfitting risk) from
`bias-variance-and-evaluation.md` as part of the evaluation plan, not just a metrics list.

**Step 7 — Write and validate the artifact.**
Fill `assets/ml_architecture_decision.template.md` with the decisions above and write the result to
`./ml_architecture_decision.md` in the current working directory. Then run:
```
python3 scripts/validate_decision_file.py ./ml_architecture_decision.md
```
Fix and re-validate on any reported error before presenting the artifact to the user — never present
an artifact that fails its own contract check.

**Step 8 — Confidence and open items.**
Always state a confidence level (`low`/`medium`/`high`) and list concrete open items — ambiguous
target semantics, unconfirmed ordinal orderings, missing domain context. If the dataset or repo
references an internal library (e.g. a stub like `unitedai.models.UaisModel` with no real usage
example anywhere), flag it as unresolved rather than guessing at its API or recommending against it
without evidence.

## Decision-file contract

Filename: `./ml_architecture_decision.md` (working directory). Format: YAML frontmatter (machine-
checkable fields the implementation skill parses) + Markdown body (narrative reasoning the
implementation skill embeds into notebook Observation cells). See
`assets/ml_architecture_decision.template.md` for the exact field set and
`scripts/validate_decision_file.py` for the enforced contract (required fields, valid enum values,
classification/regression-conditional fields).
