# Regression Model Selection (Tabular Data)

Scope: continuous-target regression on tabular data only. Source: `ML_Fundamentals_Final.md` (Module 02: Building a Regression Model).

## 1. Problem Types

Regression predicts a numeric value rather than a category. Typical structure: features (X) → continuous target (Y), e.g. Age/Risk Score → Predicted PMPM Cost.

## 2. Model Comparison

| Model | Use When | Advantages | Limitations | Healthcare Example |
|---|---|---|---|---|
| Linear Regression | Simple, mostly-linear prediction problem | Explainable, fast, easy to deploy | Assumes linear relationships, sensitive to outliers | PMPM Cost Forecasting |
| Ridge Regression | Many correlated features | Reduces overfitting, more stable coefficients | Keeps all variables (no feature elimination), less interpretable than plain linear | Cost Prediction |
| Lasso Regression | Need feature selection / "what drives cost" | Drives irrelevant coefficients to zero | May drop variables that are actually useful | Cost Driver Analysis |
| Elastic Net | Correlated features **and** feature selection both needed | Balances Ridge + Lasso | More hyperparameters to tune | Enterprise Cost Models |
| Polynomial Regression | Relationship is visibly non-linear/curved | Captures curved trends | High overfitting risk at higher degrees | Age vs. Healthcare Cost |
| Decision Tree Regression | Business-rule-driven, non-linear, explainable segments | Explainable, handles non-linearity natively | Overfits easily if unpruned | Diagnosis Cost Pathways |
| Random Forest Regression | Strong general-purpose performance, moderate interpretability loss OK | Accurate, robust to overfitting vs. single tree | Less explainable | High-Cost Member Prediction |
| Gradient Boosting Regression | Accuracy is the top priority | Very high performance via sequential correction | Complex tuning, longer training | Claims Cost Forecasting |
| XGBoost | Industry-grade structured-data regression | Usually the highest performance on tabular data | More complex tuning/infra | PMPM Forecasting |
| LightGBM | Very large datasets, need speed at scale | Fast, scalable | Less interpretable | Enterprise-Scale Cost Models |

## 3. Regression Evaluation Metrics

| Metric | What It Measures | Best For | Advantages | Limitations |
|---|---|---|---|---|
| MAE (Mean Absolute Error) | Average magnitude of error | Business-friendly reporting ("we're off by $X on average") | Easy to interpret, robust to outliers | Doesn't penalize large errors more than small ones |
| MSE (Mean Squared Error) | Average squared error | Surfacing large/costly prediction errors | Penalizes big misses heavily | Not in the original target's units, harder to explain to stakeholders |
| RMSE (Root Mean Squared Error) | Square root of MSE | General-purpose regression evaluation | Same unit as the target (e.g., dollars) | Sensitive to outliers, same as MSE in that respect |
| R² (Coefficient of Determination) | Proportion of variance explained by the model | Comparing models against each other | Easy, unit-free comparison across models | Doesn't indicate causality; can be misleadingly high with overfitting |

**Practical rule:** report **RMSE** or **MAE** to business stakeholders (same units as the target, e.g. dollars or days). Use **R²** when comparing multiple candidate models against each other. Use **MSE**/RMSE over MAE specifically when large errors are disproportionately costly (e.g., under-forecasting a very high-cost member matters more than average).

## 4. FDE / Stakeholder Decision Guide

| If Stakeholder Says... | Think... | Model |
|---|---|---|
| "Predict future cost" | Numerical prediction | Regression (general) |
| "Predict PMPM" | Forecasting | Regression (general) |
| "What drives cost?" | Feature importance / selection | Lasso |
| "We need a simple explanation" | Explainability | Linear Regression |
| "We need the highest accuracy" | Ensemble methods | XGBoost |
| "The relationship isn't linear" | Curvature | Polynomial Regression |
| "We have hundreds of variables" | Regularization needed | Ridge / Elastic Net |
| "Reduce overfitting" | Regularization | Ridge Regression |
| "Enterprise-scale prediction pipeline" | Production-grade ensemble | Gradient Boosting / XGBoost |

**Default ladder when nothing else is specified:** start at Linear Regression → add Ridge/Lasso/Elastic Net if there are many/correlated features or feature selection is needed → move to Random Forest/Gradient Boosting/XGBoost if accuracy requirements exceed what linear models deliver. (See `tabular-model-family-progression.md`.)

## 5. Healthcare Use Case → Regression Target

| Use Case | Target |
|---|---|
| PMPM Forecasting | Predicted PMPM |
| Claim Cost Prediction | Future Claim Cost |
| Revenue Forecasting | Future Revenue |
| Length of Stay Prediction | Days in Hospital |
| Readmission Cost Estimation | Expected Cost |
| Risk Adjustment Forecasting | Risk-Based Spend |
| Provider Performance Analysis | Quality Scores |
| Utilization Forecasting | Expected Visits |

## 6. Common Failure Modes

| Problem | Symptoms | Cause | Fix |
|---|---|---|---|
| Underfitting | Poor train and test performance | Model too simple | Add features/complexity |
| Overfitting | Great train, poor test performance | Model too complex | Regularization, more data |
| High Bias | Consistent, systematic errors | Oversimplified assumptions | Increase model complexity |
| High Variance | Unstable predictions across samples | Model too sensitive to training data | Regularization, more data |
| Data Drift | Accuracy decreases over time | Input distribution changes | Retrain |
| Concept Drift | Predictions become unreliable | Underlying business relationship changes | Rebuild model |
