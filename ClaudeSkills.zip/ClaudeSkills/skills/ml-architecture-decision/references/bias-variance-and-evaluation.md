# Bias, Variance, and Model Evaluation

Source: `ML_Fundamentals_Knowledge_Graph.md`, plus bias/variance/overfitting content in `ML_Fundamentals_Final.md`.

## 1. Core Definitions

| Concept | What | Why It Matters | Healthcare Example |
|---|---|---|---|
| Bias | Error from overly simple/oversimplified assumptions | Causes underfitting | Predicting member PMPM cost using only Age — ignores diagnosis, utilization, risk score |
| Variance | Model's sensitivity to the specific training data | Causes overfitting | A model that "memorizes" historical claims and fails on new claims |
| Underfitting | Model too simple to capture real patterns (high bias) | Misses important signal; poor performance even on training data | Poor PMPM predictions across the board |
| Overfitting | Model memorizes training data instead of learning generalizable patterns (high variance) | Great training performance, poor real-world performance | Model perfectly fits historical claims but fails on new members |
| Generalization | Performing well on unseen data | The actual goal of ML | Model holds up in production, not just on the training set |

```
High Bias      → Underfitting
High Variance  → Overfitting
Good Balance   → Generalization
```

## 2. Train / Validation / Test Splits

| Split | Purpose |
|---|---|
| Train | Learn patterns from historical/labeled data |
| Validation | Tune hyperparameters and model choice without touching test data |
| Test | Final, unbiased evaluation on data the model has never influenced or seen |

**Why this matters for this skill:** any recommendation this skill generates should assume metrics are reported on a held-out test set, not the training set. A model that looks excellent only on training data is not evidence of a good recommendation.

## 3. Decision Rule: Train-vs-Test Gap Heuristic

**Rule this skill should apply:** if the gap between a model's train-set metric and its test-set metric exceeds roughly **3 percentage points**, treat it as an overfitting risk signal — flag it in the recommendation output rather than presenting the model as production-ready as-is.

| Signal | Interpretation | Suggested Response |
|---|---|---|
| Train and test metrics both poor, small gap | Underfitting (high bias) | Increase model complexity, add features/interactions, move up the model-family ladder |
| Train metric much higher than test metric (gap > ~3%) | Overfitting (high variance) | Regularize, prune, gather more data, reduce model complexity, or move to an ensemble method that controls variance (e.g., Random Forest over a single Decision Tree) |
| Train and test metrics close and both acceptable | Good generalization | Proceed; monitor in production |

This is a heuristic threshold, not a formal statistical test — treat it as a trigger to investigate further (learning curves, cross-validation variance), not an automatic verdict.

## 4. Production Monitoring: Data Drift vs. Concept Drift

| Type | What Changes | Symptom | Typical Response |
|---|---|---|---|
| Data Drift | Input feature distributions shift over time (e.g., new member demographics) | Accuracy gradually decreases | Retrain on recent data |
| Concept Drift | The underlying relationship between inputs and outputs changes (e.g., risk-score behavior shifts due to a policy or clinical guideline change) | Predictions become unreliable even though inputs look normal | Rebuild/redesign the model, not just retrain — the old feature set or structure may no longer be valid |

**Caveat for generated decision docs:** any architecture recommendation this skill produces should include an open item noting that post-deployment monitoring for both data drift and concept drift is required, and that a drift signal calls for retraining (data drift) vs. a full model rebuild (concept drift) — these are not interchangeable responses.

## 5. Responsible AI Note (context, not a decision driver)

The knowledge graph source also flags Fairness, Privacy, Explainability, and Accountability as standing concerns across all model choices. This skill does not make ethics/compliance decisions, but any recommendation involving a lower-interpretability model (Random Forest and above — see `tabular-model-family-progression.md`) should note that explainability trade-offs may need review against these concerns before production use.
