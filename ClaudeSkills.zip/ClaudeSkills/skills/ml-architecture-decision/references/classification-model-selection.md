# Classification Model Selection (Tabular Data)

Scope: binary/multi-class classification on tabular data only. Source: `MLBuildingClassification.md`.

## 1. Problem Types

| Problem Type | Description | Healthcare Example |
|---|---|---|
| Binary Classification | Two possible outcomes | Fraud / Not Fraud |
| Multi-Class Classification | More than two classes | Risk Stratification: Low / Medium / High |

Output is always a class label, typically derived from a predicted probability plus a decision **threshold** (e.g., flag as "high readmission risk" above 0.8).

## 2. Model Comparison

| Model | Use When | Advantages | Limitations | Healthcare Example |
|---|---|---|---|---|
| Logistic Regression | Explainability is required | Fast, interpretable, solid baseline | Struggles with complex/non-linear patterns | Readmission Prediction |
| Decision Tree | Decisions must map to business rules | Explainable, visual, handles mixed data | Prone to overfitting | Prior Authorization (approve/deny logic) |
| Random Forest | Need accuracy + stability, some interpretability loss OK | Robust, accurate, resists overfitting vs. single tree | Less interpretable than a single tree | Member Risk Prediction |
| Naive Bayes | Text/NLP-flavored features, smaller datasets | Fast, simple, works with limited data | Assumes feature independence (often violated) | Clinical Notes Classification |
| KNN | Similarity-based decisions, small-to-medium data | Simple, intuitive | Slow at inference on large datasets | Member Similarity Matching |
| SVM | High-dimensional feature space, need a strong boundary | Strong accuracy on complex boundaries | Hard to explain, slower to train at scale | Disease Classification from clinical measurements |
| Gradient Boosting | Performance is the priority, willing to tune | High accuracy via sequential error correction | More tuning effort, slower to train | Readmission Risk |
| XGBoost | Enterprise/production-grade tabular model needed | Industry-leading performance on structured data | Complex hyperparameter tuning | Claims Fraud Detection |

## 3. FDE / Stakeholder Model Selection Guide

Use this to translate a stakeholder request directly into a starting model choice.

| Stakeholder Says... | Translate To... | Recommended Model |
|---|---|---|
| "We need to explain why" | Explainability required | Logistic Regression |
| "This should follow our business rules" | Rule-based decisions | Decision Tree |
| "We need it to be accurate and reliable" | Accuracy + stability | Random Forest |
| "This is going into production, give us the best model" | Best tabular performance | XGBoost |
| "We're classifying free text / notes" | Text classification | Naive Bayes |
| "Flag members similar to known cases" | Similarity-based decision | KNN |
| "We need the cleanest possible separation between classes" | Optimal boundary, high-dimensional data | SVM |

**Default ladder when nothing else is specified:** start at Logistic Regression → move to Random Forest if accuracy is insufficient → move to XGBoost if this is a production/enterprise pipeline. (See `tabular-model-family-progression.md` for the full reasoning chain.)

## 4. Precision vs. Recall — When to Optimize for Which

| Metric | Answers | Optimize When... | Healthcare Example |
|---|---|---|---|
| Precision | "Of predicted positives, how many were actually correct?" | False positives are costly (wasted investigation, member friction, unnecessary denial) | Claims Fraud Detection — don't want to flag legitimate claims as fraud |
| Recall | "Of actual positives, how many did we find?" | False negatives are costly (missed disease, missed high-risk member) | Disease Screening / Readmission Risk — missing a true case is worse than a false alarm |
| F1 Score | Balance of both | Classes are imbalanced and neither error type dominates business cost | Readmission Prediction reporting |

**Quick rule:** Fraud/cost-control style problems → bias toward **precision**. Screening/safety/early-detection style problems → bias toward **recall**. When imbalance is present and you need one summary number, use **F1**, not raw accuracy (accuracy is misleading on imbalanced data).

Confusion matrix building blocks: TP (correct positive), FP (incorrect positive — hurts precision), TN (correct negative), FN (missed positive — hurts recall).

## 5. Class Imbalance Handling

**Gap note:** `MLBuildingClassification.md` names class imbalance as a common problem ("high accuracy but poor value" → "resampling, class weights") but does not give a decision rule for choosing between class_weight, oversampling, undersampling, and SMOTE. The guidance below is added as general, widely-used practice to fill that gap — flag it as non-source-derived if strict source-fidelity matters.

| Technique | What It Does | Use When | Watch Out For |
|---|---|---|---|
| `class_weight="balanced"` | Penalizes misclassifying the minority class more heavily during training | First thing to try; works with most sklearn/XGBoost estimators with no data duplication | May not be enough for severe imbalance (>1:50) |
| Random Oversampling | Duplicates minority-class rows | Small datasets where you can't afford to lose majority-class data | Can cause overfitting to duplicated rows |
| Random Undersampling | Removes majority-class rows | Very large datasets where majority class has redundant signal | Throws away potentially useful data |
| SMOTE (Synthetic Minority Oversampling) | Generates synthetic minority-class examples via interpolation | Moderate-to-severe imbalance where oversampling alone overfits | Can create unrealistic synthetic points in noisy/high-dimensional feature space; apply only to training folds, never to validation/test |

**Decision order:** try `class_weight` first (cheapest, no data leakage risk) → if still underperforming on minority recall, try SMOTE on the training set only → reserve pure oversampling/undersampling for cases where weighting isn't supported by the chosen library.

## 6. Healthcare Use Case → Classification Output

| Use Case | Output |
|---|---|
| Readmission Prediction | Readmit / Not Readmit |
| Claims Fraud Detection | Fraud / Not Fraud |
| Prior Authorization | Approve / Deny |
| Risk Stratification | High / Medium / Low |
| Disease Prediction | Disease Category |
| Churn Prediction | Stay / Leave |
| Outreach Targeting | Contact / Do Not Contact |

## 7. Common Failure Modes

| Problem | Symptoms | Fix |
|---|---|---|
| Underfitting | Poor performance on both train and test | Add features, increase model complexity |
| Overfitting | Great train performance, poor test performance | Regularization, more data, simpler model |
| Class Imbalance | High accuracy but low real-world value | Resampling, class weights, F1/recall over accuracy (see Section 5) |
| Data Drift | Accuracy decreases over time as inputs change | Retrain on recent data |
| Concept Drift | Input/output relationship itself changes | Rebuild model, not just retrain |
