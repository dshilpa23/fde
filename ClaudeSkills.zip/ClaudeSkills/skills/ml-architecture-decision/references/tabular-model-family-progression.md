# Tabular Model Family Progression: One Ladder for Classification and Regression

This is a synthesized decision ladder, not a source excerpt. It unifies the classification and regression model-comparison tables (`classification-model-selection.md`, `regression-model-selection.md`) into a single interpretability-vs-performance progression. Use it to decide **how far up the ladder** a given business requirement should push you — climb only as far as the requirement demands, since every rung trades away interpretability and adds training/ops cost.

```
Linear/Logistic Regression
        ↓
   Decision Tree
        ↓
Bagging / Random Forest
        ↓
Boosting (AdaBoost / Gradient Boosting)
        ↓
       XGBoost
```

## Rung 1 — Linear Regression / Logistic Regression

- **What it buys you:** A fast, fully interpretable baseline. Coefficients map directly to feature effects; stakeholders and auditors can see exactly why a prediction came out the way it did.
- **What it costs:** Assumes linear (regression) or linearly-separable (classification) relationships. Struggles with complex/non-linear patterns and is sensitive to outliers.
- **Signal that pushes you here / keeps you here:** "We need to explain the model to compliance/clinicians/regulators." "This is a simple baseline before we invest more." Example: PMPM cost forecasting for a stakeholder deck; readmission prediction where legal/compliance needs a plain explanation.
- **Overfitting risk:** Low (often underfits before it overfits).
- **Training cost:** Very low.

## Rung 2 — Decision Tree

- **What it buys you over Rung 1:** Captures non-linear relationships and interactions natively; produces explicit if/then rules that map directly onto business logic. Handles mixed data types without heavy preprocessing.
- **What it costs:** Individual trees overfit easily and are unstable (small data changes → different tree structure).
- **Signal that pushes you here:** "We need to explain an individual prediction/decision to a clinician or caseworker" or "the decision needs to look like a business rule" — e.g., prior authorization approve/deny logic, diagnosis cost pathways. **Stop here** if per-case explainability to a non-technical human is a hard requirement and Rung 1's linear assumption is too limiting.
- **Overfitting risk:** High if unpruned.
- **Training cost:** Low.

## Rung 3 — Bagging / Random Forest

- **What it buys you over Rung 2:** Averages many trees trained on bootstrapped samples ("many weak trees → one strong model"), which materially reduces the variance/overfitting problem of a single tree while keeping most of its ability to model non-linearity. Robust and accurate with minimal tuning.
- **What it costs:** Loses the clean single-tree explainability — you get feature importances instead of a readable rule path. Slower to train and score than a single tree; larger model artifact.
- **Signal that pushes you here:** "We need accuracy and stability, and full per-prediction explainability is not a hard requirement" — e.g., member risk prediction, high-cost member prediction, general readmission risk models used internally.
- **Overfitting risk:** Moderate-low (bagging is specifically designed to control this).
- **Training cost:** Moderate (parallelizable across trees).

## Rung 4 — Boosting (AdaBoost / Gradient Boosting)

- **What it buys you over Rung 3:** Trees are built sequentially, each one correcting the errors of the previous ensemble, which typically pushes accuracy above what bagging alone achieves — especially valuable when the cost of errors is asymmetric (e.g., missing a high-cost member).
- **What it costs:** More hyperparameter tuning (learning rate, tree depth, number of estimators, regularization), longer training time, and higher overfitting risk than Random Forest if not tuned/early-stopped carefully. Interpretability drops further (though SHAP-style post-hoc explanation is still feasible).
- **Signal that pushes you here:** "Performance is the priority and we're willing to invest in tuning" — e.g., claims cost forecasting, readmission risk where marginal accuracy gains have real dollar value.
- **Overfitting risk:** Moderate-high without careful tuning (learning rate, early stopping, max depth).
- **Training cost:** Moderate-high (sequential, harder to parallelize than bagging).

## Rung 5 — XGBoost (and peers: LightGBM, CatBoost)

- **What it buys you over Rung 4:** An optimized, regularized, production-hardened implementation of gradient boosting — built-in handling of missing values, regularization to control overfitting, and engineering optimizations for speed at scale. Both source files independently name this as the top-performance / industry-standard choice for structured/tabular data (classification: "Industry Standard," "Claims Fraud"; regression: "Usually highest performance," "PMPM Forecasting").
- **What it costs:** The most complex hyperparameter surface on this ladder; least transparent without dedicated explainability tooling (SHAP/feature importance); heaviest infra/ops investment to deploy and monitor responsibly.
- **Signal that pushes you here:** "We need the best possible accuracy for a production/enterprise pipeline and explainability is not a hard blocking requirement" — e.g., claims fraud detection, enterprise-scale PMPM/cost forecasting pipelines feeding downstream automated decisions.
- **Overfitting risk:** Moderate-high if under-regularized; well-controlled if tuned (regularization params, early stopping, cross-validation).
- **Training cost:** Highest on this ladder, offset by strong tooling/scalability (esp. LightGBM variant for very large data).

## Decision Cheat-Sheet

| Business Signal | Stop At |
|---|---|
| Must explain coefficients to compliance/regulators | Rung 1 (Linear/Logistic Regression) |
| Must explain individual predictions as rules to a clinician/caseworker | Rung 2 (Decision Tree) |
| Need solid accuracy + stability, aggregate explainability (feature importance) is enough | Rung 3 (Random Forest) |
| Performance is the priority, error costs are asymmetric, team can tune | Rung 4 (Boosting) |
| Best possible accuracy for an internal/production pipeline, explainability not required | Rung 5 (XGBoost) |

**General principle:** climb the ladder only as far as the accuracy requirement forces you to — each rung is a one-way trade of interpretability and engineering simplicity for performance. Don't default to XGBoost; justify each rung against a concrete business/data signal.
