#!/usr/bin/env python3
"""Validate an ml_architecture_decision.md artifact against the decision-file contract.

Usage:
    validate_decision_file.py [path]   (defaults to ./ml_architecture_decision.md)

Exits 0 and prints "OK" + normalized JSON if valid. Exits 1 and prints a list
of specific errors otherwise. This is the self-check the ml-architecture-decision
skill runs on its own output before presenting it, and the same contract the
independent ml-implementation skill relies on when it later reads this file.
"""
import json
import re
import sys

REQUIRED_FIELDS = [
    "schema_version",
    "problem_type",
    "target_column",
    "model_family",
    "preprocessing",
    "evaluation_metrics",
    "confidence",
]
VALID_PROBLEM_TYPES = {"classification", "regression"}
VALID_CONFIDENCE = {"low", "medium", "high"}
VALID_IMBALANCE = {"none", "class_weight", "oversample", "undersample", "smote"}


def _split_top_commas(s: str) -> list:
    parts, depth, current, in_quote = [], 0, "", None
    for ch in s:
        if in_quote:
            current += ch
            if ch == in_quote:
                in_quote = None
            continue
        if ch in "\"'":
            in_quote = ch
            current += ch
        elif ch in "[{":
            depth += 1
            current += ch
        elif ch in "]}":
            depth -= 1
            current += ch
        elif ch == "," and depth == 0:
            parts.append(current)
            current = ""
        else:
            current += ch
    if current.strip():
        parts.append(current)
    return [p.strip() for p in parts if p.strip()]


def _parse_scalar(s: str):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        return s[1:-1]
    if s in ("null", "~", ""):
        return None
    if s in ("true", "True"):
        return True
    if s in ("false", "False"):
        return False
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        pass
    return s


def _parse_flow(s: str):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        if not inner:
            return []
        return [_parse_flow(p) if p.strip()[:1] in "[{" else _parse_scalar(p) for p in _split_top_commas(inner)]
    if s.startswith("{") and s.endswith("}"):
        inner = s[1:-1].strip()
        result = {}
        if not inner:
            return result
        for part in _split_top_commas(inner):
            if ":" not in part:
                continue
            k, v = part.split(":", 1)
            result[_parse_scalar(k)] = _parse_flow(v) if v.strip()[:1] in "[{" else _parse_scalar(v)
        return result
    return _parse_scalar(s)


def parse_frontmatter(text: str) -> dict:
    """Minimal YAML-subset parser for this fixed contract (not general YAML)."""
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except ImportError:
        pass

    lines = text.splitlines()
    root: dict = {}
    stack = [(root, -1)]  # (container, indent) ; container is dict or list
    pending_key = None  # top-level key waiting for an indented block

    for raw in lines:
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        content = raw.strip()

        while len(stack) > 1 and indent <= stack[-1][1]:
            stack.pop()
        container, _ = stack[-1]

        if content.startswith("- "):
            value = content[2:].strip()
            parsed = _parse_flow(value) if value[:1] in "[{" else _parse_scalar(value)
            if isinstance(container, list):
                container.append(parsed)
            continue

        if ":" not in content:
            continue
        key, _, value = content.partition(":")
        key = key.strip().strip("\"'")
        value = value.strip()

        if value == "":
            new_container: dict = {}
            if isinstance(container, dict):
                container[key] = new_container
            stack.append((new_container, indent))
        else:
            parsed = _parse_flow(value) if value[:1] in "[{" else _parse_scalar(value)
            if isinstance(container, dict):
                container[key] = parsed

    return root


def extract_frontmatter(md_text: str) -> str:
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n", md_text, re.DOTALL)
    if not match:
        raise ValueError("no YAML frontmatter block found (expected '---' ... '---' at top of file)")
    return match.group(1)


def validate(data: dict) -> list:
    errors = []
    for field in REQUIRED_FIELDS:
        if field not in data or data[field] in (None, ""):
            errors.append(f"missing required field: {field}")

    problem_type = data.get("problem_type")
    if problem_type is not None and problem_type not in VALID_PROBLEM_TYPES:
        errors.append(f"problem_type must be one of {VALID_PROBLEM_TYPES}, got {problem_type!r}")

    confidence = data.get("confidence")
    if confidence is not None and confidence not in VALID_CONFIDENCE:
        errors.append(f"confidence must be one of {VALID_CONFIDENCE}, got {confidence!r}")

    if problem_type == "classification" and not data.get("class_balance"):
        errors.append("problem_type is classification but class_balance is missing")
    if problem_type == "regression" and data.get("class_balance"):
        errors.append("problem_type is regression but class_balance is present (should be omitted)")

    imbalance = data.get("imbalance_handling")
    if problem_type == "regression" and imbalance and imbalance != "none":
        errors.append(f"problem_type is regression but imbalance_handling is set to {imbalance!r}")
    if imbalance is not None and imbalance not in VALID_IMBALANCE:
        errors.append(f"imbalance_handling must be one of {VALID_IMBALANCE}, got {imbalance!r}")

    model_family = data.get("model_family")
    if isinstance(model_family, dict):
        if not model_family.get("primary_recommendation"):
            errors.append("model_family.primary_recommendation is missing")
    elif "model_family" in data:
        errors.append("model_family must be a mapping with at least primary_recommendation")

    eval_metrics = data.get("evaluation_metrics")
    if eval_metrics is not None and not isinstance(eval_metrics, list):
        errors.append("evaluation_metrics must be a list")

    return errors


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else "./ml_architecture_decision.md"
    try:
        with open(path, "r") as f:
            text = f.read()
    except FileNotFoundError:
        print(json.dumps({"valid": False, "errors": [f"file not found: {path}"]}))
        return 1

    try:
        frontmatter_text = extract_frontmatter(text)
        data = parse_frontmatter(frontmatter_text)
    except Exception as exc:
        print(json.dumps({"valid": False, "errors": [str(exc)]}))
        return 1

    errors = validate(data)
    if errors:
        print(json.dumps({"valid": False, "errors": errors}, indent=2))
        return 1

    print(json.dumps({"valid": True, "parsed": data}, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
