#!/usr/bin/env python3
"""Profile a CSV for tabular ML architecture decisions.

Usage:
    profile_dataset.py <csv_path> [--target COLUMN]

Prints a single JSON object to stdout: shape, per-column dtype/missingness/
cardinality, and (if --target given) target-specific stats — class balance
for a likely-categorical target, or distribution/outlier stats for a likely-
continuous target. Does not fit any model and does not plot anything.
"""
import argparse
import json
import sys

import numpy as np
import pandas as pd


def profile_columns(df: pd.DataFrame) -> dict:
    n_rows = len(df)
    columns = {}
    for col in df.columns:
        series = df[col]
        n_missing = int(series.isna().sum())
        n_unique = int(series.nunique(dropna=True))
        col_info = {
            "dtype": str(series.dtype),
            "missing_count": n_missing,
            "missing_pct": round(n_missing / n_rows * 100, 2) if n_rows else 0.0,
            "n_unique": n_unique,
            "unique_pct": round(n_unique / n_rows * 100, 2) if n_rows else 0.0,
        }
        col_info["likely_id"] = col_info["unique_pct"] > 95
        col_info["high_cardinality"] = (
            series.dtype == object and n_unique > 20 and not col_info["likely_id"]
        )
        columns[col] = col_info
    return columns


def classify_target_kind(series: pd.Series) -> str:
    non_null = series.dropna()
    if non_null.dtype == object or non_null.dtype.name == "category":
        return "categorical"
    n_unique = non_null.nunique()
    if pd.api.types.is_integer_dtype(non_null) and n_unique <= 20:
        return "categorical"
    if n_unique <= 2:
        return "categorical"
    return "continuous"


def profile_target(series: pd.Series) -> dict:
    kind = classify_target_kind(series)
    non_null = series.dropna()
    if kind == "categorical":
        counts = non_null.value_counts()
        total = int(counts.sum())
        class_pct = {str(k): round(v / total, 4) for k, v in counts.items()}
        majority_count = int(counts.iloc[0])
        minority_count = int(counts.iloc[-1])
        return {
            "kind": "categorical",
            "n_classes": int(counts.shape[0]),
            "class_counts": {str(k): int(v) for k, v in counts.items()},
            "class_pct": class_pct,
            "majority_class": str(counts.index[0]),
            "minority_class": str(counts.index[-1]),
            "imbalance_ratio": round(majority_count / minority_count, 2) if minority_count else None,
        }
    else:
        q1 = float(non_null.quantile(0.25))
        q3 = float(non_null.quantile(0.75))
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        outlier_pct = round(
            float(((non_null < lower) | (non_null > upper)).mean() * 100), 2
        )
        return {
            "kind": "continuous",
            "mean": float(non_null.mean()),
            "std": float(non_null.std()),
            "min": float(non_null.min()),
            "q1": q1,
            "median": float(non_null.median()),
            "q3": q3,
            "max": float(non_null.max()),
            "skew": float(non_null.skew()),
            "iqr_outlier_pct": outlier_pct,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path")
    parser.add_argument("--target", default=None, help="Target column name")
    args = parser.parse_args()

    try:
        df = pd.read_csv(args.csv_path)
    except Exception as exc:
        print(json.dumps({"error": f"failed to read CSV: {exc}"}), file=sys.stdout)
        return 1

    result = {
        "csv_path": args.csv_path,
        "n_rows": int(df.shape[0]),
        "n_columns": int(df.shape[1]),
        "n_duplicate_rows": int(df.duplicated().sum()),
        "columns": profile_columns(df),
    }

    if args.target:
        if args.target not in df.columns:
            result["target_error"] = f"column '{args.target}' not found in CSV"
        else:
            result["target_column"] = args.target
            result["target_profile"] = profile_target(df[args.target])

    print(json.dumps(result, indent=2, default=lambda o: None))
    return 0


if __name__ == "__main__":
    sys.exit(main())
