---
schema_version: 1
generated_at: <YYYY-MM-DD>
source_dataset: <path to CSV, or "verbal description only">
problem_type: <classification|regression>
target_column: <name>
target_type: <binary|multiclass|continuous>
n_rows: <int>
n_features: <int>
missingness: {<column>: <pct as decimal>, ...}      # omit or {} if none
high_cardinality_columns: [<column>, ...]            # omit or [] if none
class_balance: {<class_label>: <pct as decimal>, ..., minority_class: <label>, imbalance_ratio: <float>}  # CLASSIFICATION ONLY — omit entirely for regression
model_family: {baseline: <ModelName>, progression: [<ModelName>, ...], primary_recommendation: <ModelName>, reasoning_summary: "<one sentence>"}
preprocessing: {imputation: {categorical: mode, numerical: median}, encoding: {onehot: [<col>, ...], ordinal: {<col>: [<ordered categories>]}}, scaling: <standard|none>, outlier_treatment: <iqr_cap|skip_binary_target>, pca: <recommended|not_recommended>}
imbalance_handling: <none|class_weight|oversample|undersample|smote>   # must be "none" for regression
evaluation_metrics: [<metric>, ...]
confidence: <low|medium|high>
open_items: ["<assumption or unknown to confirm with the user>", ...]
---

## Executive Summary
<2-3 sentences: problem type, recommended model, why.>

## Data Profile
<Key stats from scripts/profile_dataset.py — rows, missingness, cardinality, target distribution/balance.>

## Problem Framing
<Why this is classification vs. regression, and what target_type/binary-vs-multiclass/continuous means for the approach.>

## Model Family Reasoning
<Where on the interpretability-vs-performance ladder this recommendation sits and why, citing the specific business/data signal that justified it.>

## Preprocessing Plan
<Imputation, encoding, scaling, outlier treatment, PCA — with column-level specifics from the data profile.>

## Class Imbalance Plan
<Only for classification. State the ratio and the chosen remediation, or explicitly state "no action needed" with the ratio that justifies it.>

## Evaluation Plan
<Metrics list plus the train-vs-test gap overfitting heuristic.>

## Risks / Assumptions / Open Questions
<Explicit list — ambiguous columns, unconfirmed domain semantics, unresolved internal-library dependencies, verbal-only inputs.>
