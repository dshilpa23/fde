# ML Architecture Decision

A Claude Code skill that produces a structured, machine-readable + human-readable **ML architecture
decision artifact** for tabular classification and regression problems — the design step you run
*before* writing any model-training code.

## What it does

Given a CSV (or a verbal description of one), it:

1. **Profiles the data for real** — dtypes, missingness %, cardinality, class balance / target
   distribution — via a bundled script, not by eyeballing a pasted `.head()`.
2. **Classifies the problem** — binary/multiclass classification vs. regression — and states the
   rule it applied.
3. **Recommends a model family** along the house progression (Linear/Logistic Regression →
   Decision Tree → Bagging/Random Forest → Boosting → XGBoost), matched to whether the priority is
   explainability, general accuracy, or a production pipeline.
4. **Builds a preprocessing plan** — imputation, encoding (one-hot vs. ordinal), scaling, outlier
   treatment (IQR capping), and whether PCA is actually warranted.
5. **Picks a class-imbalance strategy** (classification only) — none / `class_weight` / oversample /
   undersample / SMOTE, based on the computed imbalance ratio.
6. **Specifies evaluation metrics** plus the train-vs-test overfitting heuristic (>3% gap flags
   overfitting risk).
7. **Writes and self-validates** `./ml_architecture_decision.md` in the working directory, running
   the bundled validator and fixing any contract violations before presenting it.
8. **States a confidence level** (`low`/`medium`/`high`) and lists concrete open items — ambiguous
   target semantics, unconfirmed column orderings, missing domain context.

## Scope

**In scope:** tabular classification and regression only.

**Out of scope:** text/NLP, images/computer vision, audio, time series, clustering,
dimensionality-reduction-as-the-goal, reinforcement learning, deep learning. The skill will say so
and stop rather than force-fitting its guidance onto these.

## How to invoke

In Claude Code, trigger it with `/ml-architecture-decision`, or just ask naturally:

- "What model should I use for this dataset?"
- "How should I approach this dataset?"
- "Help me choose a model for [CSV path]"
- Paste a business problem + a data sample and ask what to build

If you give a CSV path, the skill runs the profiler on it directly. Without a file, it proceeds on
your verbal description alone and caps confidence at `medium`.

## Output

A single file, `./ml_architecture_decision.md`, written to your current working directory:
YAML frontmatter (fields the companion `ml-implementation` skill parses) + a Markdown body
(narrative reasoning that gets embedded into notebook cells downstream). The two skills share no
code — only this file-naming convention.

## Directory contents

```
ml-architecture-decision/
├── SKILL.md                                    # instructions Claude follows
├── README.md                                   # this file
├── scripts/
│   ├── profile_dataset.py                      # real CSV profiler (no model fitting/plotting)
│   └── validate_decision_file.py               # enforces the decision-file contract
├── assets/
│   └── ml_architecture_decision.template.md    # blank artifact skeleton
└── references/
    ├── classification-model-selection.md       # model comparison, FDE guide, imbalance guidance
    ├── regression-model-selection.md           # model comparison, MAE/MSE/RMSE/R² guidance
    ├── tabular-model-family-progression.md     # unified interpretability-vs-performance ladder
    └── bias-variance-and-evaluation.md         # bias/variance, overfitting heuristic, drift caveats
```

### Running the profiler standalone

```
python3 scripts/profile_dataset.py <csv_path> --target <column>
```

Prints a single JSON object to stdout — shape, per-column dtype/missingness/cardinality, and (if
`--target` is given) target-specific stats: class balance for a likely-categorical target, or
distribution/outlier stats for a likely-continuous target. Does not fit any model and does not plot
anything.

### Validating a decision file standalone

```
python3 scripts/validate_decision_file.py ./ml_architecture_decision.md
```

Exits 0 with the parsed JSON if the file satisfies the contract (required fields, valid enum
values, classification/regression-conditional fields); exits 1 with a list of specific errors
otherwise.

## Installing / sharing

This is a self-contained skill folder with no external dependencies beyond a Python 3 interpreter.

- **Personal use:** place it at `~/.claude/skills/ml-architecture-decision/`.
- **Team use:** copy it into `.claude/skills/ml-architecture-decision/` inside a shared git repo and
  commit it — Claude Code auto-discovers project-scoped skills for anyone who clones the repo.

## Related skill

`ml-implementation` reads `./ml_architecture_decision.md` and scaffolds the actual
Databricks-notebook-source pipeline (imputation/encoding/scaling, baseline model, hyperparameter
tuning, model-progression comparison table) matching this codebase's house style. Run this skill
first; run that one second.
