# Secure agent development lifecycle control catalog

## Contents

1. Gate 1: idea and policy
2. Gate 2: approved components
3. Gate 3: secure architecture and development
4. Gate 4: build-time controls
5. Gate 5: testing and validation
6. Gate 6: compliance and evidence
7. Gate 7: deploy, monitor, and improve
8. Architecture surfaces

## Gate 1: Idea and policy check

Verify business objective, decision owner, affected users, autonomy level, prohibited actions, data classes, jurisdiction, sector restrictions, human accountability, and documented go/no-go authority.

Minimum evidence: use-case record, data classification, risk tier, policy references, human decision boundary, approval owner.

## Gate 2: Approved components

Inventory models, datasets, packages, frameworks, containers, tools, MCP servers, A2A peers, plugins, skills, and external APIs. Verify source, version pinning, licenses, integrity, vulnerability and malware scanning, model provenance, allowlisting, and SBOM/AIBOM evidence.

Minimum evidence: locked dependencies, component inventory, approved-source record, scan evidence, exception process.

## Gate 3: Secure architecture and development

Verify explicit trust boundaries, separate agent/runtime identities, constrained tools, gateway mediation, authenticated MCP/A2A communication, tenant isolation, least agency, least privilege, safe defaults, sandboxing, network egress rules, and human approval for high-impact actions.

Minimum evidence: architecture/data-flow map, tool registry, identity model, authorization policy, action classification, approval flow.

## Gate 4: Build-time controls

Verify input and output guardrails, deterministic policy checks, prompt/context separation, secret handling, structured outputs, schema validation, sensitive-data minimization, resource quotas, signed artifacts, protected configuration, and fail-closed behavior.

Minimum evidence: enforced code path, configuration, unit/contract tests, negative tests, release build checks.

## Gate 5: Testing and validation

Verify functional quality plus prompt injection, jailbreak, sensitive disclosure, unsafe tool use, privilege escalation, RAG and memory poisoning, inter-agent spoofing, unexpected code execution, cost exhaustion, cascading failure, emergency stop, and recovery tests.

Minimum evidence: synthetic test data, threat-to-test map, reproducible command, results, defects, retest evidence.

## Gate 6: Compliance and evidence

Map implemented controls to the standards and policies actually in scope. Preserve design, implementation, test, approval, incident, and ownership evidence. Compliance must be decided by the designated authority, not inferred by this skill.

Minimum evidence: control mapping, evidence index, retention policy, reviewer, exceptions, release decision.

## Gate 7: Deploy, monitor, and improve

Verify controlled release, workload identity, secret rotation, policy decision logs, model and tool traces, data leakage signals, cost/latency limits, incident detection, emergency stop, rollback, human feedback triage, drift review, ownership, and continuous hardening.

Minimum evidence: runbook, RACI, alerts, dashboards or queries, rollback test, feedback workflow, post-release review cadence.

## Architecture surfaces

Always inspect these surfaces when present:

- users and channels: untrusted input, authentication, rate limits;
- agent interface: session isolation, data minimization, output encoding;
- model: prompt injection, unsafe behavior, data handling, provider controls;
- orchestrator: goal integrity, planning bounds, task limits, context separation;
- tools and external services: authorization, parameters, side effects, egress, approval;
- MCP: server trust, tool-description poisoning, capability discovery, tokens, transport;
- A2A: peer identity, message integrity, delegated authority, replay, provenance;
- RAG and knowledge: source authority, access filters, poisoning, freshness, citations;
- memory: tenant/case isolation, write controls, poisoning, retention, deletion;
- gateway and guardrails: mediation coverage, deterministic policies, bypass paths;
- NHI and secrets: unique workload identity, short-lived tokens, scope, rotation;
- output and downstream code: schemas, escaping, command/query construction, human reliance;
- operations: auditability, alerts, rollback, emergency stop, ownership.

