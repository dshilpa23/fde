# Finding and audit package schema

## Status rules

- `PASS`: applicable control is implemented and supported by sufficient evidence; a test exists where reasonably feasible.
- `PARTIAL`: some control exists but coverage, enforcement, evidence, or tests are incomplete.
- `FAIL`: control is applicable and absent, bypassable, disabled, or demonstrably ineffective.
- `N/A`: category is not applicable and the reason is documented.
- `UNVERIFIED`: applicability or effectiveness cannot be established safely from available evidence.

## Severity rules

- `CRITICAL`: credible path to large-scale sensitive-data loss, unauthorized high-impact action, remote code execution, cross-tenant compromise, or irreversible harm with weak barriers.
- `HIGH`: exploitable control failure with serious confidentiality, integrity, availability, financial, legal, or patient/workflow impact.
- `MEDIUM`: meaningful weakness requiring conditions, limited authority, or additional chaining.
- `LOW`: defense-in-depth, hardening, or low-impact weakness.
- `INFO`: observation with no current security failure.

Do not assign CVSS unless the evidence supports the required parameters.

## Finding record

```yaml
id: SAR-001
title: Write-capable tool bypasses approval gate
status: FAIL
severity: HIGH
lifecycle_gate: 3
owasp_llm: [LLM03:2026]
owasp_agentic: [ASI02, ASI03]
applicability: The agent can update a case record.
attack_path: Untrusted request -> planner -> update tool -> database
evidence:
  implementation: app/tools.py:88
  test: tests/test_tool_policy.py::test_write_requires_approval
control_present: Tool registry exists but is not enforced on this entry point.
gap: The alternate API route calls the tool directly.
remediation: Route every tool call through server-side policy enforcement.
acceptance_test: Direct and alternate routes both deny the action without approval.
owner_type: Application engineering
release_impact: Block release until fixed.
confidence: High
```

## Required package

```text
security-audit/
  00_executive_summary.md
  01_scope_and_architecture.md
  02_lifecycle_gate_scorecard.md
  03_owasp_llm_2026_matrix.md
  04_owasp_agentic_2026_matrix.md
  05_findings_register.csv
  06_security_control_test_map.md
  07_remediation_and_release.md
  evidence/
    repository_evidence.json
    test_results.md
```

The executive summary must state repository revision, audit mode, confidence, critical/high counts, release decision, blockers, and major unverified areas.

The findings CSV columns are:

```text
id,title,status,severity,lifecycle_gate,owasp_llm,owasp_agentic,evidence,gap,remediation,acceptance_test,owner_type,release_impact,confidence
```

Every applicable `FAIL` or `PARTIAL` item must link to a remediation and acceptance test. Every `PASS` must cite evidence. Every `N/A` and `UNVERIFIED` must include a reason.

