# OWASP GenAI LLM Top 10 2026 audit catalog

Authoritative edition: OWASP GenAI LLM Top 10 2026, published 3 August 2026. Source: https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/

Use the official edition label in reports. Do not merge IDs with the 2025 ordering.

| ID | Risk | Repository questions | Minimum failable test |
|---|---|---|---|
| LLM01:2026 | Prompt Injection | Are system instructions separated from untrusted user, retrieved, tool, and agent content? Are high-impact actions policy-gated outside the model? | Direct and indirect injection cannot change protected goals or authorize a tool action. |
| LLM02:2026 | Sensitive Information Disclosure | Can prompts, context, outputs, logs, traces, embeddings, errors, or tools expose PII, PHI, secrets, tenant data, or system instructions? | Synthetic sensitive fields are blocked/redacted across response, logs, and tool parameters. |
| LLM03:2026 | Excessive Agency | Does the model receive more tools, permissions, autonomy, duration, or side effects than the task requires? | High-impact action is denied or requires valid approval; unknown actions fail closed. |
| LLM04:2026 | Supply Chain | Are models, packages, prompts, plugins, MCP servers, skills, datasets, and containers approved, pinned, scanned, and traceable? | Unapproved or integrity-mismatched component blocks the build or release. |
| LLM05:2026 | Data and Model Poisoning | Can untrusted training, retrieval, feedback, or memory content influence trusted behavior without validation and provenance? | Poisoned content is quarantined, down-ranked, or unable to alter policy and durable memory. |
| LLM06:2026 | Unbounded Consumption | Are calls, iterations, tokens, tools, retries, concurrency, time, and spend bounded? | Runaway loop or retry storm terminates within configured limits and emits an alert. |
| LLM07:2026 | Misinformation | Are claims grounded, uncertainty shown, high-risk decisions verified, and unsafe confidence prevented? | Unsupported or conflicting evidence produces abstention/escalation rather than a confident action. |
| LLM08:2026 | Hidden Context Exposure | Can hidden prompts, internal reasoning artifacts, private metadata, tool descriptions, or unrelated context leak to users or peers? | Requests for hidden/internal context are refused and traces remain access-controlled. |
| LLM09:2026 | Vector and Embedding Weaknesses | Are tenant filters, source trust, freshness, access controls, poisoning checks, and embedding storage protected? | Cross-tenant and poisoned retrieval tests return no unauthorized or untrusted evidence. |
| LLM10:2026 | Improper Output Handling | Is model output validated, typed, encoded, and treated as untrusted before SQL, shell, HTML, APIs, or tools consume it? | Malicious output cannot trigger command, query, template, browser, or tool injection. |

For each category, cite implementation and test evidence separately. A prompt statement alone is not a sufficient control for high-impact actions.

