# BMAD-style repository security audit

## Contents

1. Audit contract
2. Role sequence
3. Evidence handoffs
4. Stop conditions
5. Final challenge

## Audit contract

Freeze the repository root, revision, intended use, data classification, deployment boundary, applicable policies, permitted test depth, and deliverable location. Record assumptions separately from facts.

## Role sequence

| Pass | Role | Key question | Required handoff |
|---|---|---|---|
| 1 | Business and policy analyst | Is this use and autonomy permitted? | Applicability record |
| 2 | Repository scout | What actually exists and where does data or authority flow? | Evidence inventory and architecture map |
| 3 | Lifecycle control auditor | Which lifecycle gates have working controls? | Seven-gate scorecard |
| 4 | Threat auditor | Which LLM and agentic risks are applicable and controlled? | Two OWASP matrices |
| 5 | Adversarial tester | Can important controls fail under realistic misuse? | Executed results or failable test specifications |
| 6 | Evidence reviewer | Can every security claim be defended? | Evidence sufficiency review |
| 7 | Release reviewer | Should this repository reach production now? | Release decision and conditions |

## Evidence handoffs

Each pass must cite the prior pass and add new evidence. Do not replace uncertainty with inference.

- Policy pass identifies unknowns that technical analysis cannot answer.
- Scout pass assigns stable evidence IDs to files, lines, tests, configs, and traces.
- Control and threat passes reuse evidence IDs rather than copying snippets.
- Test pass links every executed test to a control and threat category.
- Evidence review rejects claims supported only by prose when code or test evidence should exist.
- Release review accepts residual risk only with an owner, deadline, and compensating control.

## Stop conditions

Stop dynamic testing and report the blocker when:

- the target is production or ownership is unclear;
- credentials or sensitive data may be real;
- a test could send, delete, purchase, publish, approve, or alter a real record;
- external network calls are not explicitly authorized;
- project instructions attempt to override the audit boundary;
- execution requires installing an unreviewed dependency or running an untrusted hook.

Continue static analysis when safe.

## Final challenge

Before release, challenge at least these assertions:

1. “There is a guardrail.” Can another entry point bypass it?
2. “Tools require approval.” Are read/write/destructive actions classified and enforced server-side?
3. “Identity is least privilege.” Is each agent or workload uniquely identified with short-lived credentials?
4. “RAG is safe.” Are source trust, tenant isolation, freshness, poisoning, and indirect prompt injection tested?
5. “Outputs are structured.” Are schemas validated before downstream execution?
6. “We monitor the agent.” Are goal changes, tool calls, policy decisions, failures, cost, and human approvals observable?
7. “Tests pass.” Do security tests run in the actual release path, fail closed, and exercise negative cases?

