# OWASP Top 10 for Agentic Applications 2026 audit catalog

Authoritative edition: OWASP Top 10 for Agentic Applications 2026, published 9 December 2025. Source: https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/

| ID | Risk | Repository questions | Minimum failable test |
|---|---|---|---|
| ASI01 | Agent Goal Hijack | Can user, RAG, memory, tool, or peer content redirect protected objectives or planning? | Malicious content cannot change protected goal, policy, or approval state. |
| ASI02 | Tool Misuse & Exploitation | Are tool choice, parameters, targets, side effects, and sequences constrained independently of the model? | Disallowed target, parameter, or action is blocked and logged. |
| ASI03 | Identity & Privilege Abuse | Does each agent/workload have unique, least-privilege, short-lived identity with delegated scope? | Agent cannot use another role, tenant, or expired/replayed token. |
| ASI04 | Agentic Supply Chain Vulnerabilities | Are models, MCP/A2A components, tools, plugins, skills, prompts, and dependencies trusted and integrity checked? | Unknown or tampered component is rejected before use. |
| ASI05 | Unexpected Code Execution (RCE) | Can natural-language, tool output, configuration, generated code, or model output reach eval, shell, template, or interpreter sinks? | Crafted content cannot execute code; sandbox and allowlist boundaries hold. |
| ASI06 | Memory & Context Poisoning | Who can write durable memory or shared context, and how are provenance, scope, expiry, and corrections enforced? | Poisoned or cross-case memory is rejected, isolated, or removable. |
| ASI07 | Insecure Inter-Agent Communication | Are peers authenticated and are messages signed/validated with explicit delegated authority and provenance? | Spoofed, replayed, malformed, or over-delegated A2A message is rejected. |
| ASI08 | Cascading Failures | Are loops, retries, fan-out, dependencies, and downstream actions bounded with circuit breakers and compensation? | One failed/false result does not propagate uncontrolled across agents or tools. |
| ASI09 | Human-Agent Trust Exploitation | Are uncertainty, evidence, action previews, conflicts, and approval consequences visible to the human? | Misleading confidence or unsupported recommendation cannot obtain silent approval. |
| ASI10 | Rogue Agents | Are autonomy, goal drift, persistence, self-modification, resource creation, and shutdown behavior bounded and observable? | Agent respects stop/revoke, cannot persist or expand authority, and fails safe. |

Map tests to the concrete action path. A generic chatbot jailbreak suite is insufficient for tool-using or multi-agent systems.

