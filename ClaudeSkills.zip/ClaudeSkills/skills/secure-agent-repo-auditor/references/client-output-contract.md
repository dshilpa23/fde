# Client report output contract

## Primary deliverables

Every completed audit must contain:

```text
Secure_Agent_Security_Audit_Report.docx
Secure_Agent_Security_Audit_Dashboard.html
```

The Markdown, CSV, JSON, and test evidence remain the audit working papers. Treat the DOCX and HTML as the primary client outputs.

## Word report

Use a formal security-assessment design with:

1. cover, audit scope, decision and confidentiality note;
2. executive summary and risk counts;
3. architecture and attack surface;
4. seven lifecycle gates;
5. OWASP LLM 2026 matrix;
6. OWASP Agentic 2026 matrix;
7. prioritized findings with evidence and acceptance tests;
8. security control and test map;
9. remediation roadmap and release recommendation;
10. test evidence and material limitations.

Use restrained navy, blue, amber, red and green status colors. Do not use emoji or decorative filler. Repeat table headers across pages, use readable column widths, and avoid wide findings tables; present detailed findings as stacked records when necessary.

Render the DOCX to page images and inspect every page. Reject clipping, split headings, orphaned labels, unreadable tables, blank pages, broken page numbering, or excessive whitespace.

## HTML dashboard

Create a single self-contained HTML file with embedded CSS and no remote dependencies. Include:

- release-decision hero;
- critical, high, medium and low risk cards;
- severity distribution chart;
- seven lifecycle-gate status view;
- OWASP LLM and Agentic coverage charts;
- prioritized finding cards with evidence, remediation and acceptance tests;
- control/test map;
- remediation phases and residual limitations;
- audit scope and generation metadata.

Use semantic HTML, accessible contrast, keyboard-readable sections, print styles and responsive layouts. Do not expose secret values or include raw repository content beyond the approved evidence snippets.

## Consistency rules

- Generate both outputs from the same package in one run.
- Keep decision, counts, statuses, finding IDs and wording consistent across DOCX and HTML.
- Preserve `N/A` and `UNVERIFIED`; do not convert them to pass.
- State separately whether the decision applies to classroom, pilot or production use when the audit contains more than one decision.
- Include the OWASP edition in each matrix title.
- Make no legal or regulatory compliance attestation.

