# Secure Agent Repo Auditor

BMAD-style security and production-readiness audit skill for AI-enabled repositories.

It reviews agentic systems as an FDE would review a real delivery: start with the business action and trust boundaries, trace the request through identity, retrieval, model, memory, tools, approvals and runtime controls, then produce evidence a release board can act on.

## Coverage

- Seven lifecycle gates: idea/policy, approved components, secure development, build-time controls, testing, compliance evidence, and deploy/monitor/improve.
- OWASP GenAI LLM Top 10 2026: LLM01–LLM10.
- OWASP Top 10 for Agentic Applications 2026: ASI01–ASI10.
- RAG controls: tenant isolation, source authority, freshness, poisoned documents, cache scope, chunk/citation lineage, embedding/index access, conflict handling and abstention.
- Agent controls: identity, least privilege, MCP/tool capability binding, A2A authentication and delegated scope, memory provenance, human approval, bounded autonomy, stop/rollback, output handling and audit integrity.
- Supply chain, model/package/tool provenance, SBOM, dependency pinning, runtime observability, feedback loops and operational ownership.

## BMAD passes

| Pass | Role | Question | Artifact |
|---|---|---|---|
| B | Business and policy analyst | Is the AI action permitted and bounded? | Applicability record |
| M | Repository mapper | What happens from input to side effect? | Architecture and trust-boundary map |
| A | Adversarial/control auditor | Which controls fail under realistic abuse? | Findings and failable tests |
| D | Decision reviewer | Can this release be defended? | Release decision and remediation plan |

Passes are sequential. Each pass consumes the prior artifact and leaves evidence for the next. See `references/bmad-audit-workflow.md` for handoffs and stop conditions.

## Safety and evidence rules

- Do not execute untrusted project code, hooks, installers, notebooks, model files or downloaded binaries merely to inspect them.
- Do not install packages, call live models, attack external systems or use production credentials without authorization.
- Never expose secret values.
- A keyword match or documentation claim is not proof of enforcement.
- Distinguish `FAIL` from `UNVERIFIED`.
- Do not claim HIPAA, ISO 42001, EU AI Act or other legal compliance from repository inspection alone; report control alignment and evidence gaps.
- Prefer synthetic data, mock tools, blocked egress and deterministic local tests.

## Required outputs

Build one evidence package containing scope, architecture, seven lifecycle gates, both OWASP 2026 matrices, findings, control/test map and remediation. Generate:

- `Secure_Agent_Security_Audit_Report.docx`;
- `Secure_Agent_Security_Audit_Dashboard.html`.

The HTML must be self-contained and offline. Render and inspect every Word-report page before delivery. Run `scripts/validate_audit_package.py` before calling the audit complete.

For a quick start and an example prompt, see the full workspace copy of this README and `SKILL.md`.

