#!/usr/bin/env python3
"""Validate structural completeness of a secure-agent audit package."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


REQUIRED_FILES = [
    "00_executive_summary.md",
    "01_scope_and_architecture.md",
    "02_lifecycle_gate_scorecard.md",
    "03_owasp_llm_2026_matrix.md",
    "04_owasp_agentic_2026_matrix.md",
    "05_findings_register.csv",
    "06_security_control_test_map.md",
    "07_remediation_and_release.md",
    "evidence/repository_evidence.json",
    "evidence/test_results.md",
    "Secure_Agent_Security_Audit_Report.docx",
    "Secure_Agent_Security_Audit_Dashboard.html",
]
LLM_IDS = [f"LLM{i:02d}:2026" for i in range(1, 11)]
AGENTIC_IDS = [f"ASI{i:02d}" for i in range(1, 11)]
FINDING_COLUMNS = {
    "id", "title", "status", "severity", "lifecycle_gate", "owasp_llm",
    "owasp_agentic", "evidence", "gap", "remediation", "acceptance_test",
    "owner_type", "release_impact", "confidence",
}
VALID_STATUS = {"PASS", "PARTIAL", "FAIL", "N/A", "UNVERIFIED"}
VALID_SEVERITY = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    args = parser.parse_args()
    root = args.package.expanduser().resolve()
    errors = []

    for rel in REQUIRED_FILES:
        path = root / rel
        if not path.is_file() or path.stat().st_size == 0:
            errors.append(f"missing_or_empty:{rel}")

    llm_path = root / "03_owasp_llm_2026_matrix.md"
    if llm_path.is_file():
        text = llm_path.read_text(encoding="utf-8", errors="replace")
        errors.extend(f"missing_category:{item}" for item in LLM_IDS if item not in text)

    agent_path = root / "04_owasp_agentic_2026_matrix.md"
    if agent_path.is_file():
        text = agent_path.read_text(encoding="utf-8", errors="replace")
        errors.extend(f"missing_category:{item}" for item in AGENTIC_IDS if item not in text)

    gate_path = root / "02_lifecycle_gate_scorecard.md"
    if gate_path.is_file():
        text = gate_path.read_text(encoding="utf-8", errors="replace").lower()
        errors.extend(f"missing_lifecycle_gate:{i}" for i in range(1, 8) if f"gate {i}" not in text)

    findings_path = root / "05_findings_register.csv"
    if findings_path.is_file():
        with findings_path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            missing = FINDING_COLUMNS - set(reader.fieldnames or [])
            if missing:
                errors.append("missing_finding_columns:" + ",".join(sorted(missing)))
            else:
                for row_no, row in enumerate(reader, start=2):
                    status = row["status"].strip().upper()
                    severity = row["severity"].strip().upper()
                    if status not in VALID_STATUS:
                        errors.append(f"invalid_status:row{row_no}:{status}")
                    if severity not in VALID_SEVERITY:
                        errors.append(f"invalid_severity:row{row_no}:{severity}")
                    if status in {"FAIL", "PARTIAL"} and (not row["remediation"].strip() or not row["acceptance_test"].strip()):
                        errors.append(f"missing_remediation_or_test:row{row_no}")
                    if status == "PASS" and not row["evidence"].strip():
                        errors.append(f"pass_without_evidence:row{row_no}")

    docx_path = root / "Secure_Agent_Security_Audit_Report.docx"
    if docx_path.is_file():
        try:
            import zipfile
            with zipfile.ZipFile(docx_path) as archive:
                if "word/document.xml" not in archive.namelist():
                    errors.append("invalid_docx:missing_document_xml")
        except (OSError, zipfile.BadZipFile):
            errors.append("invalid_docx:not_a_readable_package")

    html_path = root / "Secure_Agent_Security_Audit_Dashboard.html"
    if html_path.is_file():
        html = html_path.read_text(encoding="utf-8", errors="replace").lower()
        for marker in ("id=\"risk-dashboard\"", "id=\"lifecycle-gates\"", "id=\"owasp-coverage\"", "id=\"findings\""):
            if marker not in html:
                errors.append(f"invalid_html:missing_marker:{marker}")
        remote_dependencies = (
            r'<script[^>]+src=["\']https?://',
            r'<link[^>]+href=["\']https?://',
            r'<img[^>]+src=["\']https?://',
            r'@import\s+(?:url\()?\s*["\']?https?://',
            r'url\(\s*["\']?https?://',
        )
        import re
        for pattern in remote_dependencies:
            if re.search(pattern, html, flags=re.IGNORECASE):
                errors.append(f"invalid_html:remote_dependency:{pattern}")

    if errors:
        print("AUDIT PACKAGE: FAIL")
        for error in errors:
            print(f"- {error}")
        return 1
    print("AUDIT PACKAGE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
