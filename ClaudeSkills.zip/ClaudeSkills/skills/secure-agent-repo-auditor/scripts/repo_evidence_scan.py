#!/usr/bin/env python3
"""Safe static evidence inventory for AI and agent repositories.

This script does not execute repository code and does not assign compliance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from pathlib import Path


SKIP_DIRS = {
    ".git", ".hg", ".svn", ".idea", ".vscode", "node_modules", "vendor",
    "dist", "build", "coverage", ".coverage", ".pytest_cache", ".mypy_cache",
    "__pycache__", ".venv", "venv", "env", ".tox", "target", ".next",
}
TEXT_SUFFIXES = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rs", ".cs",
    ".rb", ".php", ".sh", ".ps1", ".sql", ".md", ".txt", ".json", ".jsonl",
    ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".xml", ".html",
    ".css", ".env", ".properties", ".gradle", ".tf", ".hcl", ".ipynb",
}
MANIFEST_NAMES = {
    "requirements.txt", "requirements-dev.txt", "pyproject.toml", "poetry.lock",
    "Pipfile", "Pipfile.lock", "package.json", "package-lock.json", "yarn.lock",
    "pnpm-lock.yaml", "go.mod", "go.sum", "Cargo.toml", "Cargo.lock", "pom.xml",
    "build.gradle", "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
    "uv.lock", "environment.yml", "environment.yaml", "conda-lock.yml",
}

SIGNALS = {
    "llm_or_model": [r"\b(openai|anthropic|azure[_ -]?openai|bedrock|vertexai|ollama|litellm)\b", r"chat(completion|model)"],
    "agent_or_orchestrator": [r"\b(agent|orchestrator|planner|langchain|langgraph|crewai|autogen|semantic[_ -]?kernel)\b"],
    "tool_execution": [r"\b(tool_call|function_call|invoke_tool|execute_tool|run_tool|tools?\s*=)\b", r"@tool\b"],
    "mcp": [r"\bmcp\b", r"model context protocol"],
    "a2a_or_multi_agent": [r"\ba2a\b", r"agent[-_ ]to[-_ ]agent", r"multi[-_ ]agent"],
    "rag_or_vector": [r"\b(rag|retriev|embedding|vector(store|db|index)?|faiss|chroma|pinecone|weaviate|milvus)\b"],
    "memory": [r"\b(memory|checkpoint|conversation_history|chat_history)\b"],
    "identity_and_authz": [
        r"\b(oauth|oidc|jwt|rbac|abac|permissions?|service account|workload identity|non[- ]human identity|nhi)\b",
        r"\bauthorization\s*(header|policy|middleware|check|decision)",
        r"\bauthori[sz]e\s*\(",
    ],
    "gateway_or_policy": [r"\b(gateway|policy engine|open policy agent|\bopa\b|allowlist|denylist|approval_required)\b"],
    "guardrail_or_safety": [r"\b(guardrail|content safety|moderation|redact|sanitize|prompt injection|jailbreak)\b"],
    "observability": [r"\b(opentelemetry|telemetry|trace|audit_log|audit log|metrics|monitoring|alert)\b"],
    "security_testing": [r"\b(red[-_ ]?team|adversarial|promptfoo|garak|pyrit|security test|penetration test)\b"],
    "deployment": [r"\b(kubernetes|helm|terraform|bicep|cloudformation|container|docker|deployment)\b"],
    "compliance": [r"\b(hipaa|phi|pii|gdpr|iso[ -]?42001|nist|owasp|compliance|risk register)\b"],
}

DANGEROUS_PATTERNS = {
    "dynamic_code_execution": [r"\beval\s*\(", r"\bexec\s*\(", r"new Function\s*\("],
    "shell_execution": [r"os\.system\s*\(", r"subprocess\.[A-Za-z_]+\s*\(", r"child_process\.(exec|spawn)\s*\("],
    "shell_true": [r"shell\s*=\s*True"],
    "wildcard_cors": [r"allow_origins\s*=\s*\[\s*[\"']\*[\"']\s*\]", r"Access-Control-Allow-Origin\s*[:=]\s*[\"']?\*"],
    "tls_verification_disabled": [r"verify\s*=\s*False", r"NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*[\"']?0"],
}

SECRET_PATTERNS = {
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "generic_secret_assignment": re.compile(
        r"(?i)(api[_-]?key|secret|token|password|client[_-]?secret)\s*[:=]\s*[\"'][^\"'\s]{8,}[\"']"
    ),
}
SECRET_VALUE_REDACTOR = re.compile(
    r"(?i)((?:api[_-]?key|secret|token|password|client[_-]?secret)\s*[:=]\s*)[\"']?[^\"'\s,;}]+[\"']?"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a safe static evidence inventory.")
    parser.add_argument("repo", type=Path, help="Repository root")
    parser.add_argument("--output", type=Path, required=True, help="Output directory")
    parser.add_argument("--max-file-bytes", type=int, default=1_000_000)
    parser.add_argument("--max-matches", type=int, default=200)
    return parser.parse_args()


def inside_repo(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root)
        return True
    except (OSError, ValueError):
        return False


def walk_files(root: Path):
    for current, dirs, files in os.walk(root, followlinks=False):
        current_path = Path(current)
        dirs[:] = [
            d for d in dirs
            if d not in SKIP_DIRS and not (current_path / d).is_symlink()
        ]
        for name in files:
            path = current_path / name
            if path.is_symlink() or not inside_repo(path, root):
                continue
            yield path


def is_text_candidate(path: Path) -> bool:
    return path.suffix.lower() in TEXT_SUFFIXES or path.name in MANIFEST_NAMES or path.name.startswith(".env")


def relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def line_matches(text: str, patterns: list[str]):
    compiled = [re.compile(p, re.IGNORECASE) for p in patterns]
    for number, line in enumerate(text.splitlines(), start=1):
        if any(p.search(line) for p in compiled):
            snippet = SECRET_VALUE_REDACTOR.sub(r"\1[REDACTED]", line.strip())
            yield number, snippet[:240]


def dependency_pin_issues(path: Path, text: str) -> list[dict]:
    issues = []
    if path.name.startswith("requirements") and path.suffix == ".txt":
        for line_no, raw in enumerate(text.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            if "==" not in line or any(x in line for x in (">=", "<=", "~=", "*")):
                issues.append({"line": line_no, "issue": "dependency_not_exactly_pinned", "value": line[:160]})
    if path.name == "package.json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return issues
        for section in ("dependencies", "devDependencies", "optionalDependencies"):
            for name, version in data.get(section, {}).items():
                if not isinstance(version, str) or version.startswith(("^", "~", "*", ">", "<", "latest", "git+", "http")):
                    issues.append({"line": None, "issue": "dependency_not_exactly_pinned", "value": f"{section}:{name}:{version}"})
    return issues


def main() -> int:
    args = parse_args()
    root = args.repo.expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"Repository root not found: {root}")
    output = args.output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)

    inventory = []
    signals = defaultdict(list)
    dangerous = defaultdict(list)
    secret_locations = []
    pinning = []
    extensions = Counter()
    skipped_large = []

    for path in walk_files(root):
        rel = relative(path, root)
        try:
            size = path.stat().st_size
        except OSError:
            continue
        extensions[path.suffix.lower() or "<none>"] += 1
        record = {"path": rel, "bytes": size, "manifest": path.name in MANIFEST_NAMES}
        if size <= args.max_file_bytes:
            try:
                record["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
            except OSError:
                record["sha256"] = None
        inventory.append(record)
        if size > args.max_file_bytes:
            skipped_large.append({"path": rel, "bytes": size})
            continue
        if not is_text_candidate(path):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for category, patterns in SIGNALS.items():
            for line_no, snippet in line_matches(text, patterns):
                if len(signals[category]) < args.max_matches:
                    signals[category].append({"path": rel, "line": line_no, "snippet": snippet})
        for category, patterns in DANGEROUS_PATTERNS.items():
            for line_no, snippet in line_matches(text, patterns):
                if len(dangerous[category]) < args.max_matches:
                    dangerous[category].append({"path": rel, "line": line_no, "snippet": snippet})
        for secret_type, pattern in SECRET_PATTERNS.items():
            for line_no, line in enumerate(text.splitlines(), 1):
                if pattern.search(line) and len(secret_locations) < args.max_matches:
                    secret_locations.append({"type": secret_type, "path": rel, "line": line_no, "value": "[REDACTED]"})
        for issue in dependency_pin_issues(path, text):
            pinning.append({"path": rel, **issue})

    report = {
        "scanner": "secure-agent-repo-auditor/repo_evidence_scan.py",
        "limitations": [
            "Static signals do not prove a control is effective or a vulnerability is exploitable.",
            "Repository code was not executed and external services were not contacted.",
            "Secret values were not included in output.",
        ],
        "repository": str(root),
        "file_count": len(inventory),
        "extensions": dict(extensions.most_common()),
        "manifests": [x["path"] for x in inventory if x["manifest"]],
        "skipped_large_files": skipped_large,
        "signals": dict(signals),
        "potentially_dangerous_sinks": dict(dangerous),
        "potential_secret_locations": secret_locations,
        "dependency_pinning_signals": pinning,
        "files": inventory,
    }
    json_path = output / "repository_evidence.json"
    json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    lines = [
        "# Repository evidence inventory",
        "",
        "> Static evidence only. Review every signal before creating a finding.",
        "",
        f"- Repository: `{root}`",
        f"- Files inventoried: {len(inventory)}",
        f"- Manifests: {', '.join(report['manifests']) or 'None detected'}",
        f"- Large files skipped from content scan: {len(skipped_large)}",
        "",
        "## Surface signals",
        "",
    ]
    for category in SIGNALS:
        matches = signals.get(category, [])
        lines.append(f"### {category.replace('_', ' ').title()} ({len(matches)})")
        lines.extend(f"- `{m['path']}:{m['line']}` — {m['snippet']}" for m in matches[:20])
        if not matches:
            lines.append("- No static signal detected; this is not proof of absence.")
        lines.append("")
    lines.extend(["## Potentially dangerous sinks", ""])
    for category, matches in dangerous.items():
        lines.append(f"### {category.replace('_', ' ').title()}")
        lines.extend(f"- `{m['path']}:{m['line']}` — {m['snippet']}" for m in matches)
        lines.append("")
    lines.extend([
        "## Secret-location signals",
        "",
        *[f"- `{m['path']}:{m['line']}` — {m['type']} — [REDACTED]" for m in secret_locations],
        "" if secret_locations else "- No static secret pattern detected; use an approved secret scanner for release evidence.",
        "",
        "## Dependency pinning signals",
        "",
        *[f"- `{m['path']}:{m.get('line') or '?'}` — {m['value']}" for m in pinning],
        "" if pinning else "- No basic pinning signal detected. Verify lockfile and artifact integrity separately.",
        "",
    ])
    (output / "repository_evidence.md").write_text("\n".join(lines), encoding="utf-8")
    print(json_path)
    print(output / "repository_evidence.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
