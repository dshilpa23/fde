#!/usr/bin/env python3
"""Build one consolidated DOCX and one offline visual HTML audit report."""

from __future__ import annotations

import argparse
import csv
import html
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


DOCX_NAME = "Secure_Agent_Security_Audit_Report.docx"
HTML_NAME = "Secure_Agent_Security_Audit_Dashboard.html"
INPUT_FILES = [
    "00_executive_summary.md", "01_scope_and_architecture.md",
    "02_lifecycle_gate_scorecard.md", "03_owasp_llm_2026_matrix.md",
    "04_owasp_agentic_2026_matrix.md", "05_findings_register.csv",
    "06_security_control_test_map.md", "07_remediation_and_release.md",
    "evidence/test_results.md",
]
STATUS_COLORS = {
    "PASS": "157A55", "PARTIAL": "D9860B", "FAIL": "B42318",
    "N/A": "667085", "UNVERIFIED": "7A5AF8",
}
SEVERITY_COLORS = {
    "CRITICAL": "8B1E1E", "HIGH": "C4320A", "MEDIUM": "D9860B",
    "LOW": "3772B4", "INFO": "667085",
}


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    parser.add_argument("--title", default="Secure Agent Repository Security Audit")
    parser.add_argument("--subtitle", default="Lifecycle, OWASP LLM 2026 and OWASP Agentic 2026 assessment")
    return parser.parse_args()


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def parse_pipe_tables(markdown: str) -> list[list[list[str]]]:
    tables, current = [], []
    for line in markdown.splitlines():
        if line.strip().startswith("|") and line.strip().endswith("|"):
            cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
            if all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in cells):
                continue
            current.append(cells)
        elif current:
            tables.append(current)
            current = []
    if current:
        tables.append(current)
    return tables


def parse_findings(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return [{k: (v or "").strip() for k, v in row.items()} for row in csv.DictReader(handle)]


def decision_from(text: str) -> str:
    upper = text.upper()
    for value in ("REJECT", "HOLD", "APPROVE WITH CONDITIONS", "APPROVE"):
        if value in upper:
            return value
    return "UNVERIFIED"


def first_table(path: Path) -> list[list[str]]:
    tables = parse_pipe_tables(read(path))
    return tables[0] if tables else []


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=110, bottom=90, end=110) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for tag, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{tag}"))
        if node is None:
            node = OxmlElement(f"w:{tag}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_cell_text(cell, text: str, *, bold=False, color="344054", size=9.0, align=None) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    if align is not None:
        paragraph.alignment = align
    run = paragraph.add_run(text)
    run.bold = bold
    run.font.name = "Aptos"
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    set_cell_margins(cell)


def add_table(doc: Document, rows: list[list[str]], widths: list[float] | None = None, font_size=8.5) -> None:
    if not rows:
        return
    cols = max(len(row) for row in rows)
    table = doc.add_table(rows=len(rows), cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = False
    if not widths:
        widths = [6.4 / cols] * cols
    for r_idx, values in enumerate(rows):
        for c_idx in range(cols):
            cell = table.cell(r_idx, c_idx)
            value = values[c_idx] if c_idx < len(values) else ""
            width = Inches(widths[c_idx] if c_idx < len(widths) else widths[-1])
            cell.width = width
            if r_idx == 0:
                set_cell_shading(cell, "143B5D")
                set_cell_text(cell, value, bold=True, color="FFFFFF", size=9.0, align=WD_ALIGN_PARAGRAPH.CENTER)
            else:
                if r_idx % 2 == 0:
                    set_cell_shading(cell, "F2F4F7")
                status = value.upper()
                color = STATUS_COLORS.get(status, "344054")
                set_cell_text(cell, value, bold=status in STATUS_COLORS, color=color, size=font_size,
                              align=WD_ALIGN_PARAGRAPH.CENTER if status in STATUS_COLORS else WD_ALIGN_PARAGRAPH.LEFT)
    set_repeat_table_header(table.rows[0])
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def add_page_number(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    run.font.size = Pt(9)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr)
    run._r.append(fld_char2)


def configure_doc(doc: Document, title: str) -> None:
    section = doc.sections[0]
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.72)
    section.left_margin = Inches(0.82)
    section.right_margin = Inches(0.82)
    section.header_distance = Inches(0.3)
    section.footer_distance = Inches(0.3)
    section.different_first_page_header_footer = True
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(9.6)
    normal.font.color.rgb = RGBColor.from_string("344054")
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.08
    for style_name, size, color, before, after in (
        ("Title", 28, "123A5A", 0, 10),
        ("Heading 1", 18, "123A5A", 16, 7),
        ("Heading 2", 13.5, "1476A8", 12, 5),
        ("Heading 3", 11.5, "344054", 8, 4),
    ):
        style = styles[style_name]
        style.font.name = "Aptos Display" if style_name != "Normal" else "Aptos"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.font.bold = True
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    header = section.header.paragraphs[0]
    header.text = title
    header.style = styles["Header"]
    header.runs[0].font.name = "Aptos"
    header.runs[0].font.size = Pt(8.5)
    header.runs[0].font.color.rgb = RGBColor.from_string("667085")
    add_page_number(section.footer.paragraphs[0])


def add_markdown(doc: Document, markdown: str, *, skip_first_h1=True, table_font_size=8.5) -> None:
    lines = markdown.splitlines()
    i, in_code, code_lines, skipped_h1 = 0, False, [], False
    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if stripped.startswith("```"):
            if in_code:
                table = doc.add_table(rows=1, cols=1)
                set_cell_shading(table.cell(0, 0), "F2F4F7")
                set_cell_text(table.cell(0, 0), "\n".join(code_lines), color="1D2939", size=8.0)
                code_lines = []
            in_code = not in_code
            i += 1
            continue
        if in_code:
            code_lines.append(line)
            i += 1
            continue
        if stripped.startswith("|"):
            block = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells):
                    block.append(cells)
                i += 1
            widths = None
            if block:
                n = len(block[0])
                if n == 3:
                    widths = [1.15, 1.25, 4.0]
                elif n == 4:
                    widths = [1.0, 1.0, 2.15, 2.25]
            add_table(doc, block, widths=widths, font_size=table_font_size)
            continue
        if not stripped:
            i += 1
            continue
        if stripped.startswith("# "):
            if skip_first_h1 and not skipped_h1:
                skipped_h1 = True
            else:
                doc.add_heading(stripped[2:].strip(), level=1)
        elif stripped.startswith("## "):
            doc.add_heading(stripped[3:].strip(), level=2)
        elif stripped.startswith("### "):
            doc.add_heading(stripped[4:].strip(), level=3)
        elif re.match(r"^[-*] ", stripped):
            p = doc.add_paragraph(style="List Bullet")
            p.add_run(re.sub(r"^[-*] ", "", stripped).replace("**", ""))
        elif re.match(r"^\d+\. ", stripped):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.18)
            p.paragraph_format.first_line_indent = Inches(-0.18)
            p.add_run(stripped.replace("**", ""))
        elif stripped.startswith(">"):
            table = doc.add_table(rows=1, cols=1)
            set_cell_shading(table.cell(0, 0), "EAF3F8")
            set_cell_text(table.cell(0, 0), stripped.lstrip("> "), color="123A5A", size=9.5)
        else:
            p = doc.add_paragraph()
            p.add_run(stripped.replace("**", "").replace("`", ""))
        i += 1


def finding_counts(findings: list[dict[str, str]]) -> Counter:
    counts = Counter(row.get("severity", "INFO").upper() for row in findings)
    for severity in SEVERITY_COLORS:
        counts.setdefault(severity, 0)
    return counts


def build_docx(root: Path, title: str, subtitle: str, findings: list[dict[str, str]], decision: str) -> Path:
    doc = Document()
    configure_doc(doc, title)
    p = doc.add_paragraph(style="Title")
    p.add_run(title)
    sub = doc.add_paragraph()
    sub_run = sub.add_run(subtitle)
    sub_run.font.name = "Aptos"
    sub_run.font.size = Pt(13)
    sub_run.font.color.rgb = RGBColor.from_string("475467")
    doc.add_paragraph()
    badge = doc.add_table(rows=1, cols=1)
    badge.alignment = WD_TABLE_ALIGNMENT.LEFT
    fill = "B42318" if decision in {"HOLD", "REJECT"} else "D9860B" if "CONDITION" in decision else "157A55"
    set_cell_shading(badge.cell(0, 0), fill)
    set_cell_text(badge.cell(0, 0), f"RELEASE DECISION  |  {decision}", bold=True, color="FFFFFF", size=12)
    doc.add_paragraph()
    meta = doc.add_table(rows=3, cols=2)
    meta.style = "Table Grid"
    meta_data = [
        ("Audit package", f"{root.parent.name} / {root.name}"),
        ("Generated", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")),
        ("Classification", "Security assessment - review before external distribution"),
    ]
    for r_idx, (label, value) in enumerate(meta_data):
        set_cell_shading(meta.cell(r_idx, 0), "EAF3F8")
        set_cell_text(meta.cell(r_idx, 0), label, bold=True, color="123A5A", size=9.0)
        set_cell_text(meta.cell(r_idx, 1), value, color="344054", size=9.0)
    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(16)
    run = note.add_run("This report assesses repository evidence and does not constitute legal or regulatory certification.")
    run.italic = True
    run.font.color.rgb = RGBColor.from_string("667085")
    doc.add_page_break()

    counts = finding_counts(findings)
    doc.add_heading("Executive risk view", level=1)
    rows = [["Severity", "Count", "Visual"]]
    max_count = max(counts.values()) or 1
    for severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        count = counts[severity]
        rows.append([severity.title(), str(count), "■" * max(1, round((count / max_count) * 12)) if count else "-"])
    add_table(doc, rows, widths=[1.35, 0.7, 4.35], font_size=9.5)
    add_markdown(doc, read(root / "00_executive_summary.md"))

    for section_index, (rel, heading) in enumerate((
        ("01_scope_and_architecture.md", "Architecture and attack surface"),
        ("02_lifecycle_gate_scorecard.md", "Secure development lifecycle"),
        ("03_owasp_llm_2026_matrix.md", "OWASP GenAI LLM Top 10 2026"),
        ("04_owasp_agentic_2026_matrix.md", "OWASP Agentic Applications Top 10 2026"),
    )):
        if section_index > 0:
            doc.add_page_break()
        doc.add_heading(heading, level=1)
        add_markdown(doc, read(root / rel))

    doc.add_page_break()
    doc.add_heading("Prioritized findings", level=1)
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    previous_severity = None
    for item in sorted(findings, key=lambda x: (severity_order.get(x.get("severity", "INFO").upper(), 5), x.get("id", ""))):
        severity = item.get("severity", "INFO").upper()
        if previous_severity is not None and severity != previous_severity:
            doc.add_page_break()
        previous_severity = severity
        head = doc.add_table(rows=1, cols=3)
        head.alignment = WD_TABLE_ALIGNMENT.CENTER
        set_cell_shading(head.cell(0, 0), SEVERITY_COLORS.get(severity, "667085"))
        set_cell_text(head.cell(0, 0), severity, bold=True, color="FFFFFF", size=9.0, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_cell_shading(head.cell(0, 1), "143B5D")
        set_cell_text(head.cell(0, 1), item.get("id", ""), bold=True, color="FFFFFF", size=9.0, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_cell_shading(head.cell(0, 2), "143B5D")
        set_cell_text(head.cell(0, 2), item.get("title", ""), bold=True, color="FFFFFF", size=9.5)
        detail_rows = [
            ["Status / mappings", " | ".join(filter(None, [item.get("status"), item.get("owasp_llm"), item.get("owasp_agentic")]))],
            ["Evidence", item.get("evidence", "")],
            ["Gap", item.get("gap", "")],
            ["Required action", item.get("remediation", "")],
            ["Acceptance test", item.get("acceptance_test", "")],
            ["Release impact", item.get("release_impact", "")],
        ]
        add_table(doc, [["Field", "Assessment"], *detail_rows], widths=[1.25, 5.15], font_size=8.5)

    for rel, heading in (
        ("06_security_control_test_map.md", "Security control and test map"),
        ("07_remediation_and_release.md", "Remediation and release recommendation"),
        ("evidence/test_results.md", "Executed test evidence"),
    ):
        doc.add_page_break()
        doc.add_heading(heading, level=1)
        table_font_size = 7.6 if rel == "06_security_control_test_map.md" else 8.2
        content = read(root / rel)
        if rel == "06_security_control_test_map.md":
            content = content.split("## Focused tests executed in this audit", 1)[0].rstrip()
            add_markdown(doc, content, table_font_size=table_font_size)
        elif rel == "evidence/test_results.md" and "## Boundary probes" in content:
            safe_execution, boundary_probes = content.split("## Boundary probes", 1)
            add_markdown(doc, safe_execution.rstrip(), table_font_size=table_font_size)
            doc.add_page_break()
            add_markdown(doc, "## Boundary probes" + boundary_probes, skip_first_h1=False,
                         table_font_size=table_font_size)
        else:
            add_markdown(doc, content, table_font_size=table_font_size)

    output = root / DOCX_NAME
    doc.core_properties.title = title
    doc.core_properties.subject = subtitle
    doc.core_properties.author = "Secure Agent Repo Auditor"
    doc.core_properties.keywords = "security audit, OWASP, agentic AI, LLM"
    doc.save(output)
    return output


def md_to_html(markdown: str) -> str:
    lines, out, i, in_code, code = markdown.splitlines(), [], 0, False, []
    while i < len(lines):
        stripped = lines[i].strip()
        if stripped.startswith("```"):
            if in_code:
                out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
                code = []
            in_code = not in_code
            i += 1
            continue
        if in_code:
            code.append(lines[i])
            i += 1
            continue
        if stripped.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                out.append("<div class=\"table-wrap\"><table><thead><tr>" + "".join(f"<th>{html.escape(c)}</th>" for c in rows[0]) + "</tr></thead><tbody>")
                for row in rows[1:]:
                    out.append("<tr>" + "".join(f"<td>{html.escape(c)}</td>" for c in row) + "</tr>")
                out.append("</tbody></table></div>")
            continue
        if not stripped:
            i += 1
            continue
        clean = html.escape(stripped.replace("**", "").replace("`", ""))
        if stripped.startswith("# "):
            out.append(f"<h2>{html.escape(stripped[2:])}</h2>")
        elif stripped.startswith("## "):
            out.append(f"<h3>{html.escape(stripped[3:])}</h3>")
        elif stripped.startswith("### "):
            out.append(f"<h4>{html.escape(stripped[4:])}</h4>")
        elif re.match(r"^[-*] ", stripped):
            items = []
            while i < len(lines) and re.match(r"^\s*[-*] ", lines[i]):
                items.append(re.sub(r"^\s*[-*] ", "", lines[i]).replace("**", "").replace("`", ""))
                i += 1
            out.append("<ul>" + "".join(f"<li>{html.escape(x)}</li>" for x in items) + "</ul>")
            continue
        elif re.match(r"^\d+\. ", stripped):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+\. ", lines[i]):
                items.append(re.sub(r"^\s*\d+\. ", "", lines[i]).replace("**", "").replace("`", ""))
                i += 1
            out.append("<ol>" + "".join(f"<li>{html.escape(x)}</li>" for x in items) + "</ol>")
            continue
        elif stripped.startswith(">"):
            out.append(f"<aside>{html.escape(stripped.lstrip('> '))}</aside>")
        else:
            out.append(f"<p>{clean}</p>")
        i += 1
    return "\n".join(out)


def status_counts(rows: list[list[str]]) -> Counter:
    counts = Counter()
    for row in rows[1:]:
        if len(row) > 1:
            status = row[1].strip().upper()
            if status in STATUS_COLORS:
                counts[status] += 1
    return counts


def donut_style(counts: Counter) -> str:
    total = sum(counts.values()) or 1
    position, segments = 0.0, []
    for status in ("PASS", "PARTIAL", "FAIL", "UNVERIFIED", "N/A"):
        value = counts.get(status, 0)
        if not value:
            continue
        start = position
        position += value / total * 100
        segments.append(f"#{STATUS_COLORS[status]} {start:.2f}% {position:.2f}%")
    return "conic-gradient(" + ", ".join(segments or ["#E4E7EC 0 100%"]) + ")"


def build_html(root: Path, title: str, subtitle: str, findings: list[dict[str, str]], decision: str) -> Path:
    severity = finding_counts(findings)
    lifecycle = first_table(root / "02_lifecycle_gate_scorecard.md")
    llm = first_table(root / "03_owasp_llm_2026_matrix.md")
    agentic = first_table(root / "04_owasp_agentic_2026_matrix.md")
    lifecycle_counts, llm_counts, agentic_counts = status_counts(lifecycle), status_counts(llm), status_counts(agentic)
    max_severity = max(severity.values()) or 1
    decision_class = "danger" if decision in {"HOLD", "REJECT"} else "warn" if "CONDITION" in decision else "safe"

    finding_cards = []
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    for item in sorted(findings, key=lambda x: (order.get(x.get("severity", "INFO").upper(), 5), x.get("id", ""))):
        sev = item.get("severity", "INFO").upper()
        finding_cards.append(f"""
        <article class="finding" style="--sev:#{SEVERITY_COLORS.get(sev, '667085')}">
          <div class="finding-head"><span class="sev">{html.escape(sev)}</span><strong>{html.escape(item.get('id',''))}</strong><h3>{html.escape(item.get('title',''))}</h3></div>
          <div class="finding-grid">
            <div><b>Evidence</b><p>{html.escape(item.get('evidence',''))}</p></div>
            <div><b>Gap</b><p>{html.escape(item.get('gap',''))}</p></div>
            <div><b>Required action</b><p>{html.escape(item.get('remediation',''))}</p></div>
            <div><b>Acceptance test</b><p>{html.escape(item.get('acceptance_test',''))}</p></div>
          </div>
          <footer>{html.escape(' | '.join(filter(None,[item.get('status'),item.get('owasp_llm'),item.get('owasp_agentic'),item.get('release_impact')])))}</footer>
        </article>""")

    lifecycle_cards = []
    for row in lifecycle[1:]:
        if len(row) >= 4:
            status = row[1].upper()
            lifecycle_cards.append(f"<article class=\"gate\"><span class=\"status s-{status.replace('/','na').replace(' ','-')}\">{html.escape(status)}</span><h3>{html.escape(row[0])}</h3><p>{html.escape(row[3])}</p></article>")

    risk_bars = []
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        width = severity[sev] / max_severity * 100
        risk_bars.append(f"<div class=\"bar-row\"><span>{sev.title()}</span><div class=\"track\"><i style=\"width:{width:.1f}%;background:#{SEVERITY_COLORS[sev]}\"></i></div><b>{severity[sev]}</b></div>")

    html_text = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>
:root{{--navy:#123a5a;--blue:#1476a8;--ink:#1d2939;--muted:#667085;--line:#d0d5dd;--panel:#f7f9fb;--amber:#d9860b;--red:#b42318;--green:#157a55;--purple:#7a5af8}}
*{{box-sizing:border-box}} body{{margin:0;font-family:Inter,Aptos,Arial,sans-serif;color:var(--ink);background:#eef3f7;line-height:1.48}} .page{{max-width:1380px;margin:auto;background:white;min-height:100vh;box-shadow:0 0 40px #123a5a18}} header.hero{{padding:50px 60px 42px;background:linear-gradient(135deg,#0f304b,#165a83);color:white;position:relative;overflow:hidden}} header.hero:after{{content:"";position:absolute;width:420px;height:420px;border:70px solid #ffffff12;border-radius:50%;right:-120px;top:-230px}} .eyebrow{{letter-spacing:.13em;text-transform:uppercase;font-size:.78rem;font-weight:800;color:#a9ddf4}} h1{{max-width:900px;font-size:clamp(2rem,4vw,3.8rem);line-height:1.04;margin:.5rem 0 1rem}} .subtitle{{max-width:850px;color:#d9edf7;font-size:1.08rem}} .decision{{display:inline-flex;margin-top:24px;padding:10px 16px;border-radius:8px;font-weight:850;letter-spacing:.04em;background:#fff;color:var(--navy)}} .decision.danger{{border-left:7px solid #f97066}} .decision.warn{{border-left:7px solid #fdb022}} .decision.safe{{border-left:7px solid #32d583}} main{{padding:34px 48px 70px}} section{{margin:24px 0 42px;scroll-margin-top:16px}} h2{{font-size:1.75rem;color:var(--navy);margin:0 0 14px}} h3{{color:var(--navy)}} .cards{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}} .metric{{border:1px solid var(--line);border-top:5px solid var(--c);border-radius:12px;padding:16px;background:white}} .metric b{{font-size:2rem;display:block;color:var(--c)}} .metric span{{color:var(--muted);font-size:.84rem;text-transform:uppercase;font-weight:750}} .dashboard-grid{{display:grid;grid-template-columns:1.1fr .9fr;gap:20px}} .panel{{background:var(--panel);border:1px solid #e4e7ec;border-radius:14px;padding:20px}} .bar-row{{display:grid;grid-template-columns:80px 1fr 25px;gap:10px;align-items:center;margin:13px 0;font-size:.88rem}} .track{{height:12px;background:#e4e7ec;border-radius:8px;overflow:hidden}} .track i{{display:block;height:100%;border-radius:8px}} .donuts{{display:grid;grid-template-columns:1fr 1fr;gap:18px}} .donut-card{{text-align:center}} .donut{{width:145px;height:145px;margin:10px auto;border-radius:50%;background:var(--chart);position:relative}} .donut:after{{content:"";position:absolute;inset:28px;background:var(--panel);border-radius:50%}} .legend{{display:flex;gap:9px;flex-wrap:wrap;justify-content:center;color:var(--muted);font-size:.75rem}} .legend i{{width:9px;height:9px;border-radius:50%;display:inline-block}} .gates{{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}} .gate{{border:1px solid var(--line);border-radius:12px;padding:16px;background:white}} .gate h3{{margin:8px 0 6px;font-size:1.02rem}} .gate p{{margin:0;color:var(--muted);font-size:.88rem}} .status,.sev{{display:inline-block;padding:4px 8px;border-radius:20px;font-size:.7rem;font-weight:850;letter-spacing:.04em}} .s-PASS{{background:#dff5ec;color:#087443}} .s-PARTIAL{{background:#fff1d6;color:#9a5800}} .s-FAIL{{background:#fee4e2;color:#b42318}} .s-UNVERIFIED{{background:#eee8ff;color:#6938ef}} .s-NnaA{{background:#eaecf0;color:#475467}} .finding{{border:1px solid var(--line);border-left:7px solid var(--sev);border-radius:12px;margin:15px 0;background:white;overflow:hidden}} .finding-head{{padding:15px 17px;display:flex;gap:11px;align-items:center;background:#f8fafc}} .finding-head h3{{font-size:1rem;margin:0;flex:1}} .sev{{background:var(--sev);color:white}} .finding-grid{{display:grid;grid-template-columns:1fr 1fr;gap:0}} .finding-grid>div{{padding:13px 17px;border-top:1px solid #eaecf0}} .finding-grid>div:nth-child(odd){{border-right:1px solid #eaecf0}} .finding-grid b{{font-size:.78rem;text-transform:uppercase;color:var(--muted)}} .finding-grid p{{margin:5px 0 0;font-size:.89rem}} .finding footer{{padding:10px 17px;background:#f8fafc;color:var(--muted);font-size:.78rem}} .prose{{background:white;border:1px solid #e4e7ec;border-radius:14px;padding:22px}} .prose h2:first-child{{display:none}} .table-wrap{{overflow:auto;margin:14px 0}} table{{width:100%;border-collapse:collapse;font-size:.83rem}} th{{background:var(--navy);color:white;text-align:left;padding:10px;position:sticky;top:0}} td{{padding:10px;border-bottom:1px solid #eaecf0;vertical-align:top}} tr:nth-child(even) td{{background:#f8fafc}} aside{{background:#eaf3f8;border-left:5px solid var(--blue);padding:12px 14px;border-radius:6px}} pre{{white-space:pre-wrap;background:#101828;color:#e4e7ec;padding:16px;border-radius:10px}} .meta{{color:var(--muted);font-size:.82rem;margin-top:18px}} @media(max-width:900px){{header.hero{{padding:34px 24px}}main{{padding:24px 18px}}.cards{{grid-template-columns:repeat(2,1fr)}}.dashboard-grid,.gates,.finding-grid{{grid-template-columns:1fr}}.finding-grid>div:nth-child(odd){{border-right:0}}}} @media print{{body{{background:white}}.page{{box-shadow:none}}header.hero{{print-color-adjust:exact}}section{{break-inside:avoid}}.finding{{break-inside:avoid}}}}
</style></head><body><div class="page" id="risk-dashboard">
<header class="hero"><div class="eyebrow">Secure agent repository assessment</div><h1>{html.escape(title)}</h1><p class="subtitle">{html.escape(subtitle)}</p><div class="decision {decision_class}">RELEASE DECISION&nbsp;&nbsp; {html.escape(decision)}</div><div class="meta">Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} | Offline report | No compliance attestation</div></header>
<main>
<section><h2>Risk at a glance</h2><div class="cards">{''.join(f'<article class="metric" style="--c:#{SEVERITY_COLORS[s]}"><b>{severity[s]}</b><span>{s.title()}</span></article>' for s in ('CRITICAL','HIGH','MEDIUM','LOW','INFO'))}</div></section>
<section class="dashboard-grid"><div class="panel"><h2>Finding severity</h2>{''.join(risk_bars)}</div><div class="panel" id="owasp-coverage"><h2>OWASP coverage</h2><div class="donuts"><div class="donut-card"><div class="donut" style="--chart:{donut_style(llm_counts)}"></div><b>LLM Top 10 2026</b></div><div class="donut-card"><div class="donut" style="--chart:{donut_style(agentic_counts)}"></div><b>Agentic Top 10 2026</b></div></div><div class="legend"><span><i style="background:#157A55"></i> Pass</span><span><i style="background:#D9860B"></i> Partial</span><span><i style="background:#B42318"></i> Fail</span><span><i style="background:#7A5AF8"></i> Unverified</span><span><i style="background:#667085"></i> N/A</span></div></div></section>
<section id="lifecycle-gates"><h2>Secure development lifecycle</h2><div class="gates">{''.join(lifecycle_cards)}</div></section>
<section class="prose"><h2>Executive summary</h2>{md_to_html(read(root/'00_executive_summary.md'))}</section>
<section id="findings"><h2>Prioritized findings</h2>{''.join(finding_cards)}</section>
<section class="prose"><h2>Architecture and attack surface</h2>{md_to_html(read(root/'01_scope_and_architecture.md'))}</section>
<section class="prose"><h2>OWASP LLM 2026 matrix</h2>{md_to_html(read(root/'03_owasp_llm_2026_matrix.md'))}</section>
<section class="prose"><h2>OWASP Agentic 2026 matrix</h2>{md_to_html(read(root/'04_owasp_agentic_2026_matrix.md'))}</section>
<section class="prose"><h2>Security control and test map</h2>{md_to_html(read(root/'06_security_control_test_map.md'))}</section>
<section class="prose"><h2>Remediation and release</h2>{md_to_html(read(root/'07_remediation_and_release.md'))}</section>
</main></div></body></html>"""
    output = root / HTML_NAME
    output.write_text(html_text, encoding="utf-8")
    return output


def main() -> int:
    ns = args()
    root = ns.package.expanduser().resolve()
    missing = [rel for rel in INPUT_FILES if not (root / rel).is_file()]
    if missing:
        raise SystemExit("Missing audit inputs: " + ", ".join(missing))
    findings = parse_findings(root / "05_findings_register.csv")
    decision = decision_from(read(root / "00_executive_summary.md"))
    docx = build_docx(root, ns.title, ns.subtitle, findings, decision)
    dashboard = build_html(root, ns.title, ns.subtitle, findings, decision)
    print(docx)
    print(dashboard)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
