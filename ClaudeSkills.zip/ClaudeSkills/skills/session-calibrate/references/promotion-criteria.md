# Promotion criteria & templates

Read this when you're in Step 4 of SKILL.md and unsure whether something belongs in the learnings file only, or should be proposed as a promotion into CLAUDE.md / a skill / a department file.

## When to propose a promotion immediately (skip the "wait for repetition" step)

- The user states it as an explicit standing rule: "always," "from now on," "every time," "never do X again."
- It's a correction of something that will clearly recur (a naming convention, a tool preference, a factual constraint about their environment) rather than a judgment call specific to this task.
- It directly contradicts an existing documented rule — this always gets surfaced immediately, promotion or not, because leaving a known contradiction undocumented is worse than over-logging.

## When to log only, and wait for a second occurrence

- A preference inferred from behavior rather than stated directly (e.g. the user rewrote three sentences to be shorter, but didn't say "always write shorter sentences").
- A workflow that worked well once — good to note, too early to enshrine as *the* way to do it.
- Anything where you're inferring the generalization yourself rather than the user stating it.

## Occurrence counting in calibrate-learnings.md

Use a lightweight format so the file stays skimmable:

```markdown
## [topic tag]
- **Seen:** 2 (2026-07-14, 2026-08-06)
- **Pattern:** User wants API error responses to include a `request_id` field, even in examples.
- **Status:** logged — promote if seen again
```

When something crosses the promotion bar, move its content into the proposal for Step 5, and update its entry:

```markdown
## [topic tag]
- **Seen:** 3 (2026-07-14, 2026-08-06, 2026-08-06)
- **Pattern:** User wants API error responses to include a `request_id` field, even in examples.
- **Status:** promoted → CLAUDE.md §API conventions (2026-08-06)
```

## Starter file if CLAUDE.md doesn't exist yet

Don't invent an elaborate structure the user didn't ask for — propose something minimal they can grow:

```markdown
# CLAUDE.md

## About this project
(one or two lines — fill in or ask the user)

## Conventions learned via /calibrate
(this section is where promoted learnings land)
```

## Starter file if calibrate-learnings.md doesn't exist yet

```markdown
# Calibrate learnings

Staging area for observations from /calibrate sessions. Entries here get
promoted into CLAUDE.md / skills / department files once they've proven
to be standing preferences rather than one-off moments. See
references/promotion-criteria.md in the calibrate skill for the bar.
```
