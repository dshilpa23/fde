---
name: session-calibrate
description: Reviews the just-completed (or in-progress) session for corrections, new preferences, and workflows that worked well, then proposes updates to CLAUDE.md, skill files, memory docs, and design references (like brandbook.html) so the agent's setup evolves to match how the user actually works. Trigger this whenever the user types "/session-calibrate", says "calibrate this session" or "session calibrate", asks to "learn from this session," "update my rules based on what just happened," "remember this preference for next time," or ends a session by asking the agent to reflect on it. Also worth proactively suggesting (not running) after a session with several corrections or a notably repeated pattern, even if the user doesn't ask. (Distinct from the built-in "calibrate" skill — this is the user's custom, more elaborate version with a staged learnings file.)
---

# Session Calibrate

## What this is for

Every session where the user corrects Claude, discovers a workflow that works, or states a preference is a session where useful information gets thrown away the moment the chat ends — unless something captures it. `/session-calibrate` is that capture step. It reads the session, figures out what's worth remembering, and proposes concrete edits to the files that actually govern future behavior (CLAUDE.md, skills, memory docs, department references).

The single most important property of this skill: **it never edits files on its own authority.** It always stops and shows the user a proposed diff first. Every real-world version of this pattern converges on the same reason — a single session is a small sample. A one-off correction might be a genuine standing preference, or it might be specific to that moment (a deadline, a one-time exception, a mood). Writing it into CLAUDE.md immediately, unreviewed, is how rule files silently rot into a pile of contradictory, over-specific noise that nobody trusts anymore. The user's approval is the filter that keeps the signal-to-noise ratio high.

## The workflow

### Step 1: Find the files that matter

Don't assume a fixed layout — workspaces vary. Look for, roughly in this order of priority:

- `CLAUDE.md` (project root, then `~/.claude/CLAUDE.md` for user-level)
- Anything in a `skills/` or `.claude/skills/` directory
- Department / domain reference files the user has mentioned or that live alongside CLAUDE.md (e.g. `content.md`, `brandbook.html`, `voice.md`, `style-guide.md`) — these are usually linked from CLAUDE.md as a "router," so read CLAUDE.md first to discover what else exists
- A memory or learnings file this skill maintains itself (see Step 4) — usually `.claude/calibrate-learnings.md` or `~/.claude/calibrate-learnings.md`

If none of these exist yet, don't fail — say so plainly, and offer to create a minimal `CLAUDE.md` plus a `calibrate-learnings.md`. Don't create files preemptively without saying so; the user should know a new file is about to appear in their repo.

### Step 2: Review the session

Read back through the current conversation (and, if the user asked for a fuller retrospective, any session transcripts available) looking for signal, not just activity. Useful categories:

- **Corrections** — anywhere the user said something like "no, actually," "don't do X, do Y instead," "I told you before," or fixed something Claude produced. These are the highest-value signal.
- **Stated preferences** — explicit likes/dislikes about format, tone, tools, process, even if no correction happened ("I always want the summary first," "skip the disclaimer next time").
- **Workflows that worked** — a multi-step approach the user approved of or reused, especially if it took a few tries to land on.
- **New capabilities or constraints discovered** — a tool that turned out to be unavailable, a naming convention in their codebase, an API quirk, a brand rule.
- **Things that are one-off, not standing** — explicitly set these aside. A deadline, a specific file's exception, a "just this once" — don't propose these as rule changes.

For each candidate, note: what happened, what the standing rule would be if generalized, and how confident you are it's actually a standing preference vs. a one-time thing.

### Step 3: Cross-reference against what's already documented

For each candidate from Step 2, check it against the files found in Step 1:

- **Already covered, session matched it** → nothing to do, don't report noise.
- **Already covered, but session contradicts it** → this is important. Surface it clearly — either the rule is stale and should be updated, or the session was the exception. Let the user decide; don't silently overwrite.
- **Not covered anywhere** → candidate for a new addition.
- **Covered in the wrong place** → e.g. a content-voice preference sitting in CLAUDE.md when it belongs in `content.md`. Propose moving it, not just duplicating it.

### Step 4: Route through the learnings file, don't write straight to CLAUDE.md

Resist writing a brand-new CLAUDE.md rule off the back of one session. Instead:

1. Log the observation to `calibrate-learnings.md` with a timestamp, what happened, and an occurrence count (increment if something very similar was already logged).
2. Only propose *promoting* something into CLAUDE.md / a skill / a department file once it has enough weight behind it — either it's shown up more than once in the learnings log, or it's high-confidence on its own (a direct, explicit, unambiguous statement of a standing preference, e.g. "always do X from now on" counts immediately; an inferred pattern from one session usually doesn't).
3. Keep the learnings file itself curated — if it's grown long, fold near-duplicate entries together instead of listing every occurrence separately. A learnings file nobody can skim is as useless as no learnings file.

This two-tier structure (learnings → promoted rule) is what keeps CLAUDE.md lean and trustworthy instead of turning into an unreadable accumulation of one-off notes.

See `references/promotion-criteria.md` for the concrete bar on what promotes immediately vs. waits for repetition, plus starter templates for CLAUDE.md and calibrate-learnings.md if neither exists yet.

### Step 5: Present the proposal, not the edit

Show the user, in the conversation, a clear before/after for every change you want to make — grouped by file. For each one include:
- The file and where in it (append / replace / new section)
- The proposed new text
- The one-or-two-sentence reason, tied to what actually happened in the session (don't invent justifications)
- Whether it's a **promotion** (learnings → durable rule) or just a **log entry** (learnings file only, low stakes, can move faster)

Then ask plainly: apply all, apply some, or skip. Only after the user responds do you touch the actual files. If the user says "just apply the obvious ones," use judgment — but a contradiction with an existing rule always gets called out explicitly before touching anything, even under a fast "just apply it" instruction.

### Step 6: Apply approved changes

- Append/edit CLAUDE.md and department files as approved.
- If a design-related change is approved (e.g. a color, spacing, or component convention that emerged from a session doing UI work), update the relevant design reference (`brandbook.html` or similar) rather than only noting it in prose — keep it in the format the rest of that file already uses.
- Update the learnings file to mark promoted items as promoted (so they don't get proposed again next time) and log anything not promoted.
- Give a short confirmation of what changed and where — not a re-print of the whole diff again.

## Environment notes

- **Claude Code**: this skill is invoked directly by typing `/session-calibrate`, or naturally at the end of a session. File paths are real paths on disk — read and edit them directly.
- **Cowork**: same workflow; there's no slash-command surface, so it triggers on phrases like "calibrate" or "update my setup from this session." Use its filesystem access the same way.
- **Claude.ai**: no persistent filesystem across sessions by default — if the user is working with uploaded files or a connected doc source (e.g. Google Drive), operate on those instead, and be explicit that changes only persist if saved back somewhere durable.

## Anti-patterns to avoid

- Don't propose a change for something that's already correctly documented — this trains the user to stop reading proposals.
- Don't infer a sweeping rule from a single ambiguous moment. "The user pushed back on this one chart's colors" is not "the user hates blue."
- Don't let the learnings file become a second, messier CLAUDE.md — it's a staging area, not a permanent home.
- Don't silently overwrite an existing rule that the session contradicted — that's exactly the kind of unreviewed edit this skill exists to prevent.
