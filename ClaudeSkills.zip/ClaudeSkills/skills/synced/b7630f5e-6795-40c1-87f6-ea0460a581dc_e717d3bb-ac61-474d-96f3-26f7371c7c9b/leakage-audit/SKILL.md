---
name: leakage-audit
description: Audits tabular ML datasets and pipelines for data leakage — target leakage, temporal leakage, group/entity leakage across splits, preprocessing-before-split contamination, train/test duplication. Runs detection scripts, then reasons about which findings are real. Use whenever model performance looks suspiciously good (AUC above ~0.95, near-perfect accuracy, one dominant feature), before trusting a validation score, before promoting a model to production, when reviewing someone's notebook or pipeline, when splitting data with repeated entities like patients/members/customers, or when the user mentions leakage, contamination, unexplained overfitting, train/test split design, cross-validation setup, or a model that worked offline but failed in production. Also use proactively when asked to build or evaluate any supervised model on tabular data — leakage is the most common cause of invalid results and far cheaper to catch before training than after deployment.
---

# Leakage Audit

## Why this exists

Leakage is the most expensive failure mode in applied ML because it is silent and inverted: it makes results look *better*, so nobody investigates. A model with 0.99 AUC gets celebrated and shipped. It then fails in production, and the post-mortem takes weeks because the offline numbers still reproduce perfectly — they were always reproducible, just meaningless.

The whole audit reduces to one question, asked of every feature:

> **Was this value knowable, for a real case, at the moment the prediction has to be made?**

Everything below is machinery for asking that question systematically. Statistics alone cannot answer it — a legitimately strong predictor and a leak are numerically identical. The scripts find candidates; the reasoning decides.

## Step 1: Establish the prediction context first

Do not run any script yet. Without this context the findings cannot be interpreted, and the audit will produce noise.

Determine, asking the user where it isn't inferable from the data or code:

1. **What is being predicted, and when?** Not "readmission" but "30-day readmission, predicted at the moment of discharge." The decision point is the reference line for every temporal judgment.
2. **What is the entity?** Patient, member, claim, encounter, account, device. This becomes the group key.
3. **Can one entity appear in multiple rows?** If yes, a random split leaks. This is the most commonly missed leak in healthcare data, where one member routinely has dozens of encounters.
4. **Is the deployment setting temporal?** If the model will predict on future data, validation must be chronological, not random.
5. **How was the data assembled?** Joins against outcome tables, or fields populated by downstream workflows, are where leaks enter. A single join against a table that post-dates the index date can contaminate everything.

If the user has a notebook or pipeline rather than just a file, read it — preprocessing-before-split leakage lives in code, not data, and no data scan will find it.

## Step 2: Run the scanner

`scripts/leakage_scan.py` runs the mechanical checks. Requires pandas, numpy, scikit-learn.

```bash
# Single dataset, before splitting
python scripts/leakage_scan.py data.csv --target readmitted_30d --group member_id --time index_date

# Existing train/test split (enables overlap, duplicate, adversarial checks)
python scripts/leakage_scan.py train.csv --target y --test-file test.csv \
    --group member_id --time index_date --json-out findings.json
```

Options: `--exclude` to drop ID-like columns from feature scoring, `--json-out` for machine-readable findings. Exits 1 when any HIGH finding is present, so it can gate a pipeline.

What each check detects, and what it can't:

| Check | Signal | Blind spot |
|---|---|---|
| `univariate_power` | One feature nearly solves the task alone | Legitimately dominant features look the same |
| `suspicious_name` | Column name implies post-outcome info | Pure heuristic; misses cryptic names entirely |
| `missingness_signal` | A field's *presence* predicts the target | Only fires between 1% and 99% missing |
| `group_repeats` / `group_overlap` | Same entity on both sides of the split | Needs the right `--group`; silent without it |
| `future_timestamp` / `temporal_overlap` | Dates after the index date; overlapping periods | Only sees parsed datetime columns |
| `duplicate_rows` / `train_test_duplicate` | Identical rows spanning splits | Near-duplicates slip through |
| `adversarial_validation` | Train and test are distinguishable | High AUC also means plain distribution shift |

Run the scanner before *and* after any remediation, so the effect is visible rather than assumed.

## Step 3: Triage each finding against the prediction context

This is the part that requires judgment, and it is the point of the skill. For every finding, classify it:

- **Confirmed leak** — the value could not have existed at prediction time. Remove the feature, or rebuild it from data available as of the index date.
- **Legitimate strong predictor** — genuinely available and genuinely predictive. Keep it, and record why it survived the audit, so the next person doesn't relitigate it.
- **Needs a data owner** — cannot be resolved from the data alone. Name the specific question to ask ("is `discharge_code` populated at admission or at discharge?") rather than guessing. Guessing here is how leaks survive audits.

Two failure modes to avoid. Do not dismiss a finding because the feature seems clinically plausible — plausibility is not availability, and outcome proxies are usually extremely plausible. Do not delete every flagged feature either; stripping real signal to make an audit pass produces a clean report and a useless model.

Read `references/taxonomy.md` when a finding needs more than a surface call — it covers each leakage type, the healthcare-specific patterns (claims lag, EHR fields populated by downstream workflows, ICD codes assigned retrospectively), and the manual checks no script can perform.

## Step 4: Remediate structurally, not by hand

Prefer fixes that make the leak impossible over fixes that depend on remembering:

- **Split first, fit second.** Every transform that learns parameters — scalers, imputers, encoders, bin edges, feature selection, resampling — belongs inside a `Pipeline` or `ColumnTransformer` fitted on training folds only. This is the difference between a structural guarantee and a good intention. Target encoding and SMOTE are the most common offenders and must sit inside the CV loop.
- **Group-aware splitting.** When entities repeat, use `GroupShuffleSplit` or `GroupKFold` keyed on the entity. Never `train_test_split` with `shuffle=True`.
- **Chronological splitting** for temporal deployment: `TimeSeriesSplit`, or an explicit cutoff date with a gap covering real-world reporting lag. Claims data often lags 30–90 days; a split ignoring that lag validates against data the model would not have had.
- **Rebuild rather than drop** where possible. `total_cost` leaks, but `total_cost_as_of_index_date` may be both legitimate and valuable.

## Step 5: Report

Produce a short written record — this is the deliverable, not the terminal output:

```
# Leakage audit: <dataset / model>

**Prediction point:** <what is predicted, at what moment>
**Entity / group key:** <key>   **Split strategy:** <random | group | chronological>

## Confirmed leaks (removed or rebuilt)
- <feature> — <why it wasn't knowable> — <action taken>

## Investigated and cleared
- <feature> — <why it is legitimately available>

## Open questions for data owners
- <specific question> — <who can answer>

## Split changes made
<before → after, e.g. random split → GroupShuffleSplit on member_id>

## Performance before / after
<metric before, metric after — a large drop is the expected, healthy outcome>
```

Report the performance drop plainly and frame it correctly: the earlier number was never real. Stakeholders anchored on the inflated figure need that stated directly, because the instinct is to treat the honest number as a regression.

## Reality check

A clean scan is not a clean bill of health. These checks find *mechanical* signatures. Leakage that requires domain knowledge to recognize — a lab panel only ordered when a physician already suspects the outcome, a billing code assigned retrospectively — produces no statistical fingerprint at all. Say this explicitly when reporting; do not let a passing scan be read as a guarantee.
