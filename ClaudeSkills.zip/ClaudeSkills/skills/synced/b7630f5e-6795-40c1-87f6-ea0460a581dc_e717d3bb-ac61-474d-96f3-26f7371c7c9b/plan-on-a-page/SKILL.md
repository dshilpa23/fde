---
name: plan-on-a-page
description: Produce a single-page orientation document — goal in one line, swimlane of who does what, phase diagram showing where we are, what changed since we started, and one next step. Use this whenever the user says they are lost, confused, or has lost the thread on a long-running project; asks "where are we", "what are we actually trying to achieve", "what have we done so far", "what changed since we started", "summarize this project", "what's the next step"; asks for a swimlane, flowchart, roadmap, or plan diagram; needs to re-orient before a stakeholder meeting or before starting a new session; or is drowning in analysis detail and needs the shape of the work instead of the data. Also use it proactively when a conversation has produced many findings and course-corrections and the user's next move is unclear. Bias toward using this skill rather than writing a long prose recap — a recap in chat is exactly what this replaces.
---

# Plan on a page

One page. Diagrams over prose. The goal is that someone who has lost the thread —
including the user, including a future session — can read it in two minutes and know
what the work is for, where it stands, and what happens next.

The failure mode this exists to prevent: a long, accurate prose recap that restates
everything and clarifies nothing. If the output is more than roughly one screen of
reading plus diagrams, it has failed.

## This skill explains. It does not implement.

The output is always a picture of the work, never the work itself. No scripts, no
code, no SQL, no copy-ready build prompts, no config. Those are legitimate and often
what the user wants next — but they are a *different* output, and mixing them in is
what turns a page into the wall of detail the user was trying to escape.

So: produce the page, then offer the implementation separately. "Want the build
prompt for step 1?" is the right way to end. Never pre-emptively append it.

If the user asks for both at once, produce two artifacts, not one blended document.

## Two modes

Decide which one is being asked for before writing anything. The structures differ;
the visual language stays identical, so the two read as a set.

| Signal | Mode |
|---|---|
| "where are we", "I'm lost", "what are we trying to achieve", "summarize this project", "what changed since we started", before a stakeholder meeting, before a new session | **Project view** |
| "what is this task", "explain what we're doing now", "what does this step involve", a single story or work item named, mid-build and unclear what the current piece is for | **Task view** |

When it is genuinely ambiguous, produce the project view and mark the current task
on the phase diagram. The project view always contains enough to locate a task; a
task view never contains enough to locate the project.

## Project view — structure

A markdown file with Mermaid diagrams. Put it in the outputs directory and present
it. Markdown because the user will edit it, paste parts into messages, and keep it
across sessions.

Skip any section that would be padding for the project at hand — an empty section is
worse than a missing one.

```
# <Project> — plan on a page

**The goal:** one sentence. What becomes possible that isn't today.
**Why it doesn't exist today:** one sentence. The actual obstacle.

## Where the work sits          <- swimlane
## <N> stages, and where we are <- phase diagram with current position marked
## What we learned that changed the plan  <- 3-row before/after table
## What we get out of this      <- fan-out diagram, 2-4 outcomes
## Next step — one thing        <- exactly one, then a short ordered list
## What each stakeholder needs from us    <- table, only if there are stakeholders
```

## Task view — structure

Same visual language, narrower frame. The job here is to answer "why am I doing this
piece, and how will I know it's done" — not to specify it.

```
# <Task name>

**What this unlocks:** one sentence. What becomes possible once this is done.
**Where it sits:** which stage of the overall plan, and what waits on it.

## The shape of it        <- small flowchart, 3-6 nodes, the task's own steps
## What we already have   <- short table: real / faked / missing
## Done when              <- 3-5 checkable statements in plain language
## Not in this task       <- the adjacent things people will assume are included
```

Two sections carry most of the value.

**"What we already have" must separate real from faked from missing.** A task feels
much bigger than it is when the parts already working are invisible. Name what is
verified, what works only because something is stubbed, and what genuinely does not
exist.

**"Not in this task"** is what stops scope creep and stops the user worrying about
things that were never in scope. Name the two or three adjacent pieces someone would
reasonably assume are included, and say they aren't.

Keep "Done when" in plain language. "The numbers come from the system instead of
from hand-run queries" is a better completion statement than a list of acceptance
criteria — criteria belong in the build prompt, which is the other artifact.

## The swimlane

This is the most valuable diagram and the one most often asked for. Mermaid has no
native swimlane, so build lanes as `subgraph` blocks with `direction TB`, laid out
left-to-right.

One lane per **actor**, not per workstream. Solid arrows for work inside a lane;
dotted arrows with labels for handoffs between lanes.

```mermaid
flowchart LR
    subgraph L1["**You** — build"]
        direction TB
        A1["First thing"] --> A2["Second thing"] --> A3["Third thing"]
    end
    subgraph L2["**Other team** — asks"]
        direction TB
        B1["The one ask that matters"]
    end
    subgraph L3["**Stakeholders** — decisions"]
        direction TB
        C1["Name: the question they own"]
    end
    A1 -.->|"finding"| B1
    A2 -.->|"the number"| C1
    B1 -.->|"unblocks"| A3
    style L1 fill:#e8f4f2,stroke:#0e5f5c
    style L2 fill:#fdf4e3,stroke:#8a6d1f
    style L3 fill:#eef1f8,stroke:#2b4a7d
```

**Then say in one line whether the user's own lane blocks on the others.** This is
usually the single most reassuring or most alarming fact on the page, and it is
almost never stated explicitly anywhere else. If their lane is independent, say so —
someone who feels stuck on five dependencies often isn't.

## The phase diagram

Stages left-to-right or top-down, with a detail node hanging off each one saying its
real state. Mark position with fill, not with text labels:

- filled/solid = done
- outlined, thicker stroke = current
- dashed outline = not started

Name stages as verbs the user would recognise from their own conversation, not as
project-management vocabulary. "Measure → Record → Explain → Learn" beats
"Discovery → Implementation → Deployment → Optimization".

## What we learned that changed the plan

Three rows, no more:

| | |
|---|---|
| **Started thinking** | the original hypothesis, in the user's own framing |
| **Found instead** | what the evidence showed |
| **So the fix moved** | the consequence for the work |

Then one italicised sentence the user could say out loud to anyone who asks.

State corrections plainly, including your own wrong turns from earlier in the
conversation. A person who has been course-correcting for days often fears the
project has drifted. Naming each correction as a correction — rather than quietly
presenting the new position as if it were always the plan — is what makes the page
feel like solid ground instead of a moving target. It is also simply honest.

## Next step — one thing

Exactly one. Bold it. Then, separately, a short ordered list of what follows.

Explain why this one is first in terms of what it unlocks, not in terms of effort or
sequence. And say what is running in parallel and therefore *not* blocking it —
people conflate "waiting on someone" with "unable to proceed".

## What to leave out

- Numbers, except where a number *is* the finding. A page with twelve figures on it
  is the thing the user was lost in.
- Every caveat. Caveats belong in the detailed report this page points away from.
- Tooling, file paths, table names, model names, query syntax.
- Anything the user already knows. This is orientation, not a record.

If a fact is load-bearing but detailed, put it in the detailed artifact and let this
page stay a page.

## Getting the content right

Draw the content from the conversation, not from a fresh interview. The user is
asking for this *because* they have said everything already and it hasn't cohered.
Asking them to restate it is the wrong move.

Read back through what happened and separate four things, because they read very
differently on the page:

| | Goes where |
|---|---|
| What was assumed at the start | "Started thinking" row |
| What was measured or verified | the stages that are marked done |
| What was built | the stage detail nodes, plainly — say what works and what is faked |
| What is still someone else's decision | the stakeholder lane and the parallel-work line |

Where the project has a design stance or a set of guardrails, the page should be
consistent with them without reciting them. If the work is deliberately additive,
read-only, or shadow-mode, one clause on the outcomes diagram is enough.

## Style, and keeping it consistent

Prose plain and short. No em-dash asides, no "not X but Y", no invented labels in
scare quotes. Sentence case in diagram nodes. Bold sparingly, and only on the thing
you want read first.

Hold the visual language constant across every page produced for a project, project
view and task view alike: same three lane colours, same fill convention for
done/current/not-started, same section names, same one-sentence opener. The point of
a fixed format is that by the third one the user stops reading the structure and
reads only what changed. Varying it for freshness destroys that.

The user asked for a page because prose failed them. Respect that by writing less
than feels complete.
