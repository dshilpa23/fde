---
name: module-dag-report
description: Run any module in this repo (module_1_story through module_5_agentic_langgraph) end-to-end and publish an Artifact showing its workflow DAG plus a real execution trace. Use when the user asks to "run module N", "show the DAG/graph for module N", "generate a report for module N", or "do this for all modules". Works with or without a live OPENAI_API_KEY.
---

# Module DAG + run report

Generalizes the Module 5 report (planner → SQL subgraph → approval gate →
booking) to any module in this repo. Given a module name (or "all"), it:

1. gets the module running end-to-end (real OpenAI key if present, otherwise
   the repo's own `tests/fakes.py::FakeLLM` harness — never invents a mock
   of its own),
2. produces the module's real control-flow diagram (LangGraph's own
   `get_graph().draw_mermaid()` for modules 4–5; a source-derived diagram,
   honestly labeled as such, for modules 1–3),
3. publishes one Artifact per module using `report_template.html` in this
   skill folder as the shared visual system, so all five reports read as one
   family.

Repo layout this skill depends on (verify paths still match before relying
on them — read the actual files, don't assume):

| Module | Workflow file | Demo/CLI | Graph object? | LLM-gated? | Matching test |
|---|---|---|---|---|---|
| `module_1_story` | six standalone scripts `01_..06_..py` | `python -m module_1_story.NN_*` | no | yes | `tests/test_module1.py` |
| `module_2_chain` | `chain_workflow.py::run_chain` | same file's `main()` | no (fixed 3-call chain) | yes | `tests/test_module2.py` |
| `module_3_plain_python` | `manual_workflow.py::ManualHospitalWorkflow` | `demo.py` | no (hand-rolled state machine over `Stage`) | yes (first call only) | `tests/test_module3.py` |
| `module_4_langgraph` | `workflow.py::build_graph` | `demo.py` | yes, `StateGraph` | no | `tests/test_module4_core.py`, `tests/test_module4_integration.py` |
| `module_5_agentic_langgraph` | `workflow.py::build_graph` + `build_sql_specialist` | `demo.py` | yes, `StateGraph` with a subgraph | yes | `tests/test_module5_core.py`, `tests/test_module5_integration.py` |

## Step 0 — resolve the target

Ask "which module?" only if genuinely ambiguous. Accept `module_1_story`,
`module_2_chain`, `module_3_plain_python`, `module_4_langgraph`,
`module_5_agentic_langgraph`, or `all` (run every module in sequence, one
Artifact each). Normalize whatever the user typed (`"module 3"`, `"m3"`,
`"the plain python one"`) to the exact directory name by checking `Glob`.

## Step 1 — environment

Reuse one venv for every module in this run; don't recreate it per module.

```powershell
python -m venv .venv          # only if .venv doesn't already exist
.\.venv\Scripts\python.exe -m pip install --quiet -r requirements.txt
```

Check whether a live key is usable:

```powershell
if (Test-Path .env) { Write-Output ".env present" }
if ($env:OPENAI_API_KEY) { Write-Output "OPENAI_API_KEY set" }
```

If a key is present, prefer running the module for real through its actual
`demo.py`/`main()` — that's a more honest report than the fake harness.
If no key is present (the common case in a fresh clone), fall back to
Step 3's fake-LLM approach and **say so explicitly in the report** — never
silently pass off scripted output as a live model run.

## Step 2 — get the diagram

**Modules 4 and 5 (LangGraph-based):** the diagram is real and
machine-generated — don't hand-draw it. Build the compiled graph with any
placeholder LLM/services object (construction never calls it) and call
`get_graph(xray=True).draw_mermaid()`:

```python
# module 4
from hospital_story.demo_domain import HospitalServices
from module_4_langgraph.workflow import build_graph
graph = build_graph(HospitalServices())
print(graph.get_graph(xray=True).draw_mermaid())

# module 5 — also render build_sql_specialist(...) standalone for the subgraph
```

Strip the mermaid output's escaped subgraph node ids (LangGraph emits
`sql_specialist\3aload_schema` for a node named `load_schema` inside a
subgraph called `sql_specialist` — `\3a` is an escaped colon) into short
plain ids before embedding in HTML, the way `module5_dag_report.html` did
(`sql_start`, `sql_bq`, `sql_gen`, ... `sql_end`), so mermaid doesn't choke
on the backslash escape.

**Modules 1–3 (no compiled graph object):** there is nothing to call
`get_graph()` on. Read the actual control flow and draw the equivalent
mermaid by hand — but label it in the report as *"derived from source, not
machine-rendered"* so the reader never mistakes it for module 4/5's
auto-generated diagrams. Concretely:

- `module_2_chain`: a 3-node linear chain, `classify -> draft -> format`,
  each edge annotated with which LLM call it is (LLM-1/2/3 per the logging
  tags already in the code).
- `module_3_plain_python`: a state diagram over the `Stage` Literal
  (`START -> REQUEST_UNDERSTOOD -> DOCTOR_FOUND -> ...`); the retry loop
  is `DOCTOR_FOUND/SEARCHING_SLOT` self-loop up to `MAX_SEARCHES`, and
  `WAITING_CONFIRMATION` is the pause/resume point — draw it as a dashed
  edge back into `CONFIRMED`/`STOPPED`, mirroring the human-gate treatment
  used for modules 4/5's `interrupt()`.
- `module_1_story`: each numbered script is its own tiny pattern, not one
  workflow — diagram each script separately (e.g. `05_agent_loop.py` is a
  bounded loop: `choose action -> run tool -> observe -> (loop, max 5
  turns) -> finish`). Don't force six scripts into one artificial DAG.

## Step 3 — run it end-to-end

If running live (`OPENAI_API_KEY` set): just invoke the module's own
`demo.py`/`main()` as documented in its README, and capture stdout/logs.

If running with the fake harness: **read that module's actual integration
test first** (see table above) and reuse its exact `FakeLLM`
`structured_responses`/`text_responses` shape — don't invent new fixture
data. Write a small throwaway script under the scratchpad directory (not
inside the repo) that:

- inserts the repo root and `tests/` onto `sys.path`,
- imports `FakeLLM` from `fakes.py`,
- builds whatever services/db the module needs (`HospitalDatabase` for
  modules 3/4/5's demo domain, or `HospitalServices` for module 3/4),
- drives the module's real entry point (`run_chain`, `ManualHospitalWorkflow.run`,
  `graph.invoke`, etc.) — not a reimplementation of its logic,
- prints the full resulting state/trace as JSON so it can be read back,
- for anything with an interrupt/confirmation pause (module 3's
  `WAITING_CONFIRMATION`, module 4/5's `interrupt()`), drive both the pause
  and the resume so the report shows the full gate, like module 5's did.
- cleans up any temp `.db`/checkpoint files it created (delete after the
  DB connection is closed — SQLite on Windows will `PermissionError` on
  unlink while a connection is still open, so close first).

Run it through the venv: `.\.venv\Scripts\python.exe <script>`.

## Step 4 — build the Artifact

Before writing HTML, load the `artifact-design` skill (same as any artifact)
— this skill's `report_template.html` already encodes the resulting design
system (palette, type stack, stat-grid, diagram panels, terminal trace
panel, gate panel, answer panel) so reuse it rather than re-deriving a new
look per module. Read `report_template.html` in this skill's folder, copy
it to the scratchpad, and fill in per-module content:

- eyebrow / title / subtitle naming the module and its one-sentence idea
  (pull from that module's own README opening line — don't paraphrase it
  into something generic),
- the callout block stating plainly whether this run used a live key or
  the fake harness,
- one stat tile grid per run (request, key outcome fields, status pill —
  field names vary by module; only include tiles that have real values,
  never pad with placeholders),
- one `diagram-panel` per diagram from Step 2, with the "derived from
  source" caption when applicable,
- a `gate-panel` only for modules that actually pause for human input
  (module 3 confirmation, module 4/5 `interrupt()`) — omit entirely for
  module 1/2, which have none,
- the `trace-panel` terminal log, grouped by phase the same way module 5's
  was (planner / execution / gate / answer),
- the closing `answer-panel` with the module's actual final text.

Publish with `Artifact` (unique `file_path` per module so each gets its own
URL), a stable module-specific favicon, e.g.:

| module | favicon |
|---|---|
| 1 | 🧪 |
| 2 | ⛓️ |
| 3 | 🛠️ |
| 4 | 🕸️ |
| 5 | 🩺 |

For `all`: publish the five per-module artifacts, then tell the user all
five links — don't force five modules onto one page; each has a different
shape (some have no graph, some have no gate) and cramming them together
would hide that rather than showing it.

## Honesty rules (carry over from the module 5 report, don't relax them)

- Never claim a diagram is machine-generated when it was hand-derived —
  say which one it is, every time.
- Never claim a run used a live model when it used `FakeLLM` — the callout
  block exists specifically to disclose this.
- Don't pad stat grids or trace panels with invented values to make
  modules look more parallel than they are; a module with no booking gate
  simply has a shorter report, and that's fine.
