# Regression Model Template (House Style)

Extracted from `Course 6 - Model Building and Performance Analysis/01_SimpleLinearRegression.py`,
`02_LinearRegression-1.py`, `03_LinearRegression-2.py`, and
`Course 7 - Advanced Algorithms in ML/02_DecisionTreeRegressor.py`.

Placeholders used throughout: `df` (working DataFrame), `target_col`, `X_train`/`X_test`/
`y_train`/`y_test`, `X_train_processed`/`X_test_processed` (post-encoding/scaling feature frames),
`numerical_cols`/`categorical_cols`.

## 1. Simple linear regression baseline (single feature, sanity-check model)

Use this only for a genuinely single-feature relationship (e.g. explaining the pattern to a
learner, or a true 1-variable problem). For anything with more than one feature, skip straight to
section 3.

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

X = np.array([...]).reshape((-1, 1))  # sklearn requires X to be 2D even for one feature
y = np.array([...])

plt.scatter(X, y)
plt.show()

model = LinearRegression()
model.fit(X, y)
print(f"intercept: {model.intercept_}")
print(f"slope: {model.coef_}")

y_pred = model.predict(X)

plt.scatter(X, y)
plt.plot(X, y_pred, c="red")
plt.show()

# Predict a new value
model.predict([[15]])
```

## 2. Full preprocessing pipeline for multi-feature regression

Reuses the same dedupe → impute → outlier-cap-features-only(never the target if its outliers are
legitimate) → split → encode(fit-train-only) → scale(fit-train-only) pipeline documented in full
in `preprocessing-template.md` and `imbalance-handling-template.md`. Key regression-specific
nuance: **do not blindly cap outliers on the target column** — inspect first whether the extreme
target values are realistic business outcomes (e.g. very high hospital charges for very sick
patients) rather than data errors; if realistic, cap only the feature columns and leave the
target untouched.

```python
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split

df = pd.read_csv("./Data/<your_file>.csv")
df_without_duplicates = df.drop_duplicates()

# Impute (mode/median) as in preprocessing-template.md section 1
df_without_nulls = df_without_duplicates.copy()
# ... mode-impute categoricals, median-impute numerics ...

# IQR-cap feature columns only, never the (possibly legitimately-skewed) target
numerical_cols = df_without_nulls.select_dtypes(include=[np.number]).columns.drop(target_col)

def get_bounds(series):
    Q1, Q3 = series.quantile(0.25), series.quantile(0.75)
    IQR = Q3 - Q1
    return Q1 - 1.5 * IQR, Q3 + 1.5 * IQR

df_without_outliers = df_without_nulls.copy()
for col in numerical_cols:
    lower_bound, upper_bound = get_bounds(df_without_nulls[col])
    df_without_outliers[col] = df_without_nulls[col].clip(lower=lower_bound, upper=upper_bound)

X = df_without_outliers.drop(columns=target_col)
y = df_without_outliers[target_col]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

categorical_cols = X.columns.drop(numerical_cols).tolist()
encoder = OneHotEncoder(drop="first", handle_unknown="ignore", sparse_output=False, dtype=int)
encoder.fit(X_train[categorical_cols])
encoded_cols = encoder.get_feature_names_out(categorical_cols)
train_encoded_df = pd.DataFrame(encoder.transform(X_train[categorical_cols]), columns=encoded_cols, index=X_train.index)
test_encoded_df = pd.DataFrame(encoder.transform(X_test[categorical_cols]), columns=encoded_cols, index=X_test.index)

scaler = StandardScaler()
scaler.fit(X_train[numerical_cols])
train_scaled_df = pd.DataFrame(scaler.transform(X_train[numerical_cols]), columns=numerical_cols, index=X_train.index)
test_scaled_df = pd.DataFrame(scaler.transform(X_test[numerical_cols]), columns=numerical_cols, index=X_test.index)

X_train_processed = pd.concat([train_scaled_df, train_encoded_df], axis=1)
X_test_processed = pd.concat([test_scaled_df, test_encoded_df], axis=1)
```

## 3. `statsmodels.api.OLS` + iterative backward elimination by p-value

House style always builds the `statsmodels` OLS model **first**, purely to inspect p-values (which
`sklearn`'s `LinearRegression` does not expose), then iteratively drops the least-significant
feature and refits until every remaining coefficient's p-value is below 0.05:

```python
import statsmodels.api as sm

# statsmodels.OLS assumes no intercept by default -> add a constant column explicitly
X_train_with_const = sm.add_constant(X_train_processed)

ols_model = sm.OLS(y_train, X_train_with_const)
ols_result = ols_model.fit()
ols_result.summary()  # inspect F-statistic (overall significance) and each coefficient's p-value

# Iteratively remove the least-significant feature until all p-values <= 0.05
for _ in X_train_with_const.columns:
    if ols_result.pvalues.max() > 0.05:
        feature_to_remove = ols_result.pvalues.idxmax()
        print(f"Removing feature {feature_to_remove} with p-value {ols_result.pvalues.max()}")
        X_train_with_const = X_train_with_const.drop(columns=feature_to_remove)
        ols_model = sm.OLS(y_train, X_train_with_const)
        ols_result = ols_model.fit()

ols_result.summary()  # all p-values should now be <= 0.05
```

**Interpretation notes to carry into the notebook's own commentary:** F-statistic probability
below 0.05 means the overall model is statistically significant; an individual coefficient's
p-value above 0.05 means that feature is not contributing significantly and is a backward-
elimination candidate. Note the house-style caveat: eliminating insignificant features by
p-value often does **not** by itself improve R² — it's a significance/interpretability cleanup
step, not a performance-guaranteed one. If R² stays low after backward elimination, the next move
is feature engineering (section 3 of `preprocessing-template.md`) or a non-linear model (section 5
below), not more p-value pruning.

Typical workflow to state explicitly: use `statsmodels` to check significance and drop
insignificant features -> train the **final** model using only the significant features in
`sklearn` for downstream use (metrics, deployment, integration with pipelines).

```python
significant_cols = [c for c in X_train_with_const.columns if c != "const"]
X_train_final = X_train_processed[significant_cols]
X_test_final = X_test_processed[significant_cols]
```

## 4. sklearn LinearRegression on the significant-feature set

```python
from sklearn.linear_model import LinearRegression

linear_model = LinearRegression()
linear_model.fit(X_train_final, y_train)

coefficients_df = pd.DataFrame(linear_model.coef_, index=X_train_final.columns, columns=["Coefficient"])
```

### Feature-impact bar chart

```python
importance = linear_model.coef_
sorted_idx = np.argsort(importance)
plt.barh(X_train_final.columns[sorted_idx], importance[sorted_idx])
plt.xlabel("Linear Coefficient")
plt.title("Feature Importance")
plt.gcf().set_size_inches(10, 7)
plt.show()
```

## 5. Ridge / Lasso via sklearn with alpha

Reach for these once the plain linear model plateaus, as a fine-tuning step. `alpha` is a
hyperparameter — the notebooks use `alpha=0.01` as an illustrative starting value and explicitly
flag it as a placeholder that should be swept via `GridSearchCV`/`RandomizedSearchCV`, not treated
as tuned.

```python
from sklearn.linear_model import Lasso, Ridge

lasso_model = Lasso(alpha=0.01)
lasso_model.fit(X_train_final, y_train)
# Lasso shrinks unimportant feature coefficients to exactly zero -> built-in feature selection

ridge_model = Ridge(alpha=0.01)
ridge_model.fit(X_train_final, y_train)
# Ridge shrinks coefficients toward zero but (generally) not to exactly zero
```

Proper alpha tuning (recommended over the illustrative fixed value above):

```python
from sklearn.model_selection import GridSearchCV

alpha_grid = {"alpha": [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]}
lasso_search = GridSearchCV(Lasso(), param_grid=alpha_grid, scoring="r2", cv=5)
lasso_search.fit(X_train_final, y_train)
print("Best alpha:", lasso_search.best_params_)
```

## 6. Decision Tree Regressor (non-linear fallback when linear models plateau)

House-style narrative: when Linear/Lasso/Ridge plateau around a mediocre R² despite feature
engineering and regularization, the diagnosis is usually **non-linearity** the linear family
can't capture — reach for a Decision Tree Regressor (or the fuller ensemble progression in
`tree-ensemble-progression-template.md`) rather than more linear-model tuning.

```python
from sklearn.tree import DecisionTreeRegressor

# Tree-based -> skip outlier capping & scaling; use the unscaled numerical + encoded categorical frame
dtree_reg = DecisionTreeRegressor(random_state=42)
dtree_reg.fit(X_train_processed, y_train)
```

See `tree-ensemble-progression-template.md` section 2 for feature importance, pre-pruning,
`KFold` cross-validation, and hyperparameter search specific to the regressor.

## 7. MAE / MSE / RMSE / R² evaluation block + train-vs-test gap framing

This is the regression analogue of the classification "3%-accuracy-gap" overfitting check in
`imbalance-handling-template.md` — same spirit (compare train vs. test), applied to R² instead of
accuracy:

```python
from sklearn.metrics import mean_absolute_error, mean_squared_error, root_mean_squared_error, r2_score

y_train_pred = model.predict(X_train_final)   # substitute the fitted model of your choice
y_test_pred = model.predict(X_test_final)

train_mae = mean_absolute_error(y_train, y_train_pred)
test_mae = mean_absolute_error(y_test, y_test_pred)

train_mse = mean_squared_error(y_train, y_train_pred)
test_mse = mean_squared_error(y_test, y_test_pred)

train_rmse = root_mean_squared_error(y_train, y_train_pred)
test_rmse = root_mean_squared_error(y_test, y_test_pred)

train_r2 = r2_score(y_train, y_train_pred)
test_r2 = r2_score(y_test, y_test_pred)
test_adj_r2 = 1 - (1 - test_r2) * (len(y_test) - 1) / (len(y_test) - X_test_final.shape[1] - 1)

print(f"Train MAE: {train_mae:.4f}   Test MAE: {test_mae:.4f}")
print(f"Train MSE: {train_mse:.4f}   Test MSE: {test_mse:.4f}")
print(f"Train RMSE: {train_rmse:.4f}  Test RMSE: {test_rmse:.4f}")
print(f"Train R^2: {train_r2:.4f}   Test R^2: {test_r2:.4f}   Test Adj R^2: {test_adj_r2:.4f}")

# Overfitting check (regression analogue of the classification 3%-accuracy-gap rule)
if abs(train_r2 - test_r2) > 0.03:
    print("Warning: Potential overfitting detected.")
else:
    print("No significant overfitting detected.")
```

Interpretation notes to reuse in the notebook's own "Observation" cell:
- **Test R² ≈ or slightly above Train R²** (as seen in the house-style Linear Regression runs) is
  a strong "no overfitting" signal — the model isn't just memorizing training rows.
- **Test Adjusted R² ≈ Test R²** confirms no low-value features are inflating the raw R² —
  Adjusted R² penalizes extra features that don't earn their keep.
- **Train R² = 1.0000 with a much lower Test R²** (the Decision Tree Regressor's default,
  unpruned behavior) is the textbook overfitting signature — respond with pruning/tuning
  (`tree-ensemble-progression-template.md` section 2), not by declaring the model "done."
- Always report MAE/RMSE in the target variable's original units alongside R² — R² alone doesn't
  tell a business stakeholder how many dollars/days/units of error to expect.
