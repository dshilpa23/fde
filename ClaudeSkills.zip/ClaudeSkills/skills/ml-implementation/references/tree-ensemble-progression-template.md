# Tree & Ensemble Progression Template (House Style)

Extracted from `Course 7 - Advanced Algorithms in ML/01` through `07`. These notebooks share one
preprocessing pipeline (dedupe → impute → target-encode → train_test_split → one-hot encode; no
outlier capping, no scaling — tree-based models don't need either) and then progress through a
model family: Decision Tree → Bagging → Random Forest → AdaBoost → Gradient Boosting → XGBoost,
each compared back to the Logistic Regression baseline from `imbalance-handling-template.md`.

Placeholders used throughout: `df` (working DataFrame), `target_col`, `X_train`/`X_test`/
`y_train`/`y_test`, `X_train_processed`/`X_test_processed` (post-encoding feature frames),
`numerical_cols`/`categorical_cols`.

## 0. Shared preprocessing for every model in this file

Tree-based models are invariant to monotonic transforms, feature scale, and outliers (they split
on thresholds/ordering, not distance), so house style explicitly **skips** IQR outlier capping and
`StandardScaler` for every model below — this is a deliberate simplification versus the
Logistic Regression pipeline in `imbalance-handling-template.md`, not an oversight.

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
    ConfusionMatrixDisplay, roc_curve,
)
import warnings
warnings.filterwarnings("ignore")

df = pd.read_csv("./Data/<your_file>.csv")
df_without_duplicates = df.drop_duplicates()
df_without_duplicates[target_col] = df_without_duplicates[target_col].replace({"Low": 0, "High": 1})

# Impute (mode for categorical, median for numerical) — see preprocessing-template.md section 1
df_without_nulls = df_without_duplicates.copy()
cat_cols = df_without_nulls.select_dtypes(include=["object"]).columns.tolist()
df_without_nulls[cat_cols] = SimpleImputer(strategy="most_frequent").fit_transform(df_without_nulls[cat_cols])
num_cols = df_without_nulls.select_dtypes(exclude="object").columns.tolist()
df_without_nulls[num_cols] = SimpleImputer(strategy="median").fit_transform(df_without_nulls[num_cols])

X = df_without_nulls.drop(columns=target_col)
y = df_without_nulls[target_col]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1000)

categorical_cols = df_without_nulls.select_dtypes(include="object").columns.tolist()
encoder = OneHotEncoder(drop="first", handle_unknown="ignore", sparse_output=False, dtype=int)
encoder.fit(X_train[categorical_cols])
encoded_cols = encoder.get_feature_names_out(categorical_cols)
train_encoded_df = pd.DataFrame(encoder.transform(X_train[categorical_cols]), columns=encoded_cols, index=X_train.index)
test_encoded_df = pd.DataFrame(encoder.transform(X_test[categorical_cols]), columns=encoded_cols, index=X_test.index)

numerical_cols = df_without_nulls.select_dtypes(exclude="object").columns.tolist()
numerical_cols.remove(target_col)
X_train_processed = pd.concat([X_train[numerical_cols], train_encoded_df], axis=1)
X_test_processed = pd.concat([X_test[numerical_cols], test_encoded_df], axis=1)
```

### Shared evaluation helpers reused for every model below

```python
def evaluate_overfitting(train_acc, test_acc, threshold=0.03):
    print(f"Train Accuracy: {train_acc:.4f}")
    print(f"Test Accuracy: {test_acc:.4f}")
    if abs(train_acc - test_acc) > threshold:
        print("Warning: Potential overfitting detected.")
    else:
        print("No significant overfitting detected.")

def plot_confusion_matrix(model, y_test, y_test_pred):
    cm = confusion_matrix(y_test, y_test_pred, labels=model.classes_)
    ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=model.classes_).plot()
    plt.show()

def plot_roc(model, X_test_processed, y_test, label):
    y_test_proba = model.predict_proba(X_test_processed)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_test_proba)
    auc_score = roc_auc_score(y_test, y_test_proba)
    plt.figure(figsize=(7, 5))
    plt.plot(fpr, tpr, label=f"{label} AUC = {auc_score:.2f}")
    plt.plot([0, 1], [0, 1], "k--")
    plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
    plt.title(f"{label} ROC Curve"); plt.legend(loc="lower right"); plt.grid(True)
    plt.show()
    return auc_score
```

---

## 1. Decision Tree Classifier

```python
from sklearn.tree import DecisionTreeClassifier, plot_tree

dtree = DecisionTreeClassifier(random_state=42)
dtree.fit(X_train_processed, y_train)

y_train_pred = dtree.predict(X_train_processed)
y_test_pred = dtree.predict(X_test_processed)
evaluate_overfitting(accuracy_score(y_train, y_train_pred), accuracy_score(y_test, y_test_pred))
```

### Visualize the tree

```python
plt.figure(figsize=(25, 20))
plot_tree(dtree, filled=True, feature_names=X_train_processed.columns.tolist(), class_names=["0", "1"])
plt.title("Decision Tree Visualization")
plt.show()
```

### Feature importance -> rebuild on reduced feature set

Default (unconstrained) trees fit training data to 100% accuracy and overfit — house style's
first fix is feature-importance-based pruning, not hyperparameters yet:

```python
importances = dtree.feature_importances_
feat_imp_df = pd.DataFrame({"feature": X_train_processed.columns, "importance": importances}) \
    .sort_values("importance", ascending=False)

threshold = 0.01
important_features = feat_imp_df[feat_imp_df["importance"] > threshold]["feature"].tolist()

X_train_selected_imp_features = X_train_processed[important_features]
X_test_selected_imp_features = X_test_processed[important_features]

dtree_reduced = DecisionTreeClassifier(random_state=42)
dtree_reduced.fit(X_train_selected_imp_features, y_train)
```

House-style observation: feature selection alone rarely fixes overfitting for a fully-grown
tree — accuracy is unchanged, confirming the overfitting is a *complexity* problem, not a
*feature-noise* problem. Pruning (below) is what actually helps.

### Pre-pruning (hand-picked hyperparameters)

```python
dtree_pruned = DecisionTreeClassifier(
    criterion="gini",          # or "entropy"
    max_depth=10,
    min_samples_split=20,
    min_samples_leaf=10,
    max_leaf_nodes=8,
    random_state=42,
)
dtree_pruned.fit(X_train_selected_imp_features, y_train)
```

### StratifiedKFold + cross_val_score / cross_val_predict (imbalanced classification target)

Use `StratifiedKFold` (not plain `KFold`) whenever the target is imbalanced, so every fold keeps
the same class ratio as the full dataset:

```python
from sklearn.model_selection import StratifiedKFold, cross_val_score, cross_val_predict

# Encode categoricals on the FULL X (not train/test split) since CV handles splitting internally
skfold = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
dt_classifier = DecisionTreeClassifier(random_state=42)

cv_accuracy_scores = cross_val_score(dt_classifier, X_CV, y, cv=skfold, scoring="accuracy")
y_pred_cv = cross_val_predict(dt_classifier, X_CV, y, cv=skfold)

print(f"Mean Accuracy across folds: {np.mean(cv_accuracy_scores):.4f}")
print(f"Std Dev across folds: {np.std(cv_accuracy_scores):.4f}")
print(confusion_matrix(y, y_pred_cv))
print(classification_report(y, y_pred_cv))
```

### RandomizedSearchCV — param grid actually used

```python
from sklearn.model_selection import RandomizedSearchCV

np.random.seed(42)
param_dist = {
    "criterion": ["gini", "entropy"],
    "max_depth": np.random.choice(np.arange(2, 12), size=5, replace=False),
    "min_samples_split": np.random.choice(np.arange(2, 31), size=5, replace=False),
    "min_samples_leaf": np.random.choice(np.arange(10, 25), size=5, replace=False),
    "max_leaf_nodes": np.random.choice(np.arange(2, 21), size=5, replace=False),
}

random_search = RandomizedSearchCV(
    estimator=DecisionTreeClassifier(random_state=42),
    param_distributions=param_dist,
    n_iter=20, cv=3, scoring="accuracy", random_state=42, n_jobs=-1,
)
random_search.fit(X_train_selected_imp_features, y_train)
print("Best params:", random_search.best_params_)
```

### GridSearchCV — smaller, curated grid for the same params

```python
from sklearn.model_selection import GridSearchCV

np.random.seed(40)
param_grid = {
    "criterion": ["gini", "entropy"],
    "max_depth": sorted(np.random.choice(np.arange(2, 12), size=4, replace=False)),
    "min_samples_split": sorted(np.random.choice(np.arange(2, 16), size=4, replace=False)),
    "min_samples_leaf": sorted(np.random.choice(np.arange(10, 25), size=4, replace=False)),
    "max_leaf_nodes": sorted(np.random.choice(np.arange(2, 16), size=4, replace=False)),
}

grid_search = GridSearchCV(
    estimator=DecisionTreeClassifier(random_state=42),
    param_grid=param_grid, cv=3, scoring="accuracy", n_jobs=-1,
)
grid_search.fit(X_train_selected_imp_features, y_train)
print("Best params:", grid_search.best_params_)
```

Compare both best estimators side by side with `plot_tree` in a `1x2` subplot, and compare their
test accuracy / recall / AUC against each other and against the Logistic Regression baseline.

---

## 2. Decision Tree Regressor

Same preprocessing skip-list (no outlier capping, no scaling), swap classifier metrics for
regression metrics:

```python
from sklearn.tree import DecisionTreeRegressor, plot_tree
from sklearn.metrics import mean_squared_error, r2_score

dtree_reg = DecisionTreeRegressor(random_state=42)
dtree_reg.fit(X_train_processed, y_train)

y_train_pred = dtree_reg.predict(X_train_processed)
y_test_pred = dtree_reg.predict(X_test_processed)

train_r2, test_r2 = r2_score(y_train, y_train_pred), r2_score(y_test, y_test_pred)
if abs(train_r2 - test_r2) > 0.03:
    print("Warning: Potential overfitting detected.")
```

Pre-pruning for a regressor (same idea, `criterion='squared_error'` default):

```python
dtree_reg_pruned = DecisionTreeRegressor(
    criterion="squared_error",  # or "friedman_mse", "absolute_error"
    max_depth=8, min_samples_split=15, min_samples_leaf=5, max_leaf_nodes=60,
    random_state=42,
)
dtree_reg_pruned.fit(X_train_selected_imp_features, y_train)
```

`KFold` (not stratified — regression target has no classes to preserve) + `cross_val_score`:

```python
from sklearn.model_selection import KFold, cross_val_score

kfold = KFold(n_splits=3, shuffle=True)
cv_r2_scores = cross_val_score(DecisionTreeRegressor(), X_CV, y, cv=kfold, scoring="r2")
cv_neg_mse_scores = cross_val_score(DecisionTreeRegressor(), X_CV, y, cv=kfold, scoring="neg_mean_squared_error")
mse_scores = -cv_neg_mse_scores
print(f"Mean R^2: {cv_r2_scores.mean():.4f}  Mean MSE: {mse_scores.mean():.4f}")
```

RandomizedSearchCV param grid for the regressor swaps `criterion` values and widens
`max_leaf_nodes`:

```python
param_dist = {
    "criterion": ["squared_error", "friedman_mse"],
    "max_depth": np.random.choice(np.arange(2, 12), size=5, replace=False),
    "min_samples_split": np.random.choice(np.arange(2, 31), size=5, replace=False),
    "min_samples_leaf": np.random.choice(np.arange(10, 25), size=5, replace=False),
    "max_leaf_nodes": np.random.choice(np.arange(4, 80), size=10, replace=False),
}
random_search = RandomizedSearchCV(
    DecisionTreeRegressor(random_state=42), param_distributions=param_dist,
    n_iter=20, cv=3, scoring="neg_mean_squared_error", random_state=42, n_jobs=-1,
)
random_search.fit(X_CV, y)  # fit on full data when doing CV-based search, not the earlier split
```

---

## 3. Bagging Classifier

```python
from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier

bagging_clf = BaggingClassifier(random_state=42)  # base estimator defaults to DecisionTreeClassifier()
bagging_clf.fit(X_train_processed, y_train)
```

Key default hyperparameters worth calling out to the user: `n_estimators=10`, `max_samples=1.0`,
`max_features=1.0`, `bootstrap=True`, `oob_score=False`.

### Out-of-Bag (OOB) error as a built-in validation signal

Enable `oob_score=True` to get an unbiased generalization estimate without a separate validation
split (each tree is trained on a bootstrap sample that leaves ~1/3 of rows out; those out-of-bag
rows validate that tree):

```python
bagging_oob = BaggingClassifier(n_estimators=45, random_state=42, oob_score=True, n_jobs=-1)
bagging_oob.fit(X_train_processed, y_train)
print(f"OOB Score: {bagging_oob.oob_score_:.4f}  OOB Error: {1 - bagging_oob.oob_score_:.4f}")

# Sweep n_estimators to find the point of diminishing returns
n_estimators_range = range(1, 51, 2)
oob_errors = []
for n_est in n_estimators_range:
    m = BaggingClassifier(n_estimators=n_est, random_state=42, oob_score=True, n_jobs=-1)
    m.fit(X_train_processed, y_train)
    oob_errors.append(1 - m.oob_score_)

plt.plot(n_estimators_range, oob_errors)
plt.xlabel("Number of Estimators"); plt.ylabel("OOB Error")
plt.title("Out-of-Bag Error vs Number of Estimators")
plt.show()
print(f"Minimum OOB Error: {min(oob_errors):.4f} at {n_estimators_range[np.argmin(oob_errors)]} estimators")
```

### GridSearchCV / RandomizedSearchCV param grid actually used

```python
param_search = {
    "n_estimators": [100, 150, 200],
    "max_samples": [0.5, 0.8, 1.0],
    "max_features": [0.5, 0.8, 1.0],
    "bootstrap": [True],
}
```

`RandomizedSearchCV(bagging_clf, param_distributions=param_search, n_iter=10, scoring="roc_auc", cv=5, n_jobs=-1)`
or `GridSearchCV(bagging_clf, param_grid=param_search, scoring="roc_auc", cv=5, n_jobs=-1)`.

---

## 4. Random Forest Classifier

Random Forest is Bagging with decorrelated trees (random feature subsampling at each split built
in) — same preprocessing, same evaluation helpers:

```python
from sklearn.ensemble import RandomForestClassifier

rf_clf = RandomForestClassifier(random_state=42)
rf_clf.fit(X_train_processed, y_train)
```

### Param grid actually used for tuning

```python
param_search = {
    "n_estimators": [100, 150, 200],
    "max_depth": [10, 15, 20],
    "min_samples_split": [2, 5, 10],
    "min_samples_leaf": [10, 15],
    "max_features": ["sqrt", "log2"],
    "bootstrap": [True],
    "class_weight": [None, "balanced"],
}
```

`class_weight='balanced'` is worth including in the grid for Random Forest specifically because,
unlike Bagging's plain `DecisionTreeClassifier` base estimator, `RandomForestClassifier` accepts
`class_weight` directly — a cheap way to combine ensemble variance-reduction with imbalance
handling in one model, as an alternative/complement to the resampling techniques in
`imbalance-handling-template.md`.

---

## 5. AdaBoost Classifier

Simpler tuning surface than Bagging/RF — house style does not use the Spark-parallel pattern for
AdaBoost, just a plain `RandomizedSearchCV`:

```python
from sklearn.ensemble import AdaBoostClassifier

ada_clf = AdaBoostClassifier(random_state=42)
ada_clf.fit(X_train_processed, y_train)
```

### Param grid actually used

```python
param_random_search = {
    "n_estimators": [50, 100, 150, 200],
    "learning_rate": [0.01, 0.05, 0.1, 0.5, 1.0],
}

from sklearn.model_selection import RandomizedSearchCV
random_search = RandomizedSearchCV(
    AdaBoostClassifier(random_state=42),
    param_distributions=param_random_search,
    n_iter=20, scoring="roc_auc", cv=3, random_state=42, n_jobs=-1,
)
random_search.fit(X_train_processed, y_train)
```

---

## 6. Gradient Boosting Classifier

```python
from sklearn.ensemble import GradientBoostingClassifier

gb_clf = GradientBoostingClassifier(random_state=42)
gb_clf.fit(X_train_processed, y_train)
```

### Param grid actually used

```python
param_random_search = {
    "n_estimators": [100, 150, 200],
    "learning_rate": [0.01, 0.05, 0.1],
    "max_depth": [4, 5, 6],
}

random_search = RandomizedSearchCV(
    GradientBoostingClassifier(random_state=42),
    param_distributions=param_random_search,
    n_iter=10, scoring="roc_auc", cv=3, random_state=42, n_jobs=-1,
)
random_search.fit(X_train_processed, y_train)
```

---

## 7. XGBoost Classifier

```python
from xgboost import XGBClassifier

xgb_clf = XGBClassifier(random_state=42)
xgb_clf.fit(X_train_processed, y_train)
```

### Param grid actually used

```python
param_random_search = {
    "n_estimators": [50, 100, 150, 200],
    "learning_rate": [0.01, 0.05, 0.1, 0.2, 0.3],
    "max_depth": [3, 4, 5, 6],
}

random_search = RandomizedSearchCV(
    XGBClassifier(random_state=42),
    param_distributions=param_random_search,
    n_iter=20, scoring="roc_auc", cv=3, random_state=42, n_jobs=-1,
)
random_search.fit(X_train_processed, y_train)
```

---

## 8. [ADVANCED / OPTIONAL] pandas_udf-based cluster-parallel grid search

This pattern appears in `03_BaggingClassifier.py`, `04_RandomForestClassifier.py`, and
`06_GradientBoostingClassifier.py`. **Only use this when the user explicitly asks for
cluster-parallel / distributed hyperparameter tuning on a Spark/Databricks cluster.** For normal
notebook work, plain `GridSearchCV`/`RandomizedSearchCV` with `n_jobs=-1` (shown above, and
commented out as the "WITHOUT PARALLELIZATION" fallback in the source notebooks) is simpler,
equally correct, and should be your default. Reach for this only when the search space is large
enough that sequential `n_jobs=-1` search is a genuine bottleneck and a Spark cluster is
available.

The idea: instead of scikit-learn evaluating each hyperparameter combination sequentially (even
with `n_jobs=-1`, that's still bounded by one machine's cores), distribute each combination to a
Spark task as a grouped `pandas_udf`, running the (small, single-machine) cross-validation loop
for that one combination inside each task, in parallel across the cluster.

```python
from pyspark.sql.functions import pandas_udf, monotonically_increasing_id, PandasUDFType
from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, BooleanType
from sklearn.model_selection import StratifiedKFold
from itertools import product
import random

# 1. Define the hyperparameter grid (same param names/values as the sequential grid above)
param_grid_search = {
    "n_estimators": [100, 150, 200],
    "max_samples": [0.5, 0.8, 1.0],
    "max_features": [0.5, 0.8, 1.0],
    "bootstrap": [True],
}

# 2a. For RandomizedSearchCV-style: sample N random combinations
random.seed(42)
param_combos = [
    {k: random.choice(v) for k, v in param_grid_search.items()}
    for _ in range(10)
]
# 2b. For GridSearchCV-style: generate the full cartesian product instead
# param_combos = [dict(zip(param_grid_search.keys(), combo)) for combo in product(*param_grid_search.values())]

# 3. Put the grid into a Spark DataFrame, one row per combination, with a unique group key
param_df = spark.createDataFrame(pd.DataFrame(param_combos))
param_df = param_df.withColumn("group_key", monotonically_increasing_id())

# 4. Broadcast the training data as plain pandas objects (captured by closure in the UDF)
X_train_df_pd = pd.DataFrame(X_train_processed)
y_train_series = pd.Series(y_train)

# 5. Declare the output schema for the grouped pandas UDF
schema = StructType([
    StructField("roc_auc", DoubleType()),
    StructField("n_estimators", IntegerType()),
    StructField("max_samples", DoubleType()),
    StructField("max_features", DoubleType()),
    StructField("bootstrap", BooleanType()),
    StructField("group_key", IntegerType()),
])

# 6. Each Spark task receives exactly ONE hyperparameter combo's row(s) and
#    runs a local StratifiedKFold CV loop over it, returning the mean ROC-AUC.
@pandas_udf(schema, PandasUDFType.GROUPED_MAP)
def crossval_roc_auc_udf(pdf: pd.DataFrame) -> pd.DataFrame:
    results = []
    for _, row in pdf.iterrows():
        model = BaggingClassifier(
            n_estimators=row["n_estimators"], max_samples=row["max_samples"],
            max_features=row["max_features"], bootstrap=row["bootstrap"],
            random_state=42, n_jobs=1,  # n_jobs=1 inside the task avoids nested parallelism
        )
        cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
        roc_scores = []
        for train_idx, val_idx in cv.split(X_train_df_pd, y_train_series):
            model.fit(X_train_df_pd.iloc[train_idx], y_train_series.iloc[train_idx])
            proba = model.predict_proba(X_train_df_pd.iloc[val_idx])[:, 1]
            roc_scores.append(roc_auc_score(y_train_series.iloc[val_idx], proba))
        results.append((np.mean(roc_scores), row["n_estimators"], row["max_samples"],
                         row["max_features"], row["bootstrap"], row["group_key"]))
    return pd.DataFrame(results, columns=["roc_auc", "n_estimators", "max_samples",
                                            "max_features", "bootstrap", "group_key"])

# 7. Run it: each group_key (i.e. each hyperparameter combo) is dispatched to a separate Spark task
scored_df = param_df.groupBy("group_key").apply(crossval_roc_auc_udf)
best_row = scored_df.drop("group_key").orderBy("roc_auc", ascending=False).first()

best_params = {
    "n_estimators": best_row["n_estimators"], "max_samples": best_row["max_samples"],
    "max_features": best_row["max_features"], "bootstrap": best_row["bootstrap"],
    "random_state": 42,
}
print("Best hyperparameters:", best_params, "  Best CV ROC-AUC:", best_row["roc_auc"])

# 8. Retrain the final model on the full training set with the winning params
bagging_best = BaggingClassifier(**best_params)
bagging_best.fit(X_train_processed, y_train)
```

Notes for adapting this pattern to Random Forest or Gradient Boosting: swap the model class and
its constructor kwargs inside the UDF (`RandomForestClassifier(...)` /
`GradientBoostingClassifier(...)`), and adjust the Spark `schema` fields to match that model's
hyperparameter names/types (e.g. Gradient Boosting's grid is `n_estimators`, `learning_rate`,
`max_depth` — no `bootstrap`/`max_samples`/`max_features`). This requires an active
`SparkSession`/`spark` variable and only makes sense inside a Databricks notebook or a Spark
cluster — it will fail outside that environment.
