# Databricks Notebook Conventions (House Style)

This house style is extracted from `.setup/learner_setup.py` (Course 6 and Capstone copies) and the
cross-cutting structural patterns used in every `.py` notebook in this codebase (Course 5, 6, 7,
Capstone). New notebooks scaffolded by the `ml-implementation` skill MUST follow this exact
cell-separator syntax and structure, because these files are exported/imported by Databricks as
"notebook source" `.py` files — get the syntax wrong and Databricks will not render cells correctly.

## 1. File header

Every notebook file starts with this exact literal line as line 1 — no exceptions:

```python
# Databricks notebook source
```

## 2. Cell separators

Cells are separated by this exact literal marker on its own line, with a blank line before and after:

```python
# COMMAND ----------
```

A full notebook is just a sequence of `# Databricks notebook source`, then repeated
`<cell content>` blocks each followed by `# COMMAND ----------`.

## 3. Markdown cells (`# MAGIC %md`)

Markdown content inside a code cell is written as a `%md` magic, with **every line** of the
markdown block prefixed by `# MAGIC `. This is not optional — every single markdown line needs
the prefix, including blank ones (`# MAGIC` with no trailing text is fine for a blank line).

```python
# MAGIC %md
# MAGIC ## Section Title
# MAGIC
# MAGIC - Bullet one
# MAGIC - Bullet two
# MAGIC
# MAGIC Regular prose paragraph explaining the *why* before the *what*.
```

House style consistently uses markdown cells to narrate: Problem Statement → Introduction →
step-by-step workflow list → the code cell(s) → an "Observation" markdown cell interpreting the
output. Mirror this "explain, then code, then interpret" rhythm rather than dumping code with no
narration.

## 4. Cell titles (`# DBTITLE`)

Some cells (usually the first substantive cell, or a cell introducing a large diagram/table) carry
a `# DBTITLE 1,<title text>` line immediately above the cell content. This renders as a named tab
in the Databricks UI. Pattern:

```python
# DBTITLE 1,Knowledge Graph: Pipeline Actions, Rationale, and Outcomes
# MAGIC %md
# MAGIC ## ...
```

Use `# DBTITLE 1,<Title>` sparingly — typically once near the top of a notebook to title an
overview/knowledge-graph cell, not on every cell.

## 5. The `%run ./.setup/learner_setup` bootstrap pattern

Course notebooks that need extra pip packages begin (after the title markdown) with:

```python
# MAGIC %run ./.setup/learner_setup
```

This runs a sibling setup notebook that detects the serverless Python/Databricks runtime version,
then does an offline (Volumes-backed) pip install and restarts the Python kernel:

```python
# Databricks notebook source
import sys, os

def get_serverless_version() -> int:
  python_version = sys.version.split()[0]
  databricks_version = os.environ.get("DATABRICKS_RUNTIME_VERSION")
  match python_version:
    case "3.10.12":
      return 1
    case "3.11.10":
      return 2
    case "3.12.3":
      if databricks_version.startswith("client.3."):
        return 3
      else:
        return 4
    case _:
      return 3  # or 2, depending on course — check the sibling file

serverless_version = get_serverless_version()
print(serverless_version)

# COMMAND ----------

lib_dir = f"/Volumes/prod_ai_dojo/wheelhouse/ml/<course_or_capstone_dir>/{serverless_version}/"
requirements = f"{lib_dir}shim.txt"
constraints = f"{lib_dir}constraints.txt"

%pip install -r $requirements -c $constraints
dbutils.library.restartPython()
print("The kernel has been restarted and you can now run the notebook.")
```

The `/Volumes/prod_ai_dojo/wheelhouse/ml/<something>/{version}/` path segment changes per
course/module (observed values: `course6`, `capstone` — each course/module directory has its own
`.setup/learner_setup.py` with its own hardcoded Volumes path).

**CRITICAL RULE — do not fabricate this line.** Only emit `# MAGIC %run ./.setup/learner_setup`
in a new notebook if a `.setup/learner_setup.py` file actually exists alongside (in the same
directory tree as) the notebook you are generating. If you are scaffolding a notebook into a new
or unknown directory and cannot confirm a `.setup/learner_setup.py` sibling exists, omit the
`%run` bootstrap entirely and rely on whatever packages are already installed in the environment.
Never invent a Volumes path or assume a setup notebook is present.

## 6. Standard import block and warnings convention

Immediately after the (optional) bootstrap cell, notebooks import packages in one cell and
immediately suppress warnings for clean notebook output:

```python
# import the required packages

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

warnings.filterwarnings("ignore")
```

Task-specific imports (sklearn transformers/models, imblearn samplers, statsmodels, xgboost,
pyspark) are added to this same block — see the other reference files in this skill for exactly
which imports pair with which modeling pattern. Keep `warnings.filterwarnings("ignore")` as the
last line of the import cell in every notebook, matching house style.

## 7. Narrative and structural conventions to replicate

- **Problem Statement cell**: a `%md` cell right after the title, naming the dataset file, the
  target column, and the task type (classification/regression) in bold.
- **Introduction cell**: explains that preprocessing is iterative and dataset-dependent ("not
  every dataset requires every step"), and lists the workflow as a numbered list.
- **Print-shape-after-every-transform convention**: after `drop_duplicates()`, imputation,
  outlier capping, encoding, scaling, etc., print the resulting `.shape` so the reader can see the
  pipeline's effect at every step, e.g. `print(f"Shape of the dataframe after dropping duplicates is {df.shape}")`.
- **Observation cells**: after every evaluation cell (accuracy print, confusion matrix,
  classification report, ROC/AUC), add a `%md` cell titled `### Observation` that interprets the
  printed numbers in prose (what the number means, whether it's good/bad, what to do next).
- **Comment style**: short, lower-case, present-tense inline comments above code lines, e.g.
  `# remove the duplicate records`, `# read the data`.

## 8. Capstone deliverable convention (only for capstone-style submissions)

This section applies **only** when the user is explicitly doing a Capstone-style final deliverable
— not for ordinary course/practice notebooks. Do not apply this convention unless asked.

The Capstone workflow (see `Capstone_Instructions.md` and `Submit_Capstone_Project.py`) requires:

1. A notebook literally named `code.ipynb` (created via the Databricks UI "Create → Notebook",
   named `code` — Databricks appends `.ipynb`) containing the full modeling work.
2. A submission CSV containing **exactly one column named `y_pred`**, with no missing/empty
   values, saved in the same directory as `code.ipynb`:
   - `regression_submission.csv` — `y_pred` must be numeric (validated with `pd.to_numeric`).
   - `classification_submission.csv` — `y_pred` must contain only the values `0` and `1`.
   - The row count of the submission CSV must exactly match a hidden reference test file, so
     predictions must be produced for the full, correctly-ordered test set provided for the
     capstone, not an arbitrary sample.
3. `code.ipynb` may also begin with `%run ./.setup/learner_setup` (Capstone has its own
   `.setup/learner_setup.py` pointing at
   `/Volumes/prod_ai_dojo/wheelhouse/ml/capstone/{serverless_version}/`) — again, only emit this
   if that file is confirmed present next to the capstone notebook.
4. Submission itself is done by running the separate `Submit_Capstone_Project` notebook, which
   zips `code.ipynb` + the CSV(s) + a status file and enforces a 2-day cooldown between submission
   attempts. The skill does not need to generate `Submit_Capstone_Project.py` — it is provided by
   the course — but generated capstone code should produce the exact `y_pred`-only CSV(s) it
   expects.

Minimal pattern for producing a compliant submission file at the end of a capstone notebook:

```python
# Final predictions on the provided test set, single-column submission format
submission_df = pd.DataFrame({"y_pred": y_test_pred})
submission_df.to_csv("regression_submission.csv", index=False)   # or classification_submission.csv
```
