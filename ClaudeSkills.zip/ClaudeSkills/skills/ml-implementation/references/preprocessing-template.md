# Preprocessing Template (House Style)

Extracted from Course 5 ("Data Handling & Preprocessing") modules on missing-value imputation,
encoding, log transformation, and feature engineering/PCA, plus the IQR outlier-capping pattern
that recurs identically across Course 6 and Course 7 notebooks (that is the clearest, most-reused
version, so it is the canonical one below).

Placeholders used throughout: `df` (working DataFrame), `target_col` (target column name),
`numerical_cols` / `categorical_cols` (column-name lists), `X_train` / `X_test` (post-split
feature frames), `y_train` / `y_test`.

All of these steps are **optional and situational** — house style explicitly says "not every
dataset requires every step." Decide per-dataset whether a step applies (e.g. skip outlier
capping if there are no outliers; skip capping on a binary/target column).

## 1. Missing value imputation

### 1a. Mode imputation for a single categorical column (manual, explicit control)

```python
# imputation using mode, for a categorical column
df_without_nulls = df.copy()
col = "<categorical_col_with_missing_values>"
col_mode = df[col].mode()[0]
df_without_nulls.loc[:, col] = df_without_nulls[col].fillna(col_mode)
```

### 1b. Batch mode imputation for all categorical columns (SimpleImputer)

```python
from sklearn.impute import SimpleImputer

cat_cols = df_without_nulls.select_dtypes(include=["object"]).columns.tolist()
cat_imputer = SimpleImputer(strategy="most_frequent")
df_without_nulls[cat_cols] = cat_imputer.fit_transform(df_without_nulls[cat_cols])
```

### 1c. Median imputation for numerical columns (manual, column-by-column)

```python
numerical_data = df_without_nulls.select_dtypes(include=[np.number])
numerical_cols = numerical_data.columns

for col in numerical_cols:
    if df_without_nulls[col].isna().sum() > 0:
        col_median = df_without_nulls[col].median()
        df_without_nulls.loc[:, col] = df_without_nulls[col].fillna(col_median)
```

### 1d. Batch median imputation for numerical columns (SimpleImputer)

```python
from sklearn.impute import SimpleImputer

num_cols = df_without_nulls.select_dtypes(exclude="object").columns.tolist()
num_imputer = SimpleImputer(strategy="median")
df_without_nulls[num_cols] = num_imputer.fit_transform(df_without_nulls[num_cols])
```

Always confirm afterward: `df_without_nulls.isna().sum()` should be all zeros.

### 1e. Domain-knowledge-based imputation (hierarchical / relationship-aware)

Use this when a missing categorical value can be inferred from a *related* column rather than
from the column's own mode — e.g. `Sector` can be recovered from `Category` when the two have a
known hierarchical mapping. Plain mode imputation would be wrong here because it ignores the
relationship between columns.

```python
# Build a mapping of parent-category -> list of child-category values seen under it
parent_col, child_col = "Sector", "Category"
parent_list = df[parent_col].value_counts().index.tolist()
parent_child_map = {}
for p in parent_list:
    parent_child_map[p] = df.loc[df[parent_col] == p][child_col].value_counts().index.tolist()

def infer_parent_from_child(row):
    if pd.isna(row[parent_col]):
        if not pd.isna(row[child_col]):
            for parent, children in parent_child_map.items():
                if row[child_col] in children:
                    return parent
        return row[parent_col]  # still missing if child is also missing
    return row[parent_col]

df[parent_col] = df.apply(infer_parent_from_child, axis=1)
```

Note the residual: rows where *both* the parent and child are missing cannot be resolved by this
pass. Impute the child column first (by its own logic), then re-run this mapping to mop up the
remaining parent nulls.

### 1f. Domain-knowledge-based imputation (group-wise median, e.g. by category/provider type)

Use this when a numeric feature's "typical value" legitimately differs by subgroup (e.g. bed
count for a "Critical Access" hospital vs. a "General Short Term" hospital) — a single global
median would blur that signal.

```python
group_col = "<categorical_grouping_col>"  # e.g. "Provider Type"
numerical_cols_to_impute = ["<col1>", "<col2>", "..."]

for col in numerical_cols_to_impute:
    if df[col].isna().sum() > 0:
        # Fill with the median within each group first
        df[col] = df.groupby(group_col)[col].transform(lambda x: x.fillna(x.median()))
        # Fallback: if a whole group was missing, fall back to the global median
        df[col] = df[col].fillna(df[col].median())
```

## 2. Encoding

### 2a. One-hot encoding for nominal columns (no inherent order) — fit on train, transform both

This is the default encoder for categorical *feature* columns in model-building notebooks (see
`imbalance-handling-template.md`, `tree-ensemble-progression-template.md`,
`regression-model-template.md` for full pipeline context). Always fit only on `X_train` and reuse
the same fitted encoder on `X_test` to avoid leakage.

```python
from sklearn.preprocessing import OneHotEncoder

encoder = OneHotEncoder(
    drop="first",          # avoid multicollinearity from the dummy trap
    handle_unknown="ignore",  # unseen category at inference time -> all-zero row, not an error
    sparse_output=False,   # dense array output (use sparse=False on sklearn < 1.2)
    dtype=int,
)
encoder.fit(X_train[categorical_cols])

train_encoded = encoder.transform(X_train[categorical_cols])
encoded_cols = encoder.get_feature_names_out(categorical_cols)
train_encoded_df = pd.DataFrame(train_encoded, columns=encoded_cols, index=X_train.index)

test_encoded = encoder.transform(X_test[categorical_cols])
test_encoded_df = pd.DataFrame(test_encoded, columns=encoded_cols, index=X_test.index)
```

Quick, low-dimensional alternative for exploratory/PCA-style work on the *whole* frame (no
train/test leakage concern because it's unsupervised prep prior to PCA, not label-aware):

```python
df_encoded = pd.get_dummies(
    df,
    columns=["<nominal_col_1>", "<nominal_col_2>", "..."],
    drop_first=True,
)
```

### 2b. Label encoding for a nominal column with many categories (dimensionality control)

Use `LabelEncoder` only when one-hot would blow up dimensionality too much for a nominal column
(house style explicitly recommends this trade-off for high-cardinality nominal columns like
`State`). Be aware it invents an arbitrary (usually alphabetical) numeric order among unordered
categories.

```python
from sklearn.preprocessing import LabelEncoder

LE = LabelEncoder()
df["<high_cardinality_nominal_col>"] = LE.fit_transform(df["<high_cardinality_nominal_col>"])
```

**Pitfall:** `LabelEncoder` creates an unintended ordinal relationship (e.g. "Average" might
become 0, "Good" might become 1, "Bad" might become 2) purely from alphabetical/appearance order.
Distance- or coefficient-based models (KNN, linear/logistic regression) can misinterpret this as
a meaningful numeric order. Prefer one-hot encoding for nominal data unless cardinality forces a
trade-off, and never use `LabelEncoder` on a column you intend to feed to a linear model as if it
were ordinal.

### 2c. Ordinal encoding for a genuinely ordered categorical column

Use `OrdinalEncoder` (not `LabelEncoder`) when the categories have a true, known order (e.g.
`Basic` < `Intermediate` < `Advanced`). You must supply the order explicitly — do not let it
infer one.

```python
from sklearn.preprocessing import OrdinalEncoder

OE = OrdinalEncoder(categories=[["Basic", "Intermediate", "Advanced"]])
df["<ordinal_col>"] = OE.fit_transform(df[["<ordinal_col>"]])
df["<ordinal_col>"] = df["<ordinal_col>"].astype(int)  # fit_transform returns float by default
```

**Pitfall to flag to the user:** applying ordinal encoding to a column that does *not* have a
real order (treating nominal data as ordinal) silently injects a false ranking into the model.
Always confirm the category order is domain-meaningful before using `OrdinalEncoder`; if it
isn't, use one-hot (2a) instead.

## 3. IQR-based outlier capping (canonical version — reused verbatim across Course 6 & 7)

This exact `get_bounds` + `clip` pattern is the one used consistently for linear/logistic
regression preprocessing. Tree-based models (Decision Tree, Bagging, Random Forest, AdaBoost,
Gradient Boosting, XGBoost) are split-threshold-based and explicitly **skip** this step in house
style, since they are invariant to monotonic transforms/outliers — only apply outlier capping
ahead of linear/distance-based models (Linear/Logistic Regression) or when explicitly doing a
comparative "does capping change tree performance" experiment.

```python
def get_bounds(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    return lower_bound, upper_bound

df_without_outliers = df_without_nulls.copy()

for col in numerical_cols:  # never include the target column here (see note below)
    lower_bound, upper_bound = get_bounds(df_without_nulls[col])
    df_without_outliers[col] = df_without_nulls[col].clip(lower=lower_bound, upper=upper_bound)
```

Notes carried over from house style:
- **Capping ≠ removal.** `clip()` replaces extreme values with the bound; it does not drop rows,
  so dataset size is unchanged — call this out explicitly in a comment/markdown cell.
- **Never cap a binary/categorical target column** (e.g. a 0/1 encoded classification target) —
  outlier logic is meaningless for two-valued data. Drop the target from `numerical_cols` before
  the loop: `numerical_cols = numerical_cols.drop(target_col)`. The *feature* columns are still
  capped as usual — only the target is excluded from the loop (this is the exact rule applied in
  `imbalance-handling-template.md`'s pipeline: "skip capping the binary target", not "skip capping
  as a step").
  For a **continuous regression target**, think before capping it: if outliers are legitimate
  extreme-but-real values for the business problem (e.g. very sick patients driving very high
  hospital charges), capping the target discards real signal — house style capped only the
  *feature* columns in that case, not `Inpatient Total Charges` itself.

### Percentile-based capping variant (looser, when 1.5×IQR is too aggressive)

```python
def cap_outliers(series, lower_percentile=5, upper_percentile=95):
    lower_bound = series.quantile(lower_percentile / 100)
    upper_bound = series.quantile(upper_percentile / 100)
    return series.clip(lower=lower_bound, upper=upper_bound)

for col in original_numerical_cols:  # typically raw features, not engineered ratio features
    df[col] = cap_outliers(df[col])
```

## 4. Log transformation for skewed numeric features

Use when a numeric feature is highly skewed (rule of thumb from house style: `abs(skew) > 1` is
"highly skewed"; `-0.5` to `0.5` is "roughly symmetric") and you want to make its distribution
more normal-like for a linear/statistical model, stabilize variance, or linearize a multiplicative
relationship. Only valid for strictly positive data (log of zero/negative is undefined).

```python
# Check skewness first
for col in numerical_cols:
    print(f"Skewness of {col}: {round(df[col].skew(), 4)}")

# Apply log transform (natural log) to skewed columns
for col in skewed_cols:
    df[col + "_scaled"] = np.log(df[col])

# Re-check skewness after transforming
for col in skewed_cols:
    print(f"Skewness of {col}_scaled: {round(df[col + '_scaled'].skew(), 4)}")
```

To reverse for interpretation in the original scale: `np.exp(value)`.

Quick visual check (before vs. after):

```python
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
sns.histplot(df[col], kde=True, bins=50, color="blue", ax=axes[0])
axes[0].set_title("Original")
sns.histplot(df[col + "_scaled"], kde=True, bins=50, color="green", ax=axes[1])
axes[1].set_title("Log-Scaled")
plt.show()
```

## 5. Feature engineering + PCA

### 5a. Domain-driven feature creation (reduce correlated raw columns into one meaningful ratio)

Prefer this over PCA when you know a meaningful formula (interpretable, keeps domain meaning) —
e.g. combining `Weight` and `Height` into `BMI`, or hospital operational counts into efficiency
ratios (`Cost_per_Discharge`, `Revenue_per_Bed`, `Employees_per_Bed`, `Bed_Utilization`,
`Avg_Length_Stay`). After deriving the new feature, drop the raw columns it was built from so you
don't have redundant/correlated columns in the model.

```python
df = df.assign(bmi=lambda x: x["weight"] / (x["height"] ** 2))
df = df.drop(columns=["height", "weight"])
```

Cap a derived ratio at its logical bound if the raw inputs can produce impossible values (e.g.
utilization over 100%):

```python
df["bed_utilization"] = df["bed_utilization"].clip(upper=1.0)
```

### 5b. PCA — fit on train only, choose components by explained variance

Use PCA when you have many correlated numeric features and want automated, non-domain-specific
dimensionality reduction rather than (or in addition to) hand-built ratios. **Fit PCA only on the
training data** — reuse the fitted `pca` object to transform the test set, exactly like the
encoder/scaler pattern above, to avoid leaking test-set variance into the transformation.
(Numeric columns should already be one-hot encoded and standardized — see `regression-model-
template.md` and `imbalance-handling-template.md` for that combined pipeline — before PCA.)

```python
from sklearn.decomposition import PCA

# Step 1: exploratory PCA with an arbitrary small number of components to inspect structure
pca_explore = PCA(n_components=2)
pca_explore.fit(X_train_processed)  # fit on train only
train_pcs_explore = pca_explore.transform(X_train_processed)

# Inspect the linear-combination coefficients (loadings) behind each PC
feature_names = X_train_processed.columns.tolist()
for i, pc_loadings in enumerate(pca_explore.components_):
    terms = " + ".join(f"{coef:.2f}*{name}" for coef, name in zip(pc_loadings, feature_names))
    print(f"PC{i + 1} = {terms}")

# Step 2: decide the number of components via a scree plot (visual "elbow")
pca_full = PCA()
pca_full.fit(X_train_processed)  # fit on train only

pc_values = np.arange(pca_full.n_components_) + 1
plt.plot(pc_values, pca_full.explained_variance_ratio_, "o-", linewidth=2)
plt.title("Scree Plot")
plt.xlabel("Principal Component")
plt.ylabel("Variance Explained")
plt.show()

# Step 3: decide the number of components via a cumulative-variance target (more objective)
cumulative_variance = np.cumsum(pca_full.explained_variance_ratio_)
target_variance = 0.90
n_components = np.argmax(cumulative_variance >= target_variance) + 1
print(f"{n_components} components explain >= {target_variance:.0%} of variance")

plt.plot(np.arange(1, len(cumulative_variance) + 1), cumulative_variance, marker="o", linestyle="--")
plt.xlabel("Number of Components")
plt.ylabel("Cumulative Explained Variance")
plt.title("Explained Variance vs. Number of Components")
plt.grid()
plt.show()

# Step 4: fit the final PCA with the chosen n_components on train, transform both sets
pca = PCA(n_components=n_components)
pca.fit(X_train_processed)  # fit on train only
X_train_pca = pca.transform(X_train_processed)
X_test_pca = pca.transform(X_test_processed)   # reuse train-fitted pca, never re-fit on test

pc_cols = [f"PC_{i}" for i in range(1, n_components + 1)]
X_train_pca_df = pd.DataFrame(X_train_pca, columns=pc_cols, index=X_train_processed.index)
X_test_pca_df = pd.DataFrame(X_test_pca, columns=pc_cols, index=X_test_processed.index)
```

**Trade-off to mention to the user when choosing between 5a and 5b:** domain-driven feature
creation is interpretable and keeps meaningful names but requires manual expertise and doesn't
scale to many features; PCA is automated and handles many correlated features at once but produces
abstract, uninterpretable components. House style's own worked example fit PCA on the full dataset
(no train/test split, since it was a pure feature-engineering demo) — when you actually build a
model downstream, always switch to the fit-on-train-only pattern in Step 4 above so no test
information leaks into the transformation.
