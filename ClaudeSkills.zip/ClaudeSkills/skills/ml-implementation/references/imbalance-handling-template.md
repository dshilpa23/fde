# Imbalance Handling Template (House Style)

Extracted primarily from `Course 6 - Model Building and Performance Analysis/04_LogisticRegression.py`,
which is the canonical end-to-end house-style pipeline for a binary classification target with
class imbalance. Use this file as the full reference pipeline; use `preprocessing-template.md` for
generic detail on any individual step.

Placeholders used throughout: `df` (working DataFrame), `target_col` (target column name,
originally categorical, encoded to 0/1), `X_train` / `X_test` / `y_train` / `y_test`.

## 0. Imports

```python
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    roc_auc_score,
)
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import RandomUnderSampler
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

warnings.filterwarnings("ignore")
```

## 1. Load, dedupe, target-encode

```python
filepath = "./Data/<your_file>.csv"
df = pd.read_csv(filepath)
print(f"Shape of the dataframe is {df.shape}")

df_without_duplicates = df.drop_duplicates()
print(f"Shape after dropping duplicates is {df_without_duplicates.shape}")

# Encode a binary categorical target to 0/1 (adapt the mapping to your actual class labels)
df_without_duplicates[target_col] = df_without_duplicates[target_col].replace({"Low": 0, "High": 1})
```

## 2. Impute missing values

```python
# Categorical: mode
df_without_nulls = df_without_duplicates.copy()
cat_col = "<categorical_col_with_missing_values>"
df_without_nulls.loc[:, cat_col] = df_without_nulls[cat_col].fillna(df[cat_col].mode()[0])

# Numerical: median
numerical_cols = df_without_nulls.select_dtypes(include=[np.number]).columns
for col in numerical_cols:
    if df_without_nulls[col].isna().sum() > 0:
        df_without_nulls.loc[:, col] = df_without_nulls[col].fillna(df_without_nulls[col].median())

df_without_nulls.isna().sum()  # confirm all zero
```

## 3. IQR outlier capping — SKIP if target is binary

House-style rule: outlier detection/capping is meaningful only for continuous numerical
**features**. If `target_col` is a binary classification target, do not attempt to cap it — a
two-valued column has no "outliers" in the statistical sense. Cap the remaining numerical feature
columns only:

```python
numerical_cols = numerical_cols.tolist()
numerical_cols.remove(target_col)  # never cap the (binary) target

def get_bounds(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    return Q1 - 1.5 * IQR, Q3 + 1.5 * IQR

df_without_outliers = df_without_nulls.copy()
for col in numerical_cols:
    lower_bound, upper_bound = get_bounds(df_without_nulls[col])
    df_without_outliers[col] = df_without_nulls[col].clip(lower=lower_bound, upper=upper_bound)

print(f"Shape after capping outliers: {df_without_outliers.shape}")  # capping doesn't drop rows
```

If the target is **not** binary (e.g. a multi-class or continuous target you've binned), decide
per-dataset whether outlier capping on features still applies — it usually still does for a
linear/logistic model's numeric inputs.

## 4. Separate X/y, train_test_split

```python
X = df_without_outliers.drop(columns=target_col)
y = df_without_outliers[target_col]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1000)
print(f"Train X: {X_train.shape}, Test X: {X_test.shape}")
```

## 5. Encode categoricals — fit on train only, transform both

```python
categorical_cols = X.columns.drop(numerical_cols).tolist()

encoder = OneHotEncoder(
    drop="first",
    handle_unknown="ignore",
    sparse_output=False,  # sparse=False on sklearn < 1.2
    dtype=int,
)
encoder.fit(X_train[categorical_cols])

train_encoded = encoder.transform(X_train[categorical_cols])
encoded_cols = encoder.get_feature_names_out(categorical_cols)
train_encoded_df = pd.DataFrame(train_encoded, columns=encoded_cols, index=X_train.index)

test_encoded = encoder.transform(X_test[categorical_cols])
test_encoded_df = pd.DataFrame(test_encoded, columns=encoded_cols, index=X_test.index)
```

Use `OrdinalEncoder(categories=[[...]])` instead of `OneHotEncoder` only if a categorical feature
has a genuine order (see `preprocessing-template.md` section 2c) — logistic regression's default
here is one-hot for nominal features.

## 6. Standardize numerics — fit on train only, transform both

```python
scaler = StandardScaler()
scaler.fit(X_train[numerical_cols])  # fit on train only

train_scaled = scaler.transform(X_train[numerical_cols])
train_scaled_df = pd.DataFrame(train_scaled, columns=numerical_cols, index=X_train.index)

test_scaled = scaler.transform(X_test[numerical_cols])
test_scaled_df = pd.DataFrame(test_scaled, columns=numerical_cols, index=X_test.index)

X_train_processed = pd.concat([train_scaled_df, train_encoded_df], axis=1)
X_test_processed = pd.concat([test_scaled_df, test_encoded_df], axis=1)
```

## 7. Baseline Logistic Regression

```python
logreg = LogisticRegression()
logreg.fit(X_train_processed, y_train)
```

## 8. Accuracy + the 3%-gap overfitting check

House-style threshold: overfitting is flagged if `abs(train_accuracy - test_accuracy) > 0.03`
(3 percentage points). This exact check is reused verbatim in the tree-ensemble notebooks too —
treat it as the standard house convention for classification overfitting checks.

```python
y_train_pred = logreg.predict(X_train_processed)
y_test_pred = logreg.predict(X_test_processed)

train_accuracy = accuracy_score(y_train, y_train_pred)
test_accuracy = accuracy_score(y_test, y_test_pred)
print(f"Train Accuracy: {train_accuracy:.4f}")
print(f"Test Accuracy: {test_accuracy:.4f}")

if abs(train_accuracy - test_accuracy) > 0.03:
    print("Warning: Potential overfitting detected.")
else:
    print("No significant overfitting detected.")
```

## 9. Confusion matrix — TN/FP/FN/TP-annotated heatmap

This custom annotated-heatmap pattern (not just `ConfusionMatrixDisplay`) is house style for
binary classification and is reused whenever the notebook wants both the raw count and the
TN/FP/FN/TP label in each cell:

```python
cm = confusion_matrix(y_test, y_test_pred)
print("Confusion Matrix:\n", cm)

plt.figure(figsize=(3, 3))
plt.imshow(cm, cmap="Blues")
plt.title("Confusion Matrix")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")

labels = np.array([["TN", "FP"], ["FN", "TP"]])
for i in range(2):
    for j in range(2):
        plt.text(j, i, f"{labels[i, j]}\n{cm[i, j]}", ha="center", va="center", color="red", fontsize=12)

plt.xticks([0, 1], ["<class_0_name>", "<class_1_name>"])
plt.yticks([0, 1], ["<class_0_name>", "<class_1_name>"])
plt.tight_layout()
plt.show()
```

## 10. Classification report

```python
report = classification_report(y_test, y_test_pred, target_names=["<class_0_name>", "<class_1_name>"])
print(report)
```

## 11. ROC curve and AUC

```python
y_test_proba = logreg.predict_proba(X_test_processed)[:, 1]

fpr, tpr, _ = roc_curve(y_test, y_test_proba)
auc_score = roc_auc_score(y_test, y_test_proba)

plt.figure(figsize=(7, 5))
plt.plot(fpr, tpr, label=f"AUC = {auc_score:.2f}")
plt.plot([0, 1], [0, 1], "k--")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend(loc="lower right")
plt.grid()
plt.show()
print("AUC Score:", auc_score)
```

At this point, if the classification report shows materially lower recall on the minority class,
proceed to imbalance remediation below.

## 12. Remediation 1 — `class_weight='balanced'` retrain

Cheapest fix: no resampling, just reweight the loss so the minority class counts more.

```python
logreg_balanced = LogisticRegression(max_iter=1000, class_weight="balanced")
logreg_balanced.fit(X_train_processed, y_train)

y_test_pred_balanced = logreg_balanced.predict(X_test_processed)
print(classification_report(y_test, y_test_pred_balanced, target_names=["<class_0_name>", "<class_1_name>"]))
```

Expected trade-off pattern (seen consistently in house-style runs): minority-class recall goes up,
minority-class precision goes down. `class_weight` options: `None` (default), `'balanced'` (auto
inverse-frequency), or an explicit dict like `{0: 1, 1: 3}` to manually weight classes.

## 13. Remediation 2, 3, 4 — resampling comparison (RandomOverSampler, RandomUnderSampler, SMOTE)

Resample the **training data only** (never the test set) after preprocessing, then retrain a
fresh baseline `LogisticRegression()` on each variant:

```python
ros = RandomOverSampler()
X_train_ups, y_train_ups = ros.fit_resample(X_train_processed, y_train)

rus = RandomUnderSampler()
X_train_downs, y_train_downs = rus.fit_resample(X_train_processed, y_train)

smote = SMOTE(sampling_strategy=0.85)  # tune sampling_strategy; 1.0 = fully balanced
X_train_smote, y_train_smote = smote.fit_resample(X_train_processed, y_train)
```

### Visualize class counts before/after each resampling method

```python
orig_counts = y_train.value_counts().sort_index()
ups_counts = y_train_ups.value_counts().sort_index()
downs_counts = y_train_downs.value_counts().sort_index()
smote_counts = y_train_smote.value_counts().sort_index()
class_labels = ["0 - <class_0_name>", "1 - <class_1_name>"]

fig, axes = plt.subplots(1, 4, figsize=(18, 5), sharey=True)
for ax, counts, title in zip(
    axes,
    [orig_counts, ups_counts, downs_counts, smote_counts],
    ["Original", "After Up-sampling", "After Down-sampling", "After Smote-sampling"],
):
    bars = ax.bar(class_labels, counts, color=["skyblue", "orange"])
    ax.set_title(title)
    ax.set_xlabel("Class")
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 10, str(count), ha="center", va="bottom")
axes[0].set_ylabel("Count")
plt.suptitle("Class Distributions: Original vs Upsampling vs Downsampling vs SMOTE", fontsize=16)
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()
```

### Train + evaluate all 4 variants side by side (confusion matrices + classification reports)

```python
class_names = ["0 - <class_0_name>", "1 - <class_1_name>"]
cm_labels = [["TN", "FP"], ["FN", "TP"]]

def plot_conf_matrix(ax, y_true, y_pred, title):
    cm = confusion_matrix(y_true, y_pred)
    sns.heatmap(cm, annot=False, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=class_names, yticklabels=class_names)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j + 0.5, i + 0.5, f"{cm[i, j]}\n({cm_labels[i][j]})",
                     ha="center", va="center", color="red", fontsize=14, fontweight="bold")
    ax.set_title(title, fontsize=14)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")

def train_predict(X_tr, y_tr):
    clf = LogisticRegression()
    clf.fit(X_tr, y_tr)
    return clf.predict(X_test_processed)

y_pred_orig = train_predict(X_train_processed, y_train)
y_pred_ups = train_predict(X_train_ups, y_train_ups)
y_pred_downs = train_predict(X_train_downs, y_train_downs)
y_pred_smote = train_predict(X_train_smote, y_train_smote)

fig, axes = plt.subplots(1, 4, figsize=(20, 5))
plot_conf_matrix(axes[0], y_test, y_pred_orig, "Original - Confusion Matrix")
plot_conf_matrix(axes[1], y_test, y_pred_ups, "Up-sampled - Confusion Matrix")
plot_conf_matrix(axes[2], y_test, y_pred_downs, "Down-sampled - Confusion Matrix")
plot_conf_matrix(axes[3], y_test, y_pred_smote, "Smote-sampled - Confusion Matrix")
plt.suptitle("Model Evaluation: Original vs Up-sampled vs Down-sampled vs Smote-sampled", fontsize=18, y=0.95)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

def print_classification_reports(y_true, y_preds, method_names):
    for y_pred, name in zip(y_preds, method_names):
        print(f"\n=== {name} ===")
        print(classification_report(y_true, y_pred))

print_classification_reports(
    y_test,
    [y_pred_orig, y_pred_ups, y_pred_downs, y_pred_smote],
    ["Original (Imbalanced)", "RandomOverSampler (Upsampling)", "RandomUnderSampler (Downsampling)", "SMOTE"],
)
```

## 14. Choosing among the remediation options

House-style conclusion pattern to reproduce in the notebook's own "Observation" cell: all three
resampling techniques (and `class_weight='balanced'`) substantially raise minority-class recall
versus the imbalanced baseline, at the cost of minority-class precision (more false positives).
SMOTE tends to land with the best precision/recall balance among the three resampling methods
because it synthesizes new minority examples via interpolation rather than duplicating existing
ones (upsampling) or discarding majority data (downsampling). Final choice should be framed as a
business trade-off: prioritize recall (catch more of the minority class, accept more false
positives) vs. precision (fewer false alarms, accept missing more minority cases), not a pure
"which number is highest" comparison.
