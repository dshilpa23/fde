#!/usr/bin/env python3
"""Parse the ml_architecture_decision.md artifact produced by the independent
ml-architecture-decision skill, into normalized JSON for the ml-implementation
skill to drive its control flow (which template to load, which sampling
strategy, which metrics) — the implementation skill should never hand-parse
the YAML itself.

Usage:
    parse_decision_file.py [path]   (defaults to ./ml_architecture_decision.md)

Exits 1 with a clear "not found" message if the file is absent — this is the
implementation skill's trigger to ask about running the decision skill first
instead of inventing an architecture.
"""
import json
import re
import sys


def _split_top_commas(s: str) -> list:
    parts, depth, current, in_quote = [], 0, "", None
    for ch in s:
        if in_quote:
            current += ch
            if ch == in_quote:
                in_quote = None
            continue
        if ch in "\"'":
            in_quote = ch
            current += ch
        elif ch in "[{":
            depth += 1
            current += ch
        elif ch in "]}":
            depth -= 1
            current += ch
        elif ch == "," and depth == 0:
            parts.append(current)
            current = ""
        else:
            current += ch
    if current.strip():
        parts.append(current)
    return [p.strip() for p in parts if p.strip()]


def _parse_scalar(s: str):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        return s[1:-1]
    if s in ("null", "~", ""):
        return None
    if s in ("true", "True"):
        return True
    if s in ("false", "False"):
        return False
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        pass
    return s


def _parse_flow(s: str):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        if not inner:
            return []
        return [_parse_flow(p) if p.strip()[:1] in "[{" else _parse_scalar(p) for p in _split_top_commas(inner)]
    if s.startswith("{") and s.endswith("}"):
        inner = s[1:-1].strip()
        result = {}
        if not inner:
            return result
        for part in _split_top_commas(inner):
            if ":" not in part:
                continue
            k, v = part.split(":", 1)
            result[_parse_scalar(k)] = _parse_flow(v) if v.strip()[:1] in "[{" else _parse_scalar(v)
        return result
    return _parse_scalar(s)


def parse_frontmatter(text: str) -> dict:
    """Minimal YAML-subset parser for this fixed contract (not general YAML)."""
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except ImportError:
        pass

    lines = text.splitlines()
    root: dict = {}
    stack = [(root, -1)]

    for raw in lines:
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        content = raw.strip()

        while len(stack) > 1 and indent <= stack[-1][1]:
            stack.pop()
        container, _ = stack[-1]

        if content.startswith("- "):
            value = content[2:].strip()
            parsed = _parse_flow(value) if value[:1] in "[{" else _parse_scalar(value)
            if isinstance(container, list):
                container.append(parsed)
            continue

        if ":" not in content:
            continue
        key, _, value = content.partition(":")
        key = key.strip().strip("\"'")
        value = value.strip()

        if value == "":
            new_container: dict = {}
            if isinstance(container, dict):
                container[key] = new_container
            stack.append((new_container, indent))
        else:
            parsed = _parse_flow(value) if value[:1] in "[{" else _parse_scalar(value)
            if isinstance(container, dict):
                container[key] = parsed

    return root


def extract_body(md_text: str) -> str:
    match = re.match(r"^---\s*\n.*?\n---\s*\n(.*)$", md_text, re.DOTALL)
    return match.group(1).strip() if match else ""


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else "./ml_architecture_decision.md"
    try:
        with open(path, "r") as f:
            text = f.read()
    except FileNotFoundError:
        print(json.dumps({
            "found": False,
            "message": (
                f"No decision file found at {path}. Run the ml-architecture-decision "
                "skill first, or confirm with the user before assuming an approach."
            ),
        }))
        return 1

    match = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    if not match:
        print(json.dumps({"found": True, "valid": False, "error": "no YAML frontmatter block found"}))
        return 1

    data = parse_frontmatter(match.group(1))
    data["_found"] = True
    data["_body_excerpt"] = extract_body(text)[:2000]
    print(json.dumps(data, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
