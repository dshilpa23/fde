#!/usr/bin/env python3
"""Compute real evaluation metrics in this codebase's house style, so the
implementation skill pastes actual numbers into notebook Observation cells
instead of inventing them.

Usage (classification):
    eval_report.py --problem_type classification \\
        --y_train_true train_true.csv --y_train_pred train_pred.csv \\
        --y_test_true test_true.csv --y_test_pred test_pred.csv

Usage (regression):
    eval_report.py --problem_type regression \\
        --y_train_true train_true.csv --y_train_pred train_pred.csv \\
        --y_test_true test_true.csv --y_test_pred test_pred.csv

Each file is a single-column CSV (header optional) of true/predicted values,
aligned by row order. Prints a formatted text block matching the notebooks'
own style (e.g. "Train Accuracy: 0.9487" / "Warning: Potential overfitting
detected.") plus a JSON summary.
"""
import argparse
import json
import sys

import numpy as np


def _load_column(path: str) -> np.ndarray:
    with open(path, "r") as f:
        lines = [line.strip() for line in f if line.strip()]
    values = []
    for line in lines:
        cell = line.split(",")[0]
        try:
            values.append(float(cell))
        except ValueError:
            continue  # header row
    return np.array(values)


def classification_report_block(y_train_true, y_train_pred, y_test_true, y_test_pred) -> dict:
    from sklearn.metrics import (
        accuracy_score,
        confusion_matrix,
        f1_score,
        precision_score,
        recall_score,
        roc_auc_score,
    )

    train_acc = accuracy_score(y_train_true, y_train_pred)
    test_acc = accuracy_score(y_test_true, y_test_pred)
    gap_pct = round(abs(train_acc - test_acc) * 100, 2)
    overfitting = gap_pct > 3.0

    cm = confusion_matrix(y_test_true, y_test_pred)

    summary = {
        "train_accuracy": round(float(train_acc), 4),
        "test_accuracy": round(float(test_acc), 4),
        "train_test_gap_pct": gap_pct,
        "overfitting_flag": overfitting,
        "precision": round(float(precision_score(y_test_true, y_test_pred, average="macro", zero_division=0)), 4),
        "recall": round(float(recall_score(y_test_true, y_test_pred, average="macro", zero_division=0)), 4),
        "f1": round(float(f1_score(y_test_true, y_test_pred, average="macro", zero_division=0)), 4),
        "confusion_matrix": cm.tolist(),
    }
    try:
        summary["roc_auc"] = round(float(roc_auc_score(y_test_true, y_test_pred)), 4)
    except ValueError:
        summary["roc_auc"] = None

    print(f"Train Accuracy: {summary['train_accuracy']:.4f}")
    print(f"Test Accuracy:  {summary['test_accuracy']:.4f}")
    print(f"Train/Test Gap: {gap_pct:.2f}%")
    if overfitting:
        print("Warning: Potential overfitting detected (gap > 3%).")
    else:
        print("Train/test gap within the 3% threshold — no overfitting flag.")
    print(f"Precision (macro): {summary['precision']:.4f}")
    print(f"Recall (macro):    {summary['recall']:.4f}")
    print(f"F1 (macro):        {summary['f1']:.4f}")
    if summary["roc_auc"] is not None:
        print(f"ROC-AUC:           {summary['roc_auc']:.4f}")
    print(f"Confusion Matrix:\n{cm}")
    return summary


def regression_report_block(y_train_true, y_train_pred, y_test_true, y_test_pred) -> dict:
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

    def block(y_true, y_pred):
        mae = mean_absolute_error(y_true, y_pred)
        mse = mean_squared_error(y_true, y_pred)
        rmse = float(np.sqrt(mse))
        r2 = r2_score(y_true, y_pred)
        return {"mae": round(float(mae), 4), "mse": round(float(mse), 4), "rmse": round(rmse, 4), "r2": round(float(r2), 4)}

    train_block = block(y_train_true, y_train_pred)
    test_block = block(y_test_true, y_test_pred)
    r2_gap_pct = round(abs(train_block["r2"] - test_block["r2"]) * 100, 2)
    overfitting = r2_gap_pct > 3.0

    summary = {"train": train_block, "test": test_block, "r2_gap_pct": r2_gap_pct, "overfitting_flag": overfitting}

    print(f"Train -> MAE: {train_block['mae']:.4f}  MSE: {train_block['mse']:.4f}  RMSE: {train_block['rmse']:.4f}  R2: {train_block['r2']:.4f}")
    print(f"Test  -> MAE: {test_block['mae']:.4f}  MSE: {test_block['mse']:.4f}  RMSE: {test_block['rmse']:.4f}  R2: {test_block['r2']:.4f}")
    print(f"Train/Test R2 Gap: {r2_gap_pct:.2f}%")
    if overfitting:
        print("Warning: Potential overfitting detected (R2 gap > 3%).")
    else:
        print("Train/test R2 gap within the 3% threshold — no overfitting flag.")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--problem_type", required=True, choices=["classification", "regression"])
    parser.add_argument("--y_train_true", required=True)
    parser.add_argument("--y_train_pred", required=True)
    parser.add_argument("--y_test_true", required=True)
    parser.add_argument("--y_test_pred", required=True)
    args = parser.parse_args()

    y_train_true = _load_column(args.y_train_true)
    y_train_pred = _load_column(args.y_train_pred)
    y_test_true = _load_column(args.y_test_true)
    y_test_pred = _load_column(args.y_test_pred)

    if args.problem_type == "classification":
        summary = classification_report_block(y_train_true, y_train_pred, y_test_true, y_test_pred)
    else:
        summary = regression_report_block(y_train_true, y_train_pred, y_test_true, y_test_pred)

    print("\n--- JSON summary ---")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
