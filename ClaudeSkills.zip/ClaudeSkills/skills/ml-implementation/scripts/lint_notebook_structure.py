#!/usr/bin/env python3
"""Check a generated Databricks-notebook-source .py file for house-style
structural conformance before the ml-implementation skill declares a
notebook done.

Usage:
    lint_notebook_structure.py <output.py>

Exits 1 and prints one violation per line if anything fails; exits 0 with
"OK" otherwise. No ML libraries required — pure text/structure checks.
"""
import os
import re
import sys


def lint(path: str) -> list:
    violations = []
    if not os.path.exists(path):
        return [f"file not found: {path}"]

    with open(path, "r") as f:
        text = f.read()
    lines = text.splitlines()

    if not lines or lines[0].strip() != "# Databricks notebook source":
        violations.append("first line must be exactly '# Databricks notebook source'")

    if "# COMMAND ----------" not in text:
        violations.append("missing '# COMMAND ----------' cell separators")

    run_setup_matches = re.findall(r"^\s*#?\s*MAGIC\s+%run\s+(\S+)", text, re.MULTILINE) + \
        re.findall(r"^\s*%run\s+(\S+)", text, re.MULTILINE)
    for setup_path in run_setup_matches:
        resolved = os.path.join(os.path.dirname(os.path.abspath(path)), setup_path.lstrip("./"))
        if not os.path.exists(resolved):
            violations.append(
                f"references '%run {setup_path}' but that file does not exist relative to the "
                f"notebook — never fabricate a setup path; omit the %run line if there is no "
                f"real .setup/learner_setup.py alongside this notebook"
            )

    if re.search(r"\bspark\.read\b", text):
        violations.append("uses spark.read — this codebase's house style loads data via pd.read_csv, not Spark I/O")
    if re.search(r"\bmlflow\.", text):
        violations.append("uses mlflow.* — this codebase's notebooks do not use MLflow tracking/logging")

    for match in re.finditer(r"train_test_split\(([^)]*)\)", text):
        if "random_state" not in match.group(1):
            violations.append("train_test_split(...) call is missing random_state= (leakage/reproducibility convention)")

    fit_on_non_train = re.findall(r"\b(\w+)\.fit\(([^)]*)\)", text)
    for method_owner, args in fit_on_non_train:
        first_arg = args.split(",")[0].strip()
        if first_arg and re.match(r"^(scaler|encoder|.*Encoder|.*Scaler|pca|PCA)$", method_owner, re.IGNORECASE):
            if first_arg not in ("X_train", "x_train") and not first_arg.startswith("X_train"):
                violations.append(
                    f"'{method_owner}.fit({first_arg}, ...)' — encoders/scalers must be fit on the "
                    f"train split only (expected an X_train-named argument), got '{first_arg}'"
                )

    return violations


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: lint_notebook_structure.py <output.py>")
        return 1
    violations = lint(sys.argv[1])
    if violations:
        print(f"FAILED — {len(violations)} violation(s):")
        for v in violations:
            print(f"  - {v}")
        return 1
    print("OK — no structural violations found.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
