---
name: ml-implementation
description: >
  Scaffolds a Databricks-notebook-source .py file (NOT a plain .ipynb) implementing the recommended
  approach from an ./ml_architecture_decision.md artifact, following this codebase's exact house-
  style pipeline: dedupe/impute/IQR-cap, 80/20 train_test_split with fixed random_state, encoders/
  scalers fit-on-train-only, baseline model -> GridSearchCV/RandomizedSearchCV tuning, Observation/
  Conclusion markdown cells, and a model-progression comparison table. Use whenever the user says
  "implement this", "build the model", "write the notebook", "scaffold the pipeline", "code up the
  approach", or references a decision file/architecture doc. Looks for ./ml_architecture_decision.md
  by convention; if absent, says so and asks whether to run the ml-architecture-decision skill first
  rather than guessing an approach. Reuses canonical code patterns from this repo's own notebooks
  (imbalance handling a la Course 6 04_LogisticRegression.py; tree/ensemble progression a la Course 7
  01-07) — never generic sklearn boilerplate. Only switch to a plain script/notebook if the user says
  they are not working in Databricks.
---

# ML Implementation

Reads `./ml_architecture_decision.md` (written independently by the `ml-architecture-decision`
skill — no shared code, only this filename convention) and scaffolds real, runnable code that
matches this codebase's house style, not generic sklearn boilerplate.

## Reference map — load only what the current step needs

| Need | Load |
|---|---|
| Notebook structural conventions (header, cell separators, %run bootstrap, Capstone submission) | `references/databricks-notebook-conventions.md` |
| Imputation, encoding, log-transform, PCA, IQR outlier capping | `references/preprocessing-template.md` |
| Full imbalance-handling pipeline (LogisticRegression baseline through SMOTE comparison) | `references/imbalance-handling-template.md` |
| Decision Tree / Bagging / RF / AdaBoost / GB / XGBoost — params, tuning, optional Spark parallel tuning | `references/tree-ensemble-progression-template.md` |
| Linear/Ridge/Lasso/statsmodels OLS, Decision Tree Regressor, MAE/MSE/RMSE/R² | `references/regression-model-template.md` |
| Notebook scaffold to start from | `assets/notebook_skeleton.py.txt` |

## Workflow

**Step 1 — Preconditions.**
Look for `./ml_architecture_decision.md`. Run:
```
python3 scripts/parse_decision_file.py ./ml_architecture_decision.md
```
If it reports `"found": false`, stop and offer to run the `ml-architecture-decision` skill first —
never invent an architecture from scratch. Use the parsed JSON for all control flow below; never
hand-parse the YAML frontmatter yourself.

**Step 2 — Pick templates from the parsed decision.**
- `problem_type: classification` + `imbalance_handling` != `none` → `references/imbalance-handling-template.md` as the primary spine.
- `problem_type: classification` + `imbalance_handling: none` → `references/tree-ensemble-progression-template.md` (skip the imbalance-remediation sections of the imbalance template, still useful for its baseline/eval blocks).
- `problem_type: regression` → `references/regression-model-template.md` for the baseline/linear family, then `references/tree-ensemble-progression-template.md` for the tree/ensemble regressors in `model_family.progression`.
- Always load `references/preprocessing-template.md` for the imputation/encoding/scaling/outlier steps dictated by the decision's `preprocessing` block.

**Step 3 — House-style structural contract.**
Follow `references/databricks-notebook-conventions.md` exactly:
- First line `# Databricks notebook source`.
- `# COMMAND ----------` between cells, `# MAGIC %md` for markdown cells, optional `# DBTITLE 1,<title>`.
- Only include `%run ./.setup/learner_setup` if `.setup/learner_setup.py` actually exists next to the
  output path — check with `ls` first. Never fabricate a Volumes requirements path.
- `import warnings; warnings.filterwarnings("ignore")` plus the standard import block.
- If the user says they are not working in Databricks: drop the `%run`/`# COMMAND` conventions,
  emit a plain script instead, and say explicitly that this is a deliberate deviation.

**Step 4 — Write the pipeline in house order**, driven by the parsed decision fields:
1. Imports, `pd.read_csv(source_dataset)`, `.head()/.shape/.info()`.
2. `drop_duplicates()`.
3. Impute per `preprocessing.imputation` (mode/median), from `preprocessing-template.md`.
4. IQR outlier capping per `preprocessing.outlier_treatment` — skip entirely if it's `skip_binary_target`.
5. Split X/y, `train_test_split(test_size=0.2, random_state=<fixed>)`.
6. Fit encoders/scalers on the train split only (per `preprocessing.encoding`/`preprocessing.scaling`), transform both — never fit on the full dataset or on test.
7. Baseline model = `model_family.baseline`, evaluate.
8. If classification and `imbalance_handling` != `none`: run the matching remediation block from `imbalance-handling-template.md`, compare against baseline.
9. Progress through `model_family.progression` using the matching template, tuning via `GridSearchCV`/`RandomizedSearchCV` with the param grids documented per model family (don't invent grids that were never used in this codebase).
10. Final comparison table across the progression + `# MAGIC %md` Observation/Conclusion cells, incorporating the decision file's Markdown body (`model_family.reasoning_summary`, risks/open items) as narrative context.

**Step 5 — Never fabricate metrics.**
After each modeling cell, actually run the equivalent code (or feed real predictions through):
```
python3 scripts/eval_report.py --problem_type <classification|regression> \
    --y_train_true ... --y_train_pred ... --y_test_true ... --y_test_pred ...
```
and paste the real numbers into the Observation cells — matching the notebooks' own habit of citing
exact figures. Apply the same train-vs-test gap threshold (>3%) the decision file specified.

**Step 6 — PySpark is optional, not default.**
Only introduce the `pandas_udf`-based parallel hyperparameter search (Bagging/RF/GB only — see
`tree-ensemble-progression-template.md` §8) if the user explicitly asks for cluster-parallel tuning.
Default to plain `GridSearchCV`/`RandomizedSearchCV`.

**Step 7 — Final QA.**
```
python3 scripts/lint_notebook_structure.py <output.py>
```
Fix any reported violation (missing header/separators, stray `spark.read`/`mlflow` calls, missing
`random_state=`, encoder/scaler fit on a non-train-named variable) before declaring the notebook done.

**Step 8 — Open items to surface, not build around.**
If the target repo or a decision-file open item references an internal serving library (e.g. the
`unitedai.models.UaisModel` stub with no real usage example anywhere in this codebase), tell the user
there's no working pattern to template from and default to sklearn/XGBoost rather than guessing an API.

**Step 9 — Capstone deliverables.**
Only if the user says "capstone": follow the two-CSV submission convention in
`databricks-notebook-conventions.md` — `regression_submission.csv` or `classification_submission.csv`
(whichever matches `problem_type`), each a single `y_pred` column, alongside a `code.ipynb`/`.py` file.
