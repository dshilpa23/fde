# Prompt 06 - Build the Human Review Router (Task 5)

## Read before generating any code
- specs/architecture.md (routing matrix section)
- src/coc_filing_assistant/domain.py (HandoffPackage, RuleEngineOutput, RiskScore)
- tests/test_router.py

## Implement
File: src/coc_filing_assistant/router.py
Function: route(package: HandoffPackage) -> str

## Routing logic (implement in priority order)
1. PIPELINE_ERROR status          -> "OPERATIONS" (always)
2. PRIOR_AUTH rule category HIGH  -> "LEGAL"
3. PHARMACY rule category         -> "PHARMACY"
4. EXCLUSION rule category        -> "LEGAL"
5. NETWORK rule category          -> "NETWORK"
6. MISSING_INFO rule category     -> "OPERATIONS"
7. ML risk_tier == HIGH           -> "ACTUARIAL"
8. RAG confidence < 0.60          -> "OPERATIONS"
9. Default NEEDS_REVIEW           -> "OPERATIONS"
10. HANDOFF_READY with no flags   -> "LEGAL" or "ACTUARIAL" based on risk tier

## Rules
- Return exactly one of: "LEGAL" | "PHARMACY" | "ACTUARIAL" | "NETWORK" | "OPERATIONS"
- Must be deterministic: same input always returns same queue
- No LLM calls. No database reads.

## Verification command
python -m pytest tests/test_router.py -v
