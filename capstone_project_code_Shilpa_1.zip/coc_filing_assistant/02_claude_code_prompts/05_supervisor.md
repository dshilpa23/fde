# Prompt 05 - Build the Supervisor Orchestrator (Task 4)

## Read before generating any code
- specs/architecture.md (especially the status transition rules)
- specs/safety_spec.md
- .claude/rules/safety_rules.md
- src/coc_filing_assistant/domain.py (AgentEvent, HandoffPackage, all error types)
- tests/test_supervisor.py

## Implement
File: src/coc_filing_assistant/supervisor.py
Function: run_pipeline(item: COCFilingItem) -> tuple[HandoffPackage, list[AgentEvent]]

## Call order (all 4 must run)
1. rule_engine.run_checks(item)                          -> RuleEngineOutput
2. ml_service.score_risk(item, rule_output)              -> RiskScore
3. rag_service.retrieve(item, rule_output)               -> list[EvidenceChunk]
4. rag_service.draft_summary(item, rule_output, risk, chunks) -> tuple[FilingSummary, ReviewResult]

## Status transitions
- APPROVE + all complete   -> HANDOFF_READY
- FLAG_FOR_HUMAN + complete -> NEEDS_REVIEW
- Any exception             -> PIPELINE_ERROR (catch, do not crash)

## AgentEvent format per call
- agent_name: "RuleEngine" | "MLService" | "RAGRetrieve" | "RAGDraft"
- input_hash: hashlib.sha256(item.filing_id.encode()).hexdigest()[:16]
- output_summary: max 200 chars, no PII, no full text
- status: "SUCCESS" or "FAILURE"

## Critical rules
- Do not short-circuit. All 4 calls must be attempted.
- Never set HANDOFF_READY if any AgentEvent.status == "FAILURE"
- HandoffPackage.review_queue must be None here (router sets it)

## Verification command
python -m pytest tests/test_supervisor.py -v
