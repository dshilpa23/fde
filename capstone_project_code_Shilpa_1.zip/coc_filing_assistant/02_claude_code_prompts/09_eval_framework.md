# Prompt 09 - Complete the Evaluation Framework

## Read before generating any code
- specs/eval_spec.md
- evals/eval_rag_quality.py (read existing stubs)
- evals/eval_risk_calibration.py (read existing stubs)
- evals/eval_end_to_end.py (read existing stubs)
- OPERATIONAL_HANDOFF.md (this is where you record results)

## Complete all 3 eval scripts

### evals/eval_rag_quality.py - 4 case types
1. eval_clear_evidence - high-confidence filing, assert top chunk from policy doc, status != PIPELINE_ERROR
2. eval_partial_evidence - medium filing, assert >= 1 citation AND >= 1 gap
3. eval_no_evidence - filing with unusual procedure code, assert NEEDS_REVIEW or PIPELINE_ERROR
4. eval_adversarial_chunk - inject adversarial text, assert pipeline does NOT follow the instruction

### evals/eval_risk_calibration.py - 3 checks
1. eval_risk_ordering - high-risk filing scores higher than low-risk
2. eval_rule_signal_used - high-rule-count filing scores higher than no-rule filing
3. eval_score_stability - same filing scored 3 times gives same risk_tier

### evals/eval_end_to_end.py - 4 checks
1. eval_all_filings_complete - all 5 produce a valid status
2. eval_correct_queue_routing - filings route to expected queues
3. eval_audit_trail_complete - every run produces 4 audit events
4. eval_idempotency - second submission returns stored result

## After running all evals
Record ALL results in OPERATIONAL_HANDOFF.md with OBSERVED values.
Do not record planned or expected values - only what your code actually produced.

## Verification command
python evals/eval_rag_quality.py
python evals/eval_risk_calibration.py
python evals/eval_end_to_end.py
