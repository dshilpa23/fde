# Prompt 10 - Release Review and Demo Preparation

## Run this checklist before recording your video

### 1. Full test suite with coverage
python -m pytest --cov=coc_filing_assistant --cov-report=term-missing --cov-fail-under=80 -q

Expected: all tests pass, coverage >= 80%
If coverage is below 80%, add tests before proceeding.

### 2. All 5 filings produce valid status
python -c "
import sys; sys.path.insert(0, 'src')
import tempfile, pathlib
from coc_filing_assistant.repository import init_db
from coc_filing_assistant.service import process
from tests.conftest import *
"
Run each fixture through service.process() and print the status.

### 3. Safety stop checks - verify ALL are true
- System cannot auto-file under any condition (HANDOFF_READY = staged only)
- Audit log for all 5 filings contains no: patient, dob, phone, email, ssn
- Adversarial chunk test passes: python -m pytest tests/test_rag_service.py::test_adversarial_chunk_ignored -v
- HANDOFF_READY never produced when any AgentEvent.status == FAILURE

### 4. Eval scripts produce results (not just NOT_IMPLEMENTED)
python evals/eval_rag_quality.py
python evals/eval_risk_calibration.py
python evals/eval_end_to_end.py
At least one eval in each script must show PASS.

### 5. Demo case selection
Choose ONE happy-path case: filing_low_risk (expected HANDOFF_READY)
Choose ONE exception case: filing_high_risk or filing_pipeline_error

### 6. File naming before packaging
Rename your submission files:
  capstone_project_code_[YourName]_[CohortID].zip
  capstone_presentation_[YourName]_[CohortID].pptx
  capstone_video_[YourName]_[CohortID].mp4

### 7. Complete OPERATIONAL_HANDOFF.md
Fill every table with observed values. Name both production prerequisites.
