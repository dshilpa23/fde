# Prompt 02 - Build the Rule Engine (Task 1)

## Read before generating any code
- specs/rule_engine_spec.md
- .claude/rules/safety_rules.md
- .claude/rules/testing_rules.md
- src/coc_filing_assistant/domain.py (COCFilingItem, RuleCheckResult, RuleEngineOutput)
- tests/test_rule_engine.py

## Implement
File: src/coc_filing_assistant/rule_engine.py
Function: run_checks(item: COCFilingItem) -> RuleEngineOutput

## Requirements from spec
- Minimum 8 rules across 4 categories: MISSING_INFO, PRIOR_AUTH, PHARMACY, EXCLUSION
- Each rule returns a RuleCheckResult with: rule_id, category, severity, description, filing_section, evidence
- overall_flag = FLAG if any HIGH or MEDIUM rule fired, else PASS
- No LLM calls. No database reads. Deterministic only.
- Raise RuleEngineError (not generic Exception) on unexpected failure

## Verification command
python -m pytest tests/test_rule_engine.py -v

## Do not
- Call any LLM
- Import from rag_service or ml_service
- Use random or non-deterministic logic
- Proceed without reading rule_engine_spec.md first
