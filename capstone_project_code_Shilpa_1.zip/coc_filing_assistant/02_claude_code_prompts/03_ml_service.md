# Prompt 03 - Build the ML Risk Service (Task 2)

## Read before generating any code
- specs/ml_service_spec.md (your documented risk-scoring approach)
- .claude/rules/safety_rules.md
- src/coc_filing_assistant/domain.py (COCFilingItem, RuleEngineOutput, RiskScore)
- tests/test_ml_service.py

## Implement
File: src/coc_filing_assistant/ml_service.py
Function: score_risk(item: COCFilingItem, rule_output: RuleEngineOutput) -> RiskScore

## Approved scoring approach
- Use the reproducible scoring approach defined in your specification
- Extract features from both COCFilingItem and RuleEngineOutput
- Predict sla_delay_probability, escalation_probability, review_effort_score
- Compute composite_risk with documented weights

## Feature-weighted scorer
- Define numeric features from rule counts and filing fields
- Apply documented weights (must be in ml_service_spec.md)
- Composite_risk = sla_delay*0.4 + escalation*0.4 + review_effort*0.2

## Risk tier thresholds (same for both options)
- composite_risk >= 0.65 -> HIGH
- composite_risk >= 0.35 -> MEDIUM
- composite_risk < 0.35  -> LOW

## Verification command
python -m pytest tests/test_ml_service.py -v

## Do not
- Use rule severity as a direct pass-through to risk tier
- Return non-deterministic results
- Raise generic Exception (use MLServiceError)
