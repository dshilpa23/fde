# Prompt 07 - Build Persistence and Audit Log (Task 6)

## Read before generating any code
- specs/safety_spec.md (PII prohibition is critical)
- .claude/rules/safety_rules.md
- src/coc_filing_assistant/repository.py (read the provided functions first)
- tests/test_repository_audit.py

## Note: audit.py does not exist - it is merged into repository.py

## Implement
File: src/coc_filing_assistant/repository.py
Function: save_package(package: HandoffPackage, agent_events: list[AgentEvent], db_path) -> None

## Requirements
1. INSERT one row into coc_filings for the HandoffPackage
2. INSERT one row into agent_audit_events per AgentEvent
3. INSERT one row into review_queue if package.review_queue is not None
4. ALL inserts must happen in a SINGLE transaction - roll back if any fails
5. Strip PII: output_summary must NEVER contain patient name, DOB, phone, email, or full text
6. Truncate output_summary to maximum 200 characters
7. Do not store filing_summary text or rule_output text - store scalar metadata only

## PII check before every audit event write
- output_summary.lower() must not contain: "patient", "dob", "date_of_birth", "ssn", "phone", "email"
- If found: truncate or replace with "[REDACTED]" before inserting

## Verification command
python -m pytest tests/test_repository_audit.py -v
