# Prompt 01 - Scout the Repository

## Your task
Read and understand the codebase. Do NOT write any code.

## Read these files in order
1. CLAUDE.md (your project context)
2. specs/architecture.md
3. src/coc_filing_assistant/domain.py (read every typed object carefully)
4. specs/rule_engine_spec.md
5. specs/ml_service_spec.md
6. specs/rag_spec.md
7. specs/safety_spec.md
8. .claude/rules/safety_rules.md

## Read 2 sample filings
- data/coc_filings/sample_filings.json (read at least the HIGH and LOW risk items)

## Produce (in your response, no code files)
1. A one-paragraph system summary in your own words
2. A numbered implementation order for Tasks 1-7 with rationale
3. The top 3 risks you see in the implementation
4. Any spec ambiguities that need clarification before you start coding

## Do not
- Modify any file
- Write any implementation code
- Skip domain.py or safety_rules.md
