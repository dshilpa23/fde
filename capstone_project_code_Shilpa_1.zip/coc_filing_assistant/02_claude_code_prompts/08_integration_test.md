# Prompt 08 - Write Integration Tests

## Read before generating any code
- tests/conftest.py (5 synthetic filing fixtures)
- src/coc_filing_assistant/service.py (idempotency gate)
- specs/eval_spec.md

## Write tests in
File: tests/test_integration.py

## Required test cases (minimum 4)
1. test_all_five_filings_produce_status
   - Run service.process() on all 5 synthetic filings
   - Assert each returns HANDOFF_READY, NEEDS_REVIEW, or PIPELINE_ERROR
   - None may raise an unhandled exception

2. test_idempotent_replay
   - Submit filing_idempotency twice via service.process()
   - Assert second result has idempotent_replay=True
   - Assert audit event count does not increase on second call

3. test_audit_trail_covers_all_agents
   - Run one filing through the full pipeline
   - Assert get_audit_events() returns events for: RuleEngine, MLService, RAGRetrieve, RAGDraft

4. test_handoff_ready_never_set_on_error
   - Submit filing_pipeline_error
   - If any agent event has status=FAILURE, assert package.status != HANDOFF_READY

## Verification command
python -m pytest tests/test_integration.py -v
