# Learner Task Map

Do not start by asking Claude Code to "finish the project." Work through these boundaries
in order. Each row is one commit.

## Starting state

- `python -m pytest -m baseline -q` should pass (15 tests).
- `python -m pytest -q` should fail at intentional `NotImplementedError` locations.
- Those failures are the implementation backlog, not setup defects.

## Incomplete locations

Nine `raise NotImplementedError` sites across seven files in `src/`, plus one embedding
hook in `scripts/ingest_documents.py`. Work in task order; run the focused proof after
each task before moving on.

| Task | File / unit | Specification | Proof |
|---|---|---|---|
| 7 | `llm_config.get_llm_client()` | `specs/rag_spec.md` | `python -c "from coc_filing_assistant.llm_config import get_llm_client; get_llm_client()"` |
| 7b | Embedding function — `rag_service.py:42` **and** `scripts/ingest_documents.py:86` (same implementation in both) | `specs/rag_spec.md` | `python scripts/ingest_documents.py` → 6 documents across 2 collections |
| 1 | `rule_engine.run_checks()` | `specs/rule_engine_spec.md` | `python -m pytest tests/test_rule_engine.py -v` |
| 2 | `ml_service.score_risk()` | `specs/ml_service_spec.md` | `python -m pytest tests/test_ml_service.py -v` |
| 3a | `rag_service.retrieve()` | `specs/rag_spec.md` | `python -m pytest tests/test_rag_service.py -k retrieve -v` |
| 3b | `rag_service.draft_summary()` | `specs/rag_spec.md`, `specs/safety_spec.md` | `python -m pytest tests/test_rag_service.py -k draft -v` |
| 4 | `supervisor.run_pipeline()` | `specs/architecture.md`, `specs/safety_spec.md` | `python -m pytest tests/test_supervisor.py -v` |
| 5 | `router.route()` | `specs/architecture.md` | `python -m pytest tests/test_router.py -v` |
| 6 | `repository.save_package()` | `specs/safety_spec.md` | `python -m pytest tests/test_repository_audit.py -v` |

Task 7 comes first because `rag_service` cannot be built or tested without a client.
Tasks 4 and 5 come after 1–3 because the supervisor wires all three services and the
router reads their combined output.

## Model selection

**Day 1 (writing the six specs) is the intelligence-sensitive phase — use Opus 5.**
Run at `xhigh` while resolving the degraded-input contract in `architecture.md`; `high`
is enough for the other five specs.

For implementation, most tasks are well-specified once the specs exist and run fine on
Sonnet 5. Four units carry the safety-critical or subtle logic — keep those on Opus 5.

| Task | Model | Why |
|---|---|---|
| 7, 7b | Sonnet 5 | Configuration only — read env vars, construct a client |
| 1 | Sonnet 5 | Mechanical once the rule catalog is written in the spec |
| 2 | Sonnet 5 | Scaffold and weights are already in the stub docstring |
| 3a | Sonnet 5 | Two-collection query and merge; contract fully specified |
| **3b** | **Opus 5** | Prompt construction, grounding verification, PII stripping, and injection resistance in one unit |
| **4** | **Opus 5** (`xhigh`) | The no-short-circuit inversion, exactly 4 `AgentEvent`s, and the degraded-input contract |
| 5 | Sonnet 5 | Pure deterministic 5-way branch with a fixed priority order |
| **6** | **Opus 5** | Three-table atomic write with rollback, PII stripping, 200-char truncation |

Notes:

- **Haiku 4.5 is not suitable for any task here.** It does not accept an effort
  parameter, and its 200K context window is too small for this package plus a spec set.
- **Effort is not a per-request dial in the Claude Code app** — it already defaults to
  `xhigh`. The levels named above are directional, and apply where a harness or a direct
  API call exposes `effort`. The lever you actually control in the app is the model.
- Cost, if it matters: Sonnet 5 is $2/$10 per 1M tokens through 2026-08-31, then $3/$15.
  Opus 5 is $5/$25.
- Opus 5 reaches for subagents readily and writes longer by default. On an agent-heavy
  workflow, cap spawn counts and ask explicitly for terse contract specs rather than
  lowering effort.

## Contract values — do not re-derive these

Every value below is fixed by a file in this repository. Read them from here rather than
inferring them from a test.

| Value | Setting | Source |
|---|---|---|
| Risk tier thresholds | `composite_risk >= 0.65` HIGH, `>= 0.35` MEDIUM, else LOW | `ml_service.py` docstring |
| Risk scoring method | Documented feature-weighted score. Not a trained model. | `ml_service.py` docstring |
| Confidence threshold | `< 0.70` → `FLAG_FOR_HUMAN`; otherwise `APPROVE` | `rag_service.py` docstring |
| Confidence formula | `verified_citations / total_citations`, clamped to `[0.0, 1.0]` | `rag_service.py` docstring |
| Rule minimum | 8+ rules across `MISSING_INFO`, `PRIOR_AUTH`, `PHARMACY`, `EXCLUSION`; `NETWORK` optional | `rule_engine.py` docstring |
| Overall flag | `FLAG` if any HIGH or MEDIUM rule fired, else `PASS` | `rule_engine.py` docstring |
| Collections | `coc_policy_docs`, `coc_regulatory` — query both, merge, sort by similarity desc | `llm_config.py` constants |
| Retrieval error | Raise `RAGServiceError` only if **both** collections are empty or unreachable | `rag_service.py` docstring |
| Queue priority | `LEGAL > PHARMACY > ACTUARIAL > NETWORK > OPERATIONS` | `router.py` docstring |
| Error routing | `PIPELINE_ERROR` → always `OPERATIONS` | `router.py` docstring |
| Audit events | Exactly 4 per successful run: `RuleEngine`, `MLService`, `RAGRetrieve`, `RAGDraft` | `supervisor.py` docstring, `evals/eval_end_to_end.py` |
| Audit summary cap | `output_summary` ≤ 200 characters, no PII, no full text | `.claude/rules/safety_rules.md` rule 2 |
| Persistence | 3 tables (`coc_filings`, `agent_audit_events`, `review_queue`) in one transaction | `repository.py` docstring |
| Input hash | `sha256(filing_id)[:16]` | `supervisor.py` docstring |
| Coverage gate | 80% minimum | `README.md`, `pyproject.toml` |

## Two open decisions

Neither is specified by the starter package. Decide each, record it in the named spec,
and do not leave it implicit in code.

1. **Frozen-file conflict.** `scripts/ingest_documents.py` appears on the
   "must NOT modify" list in `README.md`, yet Step 4 of the same file and line 86 of the
   script require supplying an embedding implementation. Record the adopted reading in
   `specs/rag_spec.md`. The reading taken in `CLAUDE.md` §3: the embedding hook is the
   only permitted edit in that file.
2. **Degraded-input contract.** Safety rule 7 requires all services to run for every
   filing, but `ml_service.score_risk(item, rule_output)` and
   `rag_service.retrieve(item, rule_output)` both consume `rule_output`. Define what is
   passed when `rule_engine.run_checks()` raises, so "attempt all four" is
   implementable. Record in `specs/architecture.md`.

## Frozen paths

Never edit: `domain.py`, `service.py`, `api.py`, `repository.py` (read functions only),
`tests/conftest.py`, `scripts/init_db.py`, `.claude/rules/safety_rules.md`.

## Specs to write first (Day 1, before any code)

`architecture.md`, `rule_engine_spec.md`, `ml_service_spec.md`, `rag_spec.md`,
`safety_spec.md`, `eval_spec.md` — see `specs/README.md` for the required contents of
each.
