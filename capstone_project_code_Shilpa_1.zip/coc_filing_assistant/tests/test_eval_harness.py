"""Tests for the harness's own gate logic — `evals/harness.py` and `evals/run_all.py`.

`tests/test_eval_fixture_parity.py`, `test_eval_invariants.py`, and `test_eval_isolation.py`
prove the harness's *inputs* and *domain rules* are correct. This file proves the harness
*itself* behaves correctly: exit codes, baseline comparison, policy resolution, output
sanitization, and the atomic-write guarantees around `--update-baseline`.

Every test that touches the baseline file redirects `harness.RESULTS_DIR` /
`harness.BASELINE_PATH` to a pytest `tmp_path` via `monkeypatch`. None of these tests may
read or write the real `evals/results/baseline.json` — that file is a human-approved
artifact this session was explicitly told not to create.
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from evals import harness, run_all


def _args(release: bool = False, update_baseline: bool = False) -> argparse.Namespace:
    """Build a minimal args namespace matching `harness.parse_args()`'s shape."""
    return argparse.Namespace(release=release, update_baseline=update_baseline)


def _isolate_results(monkeypatch, tmp_path: Path) -> Path:
    """Redirect every harness write target into a pytest tmp_path."""
    results_dir = tmp_path / "results"
    monkeypatch.setattr(harness, "RESULTS_DIR", results_dir)
    monkeypatch.setattr(harness, "BASELINE_PATH", results_dir / "baseline.json")
    monkeypatch.setattr(run_all.harness, "RESULTS_DIR", results_dir)
    return results_dir


def _result(
    name: str = "case",
    outcome: str = "PASS",
    required: bool = True,
    reason: str = "",
    observed: dict | None = None,
) -> harness.CaseResult:
    """Build a CaseResult without going through `_execute()`."""
    return harness.CaseResult(
        name=name, outcome=outcome, required=required, reason=reason,
        observed=observed or {},
    )


# ---------------------------------------------------------------------------
# Exit-code matrix (`eval_spec.md` §0.4)
# ---------------------------------------------------------------------------

def _exit_code(
    results, regressions=(), release=False, update_baseline=False,
    baseline_usable=True, required_absent=False, unpoliced_required=False,
    unsafe_required=False,
):
    return harness._exit_code(
        list(results), list(regressions), _args(release, update_baseline),
        baseline_usable, required_absent, unpoliced_required, unsafe_required,
    )


def test_exit_code_fail_or_error_is_always_a_release_blocker():
    results = [_result(outcome="FAIL")]
    assert _exit_code(results) == 1
    assert _exit_code(results, release=True) == 1
    assert _exit_code(results, update_baseline=True) == 2  # ineligible, not "1"


def test_exit_code_error_same_as_fail():
    results = [_result(outcome="ERROR")]
    assert _exit_code(results) == 1
    assert _exit_code(results, release=True) == 1
    assert _exit_code(results, update_baseline=True) == 2


def test_exit_code_required_skip_passes_normal_fails_release():
    results = [_result(outcome="SKIP", required=True)]
    assert _exit_code(results) == 0
    assert _exit_code(results, release=True) == 1
    assert _exit_code(results, update_baseline=True) == 2


def test_exit_code_optional_skip_never_blocks_anything():
    results = [_result(outcome="SKIP", required=False)]
    assert _exit_code(results) == 0
    assert _exit_code(results, release=True) == 0
    assert _exit_code(results, update_baseline=True) == 0


def test_exit_code_regression_fails_normal_and_release_but_not_update():
    results = [_result(outcome="PASS")]
    assert _exit_code(results, regressions=["x moved"]) == 1
    assert _exit_code(results, regressions=["x moved"], release=True) == 1
    # A regression during an approved update is the delta being approved, not a failure.
    assert _exit_code(results, regressions=["x moved"], update_baseline=True) == 0


def test_exit_code_missing_baseline_only_blocks_release():
    results = [_result(outcome="PASS")]
    assert _exit_code(results, baseline_usable=False) == 0
    assert _exit_code(results, baseline_usable=False, release=True) == 1
    assert _exit_code(results, baseline_usable=False, update_baseline=True) == 0


def test_exit_code_required_case_absent_from_baseline_only_blocks_release():
    results = [_result(outcome="PASS")]
    assert _exit_code(results, required_absent=True) == 0
    assert _exit_code(results, required_absent=True, release=True) == 1
    assert _exit_code(results, required_absent=True, update_baseline=True) == 0


def test_exit_code_unpoliced_required_metric_blocks_release_and_update():
    results = [_result(outcome="PASS")]
    assert _exit_code(results, unpoliced_required=True) == 0
    assert _exit_code(results, unpoliced_required=True, release=True) == 1
    assert _exit_code(results, unpoliced_required=True, update_baseline=True) == 2


def test_exit_code_unsafe_value_blocks_release_and_update():
    results = [_result(outcome="PASS")]
    assert _exit_code(results, unsafe_required=True) == 0
    assert _exit_code(results, unsafe_required=True, release=True) == 1
    assert _exit_code(results, unsafe_required=True, update_baseline=True) == 2


def test_exit_code_clean_run_is_always_zero_except_it_is_not_updating():
    results = [_result(outcome="PASS"), _result(name="c2", outcome="SKIP", required=False)]
    assert _exit_code(results) == 0
    assert _exit_code(results, release=True) == 0
    assert _exit_code(results, update_baseline=True) == 0


def test_run_suite_refuses_contradictory_flags(monkeypatch, tmp_path):
    _isolate_results(monkeypatch, tmp_path)
    code = harness.run_suite(
        "s", [harness.Case(lambda: {})], _args(release=True, update_baseline=True)
    )
    assert code == 2
    assert not harness.BASELINE_PATH.exists()


# ---------------------------------------------------------------------------
# Baseline comparison: required-case-absent, missing/incompatible baseline
# ---------------------------------------------------------------------------

def _write_baseline(monkeypatch, tmp_path, suites: dict) -> None:
    results_dir = _isolate_results(monkeypatch, tmp_path)
    results_dir.mkdir(parents=True, exist_ok=True)
    harness.BASELINE_PATH.write_text(
        json.dumps({"schema_version": harness.SCHEMA_VERSION, "suites": suites})
    )


def test_compare_to_baseline_missing_file_is_a_notice_not_a_regression(monkeypatch, tmp_path):
    _isolate_results(monkeypatch, tmp_path)
    regressions, notices, usable, absent = harness.compare_to_baseline(
        "s", [_result()]
    )
    assert regressions == []
    assert any("no approved baseline" in n for n in notices)
    assert usable is False
    assert absent is False


def test_compare_to_baseline_schema_mismatch_treated_as_missing(monkeypatch, tmp_path):
    _write_baseline(monkeypatch, tmp_path, suites={})
    harness.BASELINE_PATH.write_text(json.dumps({"schema_version": "99.0", "suites": {}}))
    regressions, notices, usable, absent = harness.compare_to_baseline("s", [_result()])
    assert usable is False
    assert any("incompatible" in n for n in notices)


def test_compare_to_baseline_required_case_absent_is_flagged(monkeypatch, tmp_path):
    _write_baseline(monkeypatch, tmp_path, suites={"s": {"results": []}})
    _, notices, usable, absent = harness.compare_to_baseline(
        "s", [_result(name="brand_new_case", required=True)]
    )
    assert usable is True
    assert absent is True
    assert any("required case not in baseline: brand_new_case" in n for n in notices)


def test_compare_to_baseline_optional_case_absent_does_not_set_required_absent(
    monkeypatch, tmp_path
):
    _write_baseline(monkeypatch, tmp_path, suites={"s": {"results": []}})
    _, notices, usable, absent = harness.compare_to_baseline(
        "s", [_result(name="new_optional", required=False)]
    )
    assert absent is False
    assert any("optional case not in baseline: new_optional" in n for n in notices)


def test_compare_to_baseline_pass_to_skip_downgrade_is_a_regression(monkeypatch, tmp_path):
    _write_baseline(
        monkeypatch, tmp_path,
        suites={"s": {"results": [{"name": "c", "outcome": "PASS", "observed": {}}]}},
    )
    regressions, _, _, _ = harness.compare_to_baseline(
        "s", [_result(name="c", outcome="SKIP", reason="blocked on US-9")]
    )
    assert any("downgraded PASS -> SKIP" in r for r in regressions)


# ---------------------------------------------------------------------------
# Unpoliced-metric escalation and policy resolution
# ---------------------------------------------------------------------------

def test_unpoliced_metric_on_required_case_escalates():
    notices, on_required = harness._unpoliced(
        [_result(name="c", required=True, observed={"totally_new_metric": 1})]
    )
    assert on_required is True
    assert any("unpoliced metric" in n and "totally_new_metric" in n for n in notices)


def test_unpoliced_metric_on_optional_case_does_not_escalate():
    notices, on_required = harness._unpoliced(
        [_result(name="c", required=False, observed={"totally_new_metric": 1})]
    )
    assert on_required is False
    assert notices  # still surfaced, just not release-blocking


def test_resolve_policy_case_specific_key_wins_over_generic():
    clear = harness.resolve_policy("eval_clear_evidence", "confidence_score")
    no_evidence = harness.resolve_policy("eval_no_evidence", "confidence_score")
    assert clear.policy is harness.Policy.THRESHOLD and clear.floor == 0.70
    assert no_evidence.policy is harness.Policy.THRESHOLD and no_evidence.ceiling < 0.70


def test_resolve_policy_leaf_fallback_for_fanned_out_metrics():
    # eval_risk_ordering.low_risk.composite_risk is not registered directly; the leaf
    # "composite_risk" is. This is the exact gap this session's own registry hit.
    policy = harness.resolve_policy("eval_risk_ordering", "low_risk.composite_risk")
    assert policy is harness.METRIC_POLICIES["composite_risk"]


def test_resolve_policy_unregistered_metric_returns_none():
    assert harness.resolve_policy("some_case", "never_registered_metric") is None


# ---------------------------------------------------------------------------
# Type safety: nonnumeric values under numeric-only policies
# ---------------------------------------------------------------------------

def test_nonnumeric_value_under_threshold_policy_becomes_error():
    results = [_result(name="c", outcome="PASS", observed={"grounding_rate": "n/a"})]
    harness.validate_metric_types(results)
    assert results[0].outcome == "ERROR"
    assert "grounding_rate" in results[0].reason
    assert "THRESHOLD" in results[0].reason


def test_nonnumeric_value_under_directional_policy_becomes_error():
    results = [_result(name="c", outcome="PASS", observed={"precision_at_5": "high"})]
    harness.validate_metric_types(results)
    assert results[0].outcome == "ERROR"


def test_already_failing_case_is_not_overwritten_by_type_validation():
    results = [_result(name="c", outcome="FAIL", reason="its own assertion failed",
                        observed={"grounding_rate": "n/a"})]
    harness.validate_metric_types(results)
    assert results[0].outcome == "FAIL"
    assert results[0].reason == "its own assertion failed"


def test_numeric_value_under_threshold_policy_is_untouched():
    results = [_result(name="c", outcome="PASS", observed={"grounding_rate": 1.0})]
    harness.validate_metric_types(results)
    assert results[0].outcome == "PASS"


# ---------------------------------------------------------------------------
# SAMPLED: declared but not claiming variance enforcement (this round's fix #5)
# ---------------------------------------------------------------------------

def test_sampled_comparison_always_carries_a_not_enforced_notice():
    policy = harness.METRIC_POLICIES["confidence_mean"]
    _, notice = harness._compare_value("case.confidence_mean", policy, 0.80, 0.81)
    assert notice is not None
    assert "not enforced until US-6" in notice


def test_sampled_comparison_still_flags_a_mean_that_moved_past_tolerance():
    policy = harness.METRIC_POLICIES["confidence_mean"]
    regression, notice = harness._compare_value(
        "case.confidence_mean", policy, 0.80, 0.50
    )
    assert regression is not None
    assert "mean moved" in regression
    assert notice is not None  # still discloses non-enforcement even while flagging


def test_sampled_comparison_within_tolerance_is_not_a_regression():
    policy = harness.METRIC_POLICIES["confidence_mean"]
    regression, _ = harness._compare_value("case.confidence_mean", policy, 0.80, 0.81)
    assert regression is None


# ---------------------------------------------------------------------------
# Output safety: redaction inside observed/telemetry, and Markdown escaping
# ---------------------------------------------------------------------------

def test_reason_is_sanitized_on_construction():
    result = _result(reason="see https://internal.example.com/x?token=" + "A" * 25)
    assert "https://" not in result.reason
    assert "[redacted-url]" in result.reason


def test_observed_string_values_are_redacted_not_just_reason():
    result = _result(required=True, observed={"debug": "api_key=" + "B" * 25})
    assert "B" * 25 not in result.observed["debug"]
    assert any("observed.debug" in w for w in result.output_warnings)
    # A credential-bearing value is treated the same as a non-finite float: `unsafe_values`
    # escalates a required case's outcome under --release/--update-baseline rather than
    # letting a redacted secret pass through as a quiet notice.
    assert result.unsafe_values is True


def test_non_finite_observed_value_is_nulled_and_flagged_unsafe():
    result = _result(required=True, observed={"composite_risk": math.nan})
    assert result.observed["composite_risk"] is None
    assert result.unsafe_values is True


def test_finite_observed_values_are_left_alone():
    result = _result(observed={"composite_risk": 0.54, "risk_tier": "MEDIUM"})
    assert result.observed == {"composite_risk": 0.54, "risk_tier": "MEDIUM"}
    assert result.unsafe_values is False


def test_invalid_outcome_is_rejected_at_construction():
    try:
        harness.CaseResult(name="c", outcome="PASSED", required=True)
    except ValueError as exc:
        assert "invalid outcome" in str(exc)
    else:
        raise AssertionError("CaseResult accepted an invalid outcome")


def test_escape_md_cell_neutralizes_pipes_and_newlines():
    assert harness._escape_md_cell("a|b\nc\r\nd") == "a\\|b c d"


def test_json_write_never_leaves_a_stray_temp_file(monkeypatch, tmp_path):
    results_dir = _isolate_results(monkeypatch, tmp_path)
    target = results_dir / "x.json"
    harness._atomic_write_json(target, {"a": 1})
    assert target.exists()
    assert list(results_dir.glob("*.tmp*")) == []


def test_atomic_write_leaves_original_untouched_on_failure(monkeypatch, tmp_path):
    results_dir = _isolate_results(monkeypatch, tmp_path)
    target = results_dir / "x.json"
    harness._atomic_write_json(target, {"a": 1})

    def _boom(*args, **kwargs):
        raise ValueError("simulated failure")

    monkeypatch.setattr(harness.json, "dump", _boom)
    try:
        harness._atomic_write_json(target, {"a": 2})
    except ValueError:
        pass
    else:
        raise AssertionError("expected the simulated failure to propagate")

    assert json.loads(target.read_text()) == {"a": 1}  # untouched
    assert list(results_dir.glob("*.tmp*")) == []  # temp file cleaned up


# ---------------------------------------------------------------------------
# Baseline writes: single merge, atomic, refuses to overwrite blindly
# ---------------------------------------------------------------------------

def test_build_baseline_document_is_pure(monkeypatch, tmp_path):
    _isolate_results(monkeypatch, tmp_path)
    envelope = {"meta": {"suite": "s"}, "results": []}
    document = harness.build_baseline_document({"s": envelope})
    assert document["suites"]["s"] == envelope
    assert not harness.BASELINE_PATH.exists()  # pure — no I/O


def test_build_baseline_document_merges_without_disturbing_other_suites(
    monkeypatch, tmp_path
):
    _write_baseline(monkeypatch, tmp_path, suites={"old": {"results": ["untouched"]}})
    document = harness.build_baseline_document({"new": {"meta": {}, "results": []}})
    assert document["suites"]["old"] == {"results": ["untouched"]}
    assert "new" in document["suites"]


def test_update_baseline_many_writes_every_suite_in_a_single_call(monkeypatch, tmp_path):
    _isolate_results(monkeypatch, tmp_path)
    envelopes = {
        "risk_calibration": {"meta": _fake_meta(), "results": []},
        "rag_quality": {"meta": _fake_meta(), "results": []},
    }
    harness.update_baseline_many(envelopes)
    document = json.loads(harness.BASELINE_PATH.read_text())
    assert set(document["suites"]) == {"risk_calibration", "rag_quality"}


def _fake_meta() -> dict:
    return {
        "run_id": "deadbeef", "git_sha": "abc123", "git_dirty": False,
        "started_at": "2026-01-01T00:00:00+00:00",
    }


def test_run_all_approve_scope_refuses_when_any_suite_ineligible(monkeypatch, tmp_path):
    """Regression test for this session's own bug.

    `run_all.py --update-baseline` originally called `update_baseline()` once per suite,
    so a suite that happened to be green wrote a baseline for a scope where the other
    suites were still skipping. Eligibility must be judged — and refused — across the
    whole invoked scope before anything is written.
    """
    _isolate_results(monkeypatch, tmp_path)
    code = run_all._approve_scope(["a", "b", "c"], [0, 2, 0])
    assert code == 2
    assert not harness.BASELINE_PATH.exists()


def test_run_all_approve_scope_writes_once_when_fully_eligible(monkeypatch, tmp_path):
    results_dir = _isolate_results(monkeypatch, tmp_path)
    results_dir.mkdir(parents=True, exist_ok=True)
    for suite in ("a", "b"):
        (results_dir / f"{suite}.json").write_text(
            json.dumps({"meta": _fake_meta(), "results": [], "regressions": []})
        )
    code = run_all._approve_scope(["a", "b"], [0, 0])
    assert code == 0
    document = json.loads(harness.BASELINE_PATH.read_text())
    assert set(document["suites"]) == {"a", "b"}


# ---------------------------------------------------------------------------
# Development-status banner
# ---------------------------------------------------------------------------

def test_development_run_true_when_a_required_case_skipped():
    assert harness._is_development_run(1, baseline_usable=True, git_dirty=False)


def test_development_run_true_when_baseline_unusable():
    assert harness._is_development_run(0, baseline_usable=False, git_dirty=False)


def test_development_run_true_when_tree_is_dirty():
    assert harness._is_development_run(0, baseline_usable=True, git_dirty=True)


def test_development_run_false_when_clean_complete_and_baselined():
    assert not harness._is_development_run(0, baseline_usable=True, git_dirty=False)


def test_run_suite_prints_banner_and_marks_envelope_for_a_dev_run(
    monkeypatch, tmp_path, capsys
):
    _isolate_results(monkeypatch, tmp_path)
    harness.run_suite("s", [harness.Case(lambda: {}, required=True)], _args())
    envelope = json.loads((harness.RESULTS_DIR / "s.json").read_text())
    assert envelope["development_run"] is True  # no baseline exists yet
    assert harness._DEVELOPMENT_BANNER in capsys.readouterr().out


# ---------------------------------------------------------------------------
# Provenance capture ordering (regression: git_dirty must reflect the tree at
# invocation start, not after the run's own generated artifacts have been written)
# ---------------------------------------------------------------------------

def _init_git_repo(path: Path) -> None:
    """Create a throwaway git repo at `path` with one committed file."""
    run = lambda *a: subprocess.run(a, cwd=path, check=True, capture_output=True)
    run("git", "init", "-q")
    run("git", "config", "user.email", "test@example.com")
    run("git", "config", "user.name", "Test")
    (path / "committed.txt").write_text("v1")
    run("git", "add", "committed.txt")
    run("git", "commit", "-q", "-m", "init")


def test_git_dirty_reflects_tree_at_start_not_after_case_writes_artifacts(
    monkeypatch, tmp_path
):
    """A clean starting tree stays recorded as clean even though the case itself
    writes a generated file into the repo while it runs — proving provenance is
    captured before `_execute()`, not read back after the run's own writes.
    """
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)
    monkeypatch.setattr(harness, "REPO_ROOT", repo)
    _isolate_results(monkeypatch, tmp_path)

    def _case_writes_generated_artifact():
        (repo / "generated_during_run.txt").write_text("artifact")
        return {}

    harness.run_suite("s", [harness.Case(_case_writes_generated_artifact)], _args())

    envelope = json.loads((harness.RESULTS_DIR / "s.json").read_text())
    assert envelope["meta"]["git_dirty"] is False
    # Sanity: the repo really is dirty now — the fix is about *when* it was read.
    dirty_now = subprocess.run(
        ["git", "status", "--porcelain"], cwd=repo, capture_output=True, text=True
    ).stdout
    assert dirty_now.strip() != ""


def test_git_dirty_true_when_tree_is_genuinely_dirty_before_invocation(
    monkeypatch, tmp_path
):
    """A tree that already had uncommitted changes before the suite even started
    must still be recorded as dirty — the fix must not weaken the dirty-tree rule.
    """
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)
    (repo / "uncommitted.txt").write_text("pre-existing local change")
    monkeypatch.setattr(harness, "REPO_ROOT", repo)
    _isolate_results(monkeypatch, tmp_path)

    harness.run_suite("s", [harness.Case(lambda: {})], _args())

    envelope = json.loads((harness.RESULTS_DIR / "s.json").read_text())
    assert envelope["meta"]["git_dirty"] is True


def test_run_all_shares_one_starting_provenance_across_every_suite(
    monkeypatch, tmp_path
):
    """`run_all.py` must capture git_sha/git_dirty once and hand the same snapshot to
    every suite it drives — not let a later suite re-read git after an earlier suite's
    case has already written a generated artifact into the tree.
    """
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)
    monkeypatch.setattr(harness, "REPO_ROOT", repo)
    results_dir = _isolate_results(monkeypatch, tmp_path)

    class _FakeModule:
        def __init__(self, suite: str) -> None:
            self.SUITE = suite
            self.CASES = [harness.Case(self._case)]

        def _case(self) -> dict:
            (repo / f"{self.SUITE}_generated.txt").write_text("artifact")
            return {}

    modules = [_FakeModule("suite_a"), _FakeModule("suite_b")]
    monkeypatch.setattr(run_all, "SUITES", modules)
    monkeypatch.setattr(sys, "argv", ["run_all.py"])

    run_all.main()

    meta_a = json.loads((results_dir / "suite_a.json").read_text())["meta"]
    meta_b = json.loads((results_dir / "suite_b.json").read_text())["meta"]
    assert meta_a["git_sha"] == meta_b["git_sha"]
    # suite_a's own case wrote a file into the repo before suite_b ran; if suite_b
    # captured its own provenance fresh (the bug), it would see git_dirty=True while
    # suite_a saw False. Sharing one snapshot means both agree — both clean.
    assert meta_a["git_dirty"] is False
    assert meta_b["git_dirty"] is False
