"""Tests for secured_app.py - inbound access control around the frozen FastAPI app.

api.py is frozen, so the control is an external ASGI wrapper rather than middleware
registered on the app. These tests assert the boundary the wrapper is supposed to draw:
protected paths reject an unauthenticated caller, open paths do not, and a missing key
fails closed rather than open.

Isolation follows tests/test_api.py: repository.get_connection is monkeypatched to a
temp-file database. Patching repository.DB_PATH would not work, because every provided
repository function binds `db_path: Path = DB_PATH` as a default at import time.

TestClient is used as a context manager so api.py's @app.on_event("startup") hook fires
and creates the tables. That hook is also the reason the wrapper is pure ASGI: it has to
pass lifespan messages through untouched.
"""
import sqlite3

import pytest
from fastapi.testclient import TestClient

from coc_filing_assistant import repository, secured_app

GOOD_KEY = "test-inbound-key-123"


@pytest.fixture
def client(tmp_path, monkeypatch):
    db_path = tmp_path / "test_secured.db"

    def fake_get_connection(path=repository.DB_PATH):
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    monkeypatch.setattr(repository, "get_connection", fake_get_connection)
    monkeypatch.setenv("COC_API_KEY", GOOD_KEY)
    with TestClient(secured_app.secured) as c:
        yield c


def _valid_filing_payload(filing_id="SECURED-TEST-001"):
    return {
        "filing_id": filing_id, "filing_type": "NEW", "payer_name": "Acme",
        "plan_type": "PPO", "state": "TX", "effective_date": "2026-01-01",
        "prior_auth_language": "x", "pharmacy_language": "x",
        "exclusion_clauses": "x", "network_language": "x",
        "benefit_summary": "x", "mandatory_sections_present": ["benefits"],
        "submitted_by": "tester",
    }


# ---------------------------------------------------------------------------
# Protected reads
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", ["/filings", "/audit-log", "/review-queue",
                                   "/risk-report", "/dashboard"])
def test_protected_path_rejects_missing_header(client, path):
    resp = client.get(path)
    assert resp.status_code == 401
    assert "X-API-Key" in resp.json()["detail"]


@pytest.mark.parametrize("path", ["/filings", "/audit-log", "/review-queue",
                                   "/risk-report", "/dashboard"])
def test_protected_path_allows_correct_header(client, path):
    resp = client.get(path, headers={"X-API-Key": GOOD_KEY})
    assert resp.status_code == 200


def test_wrong_key_is_rejected(client):
    resp = client.get("/filings", headers={"X-API-Key": "not-the-key"})
    assert resp.status_code == 401


def test_empty_key_header_is_rejected(client):
    resp = client.get("/filings", headers={"X-API-Key": ""})
    assert resp.status_code == 401


def test_header_name_is_case_insensitive(client):
    """HTTP header names are case-insensitive; the check must not depend on casing."""
    resp = client.get("/filings", headers={"x-ApI-kEy": GOOD_KEY})
    assert resp.status_code == 200


def test_error_body_does_not_leak_the_expected_key(client):
    resp = client.get("/filings")
    assert GOOD_KEY not in resp.text


# ---------------------------------------------------------------------------
# The write path must be covered too, not just reads
# ---------------------------------------------------------------------------

def test_process_filing_rejects_missing_header(client):
    resp = client.post("/filings/process", json=_valid_filing_payload())
    assert resp.status_code == 401


def test_process_filing_reaches_validation_with_correct_header(client):
    """With a valid key the request reaches the app: an unknown field yields 422, not 401."""
    payload = _valid_filing_payload()
    payload["unexpected_field"] = "boom"
    resp = client.post("/filings/process", json=payload,
                       headers={"X-API-Key": GOOD_KEY})
    assert resp.status_code == 422


# ---------------------------------------------------------------------------
# Open paths
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", ["/health", "/docs", "/openapi.json"])
def test_open_path_needs_no_header(client, path):
    assert client.get(path).status_code == 200


def test_open_paths_are_exactly_the_documented_set():
    """Guards against a route being quietly added to the unauthenticated set."""
    assert secured_app.OPEN_PATHS == frozenset({"/health", "/docs", "/openapi.json"})


# ---------------------------------------------------------------------------
# Fail closed
# ---------------------------------------------------------------------------

def test_unset_key_fails_closed(client, monkeypatch):
    """An unset COC_API_KEY must refuse requests, never allow them through."""
    monkeypatch.delenv("COC_API_KEY", raising=False)
    with pytest.raises(RuntimeError, match="COC_API_KEY must be set"):
        client.get("/filings")


def test_empty_key_env_fails_closed(client, monkeypatch):
    monkeypatch.setenv("COC_API_KEY", "")
    with pytest.raises(RuntimeError, match="COC_API_KEY must be set"):
        client.get("/filings")


def test_expected_key_reads_environment_at_call_time(monkeypatch):
    monkeypatch.setenv("COC_API_KEY", "first")
    assert secured_app._expected_key() == "first"
    monkeypatch.setenv("COC_API_KEY", "second")
    assert secured_app._expected_key() == "second"


# ---------------------------------------------------------------------------
# The wrapper must not break the frozen app's startup hook
# ---------------------------------------------------------------------------

def test_lifespan_passes_through_and_creates_tables(tmp_path, monkeypatch):
    """api.py's startup hook calls repository.init_db(); swallowing lifespan would
    leave the database with no tables and make every query look like an auth failure."""
    db_path = tmp_path / "lifespan.db"

    def fake_get_connection(path=repository.DB_PATH):
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    monkeypatch.setattr(repository, "get_connection", fake_get_connection)
    monkeypatch.setenv("COC_API_KEY", GOOD_KEY)
    with TestClient(secured_app.secured):
        pass

    conn = sqlite3.connect(db_path)
    tables = {row[0] for row in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    conn.close()
    assert {"coc_filings", "agent_audit_events", "review_queue"} <= tables


# ---------------------------------------------------------------------------
# OpenAPI advertises the scheme, so Swagger's "Try it out" can authenticate
# ---------------------------------------------------------------------------

def test_openapi_declares_the_api_key_scheme(client):
    schema = client.get("/openapi.json").json()
    scheme = schema["components"]["securitySchemes"]["ApiKeyAuth"]
    assert scheme == {"type": "apiKey", "in": "header", "name": "X-API-Key"}
    assert schema["security"] == [{"ApiKeyAuth": []}]
