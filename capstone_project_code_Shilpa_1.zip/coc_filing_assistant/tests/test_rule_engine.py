"""Tests for rule_engine.py.

Baseline tests (marked @pytest.mark.baseline):
  Pass immediately - verify imports and domain objects work.

Implementation tests (marked @pytest.mark.implementation):
  Fail with NotImplementedError until you implement run_checks().

Run baseline only:  python -m pytest tests/test_rule_engine.py -m baseline -v
Run all:            python -m pytest tests/test_rule_engine.py -v
"""
import pytest
from coc_filing_assistant.domain import (
    COCFilingItem, RuleEngineOutput, RuleCheckResult, RuleEngineError
)


# ---------------------------------------------------------------------------
# Baseline - pass immediately
# ---------------------------------------------------------------------------

@pytest.mark.baseline
def test_rule_engine_imports():
    from coc_filing_assistant import rule_engine
    assert hasattr(rule_engine, "run_checks")


@pytest.mark.baseline
def test_rule_check_result_fields():
    r = RuleCheckResult(
        rule_id="R001",
        category="MISSING_INFO",
        severity="HIGH",
        description="Mandatory section absent",
        filing_section="Section 3",
        evidence="",
    )
    assert r.rule_id == "R001"
    assert r.severity == "HIGH"


@pytest.mark.baseline
def test_rule_engine_output_fields():
    out = RuleEngineOutput(filing_id="TEST-001", rule_results=[], overall_flag="PASS")
    assert out.overall_flag == "PASS"
    assert out.rule_results == []


# ---------------------------------------------------------------------------
# Implementation tests - fail until run_checks() is implemented
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_run_checks_returns_rule_engine_output(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    result = run_checks(filing_high_risk)
    assert isinstance(result, RuleEngineOutput)
    assert result.filing_id == filing_high_risk.filing_id


@pytest.mark.implementation
def test_high_risk_filing_flags_issues(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    result = run_checks(filing_high_risk)
    assert result.overall_flag == "FLAG"
    assert len(result.rule_results) > 0


@pytest.mark.implementation
def test_rule_results_have_required_fields(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    result = run_checks(filing_high_risk)
    for r in result.rule_results:
        assert r.rule_id, "rule_id must not be empty"
        assert r.category in {"MISSING_INFO", "PRIOR_AUTH", "PHARMACY", "EXCLUSION", "NETWORK"}
        assert r.severity in {"HIGH", "MEDIUM", "LOW"}
        assert r.description


@pytest.mark.implementation
def test_missing_mandatory_sections_flagged(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    result = run_checks(filing_high_risk)
    categories = [r.category for r in result.rule_results]
    assert "MISSING_INFO" in categories, "Missing sections must produce MISSING_INFO rules"


@pytest.mark.implementation
def test_pharmacy_issues_flagged(filing_medium_risk):
    # filing_high_risk.pharmacy_language ("No exceptions noted.", "Tier 3") satisfies
    # PH-003 but also the PH-002 substring check for "exception" - see
    # rule_engine_spec.md §4's documented substring-matching limitation. filing_medium_risk
    # genuinely lacks both an exception process and a tier/formulary structure.
    from coc_filing_assistant.rule_engine import run_checks
    result = run_checks(filing_medium_risk)
    categories = [r.category for r in result.rule_results]
    assert "PHARMACY" in categories


@pytest.mark.implementation
def test_low_risk_filing_passes(filing_low_risk):
    from coc_filing_assistant.rule_engine import run_checks
    result = run_checks(filing_low_risk)
    high_rules = [r for r in result.rule_results if r.severity == "HIGH"]
    assert len(high_rules) == 0, "Low-risk filing must not produce HIGH severity rules"


@pytest.mark.implementation
def test_determinism(filing_medium_risk):
    from coc_filing_assistant.rule_engine import run_checks
    result1 = run_checks(filing_medium_risk)
    result2 = run_checks(filing_medium_risk)
    assert result1.overall_flag == result2.overall_flag
    assert len(result1.rule_results) == len(result2.rule_results)


@pytest.mark.implementation
def test_minimum_eight_rules_implemented(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    # Submit the most problematic filing - should trigger many rules
    result = run_checks(filing_high_risk)
    unique_rule_ids = {r.rule_id for r in result.rule_results}
    # At minimum, a high-risk filing should trigger >= 3 distinct rules
    assert len(unique_rule_ids) >= 3, (
        "High-risk filing must trigger at least 3 distinct rules. "
        "Your spec requires 8 total rules across 4 categories."
    )
