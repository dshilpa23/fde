"""Tests for ml_service.py.

Run baseline only:  python -m pytest tests/test_ml_service.py -m baseline -v
Run all:            python -m pytest tests/test_ml_service.py -v
"""
import pytest
from coc_filing_assistant.domain import RuleEngineOutput, RiskScore


# ---------------------------------------------------------------------------
# Baseline
# ---------------------------------------------------------------------------

@pytest.mark.baseline
def test_ml_service_imports():
    from coc_filing_assistant import ml_service
    assert hasattr(ml_service, "score_risk")


@pytest.mark.baseline
def test_risk_score_fields():
    rs = RiskScore(
        filing_id="TEST-001",
        sla_delay_probability=0.8,
        escalation_probability=0.7,
        review_effort_score=0.9,
        composite_risk=0.8,
        risk_tier="HIGH",
        model_version="v1.0",
    )
    assert rs.risk_tier == "HIGH"
    assert 0.0 <= rs.composite_risk <= 1.0


# ---------------------------------------------------------------------------
# Implementation tests
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_score_risk_returns_risk_score(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    from coc_filing_assistant.ml_service import score_risk
    rule_out = run_checks(filing_high_risk)
    result = score_risk(filing_high_risk, rule_out)
    assert isinstance(result, RiskScore)
    assert result.filing_id == filing_high_risk.filing_id


@pytest.mark.implementation
def test_probabilities_in_range(filing_medium_risk):
    from coc_filing_assistant.rule_engine import run_checks
    from coc_filing_assistant.ml_service import score_risk
    rule_out = run_checks(filing_medium_risk)
    result = score_risk(filing_medium_risk, rule_out)
    for val in [result.sla_delay_probability,
                result.escalation_probability,
                result.review_effort_score,
                result.composite_risk]:
        assert 0.0 <= val <= 1.0, f"Probability out of range: {val}"


@pytest.mark.implementation
def test_high_risk_filing_scores_high(filing_high_risk):
    from coc_filing_assistant.rule_engine import run_checks
    from coc_filing_assistant.ml_service import score_risk
    rule_out = run_checks(filing_high_risk)
    result = score_risk(filing_high_risk, rule_out)
    assert result.risk_tier == "HIGH", (
        f"High-risk filing must score HIGH, got {result.risk_tier}"
    )


@pytest.mark.implementation
def test_low_risk_filing_scores_low(filing_low_risk):
    from coc_filing_assistant.rule_engine import run_checks
    from coc_filing_assistant.ml_service import score_risk
    rule_out = run_checks(filing_low_risk)
    result = score_risk(filing_low_risk, rule_out)
    assert result.risk_tier in {"LOW", "MEDIUM"}, (
        f"Low-risk filing must score LOW or MEDIUM, got {result.risk_tier}"
    )


@pytest.mark.implementation
def test_model_version_set(filing_medium_risk):
    from coc_filing_assistant.rule_engine import run_checks
    from coc_filing_assistant.ml_service import score_risk
    rule_out = run_checks(filing_medium_risk)
    result = score_risk(filing_medium_risk, rule_out)
    assert result.model_version, "model_version must be set"


@pytest.mark.implementation
def test_determinism(filing_medium_risk):
    from coc_filing_assistant.rule_engine import run_checks
    from coc_filing_assistant.ml_service import score_risk
    rule_out = run_checks(filing_medium_risk)
    r1 = score_risk(filing_medium_risk, rule_out)
    r2 = score_risk(filing_medium_risk, rule_out)
    assert r1.risk_tier == r2.risk_tier
    assert abs(r1.composite_risk - r2.composite_risk) < 0.001
