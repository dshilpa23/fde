"""Shared pytest fixtures. Provided complete - do not modify."""
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from coc_filing_assistant.domain import COCFilingItem


# ---------------------------------------------------------------------------
# 5 synthetic COC filing items
# ---------------------------------------------------------------------------

@pytest.fixture
def filing_high_risk():
    """High-risk filing: missing sections, pharmacy issues, HIGH ML risk."""
    return COCFilingItem(
        filing_id="FILING-HIGH-001",
        filing_type="NEW",
        payer_name="Centene Corporation",
        plan_type="HMO",
        state="TX",
        effective_date="2025-01-01",
        prior_auth_language="Prior authorization required for all specialist visits.",
        pharmacy_language="Tier 3 drugs require step therapy. No exceptions noted.",
        exclusion_clauses="Experimental treatments excluded. Definition of experimental not provided.",
        network_language="In-network providers only. Network adequacy not demonstrated.",
        benefit_summary="Basic hospitalization covered. Outpatient details pending.",
        mandatory_sections_present=["benefits", "exclusions"],
        submitted_by="analyst_01",
    )


@pytest.fixture
def filing_medium_risk():
    """Medium-risk filing: minor prior-auth gaps, MEDIUM ML risk."""
    return COCFilingItem(
        filing_id="FILING-MED-001",
        filing_type="AMENDMENT",
        payer_name="Humana Inc",
        plan_type="PPO",
        state="FL",
        effective_date="2025-04-01",
        prior_auth_language=(
            "Prior authorization required for MRI and CT scans exceeding $500. "
            "Urgent care does not require prior authorization."
        ),
        pharmacy_language=(
            "Generic drugs preferred. Brand-name drugs require physician justification. "
            "Specialty drugs require prior authorization."
        ),
        exclusion_clauses=(
            "Cosmetic procedures excluded unless medically necessary as defined in Section 4. "
            "Experimental treatments excluded per CMS guidelines."
        ),
        network_language=(
            "In-network and out-of-network coverage provided. "
            "Out-of-network cost-sharing applies per Schedule of Benefits."
        ),
        benefit_summary=(
            "Hospitalization, outpatient surgery, preventive care, and mental health "
            "services covered. Dental and vision not included."
        ),
        mandatory_sections_present=[
            "benefits", "exclusions", "prior_auth", "pharmacy", "network", "grievance"
        ],
        submitted_by="analyst_02",
    )


@pytest.fixture
def filing_low_risk():
    """Low-risk filing: complete sections, clear language, LOW ML risk."""
    return COCFilingItem(
        filing_id="FILING-LOW-001",
        filing_type="RENEWAL",
        payer_name="BlueCross BlueShield",
        plan_type="PPO",
        state="IL",
        effective_date="2025-01-01",
        prior_auth_language=(
            "Prior authorization is required for inpatient admissions, "
            "outpatient surgery, home health services, durable medical equipment, "
            "and all specialty medications. The prior authorization process is "
            "described in the Member Handbook, Section 7. Urgent and emergency "
            "services do not require prior authorization."
        ),
        pharmacy_language=(
            "The formulary is organized into four tiers. Tier 1: generic drugs. "
            "Tier 2: preferred brand. Tier 3: non-preferred brand. Tier 4: specialty. "
            "Step therapy applies to Tier 3 and Tier 4 medications. "
            "Exceptions are available via the formulary exception process in Section 9."
        ),
        exclusion_clauses=(
            "Services not covered include: cosmetic surgery not medically necessary, "
            "custodial care, experimental treatments not approved by FDA or CMS, "
            "and services received outside the service area except for emergencies. "
            "Full exclusion list is provided in Exhibit A."
        ),
        network_language=(
            "Network adequacy standards meet or exceed state requirements. "
            "Member-to-PCP ratio is 1500:1 in all service areas. "
            "Specialist access within 30 miles or 30 minutes in urban areas."
        ),
        benefit_summary=(
            "Comprehensive coverage including hospitalization, outpatient, "
            "preventive, mental health, substance use disorder, maternity, "
            "pediatric, and emergency services. Cost-sharing details in Schedule of Benefits."
        ),
        mandatory_sections_present=[
            "benefits", "exclusions", "prior_auth", "pharmacy",
            "network", "grievance", "coordination_of_benefits", "definitions"
        ],
        submitted_by="analyst_03",
    )


@pytest.fixture
def filing_pipeline_error():
    """Filing designed to test error handling - minimal data."""
    return COCFilingItem(
        filing_id="FILING-ERR-001",
        filing_type="NEW",
        payer_name="",
        plan_type="HMO",
        state="XX",
        effective_date="",
        prior_auth_language="",
        pharmacy_language="",
        exclusion_clauses="",
        network_language="",
        benefit_summary="",
        mandatory_sections_present=[],
        submitted_by="test",
    )


@pytest.fixture
def filing_idempotency():
    """Standard filing for idempotency testing."""
    return COCFilingItem(
        filing_id="FILING-IDEM-001",
        filing_type="RENEWAL",
        payer_name="Aetna",
        plan_type="EPO",
        state="NY",
        effective_date="2025-07-01",
        prior_auth_language=(
            "Prior authorization required for inpatient, specialty drugs, "
            "and imaging studies over $1000."
        ),
        pharmacy_language=(
            "Three-tier formulary. Step therapy on tier 3. "
            "Exception process available."
        ),
        exclusion_clauses=(
            "Experimental treatments excluded per current CMS policy. "
            "All exclusions listed in Appendix B."
        ),
        network_language=(
            "Statewide network with 5000+ providers. "
            "Out-of-network coverage for emergencies only."
        ),
        benefit_summary=(
            "Full coverage for preventive, inpatient, outpatient, and mental health. "
            "Vision and dental riders available separately."
        ),
        mandatory_sections_present=[
            "benefits", "exclusions", "prior_auth", "pharmacy", "network", "grievance"
        ],
        submitted_by="analyst_04",
    )
