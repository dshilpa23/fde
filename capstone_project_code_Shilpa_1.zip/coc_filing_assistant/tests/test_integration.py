"""End-to-end integration tests - all 5 synthetic filings through the full pipeline.

These tests verify the complete workflow:
  COCFilingItem -> supervisor -> router -> repository -> readable audit trail

Run all: python -m pytest tests/test_integration.py -v
"""
import pytest
import tempfile
from pathlib import Path


@pytest.fixture
def tmp_db(tmp_path):
    return tmp_path / "integration_test.db"


@pytest.mark.implementation
def test_all_five_filings_produce_status(
    filing_high_risk, filing_medium_risk, filing_low_risk,
    filing_pipeline_error, filing_idempotency, tmp_db
):
    """Every filing must produce a status. None must crash silently."""
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import init_db, save_package

    init_db(tmp_db)
    filings = [
        filing_high_risk, filing_medium_risk, filing_low_risk,
        filing_pipeline_error, filing_idempotency
    ]
    valid_statuses = {"HANDOFF_READY", "NEEDS_REVIEW", "PIPELINE_ERROR"}

    for item in filings:
        package, events = run_pipeline(item)
        assert package.status in valid_statuses, (
            f"Filing {item.filing_id} produced invalid status: {package.status!r}"
        )
        package.review_queue = route(package)
        save_package(package, events, tmp_db)


@pytest.mark.implementation
def test_idempotent_replay(filing_idempotency, tmp_db):
    """Submitting the same filing_id twice returns stored result, no new agents run."""
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import init_db, save_package, get_audit_events
    from coc_filing_assistant.service import process

    init_db(tmp_db)

    # First submission
    result1 = process(filing_idempotency, db_path=tmp_db)
    assert not result1.idempotent_replay

    events_after_first = len(get_audit_events(filing_idempotency.filing_id, tmp_db))

    # Second submission - must return stored result
    result2 = process(filing_idempotency, db_path=tmp_db)
    assert result2.idempotent_replay is True
    assert result2.filing_id == filing_idempotency.filing_id

    events_after_second = len(get_audit_events(filing_idempotency.filing_id, tmp_db))
    assert events_after_second == events_after_first, (
        "Second submission must not create new audit events"
    )


@pytest.mark.implementation
def test_audit_trail_covers_all_agents(filing_medium_risk, tmp_db):
    """Every pipeline run must produce audit events for all 4 agents."""
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import init_db, save_package, get_audit_events

    init_db(tmp_db)
    package, events = run_pipeline(filing_medium_risk)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)

    audit = get_audit_events(filing_medium_risk.filing_id, tmp_db)
    agent_names = {ev["agent_name"] for ev in audit}
    required = {"RuleEngine", "MLService", "RAGRetrieve", "RAGDraft"}
    assert required.issubset(agent_names), (
        f"Missing agents in audit trail: {required - agent_names}"
    )


@pytest.mark.implementation
def test_handoff_ready_never_set_on_error(filing_pipeline_error, tmp_db):
    """HANDOFF_READY must never be produced when any service failed."""
    from coc_filing_assistant.supervisor import run_pipeline

    package, events = run_pipeline(filing_pipeline_error)
    failed_events = [e for e in events if e.status == "FAILURE"]
    if failed_events:
        assert package.status != "HANDOFF_READY", (
            "HANDOFF_READY must never be set when any agent event is FAILURE"
        )
