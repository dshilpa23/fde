"""Route-on-persist: the review queue must survive the frozen API call order.

Regression tests for a real integration gap found during demo rehearsal. Frozen
`service.process()` calls `repository.save_package()` *before* frozen `api.py` calls
`router.route()`, so on the API path `package.review_queue` was still `None` at write
time and the `review_queue` table never received a row — `/review-queue` and
`/dashboard` rendered empty after successful filings, while the whole test suite stayed
green because the provided `test_repository_audit.py` tests set `review_queue` by hand
before saving.

`repository._ensure_review_queue()` closes that gap by delegating to the same pure
`router.route()` when the caller left the queue unset. These tests pin both halves of
that contract: unset gets routed, already-set is never overwritten.

Packages are constructed directly rather than through `run_pipeline()` so these stay
fast and deterministic — no LLM or vector-store calls.

Run: python -m pytest tests/test_review_queue_persistence.py -v
"""
from __future__ import annotations

from datetime import datetime

import pytest

from coc_filing_assistant import repository, router, service, supervisor
from coc_filing_assistant.domain import (
    AgentEvent,
    HandoffPackage,
    ReviewResult,
    RiskScore,
    RuleCheckResult,
    RuleEngineOutput,
)


def _rule_output(filing_id: str, results: list[RuleCheckResult], flag: str) -> RuleEngineOutput:
    return RuleEngineOutput(filing_id=filing_id, rule_results=results, overall_flag=flag)


def _risk(filing_id: str, tier: str, composite: float) -> RiskScore:
    return RiskScore(
        filing_id=filing_id, sla_delay_probability=composite,
        escalation_probability=composite, review_effort_score=composite,
        composite_risk=composite, risk_tier=tier, model_version="test-v1",
    )


def _events(filing_id: str) -> list[AgentEvent]:
    return [
        AgentEvent(
            filing_id=filing_id, agent_name=name, input_hash="deadbeef",
            output_summary=f"{name} ok", confidence=None, status="SUCCESS",
            error_message=None,
        )
        for name in ("RuleEngine", "MLService", "RAGRetrieve", "RAGDraft")
    ]


def _package(
    filing_id: str = "FILING-Q-001",
    status: str = "HANDOFF_READY",
    review_queue: str | None = None,
    categories: tuple[str, ...] = (),
    tier: str = "LOW",
    composite: float = 0.0,
) -> HandoffPackage:
    """A persistable package. `categories` drives what router.route() will pick."""
    results = [
        RuleCheckResult(
            rule_id=f"R{i}", category=category, severity="HIGH",
            description=f"{category} finding", filing_section="prior_auth_language",
            evidence="",
        )
        for i, category in enumerate(categories)
    ]
    return HandoffPackage(
        filing_id=filing_id,
        rule_output=_rule_output(filing_id, results, "FLAG" if results else "PASS"),
        risk_score=_risk(filing_id, tier, composite),
        filing_summary=None,
        review_result=ReviewResult(
            confidence_score=0.95, ungrounded_claims=[], recommendation="APPROVE",
        ),
        status=status,
        error_reason=None,
        review_queue=review_queue,
        assembled_at=datetime(2026, 8, 18, 12, 0, 0),
    )


# ---------------------------------------------------------------------------
# Unset queue gets routed and persisted (the gap being fixed)
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_unset_queue_is_routed_and_persisted_to_both_tables(tmp_path):
    """A package arriving with review_queue=None - exactly what frozen
    service.process() hands over - must still land in review_queue."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    package = _package(categories=("PHARMACY",), tier="MEDIUM", composite=0.5)
    assert package.review_queue is None, "precondition: caller left the queue unset"

    repository.save_package(package, _events(package.filing_id), db)

    expected = router.route(_package(categories=("PHARMACY",), tier="MEDIUM", composite=0.5))
    # 1. the in-memory package now carries the queue (api.py reads this back)
    assert package.review_queue == expected
    # 2. the filing row carries it
    row = repository.find_by_filing_id(package.filing_id, db)
    assert row["review_queue"] == expected
    # 3. the review_queue table has exactly one matching row
    queue_rows = [q for q in repository.list_review_queue(db)
                  if q["filing_id"] == package.filing_id]
    assert len(queue_rows) == 1
    assert queue_rows[0]["queue_name"] == expected
    assert queue_rows[0]["status"] == "HANDOFF_READY"


@pytest.mark.implementation
def test_filing_row_and_queue_row_agree_on_the_queue(tmp_path):
    """The two tables must never disagree - one route() call feeds both."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    package = _package(categories=("NETWORK",))
    repository.save_package(package, _events(package.filing_id), db)

    row = repository.find_by_filing_id(package.filing_id, db)
    queue_row = next(q for q in repository.list_review_queue(db)
                     if q["filing_id"] == package.filing_id)
    assert row["review_queue"] == queue_row["queue_name"] == package.review_queue


# ---------------------------------------------------------------------------
# An already-routed package is preserved, never re-routed
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_preset_queue_is_preserved_not_overwritten(tmp_path):
    """The provided tests (and api.py) may route first; that decision wins."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    # LEGAL-triggering findings, but the caller deliberately set OPERATIONS.
    package = _package(review_queue="OPERATIONS", categories=("EXCLUSION",),
                       tier="HIGH", composite=0.9)

    repository.save_package(package, _events(package.filing_id), db)

    assert package.review_queue == "OPERATIONS"
    row = repository.find_by_filing_id(package.filing_id, db)
    assert row["review_queue"] == "OPERATIONS"
    queue_row = next(q for q in repository.list_review_queue(db)
                     if q["filing_id"] == package.filing_id)
    assert queue_row["queue_name"] == "OPERATIONS"


@pytest.mark.implementation
def test_router_not_called_when_queue_already_set(tmp_path, monkeypatch):
    """Proves preservation is a skipped call, not a coincidental match."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    calls: list[str] = []

    def _boom(package):
        calls.append(package.filing_id)
        raise AssertionError("router.route() must not be called for a pre-routed package")

    monkeypatch.setattr(repository.router, "route", _boom)
    package = _package(review_queue="ACTUARIAL")
    repository.save_package(package, _events(package.filing_id), db)

    assert calls == []
    assert repository.find_by_filing_id(package.filing_id, db)["review_queue"] == "ACTUARIAL"


@pytest.mark.implementation
def test_route_called_exactly_once_when_unset(tmp_path, monkeypatch):
    """No double-routing inside persistence."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    calls: list[str] = []
    real_route = router.route

    def _counting(package):
        calls.append(package.filing_id)
        return real_route(package)

    monkeypatch.setattr(repository.router, "route", _counting)
    package = _package(categories=("PHARMACY",))
    repository.save_package(package, _events(package.filing_id), db)

    assert len(calls) == 1


# ---------------------------------------------------------------------------
# PIPELINE_ERROR still persists OPERATIONS
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_pipeline_error_persists_operations(tmp_path):
    """safety-relevant: a failed pipeline must reach the Operations queue,
    and now it actually reaches it in the database too."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    package = _package(
        filing_id="FILING-Q-ERR", status="PIPELINE_ERROR",
        categories=("EXCLUSION",), tier="HIGH", composite=1.0,
    )
    package.error_reason = "simulated stage failure"

    repository.save_package(package, _events(package.filing_id), db)

    assert package.review_queue == "OPERATIONS"
    assert repository.find_by_filing_id(package.filing_id, db)["review_queue"] == "OPERATIONS"
    queue_row = next(q for q in repository.list_review_queue(db)
                     if q["filing_id"] == package.filing_id)
    assert queue_row["queue_name"] == "OPERATIONS"


# ---------------------------------------------------------------------------
# Idempotent replay: no agents re-run, no duplicate queue or audit rows
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_idempotent_replay_adds_no_duplicate_queue_or_audit_rows(
    tmp_path, monkeypatch, filing_low_risk
):
    """Second submission through service.process() must replay from storage:
    run_pipeline is never re-entered, and neither table grows."""
    db = tmp_path / "q.db"
    repository.init_db(db)
    runs: list[str] = []

    def _fake_run_pipeline(item):
        runs.append(item.filing_id)
        package = _package(filing_id=item.filing_id, categories=("PHARMACY",))
        return package, _events(item.filing_id)

    monkeypatch.setattr(supervisor, "run_pipeline", _fake_run_pipeline)

    first = service.process(filing_low_risk, db)
    assert first.idempotent_replay is False
    assert len(runs) == 1
    queue_after_first = repository.list_review_queue(db)
    audit_after_first = repository.get_audit_events(filing_low_risk.filing_id, db)
    assert len(queue_after_first) == 1
    assert len(audit_after_first) == 4

    second = service.process(filing_low_risk, db)

    assert second.idempotent_replay is True
    assert len(runs) == 1, "idempotent replay must not re-run the agents"
    # The replayed package carries the persisted queue back out.
    assert second.review_queue == first.review_queue
    assert len(repository.list_review_queue(db)) == 1, "no duplicate queue row"
    assert len(repository.get_audit_events(filing_low_risk.filing_id, db)) == 4, (
        "no duplicate audit rows"
    )
