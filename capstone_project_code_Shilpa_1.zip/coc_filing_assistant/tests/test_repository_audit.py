"""Tests for repository.py and audit trail correctness.

Run all: python -m pytest tests/test_repository_audit.py -v
"""
import pytest
import tempfile
from pathlib import Path
from coc_filing_assistant.domain import HandoffPackage, AgentEvent


@pytest.fixture
def tmp_db(tmp_path):
    return tmp_path / "test.db"


# ---------------------------------------------------------------------------
# Baseline
# ---------------------------------------------------------------------------

@pytest.mark.baseline
def test_repository_imports():
    from coc_filing_assistant import repository
    assert hasattr(repository, "init_db")
    assert hasattr(repository, "save_package")
    assert hasattr(repository, "find_by_filing_id")
    assert hasattr(repository, "get_audit_events")


@pytest.mark.baseline
def test_init_db_creates_tables(tmp_db):
    from coc_filing_assistant.repository import init_db, get_connection
    init_db(tmp_db)
    conn = get_connection(tmp_db)
    tables = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()}
    conn.close()
    assert "coc_filings" in tables
    assert "agent_audit_events" in tables
    assert "review_queue" in tables


@pytest.mark.baseline
def test_audit_events_append_only(tmp_db):
    from coc_filing_assistant.repository import init_db, get_connection
    import sqlite3
    init_db(tmp_db)
    conn = get_connection(tmp_db)
    # Try to delete - should be blocked by trigger
    conn.execute("""
        INSERT INTO coc_filings VALUES
        ('TRIG-001','HANDOFF_READY','LOW','LEGAL',0.9,NULL,'2025-01-01T00:00:00')
    """)
    conn.execute("""
        INSERT INTO agent_audit_events
        (filing_id, agent_name, input_hash, output_summary, confidence, status, error_message, executed_at)
        VALUES ('TRIG-001','RuleEngine','abc','3 rules checked',NULL,'SUCCESS',NULL,'2025-01-01T00:00:00')
    """)
    conn.commit()
    with pytest.raises((sqlite3.OperationalError, sqlite3.IntegrityError)):
        conn.execute("DELETE FROM agent_audit_events WHERE filing_id='TRIG-001'")
    conn.close()


# ---------------------------------------------------------------------------
# Implementation tests
# ---------------------------------------------------------------------------

@pytest.mark.implementation
def test_save_package_persists_filing(filing_low_risk, tmp_db):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import save_package, find_by_filing_id, init_db
    init_db(tmp_db)
    package, events = run_pipeline(filing_low_risk)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)
    row = find_by_filing_id(filing_low_risk.filing_id, tmp_db)
    assert row is not None
    assert row["filing_id"] == filing_low_risk.filing_id
    assert row["status"] == package.status


@pytest.mark.implementation
def test_save_package_writes_audit_events(filing_medium_risk, tmp_db):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import save_package, get_audit_events, init_db
    init_db(tmp_db)
    package, events = run_pipeline(filing_medium_risk)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)
    audit = get_audit_events(filing_medium_risk.filing_id, tmp_db)
    assert len(audit) == len(events), "One audit event row per AgentEvent"


@pytest.mark.implementation
def test_no_pii_in_audit_records(filing_medium_risk, tmp_db):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import save_package, get_audit_events, init_db
    init_db(tmp_db)
    package, events = run_pipeline(filing_medium_risk)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)
    audit = get_audit_events(filing_medium_risk.filing_id, tmp_db)
    prohibited = ["patient", "dob", "date_of_birth", "ssn", "phone", "email"]
    for ev in audit:
        summary = str(ev.get("output_summary", "")).lower()
        for term in prohibited:
            assert term not in summary, (
                f"Prohibited PII term '{term}' found in audit output_summary"
            )


@pytest.mark.implementation
def test_output_summary_max_200_chars(filing_medium_risk, tmp_db):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import save_package, get_audit_events, init_db
    init_db(tmp_db)
    package, events = run_pipeline(filing_medium_risk)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)
    audit = get_audit_events(filing_medium_risk.filing_id, tmp_db)
    for ev in audit:
        assert len(ev.get("output_summary", "")) <= 200


@pytest.mark.implementation
def test_idempotent_save_does_not_duplicate(filing_idempotency, tmp_db):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import save_package, get_audit_events, init_db
    init_db(tmp_db)
    package, events = run_pipeline(filing_idempotency)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)
    count_before = len(get_audit_events(filing_idempotency.filing_id, tmp_db))
    # Second save of the same filing_id must not insert duplicate rows
    # (service.py prevents this via find_by_filing_id, but repository must
    #  not corrupt data if called directly)
    try:
        save_package(package, events, tmp_db)
    except Exception:
        pass  # Acceptable - uniqueness constraint should block it
    count_after = len(get_audit_events(filing_idempotency.filing_id, tmp_db))
    assert count_after == count_before, "Duplicate save must not add extra audit events"


@pytest.mark.implementation
def test_review_queue_populated_in_db(filing_low_risk, tmp_db):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    from coc_filing_assistant.repository import save_package, list_review_queue, init_db
    init_db(tmp_db)
    package, events = run_pipeline(filing_low_risk)
    package.review_queue = route(package)
    save_package(package, events, tmp_db)
    queue = list_review_queue(tmp_db)
    filing_ids = [q["filing_id"] for q in queue]
    assert filing_low_risk.filing_id in filing_ids
