"""Tests for api.py - the FastAPI transport layer (provided, frozen).

api.py has no learner task attached to it, but was 0% covered: no test file
exercised the app at all. These tests add that coverage using only PROVIDED
repository functions (get_connection, init_db, find_by_filing_id,
get_audit_events, list_filings, list_review_queue) - none of them require
repository.save_package() (Task 6 / US-9, not yet implemented).

Isolation: repository.get_connection() is monkeypatched to always open a
temp-file sqlite database, ignoring whatever db_path argument it's called
with. Every provided repository function takes `db_path: Path = DB_PATH` as
a default evaluated at import time, so patching DB_PATH itself would not be
picked up - patching the one function everything else routes through is
what actually redirects all of api.py's DB access to the temp file.

The only endpoint behavior these tests cannot cover is a FRESH (non-replay)
POST /filings/process, since that calls repository.save_package() -
covered separately once US-9 lands.
"""
import sqlite3
import pytest
from fastapi.testclient import TestClient

from coc_filing_assistant import api, repository


@pytest.fixture
def client(tmp_path, monkeypatch):
    db_path = tmp_path / "test_coc_filings.db"

    def fake_get_connection(path=repository.DB_PATH):
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    monkeypatch.setattr(repository, "get_connection", fake_get_connection)
    with TestClient(api.app) as c:
        yield c


def _insert_filing(db_path_conn, filing_id, status="HANDOFF_READY", risk_tier="LOW",
                    review_queue=None, confidence_score=0.9):
    db_path_conn.execute(
        "INSERT INTO coc_filings (filing_id, status, risk_tier, review_queue, "
        "confidence_score, error_reason, assembled_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (filing_id, status, risk_tier, review_queue, confidence_score, None,
         "2026-08-17T12:00:00"),
    )
    db_path_conn.commit()


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------

def test_health_ok_reports_chunk_counts(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert "policy_chunks" in body and "regulatory_chunks" in body


def test_health_degrades_when_vector_store_unreachable(client, monkeypatch):
    import chromadb

    def boom(*args, **kwargs):
        raise RuntimeError("vector store unreachable")

    monkeypatch.setattr(chromadb, "PersistentClient", boom)
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["policy_chunks"] == 0
    assert body["regulatory_chunks"] == 0


# ---------------------------------------------------------------------------
# FilingRequest validation
# ---------------------------------------------------------------------------

def _valid_filing_payload(filing_id="API-TEST-001"):
    return {
        "filing_id": filing_id, "filing_type": "NEW", "payer_name": "Acme",
        "plan_type": "PPO", "state": "TX", "effective_date": "2026-01-01",
        "prior_auth_language": "x", "pharmacy_language": "x",
        "exclusion_clauses": "x", "network_language": "x",
        "benefit_summary": "x", "mandatory_sections_present": ["benefits"],
        "submitted_by": "tester",
    }


def test_process_filing_rejects_unknown_field(client):
    payload = _valid_filing_payload()
    payload["unexpected_field"] = "not allowed"
    resp = client.post("/filings/process", json=payload)
    assert resp.status_code == 422


def test_process_filing_idempotent_replay_skips_pipeline(client, monkeypatch):
    """Seeds a row directly (never calling save_package()) so service.process()
    takes its idempotent-replay branch - exercises api.py's full response
    construction without needing US-9."""
    conn = repository.get_connection()
    _insert_filing(conn, "API-TEST-001", status="HANDOFF_READY", risk_tier="LOW",
                    review_queue="OPERATIONS", confidence_score=0.95)
    conn.close()

    called = {"run_pipeline": False}
    monkeypatch.setattr(
        "coc_filing_assistant.supervisor.run_pipeline",
        lambda item: called.update(run_pipeline=True) or (_ for _ in ()).throw(
            AssertionError("run_pipeline must not be called on idempotent replay")
        ),
    )

    resp = client.post("/filings/process", json=_valid_filing_payload("API-TEST-001"))
    assert resp.status_code == 200
    body = resp.json()
    assert body["filing_id"] == "API-TEST-001"
    assert body["idempotent_replay"] is True
    assert body["status"] == "HANDOFF_READY"
    assert body["review_queue"] == "OPERATIONS"
    assert called["run_pipeline"] is False


# ---------------------------------------------------------------------------
# /filings, /filings/{id}
# ---------------------------------------------------------------------------

def test_list_filings_empty(client):
    resp = client.get("/filings")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_filings_with_rows(client):
    conn = repository.get_connection()
    _insert_filing(conn, "API-TEST-002")
    conn.close()
    resp = client.get("/filings")
    assert resp.status_code == 200
    assert any(f["filing_id"] == "API-TEST-002" for f in resp.json())


def test_get_filing_not_found_returns_404(client):
    resp = client.get("/filings/DOES-NOT-EXIST")
    assert resp.status_code == 404


def test_get_filing_found_includes_audit_events(client):
    conn = repository.get_connection()
    _insert_filing(conn, "API-TEST-003")
    conn.execute(
        "INSERT INTO agent_audit_events (filing_id, agent_name, input_hash, "
        "output_summary, confidence, status, error_message, executed_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        ("API-TEST-003", "RuleEngine", "abc123", "0 rules flagged", None,
         "SUCCESS", None, "2026-08-17T12:00:00"),
    )
    conn.commit()
    conn.close()

    resp = client.get("/filings/API-TEST-003")
    assert resp.status_code == 200
    body = resp.json()
    assert body["filing_id"] == "API-TEST-003"
    assert len(body["audit_events"]) == 1
    assert body["audit_events"][0]["agent_name"] == "RuleEngine"


# ---------------------------------------------------------------------------
# /audit-log, /review-queue, /risk-report
# ---------------------------------------------------------------------------

def test_audit_log_returns_rows_ordered(client):
    conn = repository.get_connection()
    _insert_filing(conn, "API-TEST-004")
    conn.execute(
        "INSERT INTO agent_audit_events (filing_id, agent_name, input_hash, "
        "output_summary, confidence, status, error_message, executed_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        ("API-TEST-004", "MLService", "def456", "risk_tier=LOW", 0.1,
         "SUCCESS", None, "2026-08-17T12:01:00"),
    )
    conn.commit()
    conn.close()

    resp = client.get("/audit-log")
    assert resp.status_code == 200
    rows = resp.json()
    assert any(r["agent_name"] == "MLService" for r in rows)


def test_review_queue_endpoint(client):
    conn = repository.get_connection()
    conn.execute(
        "INSERT INTO review_queue (filing_id, queue_name, status, risk_tier, "
        "confidence_score, assembled_at) VALUES (?, ?, ?, ?, ?, ?)",
        ("API-TEST-005", "LEGAL", "NEEDS_REVIEW", "MEDIUM", 0.5, "2026-08-17T12:00:00"),
    )
    conn.commit()
    conn.close()

    resp = client.get("/review-queue")
    assert resp.status_code == 200
    assert any(r["filing_id"] == "API-TEST-005" for r in resp.json())


def test_risk_report_aggregates_by_tier(client):
    conn = repository.get_connection()
    _insert_filing(conn, "RISK-HIGH", status="NEEDS_REVIEW", risk_tier="HIGH")
    _insert_filing(conn, "RISK-MED", status="HANDOFF_READY", risk_tier="MEDIUM")
    _insert_filing(conn, "RISK-LOW", status="HANDOFF_READY", risk_tier="LOW")
    _insert_filing(conn, "RISK-ERR", status="PIPELINE_ERROR", risk_tier=None)
    conn.close()

    resp = client.get("/risk-report")
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 4
    assert body["HIGH"] == 1
    assert body["MEDIUM"] == 1
    assert body["LOW"] == 1
    assert body["PIPELINE_ERROR"] == 1
    assert body["high_risk_filings"] == ["RISK-HIGH"]


# ---------------------------------------------------------------------------
# /dashboard
# ---------------------------------------------------------------------------

def test_dashboard_shows_placeholder_when_empty(client):
    resp = client.get("/dashboard")
    assert resp.status_code == 200
    assert "No filings yet" in resp.text


def test_dashboard_renders_rows_with_status_colors(client):
    conn = repository.get_connection()
    for filing_id, status, risk_tier, queue, conf in [
        ("DASH-READY", "HANDOFF_READY", "LOW", "OPERATIONS", 0.95),
        ("DASH-REVIEW", "NEEDS_REVIEW", "MEDIUM", "LEGAL", 0.5),
        ("DASH-ERR", "PIPELINE_ERROR", None, "OPERATIONS", None),
    ]:
        conn.execute(
            "INSERT INTO review_queue (filing_id, queue_name, status, risk_tier, "
            "confidence_score, assembled_at) VALUES (?, ?, ?, ?, ?, ?)",
            (filing_id, queue, status, risk_tier, conf, "2026-08-17T12:00:00"),
        )
    conn.commit()
    conn.close()

    resp = client.get("/dashboard")
    assert resp.status_code == 200
    assert "DASH-READY" in resp.text
    assert "DASH-REVIEW" in resp.text
    assert "DASH-ERR" in resp.text
