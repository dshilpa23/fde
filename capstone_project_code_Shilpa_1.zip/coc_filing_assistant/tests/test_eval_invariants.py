"""Prove `harness.check_invariants()` implements `eval_spec.md` §4 correctly.

§4 names four rules that must never regress between commits. Nothing computed them
before, so they were a comment rather than a check. These tests hand-build domain objects
directly, which is why they can run now: no service implementation is required.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from coc_filing_assistant.domain import (
    AgentEvent,
    HandoffPackage,
    ReviewResult,
    RiskScore,
)
from evals import harness

AGENT_NAMES = ("RuleEngine", "MLService", "RAGRetrieve", "RAGDraft")


def _event(name: str, status: str = "SUCCESS", summary: str = "ok") -> AgentEvent:
    """Build one audit event."""
    return AgentEvent(
        agent_name=name,
        filing_id="FILING-MED-001",
        input_hash="0123456789abcdef",
        output_summary=summary,
        confidence=0.8,
        status=status,
        error_message=None,
    )


def _risk(composite: float = 0.54) -> RiskScore:
    """Build a risk score with a caller-chosen composite."""
    return RiskScore(
        filing_id="FILING-MED-001",
        sla_delay_probability=0.6,
        escalation_probability=0.45,
        review_effort_score=0.6,
        composite_risk=composite,
        risk_tier="MEDIUM",
        model_version="feature-weighted-v1.0",
    )


def _package(
    status: str = "HANDOFF_READY",
    composite: float = 0.54,
    confidence: float = 0.82,
) -> HandoffPackage:
    """Build a fully populated handoff package."""
    return HandoffPackage(
        filing_id="FILING-MED-001",
        rule_output=None,
        risk_score=_risk(composite),
        filing_summary=None,
        review_result=ReviewResult(
            confidence_score=confidence, ungrounded_claims=[], recommendation="APPROVE"
        ),
        status=status,
        error_reason=None,
        review_queue=None,
    )


def test_clean_successful_run_has_no_violations():
    """Four SUCCESS events on a populated package is the clean case."""
    events = [_event(name) for name in AGENT_NAMES]
    assert harness.check_invariants(_package(), events) == []


def test_wrong_event_count_is_a_violation():
    """A successful run with three events breaks the audit-trail guarantee."""
    events = [_event(name) for name in AGENT_NAMES[:3]]
    violations = harness.check_invariants(_package(), events)
    assert any("expected 4 agent events" in v for v in violations), violations


def test_oversized_output_summary_is_a_violation():
    """`output_summary` above 200 chars breaks safety_rules.md rule 2."""
    events = [_event(name) for name in AGENT_NAMES]
    events[1] = _event("MLService", summary="x" * 201)
    violations = harness.check_invariants(_package(), events)
    assert any("output_summary for MLService is 201 chars" in v for v in violations), violations


def test_out_of_range_scores_are_violations():
    """composite_risk and confidence_score must stay inside [0.0, 1.0]."""
    events = [_event(name) for name in AGENT_NAMES]
    violations = harness.check_invariants(
        _package(composite=1.4, confidence=-0.2), events
    )
    assert any("composite_risk 1.4 outside" in v for v in violations), violations
    assert any("confidence_score -0.2 outside" in v for v in violations), violations


def test_handoff_ready_with_a_failure_event_is_a_violation():
    """HANDOFF_READY must never coexist with a FAILURE event (safety_rules.md rule 6)."""
    events = [_event(name) for name in AGENT_NAMES]
    events[3] = _event("RAGDraft", status="FAILURE")
    violations = harness.check_invariants(_package(), events)
    assert any("HANDOFF_READY set while an AgentEvent reports FAILURE" in v for v in violations), (
        violations
    )


def test_pipeline_error_with_partial_events_is_clean():
    """A degraded PIPELINE_ERROR run is not an invariant violation.

    §4 pins the four-event count for a *successful* run. This is the boundary a naive
    implementation gets wrong twice over: by counting events on an errored package, and
    by dereferencing the Optional members that are legitimately None here.
    """
    package = HandoffPackage(
        filing_id="FILING-ERR-001",
        rule_output=None,
        risk_score=None,
        filing_summary=None,
        review_result=None,
        status="PIPELINE_ERROR",
        error_reason="RuleEngineError: empty filing",
        review_queue=None,
    )
    events = [_event("RuleEngine", status="FAILURE"), _event("MLService")]
    assert harness.check_invariants(package, events) == []
