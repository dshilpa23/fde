"""Enforce that the eval harness stays runnable without pytest.

`specs/eval_spec.md` §0.2 requires no module under `evals/` to import pytest or conftest:
the harness is a standalone program, and `release_rules.md` expects it to gate a release
from a plain shell. Without this test the rule is a comment that the next contributor
breaks silently, and the breakage only surfaces on a machine with no dev dependencies.
"""
from __future__ import annotations

import ast
from pathlib import Path

EVALS_DIR = Path(__file__).parent.parent / "evals"
FORBIDDEN = {"pytest", "conftest"}

# filings, harness, run_all, and the three eval_* suites. Guards against a glob that
# matches nothing and lets this test pass vacuously.
MIN_EXPECTED_MODULES = 6


def _imported_roots(tree: ast.AST) -> set[str]:
    """Collect the top-level module name of every import in a parsed file."""
    roots: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            roots.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            roots.add(node.module.split(".", 1)[0])
    return roots


def test_evals_never_import_pytest_or_conftest():
    """No module under evals/, at any depth, may import pytest or conftest."""
    modules = sorted(EVALS_DIR.rglob("*.py"))
    assert len(modules) >= MIN_EXPECTED_MODULES, (
        f"found only {len(modules)} modules under {EVALS_DIR}; "
        "the scan is not reaching the harness"
    )

    offenders: dict[str, set[str]] = {}
    for path in modules:
        # Parse the AST rather than substring-matching, so a docstring that mentions
        # pytest does not fail the test.
        roots = _imported_roots(ast.parse(path.read_text(), filename=str(path)))
        forbidden = roots & FORBIDDEN
        if forbidden:
            offenders[path.name] = forbidden

    assert not offenders, f"evals/ must not import a test framework: {offenders}"
