"""Prove `evals/filings.py` has not drifted from the frozen conftest fixtures.

`tests/conftest.py` is frozen and exposes the five synthetic filings as pytest fixtures,
which a standalone eval script cannot import. `evals/filings.py` therefore holds a second
copy for runtime use. This module is the only place permitted to reference both
representations (`specs/eval_spec.md` §0.2), and it is what turns that duplication from a
silent drift risk into a test failure.
"""
from __future__ import annotations

import sys
from pathlib import Path

# conftest.py puts `src` on the path but not the repo root, which is what `evals` needs.
sys.path.insert(0, str(Path(__file__).parent.parent))

from coc_filing_assistant.domain import COCFilingItem
from evals import filings, harness

# Asserted literally rather than derived, so a field added to or removed from
# COCFilingItem fails here instead of silently shrinking every comparison below.
COC_FILING_ITEM_FIELDS = {
    "filing_id",
    "filing_type",
    "payer_name",
    "plan_type",
    "state",
    "effective_date",
    "prior_auth_language",
    "pharmacy_language",
    "exclusion_clauses",
    "network_language",
    "benefit_summary",
    "mandatory_sections_present",
    "submitted_by",
}


def test_high_risk_parity(filing_high_risk):
    """The high-risk factory matches the frozen fixture field for field."""
    assert harness.business_fields(filing_high_risk) == harness.business_fields(
        filings.high_risk()
    )


def test_medium_risk_parity(filing_medium_risk):
    """The medium-risk factory matches the frozen fixture field for field."""
    assert harness.business_fields(filing_medium_risk) == harness.business_fields(
        filings.medium_risk()
    )


def test_low_risk_parity(filing_low_risk):
    """The low-risk factory matches the frozen fixture field for field."""
    assert harness.business_fields(filing_low_risk) == harness.business_fields(
        filings.low_risk()
    )


def test_pipeline_error_parity(filing_pipeline_error):
    """The pipeline-error factory matches the frozen fixture field for field."""
    assert harness.business_fields(filing_pipeline_error) == harness.business_fields(
        filings.pipeline_error()
    )


def test_idempotency_parity(filing_idempotency):
    """The idempotency factory matches the frozen fixture field for field."""
    assert harness.business_fields(filing_idempotency) == harness.business_fields(
        filings.idempotency()
    )


def test_factories_are_fresh_and_fully_compared():
    """Each factory returns a new object, and parity compares every business field.

    The field-coverage half of this test is the anti-vacuity guard: without it, a
    mis-specified `GENERATED_TIMESTAMP_FIELDS` could exclude real data and leave the five
    parity tests above passing while comparing almost nothing.
    """
    assert set(filings.ALL) == {
        "low_risk", "idempotency", "medium_risk", "high_risk", "pipeline_error",
    }

    for name, factory in filings.ALL.items():
        first, second = factory(), factory()
        assert isinstance(first, COCFilingItem), name
        assert first == second, f"{name} factories disagree"
        assert first is not second, f"{name} returned a shared instance"
        assert first.mandatory_sections_present is not second.mandatory_sections_present, (
            f"{name} handed out a shared list — one suite could mutate another's input"
        )
        assert set(harness.business_fields(first)) == COC_FILING_ITEM_FIELDS, (
            f"{name}: business_fields() dropped a field from comparison"
        )
