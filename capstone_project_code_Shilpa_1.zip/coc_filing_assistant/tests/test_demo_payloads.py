"""The committed demo payloads must still match the fixtures they came from.

`demo_payloads/*.json` are derived artifacts pasted into the Swagger UI during a live
demo. If a fixture in `evals/filings.py` changes and the payloads are not regenerated,
the demo would silently submit stale input - a failure that would surface on camera
rather than in CI. These tests make that drift a test failure instead.

Run: python -m pytest tests/test_demo_payloads.py -v
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from demo_payloads.generate import FIXTURES, payload_for  # noqa: E402

PAYLOAD_DIR = REPO_ROOT / "demo_payloads"


@pytest.mark.implementation
@pytest.mark.parametrize("builder", FIXTURES, ids=lambda b: b.__name__)
def test_committed_payload_matches_its_fixture(builder):
    """Each committed JSON equals the current fixture, field for field."""
    expected = payload_for(builder)
    path = PAYLOAD_DIR / f"{expected['filing_id']}.json"
    assert path.exists(), f"missing demo payload {path.name} - run demo_payloads/generate.py"
    assert json.loads(path.read_text()) == expected, (
        f"{path.name} is stale - run demo_payloads/generate.py and commit the result"
    )


@pytest.mark.implementation
def test_payload_fields_match_the_api_request_contract():
    """Payload keys match FilingRequest exactly.

    `FilingRequest` sets `extra="forbid"`, so a payload carrying an unexpected key would
    return 422 mid-demo rather than processing the filing.
    """
    from coc_filing_assistant.api import FilingRequest

    expected_fields = set(FilingRequest.model_fields)
    for builder in FIXTURES:
        payload = payload_for(builder)
        assert set(payload) == expected_fields, (
            f"{payload['filing_id']} fields diverge from FilingRequest: "
            f"extra={set(payload) - expected_fields}, missing={expected_fields - set(payload)}"
        )


@pytest.mark.implementation
def test_every_payload_carries_a_usable_filing_id():
    """Guards against a generator regression writing bodies with no identity."""
    ids = [payload_for(builder)["filing_id"] for builder in FIXTURES]
    assert all(fid.startswith("FILING-") for fid in ids), ids
    assert len(set(ids)) == len(ids), f"filing_id collision would break idempotency: {ids}"


@pytest.mark.implementation
def test_only_the_empty_field_fixture_is_sparse():
    """`FILING-ERR-001` is deliberately sparse; the other four must stay populated.

    `testing_rules.md` requires an empty-field item, and `filings.pipeline_error()` is
    it - blank strings and an empty `mandatory_sections_present` are the point, since
    that is what makes every MISSING_INFO rule fire. Pinning which payload is allowed
    to be sparse means a generator bug that blanks a *different* fixture still fails.
    """
    sparse = {
        payload_for(builder)["filing_id"]
        for builder in FIXTURES
        if not payload_for(builder)["mandatory_sections_present"]
    }
    assert sparse == {"FILING-ERR-001"}, f"unexpected sparse payloads: {sparse}"

    for builder in FIXTURES:
        payload = payload_for(builder)
        if payload["filing_id"] == "FILING-ERR-001":
            continue
        blank = [
            key for key, value in payload.items()
            if isinstance(value, str) and not value.strip()
        ]
        assert not blank, f"{payload['filing_id']} has unexpected blank fields: {blank}"
