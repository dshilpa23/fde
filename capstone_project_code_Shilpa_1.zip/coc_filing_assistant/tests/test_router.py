"""Tests for router.py.

Run all: python -m pytest tests/test_router.py -v
"""
import pytest
from datetime import datetime
from coc_filing_assistant.domain import HandoffPackage, RuleEngineOutput, RuleCheckResult, RiskScore


def make_package(status, rule_categories=None, risk_tier="MEDIUM"):
    rule_results = []
    if rule_categories:
        for cat in rule_categories:
            rule_results.append(RuleCheckResult(
                rule_id=f"R-{cat}", category=cat,
                severity="HIGH", description=f"{cat} issue",
                filing_section="Section 1", evidence="",
            ))
    rule_output = RuleEngineOutput(
        filing_id="TEST-001",
        rule_results=rule_results,
        overall_flag="FLAG" if rule_results else "PASS",
    )
    risk_score = RiskScore(
        filing_id="TEST-001",
        sla_delay_probability=0.5,
        escalation_probability=0.5,
        review_effort_score=0.5,
        composite_risk={"HIGH": 0.75, "MEDIUM": 0.5, "LOW": 0.2}[risk_tier],
        risk_tier=risk_tier,
        model_version="v1.0",
    )
    return HandoffPackage(
        filing_id="TEST-001",
        rule_output=rule_output,
        risk_score=risk_score,
        filing_summary=None,
        review_result=None,
        status=status,
        error_reason=None,
        review_queue=None,
    )


@pytest.mark.baseline
def test_router_imports():
    from coc_filing_assistant import router
    assert hasattr(router, "route")


@pytest.mark.implementation
def test_pipeline_error_routes_to_operations():
    from coc_filing_assistant.router import route
    pkg = make_package("PIPELINE_ERROR")
    assert route(pkg) == "OPERATIONS"


@pytest.mark.implementation
def test_prior_auth_routes_to_legal():
    from coc_filing_assistant.router import route
    pkg = make_package("NEEDS_REVIEW", rule_categories=["PRIOR_AUTH"])
    assert route(pkg) == "LEGAL"


@pytest.mark.implementation
def test_pharmacy_routes_to_pharmacy():
    from coc_filing_assistant.router import route
    pkg = make_package("NEEDS_REVIEW", rule_categories=["PHARMACY"])
    assert route(pkg) == "PHARMACY"


@pytest.mark.implementation
def test_high_risk_routes_to_actuarial():
    from coc_filing_assistant.router import route
    pkg = make_package("HANDOFF_READY", rule_categories=[], risk_tier="HIGH")
    result = route(pkg)
    assert result in {"ACTUARIAL", "LEGAL"}, (
        f"HIGH risk without rule flags should route to ACTUARIAL or LEGAL, got {result}"
    )


@pytest.mark.implementation
def test_route_returns_valid_queue_name(filing_medium_risk):
    from coc_filing_assistant.supervisor import run_pipeline
    from coc_filing_assistant.router import route
    package, _ = run_pipeline(filing_medium_risk)
    result = route(package)
    assert result in {"LEGAL", "PHARMACY", "ACTUARIAL", "NETWORK", "OPERATIONS"}, (
        f"route() must return one of the 5 valid queue names, got {result!r}"
    )


@pytest.mark.implementation
def test_network_routes_to_network():
    """testing_rules.md floor: one test per queue - NETWORK was missing."""
    from coc_filing_assistant.router import route
    pkg = make_package("NEEDS_REVIEW", rule_categories=["NETWORK"])
    assert route(pkg) == "NETWORK"


@pytest.mark.implementation
def test_priority_legal_beats_pharmacy_when_both_fire():
    """testing_rules.md floor: explicit priority resolution when two triggers
    fire - LEGAL > PHARMACY per the documented order."""
    from coc_filing_assistant.router import route
    pkg = make_package("NEEDS_REVIEW", rule_categories=["PRIOR_AUTH", "PHARMACY"])
    assert route(pkg) == "LEGAL"


@pytest.mark.implementation
def test_priority_pharmacy_beats_actuarial_when_both_fire():
    from coc_filing_assistant.router import route
    pkg = make_package("HANDOFF_READY", rule_categories=["PHARMACY"], risk_tier="HIGH")
    assert route(pkg) == "PHARMACY"


@pytest.mark.implementation
def test_priority_actuarial_beats_network_when_both_fire():
    from coc_filing_assistant.router import route
    pkg = make_package("NEEDS_REVIEW", rule_categories=["NETWORK"], risk_tier="HIGH")
    assert route(pkg) == "ACTUARIAL"


@pytest.mark.implementation
def test_missing_info_falls_back_to_operations():
    """MISSING_INFO has no dedicated queue - router.py docstring item 5."""
    from coc_filing_assistant.router import route
    pkg = make_package("NEEDS_REVIEW", rule_categories=["MISSING_INFO"])
    assert route(pkg) == "OPERATIONS"


@pytest.mark.implementation
def test_route_never_raises_on_none_rule_output_or_risk_score():
    """router.py docstring: must not raise exceptions for a valid
    HandoffPackage - rule_output/risk_score are Optional in domain.py."""
    from coc_filing_assistant.router import route
    from coc_filing_assistant.domain import HandoffPackage
    pkg = HandoffPackage(
        filing_id="TEST-002", rule_output=None, risk_score=None,
        filing_summary=None, review_result=None, status="NEEDS_REVIEW",
        error_reason=None, review_queue=None,
    )
    result = route(pkg)
    assert result in {"LEGAL", "PHARMACY", "ACTUARIAL", "NETWORK", "OPERATIONS"}
