"""Build the sanitized local Arize artifacts from what actually ran.

Reads `evals/results/*.json` (the harness's own envelopes - already sanitized per
`eval_spec.md` §0.8) and `evals/arize/traces.jsonl` (already sanitized per
`observability.py`'s `safe_attrs()`), and produces two derived, reproducible artifacts:

  evals/arize/eval_results.csv     - one row per (suite, case, metric) observed value
  evals/arize/latency_summary.json - count/min/mean/p50/p90/p95/max per instrumented stage

Both are pure functions of files already on disk - this script performs no LLM call, no
retrieval, no pipeline run of its own. Run it after `evals/run_all.py` (or any subset of
eval/test runs that populated `traces.jsonl`).

Run: python evals/arize/build_artifacts.py
"""
from __future__ import annotations

import csv
import json
import statistics
import sys
from pathlib import Path

ARIZE_DIR = Path(__file__).resolve().parent
REPO_ROOT = ARIZE_DIR.parent.parent
RESULTS_DIR = REPO_ROOT / "evals" / "results"
TRACES_PATH = ARIZE_DIR / "traces.jsonl"
CSV_PATH = ARIZE_DIR / "eval_results.csv"
LATENCY_PATH = ARIZE_DIR / "latency_summary.json"

# Stages given a named, human-readable row in the latency summary, beyond the raw
# per-span-name breakdown (which is emitted for every span name observed, not just
# these). Mirrors `specs/eval_spec.md` §... latency reporting requirements: end-to-end,
# RAG retrieval, and LLM generation are the three the user explicitly asked to see
# broken out separately.
_NAMED_STAGES = {
    "Supervisor.run_pipeline": "end_to_end_pipeline",
    "RAGService.retrieve": "rag_retrieval",
    "RAGService.draft_summary": "llm_generation",
    "RuleEngine.run_checks": "rule_engine",
    "MLService.score_risk": "ml_risk_scoring",
    "Router.route": "router",
    "Repository.save_package": "repository_save",
}


def _build_eval_results_csv() -> int:
    rows: list[list[object]] = []
    for path in sorted(RESULTS_DIR.glob("*.json")):
        if path.name == "baseline.json":
            continue
        envelope = json.loads(path.read_text())
        suite = envelope.get("meta", {}).get("suite", path.stem)
        for case in envelope.get("results", []):
            for metric, value in case.get("observed", {}).items():
                rows.append([suite, case["name"], case["outcome"], case["required"], metric, value])

    CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["suite", "case", "outcome", "required", "metric", "value"])
        writer.writerows(rows)
    return len(rows)


def _percentile(sorted_values: list[float], pct: float) -> float:
    """Nearest-rank percentile - no interpolation, so the reported value is always
    one of the actual observed samples, never a number nothing in the sample produced."""
    if not sorted_values:
        return 0.0
    k = max(0, min(len(sorted_values) - 1, int(round(pct / 100 * (len(sorted_values) - 1)))))
    return sorted_values[k]


def _stage_stats(durations_ms: list[float]) -> dict:
    ordered = sorted(durations_ms)
    n = len(ordered)
    return {
        "count": n,
        "min_ms": round(ordered[0], 2),
        "mean_ms": round(statistics.fmean(ordered), 2),
        "p50_ms": round(_percentile(ordered, 50), 2),
        "p90_ms": round(_percentile(ordered, 90), 2),
        "p95_ms": round(_percentile(ordered, 95), 2),
        "max_ms": round(ordered[-1], 2),
        "note": (
            "Observed on this small synthetic evaluation sample - not a production "
            "SLA estimate." if n < 30 else "Observed on the evaluation sample."
        ),
    }


def _build_latency_summary() -> dict:
    if not TRACES_PATH.exists():
        return {"stages": {}, "notice": "no traces.jsonl found - run the test/eval suites first"}

    durations_by_name: dict[str, list[float]] = {}
    with open(TRACES_PATH, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            record = json.loads(line)
            durations_by_name.setdefault(record["name"], []).append(record["duration_ms"])

    stages = {}
    for span_name, durations in sorted(durations_by_name.items()):
        label = _NAMED_STAGES.get(span_name, span_name)
        stages[label] = {"span_name": span_name, **_stage_stats(durations)}

    summary = {
        "stages": stages,
        "sample_disclaimer": (
            "All statistics here are Measured values from the synthetic 5-filing "
            "evaluation sample plus this repository's own test suite, run on a "
            "developer workstation - not a Future production target and not a "
            "validated Threshold. See evals/arize/README.md."
        ),
    }
    return summary


def main() -> int:
    row_count = _build_eval_results_csv()
    print(f"wrote {CSV_PATH} ({row_count} rows)")

    summary = _build_latency_summary()
    LATENCY_PATH.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(f"wrote {LATENCY_PATH} ({len(summary.get('stages', {}))} stages)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
