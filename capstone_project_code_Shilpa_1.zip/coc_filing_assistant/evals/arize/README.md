# Arize observability layer

Supplementary observability and AI-quality evaluation on top of the COC Filing
Readiness Assistant pipeline. **This layer never gates a release.** The repository's
existing evaluation harness (`evals/harness.py`, `evals/eval_*.py`, `specs/eval_spec.md`)
remains the sole release-gating source of truth: pytest, the deterministic eval
assertions, and the safety checks in `safety_spec.md` are unaffected by anything in
this directory. Arize/OpenTelemetry adds a second, independent view onto the same
runs — useful for interactive debugging and for a small set of LLM-judge scores that
supplement (never replace) the deterministic citation-grounding check.

## What was instrumented

Every meaningful pipeline stage opens its own OpenTelemetry span, nested automatically
under a root span for the whole run:

| Span | Where | What it records |
|---|---|---|
| `Supervisor.run_pipeline` | `supervisor.py` | root span for the whole filing run; final `status`, `audit_event_count`, `agent_names` |
| `RuleEngine.run_checks` | `rule_engine.py` | `rule_count`, `overall_flag`, `fired_categories`, HIGH/MEDIUM counts |
| `MLService.score_risk` | `ml_service.py` | `risk_tier`, `composite_risk`, `model_version` |
| `RAGService.retrieve` | `rag_service.py` | `chunk_count`, `collections_hit`, `retrieved_source_docs`, `top_similarity` |
| `RAGService.draft_summary` | `rag_service.py` | LLM generation stage: `llm_deployment`, `citation_count`, `verified_citation_count`, `confidence_score`, `recommendation`, token counts where the endpoint returns them |
| `Router.route` | `router.py` | `status` in, `review_queue` out |
| `Repository.save_package` | `repository.py` | `status`, `audit_event_count`, `review_queue` |

Two frozen files sit between the API boundary and these spans and could not be
instrumented directly: `api.py` and `service.py` (both on the do-not-modify list in
`CLAUDE.md` §3 / `project_rules.md`). `Supervisor.run_pipeline`'s root span is the
closest available proxy for "the whole filing pipeline" — it covers all four service
calls, but not `service.py`'s idempotency check or `api.py`'s post-hoc `router.route()`
call for a fresh filing. This is a disclosed limitation, not an oversight.

No business behavior changed to make this instrumentation possible. Every span wraps
existing logic; nothing was reordered, retried, or given new side effects to make it
"easier to trace."

## How traces are generated

`src/coc_filing_assistant/observability.py` configures one process-wide OpenTelemetry
`TracerProvider` the first time any stage asks for a tracer. It always attaches a
`SimpleSpanProcessor` writing sanitized spans to `evals/arize/traces.jsonl` (this file).
If `ARIZE_API_KEY` and `ARIZE_SPACE_ID` are both set, it *additionally* attaches a
`BatchSpanProcessor` exporting the same spans via OTLP/gRPC directly to Arize
(`otlp.arize.com:443` by default, or `ARIZE_OTLP_ENDPOINT`). If either variable is
absent, Arize export is simply never configured — tracing continues local-only, with no
error and no behavior change to the pipeline.

Integration path chosen: **raw OpenTelemetry SDK + OTLP/gRPC exporter**, not the
`arize-otel` or `openinference-instrumentation-*` packages. Those packages were not
already installed in this project's environment; `opentelemetry-api`,
`opentelemetry-sdk`, and `opentelemetry-exporter-otlp-proto-grpc` were. Building on what
was already present avoided adding a new SDK dependency beyond the three OTel packages
themselves (added to `requirements.txt`, flagged to the project owner before use, since
`project_rules.md` states "no new dependencies").

## How Arize is configured

Four environment variables, read from `.env` exactly like every other credential in
this project (`.env.example` documents the placeholders):

- `ARIZE_API_KEY`
- `ARIZE_SPACE_ID`
- `ARIZE_PROJECT_NAME` — set to `capstone_project_code_shilpa`, an internal identifier
  chosen to associate traces in the Arize UI with this capstone submission. It is not
  claimed to exactly match the required `capstone_project_code_[YourName]_[CohortID].zip`
  naming convention from `README.md` (no Cohort ID is included) — it is a mnemonic
  label, not a naming-convention artifact.
- `ARIZE_OTLP_ENDPOINT` — defaults to `otlp.arize.com:443` if unset.

No Arize credential is ever read into a span attribute, logged, or written to any file
in this repository. `observability.py`'s attribute sanitizer additionally redacts any
string matching a labelled-credential or bare-token pattern defensively, on top of the
allowlist-by-construction discipline (call sites only ever pass short, named fields
through `safe_attrs()` — never a raw filing field, chunk text, or LLM response).

## How local artifacts are generated

```bash
python evals/run_all.py                 # runs risk_calibration, rag_quality, end_to_end
python evals/arize/build_artifacts.py   # derives eval_results.csv and latency_summary.json
```

`traces.jsonl` accumulates automatically as an append-only file every time any test or
eval process imports and runs the instrumented pipeline code — no separate step
required for it. `build_artifacts.py` is a pure post-processing script: it reads
`evals/results/*.json` and `evals/arize/traces.jsonl`, both already on disk, and writes
`eval_results.csv` (one row per suite/case/metric) and `latency_summary.json`
(count/min/mean/p50/p90/p95/max per stage). It performs no LLM call and no pipeline run
of its own, so re-running it is always safe and always reproducible from whatever is
already on disk.

## Evaluators used, and what each measures

| Evaluator | Kind | Measures | Gates a release? |
|---|---|---|---|
| Citation grounding (`rag_service._verify_citations`, wrapped by `arize_evaluators.judge_groundedness`) | Deterministic | Every citation excerpt is a verbatim substring of a chunk actually retrieved for that call, with matching `source_doc` | **Yes** — `grounding_rate` (floor 1.0) and `ungrounded_claim_count` (ceiling 0) are required, gating metrics |
| Retrieval precision/recall (`eval_rag_quality.eval_retrieval_precision_recall`) | Deterministic | 6 hand-labeled query → expected-source-document pairs against real `retrieve()` output | Yes — required case, sanity floor recall@5 ≥ 0.8 |
| Adversarial/red-team catalogue (5 cases + `eval_adversarial_chunk`) | Deterministic | Injected-instruction chunk text never changes `recommendation`/confidence math | Yes — required cases |
| `judge_hallucination` | LLM judge | Whether free-text summary claims (`executive_summary`, `flagged_issues`, `coverage_gaps`) are supported by the retrieved evidence — catches unsupported claims that carry no formal citation, invisible to the grounding check above | **No** — optional, `INFORMATIONAL` |
| `judge_answer_relevance` | LLM judge | Whether the drafted summary substantively addresses the filing's own rule-engine findings | No — optional, `INFORMATIONAL` |
| `judge_retrieval_relevance` | LLM judge | Topical relevance of retrieved chunks to the query context — deliberately not a fact a substring check can verify | No — optional, `INFORMATIONAL` |

**Tool-selection / tool-invocation evaluators were deliberately not used.**
`supervisor.run_pipeline()` invokes Rule Engine → ML Risk → RAG Retrieve → RAG Draft in
a fixed, code-authored sequence (`safety_rules.md` rule 7: all four always attempted,
never short-circuited). There is no point in this pipeline where an LLM chooses which
tool to call or constructs a tool's arguments — the only LLM call in the whole system
is `rag_service.draft_summary()`'s single, fixed-purpose text-generation call. Grading
a decision the model never made would be a meaningless metric;
`tests/test_supervisor.py`'s no-short-circuit test is the correct, and already
existing, source of truth for orchestration correctness.

## Score semantics — every metric, precisely

Every metric below either gates a release (fails `--release`, refuses
`--update-baseline`) or is `INFORMATIONAL` in `harness.py`'s `METRIC_POLICIES` (recorded,
never compared). Range and direction are stated so a reader never has to infer whether a
higher number is better.

| Metric | Range | Direction | Label mapping | Gating? |
|---|---|---|---|---|
| `grounding_rate` | `[0.0, 1.0]` | Higher is better; `1.0` required | — (no label, numeric only) | **Yes** — `THRESHOLD(floor=1.0)` |
| `ungrounded_claim_count` | `{0, 1, 2, …}` | Lower is better; `0` required | — | **Yes** — `THRESHOLD(ceiling=0)` |
| `confidence_score` (production `ReviewResult`) | `[0.0, 1.0]`, clamped at every producing boundary (`safety_rules.md` rule 5) | Higher is better; `< 0.70` flips `recommendation` to `FLAG_FOR_HUMAN` | — | Case-specific: `eval_clear_evidence.confidence_score` floor 0.70, `eval_no_evidence.confidence_score` ceiling 0.6999…; bare `confidence_score` elsewhere is `INFORMATIONAL` |
| `precision_at_5` / `recall_at_5` | `[0.0, 1.0]` | Higher is better | — | Yes — `DIRECTIONAL(non_decreasing)`, sanity floor recall@5 ≥ 0.8 checked in the case itself |
| `injection_followed_count` | `{0, 1}` | Lower is better; `0` required | — | **Yes** — `THRESHOLD(ceiling=0)` |
| `hallucination_score` (`judge_hallucination`) | `[0.0, 1.0]` or `null` on judge error | Higher = more supported by evidence; `1.0` = fully supported, `0.0` = evidence contradicts or omits the claim | Free-text judge label, e.g. `"Mostly Supported"`, `"Unsupported"`, `"judge_error"` on failure | No — `INFORMATIONAL` |
| `answer_relevance_score` (`judge_answer_relevance`) | `[0.0, 1.0]` or `null` | Higher = summary substantively engages the filing's own rule findings; `0.0` = ignores them entirely | e.g. `"fully_engaged"`, `"partially_engaged"`, `"judge_error"` | No — `INFORMATIONAL` |
| `retrieval_relevance_score` (`judge_retrieval_relevance`) | `[0.0, 1.0]` or `null` | Higher = retrieved evidence is topically on-point; `0.0` = unrelated | e.g. `"highly relevant"`, `"unrelated"`, `"judge_error"` | No — `INFORMATIONAL` |

**Judge label vocabulary is not a fixed enum.** The three LLM judges are prompted for a
`"label"` field but not given a closed set of allowed strings — the label is a
human-readable gloss on the numeric score, and the numeric score is what any downstream
comparison should key on. `label` is recorded for readability in `eval_results.csv` and
on the `ArizeJudge.*` span, never compared or gated (`judge_label` is `INFORMATIONAL`).
On any judge failure (unset credentials, transport error, unparseable JSON response),
`_run_judge()` returns `score=None, label="judge_error"` — `judge_error` is the one label
value that is a fixed sentinel, since it must be reliably distinguishable from a genuine
low score.

## Arize live verification (performed 2026-08-18)

Verified end-to-end with the user's own Arize credentials (`ARIZE_API_KEY`,
`ARIZE_SPACE_ID`) via the `ax` CLI (`arize-ax-cli`, already installed on this machine).

**Bug found and fixed first.** The initial export failed with `INVALID_ARGUMENT: trace
export requires project routing: set x-project-name header, arize.project.name,
openinference.project.name, or model_id`. Setting `arize.project.name` as an OTel
*resource* attribute (the original implementation) was not sufficient — Arize's
collector specifically checks the `x-project-name` OTLP header. Fixed in
`observability.py` by sending `ARIZE_PROJECT_NAME` as a header alongside `space_id`/
`api_key`, not only as a resource attribute.

| Check | Result |
|---|---|
| Project name | `capstone_project_code_shilpa` (auto-created by this fix's first successful export; visible via `ax projects list --space <NonProd space> --name capstone`) |
| Space | "Forward Deployed Engineer (NonProd)" |
| Controlled pipeline trace ID | `f0de5c75491f01a0b7ee27b045c45cdb` (one real `filing_medium_risk` run through `supervisor.run_pipeline()`) |
| Spans visible for that trace | All 5: `Supervisor.run_pipeline` (root), `RuleEngine.run_checks`, `MLService.score_risk`, `RAGService.retrieve`, `RAGService.draft_summary` (all 4 children correctly parented under the root span's `span_id`) — confirmed via `ax traces export`, byte-for-byte matching the local `traces.jsonl` record for the same run (`status=HANDOFF_READY`, `audit_event_count=4`, same `filing_id_hash`) |
| Eval/judge annotations visible | **Yes, after adding span instrumentation to `arize_evaluators._run_judge()`** (not present before this verification pass — see below) |
| Judge trace ID | `ArizeJudge.hallucination` span, exported and confirmed with `evaluator_score=0.85`, `evaluator_label="Mostly Supported"` — exact match to the value returned locally by `eval_hallucination_judge()` |

**What "eval annotations visible" means here, precisely.** This does not use Arize's
formal Annotations/Evaluations feature (the `ax annotation-configs` / `ax
annotation-queues` / `ax evaluators` surface, which expects evaluation results
associated with spans through a separate ingestion path). What was verified instead:
each of the three LLM-judge calls now opens its own `ArizeJudge.<name>` span carrying
`evaluator_score`/`evaluator_label`/`evaluator_explanation` as ordinary span attributes,
and that span — like every other pipeline span — is confirmed visible and queryable in
Arize via the CLI. This is genuine, verified visibility of the judge result data inside
Arize, not the platform's dedicated annotation UI surface. Wiring the latter is a
reasonable next step but was not requested or built in this pass.

## A finding worth reading before trusting `confidence_score` as "relevance"

`eval_no_evidence` (in `eval_rag_quality.py`) originally assumed a topically-mismatched
filing would produce a low `confidence_score`. Verified live, it does not: ChromaDB
always returns nearest neighbors (there is no "no match" result), and the LLM keeps
`confidence_score` at 1.0 by citing verbatim, genuinely-grounded boilerplate from the
mismatched chunks. **Grounding measures citation traceability, not topical relevance —
these are different properties.** The case now proves the mechanism `rag_spec.md` §7
actually specifies (zero retrieved chunks → zero citations → `confidence_score = 0.0`),
and separately records the real retrieval's `judge_retrieval_relevance` score as a
disclosed, non-gating data point showing the mismatch a grounding-only metric misses.
This is exactly the gap the LLM-judge relevance evaluator exists to surface.

A related, similarly-resolved finding lives in `eval_end_to_end.py`'s
`eval_correct_queue_routing`: the real `filing_pipeline_error` fixture never actually
fails a stage (so it routes to LEGAL, not the OPERATIONS the original spec assumed) —
resolved by forcing a genuine failure to prove the OPERATIONS mapping, with the real
fixture's actual routing recorded as a disclosed, non-asserted finding. The equivalent
`filing_low_risk` question (2026-08-18) was resolved the *other* way: verified live to
correctly route to OPERATIONS by design (zero rule categories, LOW tier), `eval_spec.md`
§3 was corrected to match, and `filing_low_risk` is now the gating assertion itself — a
separate lightly-flagged filing remains only as additional, non-substitute coverage of
the LEGAL/ACTUARIAL path at LOW risk. Both are the same category of
spec-assumption-vs-verified-behavior gap already resolved for US-3 and US-7 elsewhere in
this repo; all three were resolved by explicit decision, recorded in `plan.md`, rather
than silently rewritten.

## Why `eval_clear_evidence.confidence_score` varies between runs (investigated, not "fixed")

Observed committed value: `0.7143` (5/7 citations grounded). Re-run live three more
times against the identical fixture and prompt: `1.0` (7/7), `0.857` (6/7), `1.0` (8/8).
**This is call-to-call LLM citation-copying variance, not a scoring bug, a threshold
issue, or a difference between `eval_clear_evidence` and `eval_partial_evidence`** — no
threshold was changed to produce this explanation.

Root cause, captured directly from a reproduced ungrounded case: the retrieved chunk
contains

```
Standard: 3 business days from receipt of complete request
- Urgent: 1 business day from receipt of complete request
```

and the LLM's citation excerpt for the same underlying claim was

```
Standard: 3 business days from receipt of complete request. Urgent: 1 business day from receipt of complete request
```

Semantically identical; not byte-identical. The LLM replaced the newline-dash line break
with a period when copying, which survives `_normalize()`'s whitespace collapse as a
*different* token sequence (`"request - urgent"` vs `"request. urgent"`), so the
verbatim-substring grounding check correctly reports this specific citation as
ungrounded — it is not a fabricated citation, but it does not pass the same bar a
byte-exact quote would. `confidence_score = verified/total` then drops proportionally to
however many of that call's citations happened to get lightly reformatted this way.

This is the accepted cost of the strict-substring grounding design
(`rag_spec.md` §4 / `safety_spec.md` §3): a citation must be a real, traceable quote, not
"close enough" — the alternative (fuzzy/semantic matching) would let a plausible-sounding
but altered claim pass as grounded, which is the actual hallucination risk `safety_spec.md`
exists to prevent. The threshold (0.70) and the grounding check were **not** changed to
make any particular run's number look better, per instruction; this section exists so the
variance is understood rather than mistaken for a defect.

## Privacy and redaction rules

Applies uniformly to Arize-exported spans and to `traces.jsonl` — the same sanitizer
runs before either path, so there is exactly one place this rule can be violated, not
two independently-maintained ones.

**Never recorded, anywhere in this layer:**
- Patient/member PII (name, DOB, SSN, phone, email) — this system never ingests any in
  the first place (`CLAUDE.md` §1: "the unit of work is a filing document, not a
  patient").
- Full filing-section text, full chunk text, or full LLM prompt/response text.
- API keys, authorization headers, or bearer tokens — `observability.safe_attrs()`
  additionally pattern-redacts labelled credentials and bare 20+ character tokens
  defensively, on top of never being given one to begin with.

**What is recorded:** synthetic `filing_id`-derived identifiers are never even needed
here (unlike the audit table, no span carries a raw `filing_id` — only structural
attributes), span/trace IDs, stage name, model/deployment *name* (never a credential),
start/end timestamps and duration, success/failure status, retry counts where the
transport layer exposes them, `risk_tier`, `confidence_score`, rule-category counts,
retrieved source-document *names* (the six synthetic filenames — not PII, not filing
content), citation counts, and judge scores/labels. Every attribute value is truncated
to 200 characters, the same cap `safety_rules.md` rule 2 puts on `output_summary`.

This does not weaken `repository.py`'s existing audit redaction rules — the audit
table's PII/text prohibitions were never relaxed, and this layer adds a second,
independently-enforced sanitizer rather than routing anything through the audit path.

### Consequence: spans carry no free-text input/output fields

Inspecting this project's spans in the Arize UI shows structured attributes only —
`RAGService.draft_summary`, for example, exposes `recommendation`, `citation_count`,
`verified_citation_count`, `ungrounded_citation_count`, `confidence_score`,
`retrieved_source_docs`, and token counts, with no prompt or completion text. **That is
the designed boundary, not missing instrumentation.**

Three categories are intentionally excluded from every span:

| Excluded | Why |
|---|---|
| Raw filing text (including the `prior_auth_language`/`pharmacy_language` excerpts used to build the retrieval query) | COC filing-section content; `safety_rules.md` rule 2 and this layer's no-full-text rule. Exporting it would place filing content in a third-party system outside the audit boundary. |
| Retrieved chunk text | Policy/regulatory document content, same rule. |
| Full prompt and response content | `safety_rules.md` rule 2 names LLM responses and drafted summaries explicitly. |

What is exported instead is structured, sanitized telemetry: stage timings, trace
topology, counts, scores, tiers, and judge results.

Two consequences follow, and both are accepted deliberately:

1. Arize views keyed on OpenInference input/output semantic conventions stay empty for
   this project. Trace structure, latency, span attributes, and the agent graph all work
   normally.
2. Server-side evaluators that require input/output text cannot run. This is why the
   judge evaluators in `arize_evaluators.py` execute locally and publish their results as
   attributes on dedicated `ArizeJudge.*` spans instead.

There is also no natural free-text "question" to record even if the rules allowed it: the
pipeline's input is a structured filing record, not a user query. The retrieval query is
assembled from filing excerpts (`rag_spec.md` §3) and the generation prompt receives
code-authored rule/risk context plus retrieved evidence — so **raw filing excerpts are
used for retrieval embeddings, but raw filing free-text is not passed to the LLM
generation prompt.**

## Limitations of this evaluation

- **Sample size.** Five synthetic filings and a handful of pytest runs. Every
  percentile in `latency_summary.json` is labeled a *Measured* value observed on this
  small sample, not a *Threshold* or a *Future production target* — see that file's
  `sample_disclaimer` field. Do not cite p90/p95 here as a production SLA.
- **LLM-judge non-determinism.** `judge_hallucination`, `judge_answer_relevance`, and
  `judge_retrieval_relevance` call the same enterprise LLM endpoint the pipeline uses,
  at `temperature=0.0`, but a judge call can still fail transiently (network, rate
  limit) — on failure it returns `score=None, label="judge_error"` rather than raising,
  by design (a judge failing must never affect release gating).
- **`confidence_score` measures grounding, not relevance** — see the finding above.
  Do not read a high `confidence_score` as proof the retrieved evidence was topically
  appropriate; check `retrieval_relevance_score` (informational) alongside it.
- **Filename false-positive redaction.** Both sanitizers (`harness.py`'s
  `sanitize_reason`/`coerce_json_safe` and `observability.py`'s `_sanitize_scalar`) use
  the same conservative bare-token pattern (`[A-Za-z0-9+/=_-]{20,}`) to catch
  credential-shaped strings. Several real corpus filenames happen to be ≥20 characters
  of that character class (e.g. `CMS_COC_Filing_Requirements.txt`,
  `State_COC_Regulations.txt`) and get redacted to `[redacted-token]` in
  `traces.jsonl` and in eval JSON output whenever a case tried to report the raw
  filename — a false positive on a real, non-sensitive document name, not a leak.
  Worked around in `eval_clear_evidence` by reporting `expected_doc_retrieved: bool`
  instead of the raw filename; the same pattern would recur for any future case that
  reports a corpus filename directly. Not fixed at the sanitizer level, since loosening
  either regex to special-case "things that look like filenames" would weaken the same
  pattern's actual job of catching a real credential that happens to be long and
  alphanumeric.
- **No Arize account required to evaluate this submission.** Every number in this
  README's tables, `eval_results.csv`, and `latency_summary.json` comes from files
  committed in this repository. Arize's own dashboard is optional supporting evidence
  for the live demo, not a second, hidden source of results.

## Reproducing this evaluation

```bash
# 1. Full pytest suite + coverage (unaffected by this layer; run first to confirm no regression)
python -m pytest --cov=coc_filing_assistant --cov-report=term-missing --cov-fail-under=80 -q

# 2. Deterministic + judge eval suites (writes evals/results/*.json|md and appends to traces.jsonl)
python evals/run_all.py

# 3. Derive the local Arize artifacts from what just ran
python evals/arize/build_artifacts.py

# 4. (Optional) Set ARIZE_API_KEY / ARIZE_SPACE_ID in .env first to also see the same
#    traces in the Arize UI under the project named by ARIZE_PROJECT_NAME.
```
