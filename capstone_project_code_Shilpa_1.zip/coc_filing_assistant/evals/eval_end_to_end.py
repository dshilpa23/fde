"""End-to-End Pipeline Evaluation — `eval_spec.md` §3.

All four cases now run for real against the implemented `supervisor.run_pipeline()`
(US-7), `router.route()` (US-8), and `repository.save_package()` (US-9).

`eval_correct_queue_routing`'s PIPELINE_ERROR sub-case is a forced failure
(`unittest.mock.patch`, the standalone-script equivalent of the `monkeypatch` pattern
already used in `tests/test_supervisor.py::test_pipeline_error_does_not_crash`), not the
real `filing_pipeline_error` fixture — verified live, that fixture never actually fails
a stage (rule_engine finds 13 legitimate findings including PRIOR_AUTH/PHARMACY category
hits, so a correctly-implemented pipeline reaches `HANDOFF_READY`/`NEEDS_REVIEW`, not
`PIPELINE_ERROR`, and routes to LEGAL, not OPERATIONS). This is the same category of
spec/fixture mismatch already resolved for US-3 and US-7 in this repo; resolved here the
same way, by user decision: force the failure to prove the OPERATIONS mapping, and record
the real fixture's actual observed routing as a disclosed, non-asserted finding rather
than silently rewriting `eval_spec.md` §3's stated criteria.

`eval_correct_queue_routing`'s LOW-risk sub-case is the opposite resolution, by later
user decision (2026-08-18): `filing_low_risk` itself is now the gating assertion,
verified live to route to OPERATIONS - `router.py`'s own documented fallback for a
filing with no rule category and no HIGH tier, which is exactly what this fixture is by
design. `eval_spec.md` §3 was corrected to match. A separate, additional
`_lightly_flagged_low_risk_item()` filing (one MEDIUM `PRIOR_AUTH` finding, still
`risk_tier=LOW`) proves the LEGAL/ACTUARIAL path also works at LOW risk when a rule
category *is* present - recorded, never gating, and never a substitute for the
`filing_low_risk` assertion above it.

Run: python evals/eval_end_to_end.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

from coc_filing_assistant import ml_service, repository, router, rule_engine, service, supervisor
from coc_filing_assistant.domain import COCFilingItem, HandoffPackage, RuleEngineError
from evals import filings, harness

SUITE = "end_to_end"

_VALID_STATUSES = {"HANDOFF_READY", "NEEDS_REVIEW", "PIPELINE_ERROR"}


def _tmp_db(case_name: str) -> Path:
    """A fresh, isolated SQLite file per case - no filing_id ever collides across
    cases sharing state, and no case's idempotency behavior can leak into another's
    routing assertions (idempotent replay strips rule_output/risk_score, which would
    silently break a routing check run against an already-processed filing_id)."""
    return Path(tempfile.mkdtemp(prefix=f"coc_eval_e2e_{case_name}_")) / "eval.db"


def eval_all_filings_complete() -> dict:
    """All 5 filings must complete without crashing."""
    db_path = _tmp_db("all_filings")
    observed: dict[str, object] = {}
    for name, factory in filings.ALL.items():
        item = factory()
        package = service.process(item, db_path=db_path)
        assert package.status in _VALID_STATUSES, (
            f"{name} produced an invalid status: {package.status!r}"
        )
        observed[f"{name}.status"] = package.status
        observed[f"{name}.risk_tier"] = (
            package.risk_score.risk_tier if package.risk_score else None
        )
    return observed


def _lightly_flagged_low_risk_item() -> COCFilingItem:
    """A LOW-risk filing that still fires exactly one rule (PA-003, "no urgent-care
    carve-out mentioned", category PRIOR_AUTH) - unlike `filings.low_risk()`, which
    fires zero rules by design and therefore has no rule category or HIGH tier for
    router.route() to key on at all (see module docstring: verified live,
    `filings.low_risk()` routes to OPERATIONS, its correct, documented fallback for a
    filing with no triggers - not a LEGAL/ACTUARIAL case). This variant exists only to
    exercise the LEGAL/ACTUARIAL routing path at LOW risk without touching the shared
    `filings.low_risk()` fixture other cases rely on.
    """
    return COCFilingItem(
        filing_id="FILING-EVAL-LIGHT-LOW-001",
        filing_type="RENEWAL", payer_name="BlueCross BlueShield", plan_type="PPO",
        state="IL", effective_date="2025-01-01",
        prior_auth_language=(
            "Prior authorization is required for inpatient admissions, outpatient "
            "surgery, home health services, durable medical equipment, and all "
            "specialty medications. The prior authorization process is described in "
            "the Member Handbook, Section 7. Emergency services do not require "
            "prior authorization."
        ),
        pharmacy_language=(
            "The formulary is organized into four tiers. Tier 1: generic drugs. "
            "Tier 2: preferred brand. Tier 3: non-preferred brand. Tier 4: specialty. "
            "Step therapy applies to Tier 3 and Tier 4 medications. Exceptions are "
            "available via the formulary exception process in Section 9."
        ),
        exclusion_clauses=(
            "Services not covered include: cosmetic surgery not medically necessary, "
            "custodial care, experimental treatments not approved by FDA or CMS, and "
            "services received outside the service area except for emergencies. Full "
            "exclusion list is provided in Exhibit A."
        ),
        network_language=(
            "Network adequacy standards meet or exceed state requirements. "
            "Member-to-PCP ratio is 1500:1 in all service areas."
        ),
        benefit_summary=(
            "Comprehensive coverage including hospitalization, outpatient, "
            "preventive, mental health, substance use disorder, maternity, "
            "pediatric, and emergency services."
        ),
        mandatory_sections_present=[
            "benefits", "exclusions", "prior_auth", "pharmacy",
            "network", "grievance", "coordination_of_benefits", "definitions",
        ],
        submitted_by="eval_harness",
    )


def eval_correct_queue_routing() -> dict:
    """Filings must route to expected queues."""
    def _route_fresh(item, status="HANDOFF_READY"):
        rule_out = rule_engine.run_checks(item)
        risk = ml_service.score_risk(item, rule_out)
        package = HandoffPackage(
            filing_id=item.filing_id, rule_output=rule_out, risk_score=risk,
            filing_summary=None, review_result=None, status=status,
            error_reason=None, review_queue=None,
        )
        return router.route(package)

    high_queue = _route_fresh(filings.high_risk())
    assert high_queue in {"LEGAL", "PHARMACY"}, (
        f"filing_high_risk routed to {high_queue}, expected LEGAL or PHARMACY"
    )

    # Gating case (eval_spec.md §3, corrected 2026-08-18): filing_low_risk itself
    # fires zero rule categories and scores risk_tier=LOW by design, so OPERATIONS -
    # router.py's own documented fallback for exactly this shape of package - is the
    # actual, asserted-correct outcome, not a disclosed exception to it.
    low_queue = _route_fresh(filings.low_risk())
    assert low_queue == "OPERATIONS", (
        f"filing_low_risk routed to {low_queue}, expected OPERATIONS"
    )

    # Additional, non-substitute coverage only: a separate lightly-flagged low-risk
    # filing that *does* still fire one rule category, proving router.py's
    # LEGAL/ACTUARIAL path also works at LOW risk_tier when a category is present.
    # Recorded, not asserted - it must never gate this case's PASS/FAIL, since
    # filing_low_risk above is the one eval_spec.md §3 actually requires.
    lightly_flagged_queue = _route_fresh(_lightly_flagged_low_risk_item())

    error_item = filings.pipeline_error()
    with patch.object(
        rule_engine, "run_checks",
        side_effect=RuleEngineError("simulated failure for EVAL-E routing case"),
    ):
        forced_package, _ = supervisor.run_pipeline(error_item)
    assert forced_package.status == "PIPELINE_ERROR", (
        f"forced failure produced status={forced_package.status}, expected PIPELINE_ERROR"
    )
    forced_queue = router.route(forced_package)
    assert forced_queue == "OPERATIONS", (
        f"PIPELINE_ERROR routed to {forced_queue}, expected OPERATIONS"
    )

    # Disclosed finding, deliberately not asserted (see module docstring): the real
    # fixture never actually fails, so its real routing is LEGAL, not OPERATIONS.
    real_queue = _route_fresh(error_item)

    return {
        "high_risk.review_queue": high_queue,
        "low_risk.review_queue": low_queue,
        "lightly_flagged_low_risk.review_queue": lightly_flagged_queue,
        "forced_pipeline_error.review_queue": forced_queue,
        "real_filing_pipeline_error.review_queue": real_queue,
    }


def eval_audit_trail_complete() -> dict:
    """Every successful pipeline run must have 4 audit events."""
    db_path = _tmp_db("audit_trail")
    item = filings.medium_risk()

    package, events = supervisor.run_pipeline(item)
    violations = harness.check_invariants(package, events)
    assert not violations, f"invariant violations: {violations}"

    repository.init_db(db_path)
    repository.save_package(package, events, db_path)
    db_events = repository.get_audit_events(item.filing_id, db_path)
    assert len(db_events) == 4, f"expected 4 persisted audit events, got {len(db_events)}"

    agent_names = {e["agent_name"] for e in db_events}
    assert agent_names == {"RuleEngine", "MLService", "RAGRetrieve", "RAGDraft"}, sorted(agent_names)

    max_summary_len = max((len(e["output_summary"] or "") for e in db_events), default=0)
    assert max_summary_len <= 200, f"an output_summary exceeded 200 chars ({max_summary_len})"

    return {
        "status": package.status,
        "audit_event_count": len(db_events),
        "agent_names": sorted(agent_names),
        "max_output_summary_len": max_summary_len,
    }


def eval_idempotency() -> dict:
    """Second submission must return stored result."""
    db_path = _tmp_db("idempotency")
    item = filings.idempotency()

    first = service.process(item, db_path=db_path)
    assert first.idempotent_replay is False, "first submission must not be a replay"
    first_count = len(repository.get_audit_events(item.filing_id, db_path))

    second = service.process(item, db_path=db_path)
    assert second.idempotent_replay is True, "second submission must report idempotent_replay=True"
    second_count = len(repository.get_audit_events(item.filing_id, db_path))
    assert second_count == first_count, (
        f"audit event count changed on replay: {first_count} -> {second_count}"
    )

    return {
        "status": first.status,
        "audit_event_count": first_count,
        "idempotent_replay": second.idempotent_replay,
    }


CASES = [
    harness.Case(eval_all_filings_complete),
    harness.Case(eval_correct_queue_routing),
    harness.Case(eval_audit_trail_complete),
    harness.Case(eval_idempotency),
]


if __name__ == "__main__":
    sys.exit(harness.run_suite(SUITE, CASES, harness.parse_args()))
