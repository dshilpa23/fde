"""ML Risk Calibration Evaluation — `eval_spec.md` §2.

Verify that the ML Risk Service ranks filings by risk, consumes the rule-engine signal,
and scores reproducibly. This suite is fully implemented: `rule_engine.run_checks()`
(US-3) and `ml_service.score_risk()` (US-4) are both complete, and both are specified
deterministic, so every metric here compares EXACT against an approved baseline.

Run: python evals/eval_risk_calibration.py
     python evals/eval_risk_calibration.py --release
"""
from __future__ import annotations

import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

from coc_filing_assistant import ml_service, rule_engine
from coc_filing_assistant.domain import RuleEngineOutput
from evals import filings, harness

SUITE = "risk_calibration"


def _score(name: str):
    """Score one named filing through the real rule engine and risk model."""
    item = filings.ALL[name]()
    rule_output = rule_engine.run_checks(item)
    return ml_service.score_risk(item, rule_output)


def eval_risk_ordering() -> dict:
    """High-risk filings must score above medium, and medium above low."""
    scores = {name: _score(name) for name in filings.ALL}

    high = scores["high_risk"].composite_risk
    medium = scores["medium_risk"].composite_risk
    low = scores["low_risk"].composite_risk
    assert high > medium, f"high_risk {high} must exceed medium_risk {medium}"
    assert medium > low, f"medium_risk {medium} must exceed low_risk {low}"
    assert scores["high_risk"].risk_tier == "HIGH", (
        f"high_risk tier is {scores['high_risk'].risk_tier}, expected HIGH"
    )
    assert scores["low_risk"].risk_tier in {"LOW", "MEDIUM"}, (
        f"low_risk tier is {scores['low_risk'].risk_tier}, expected LOW or MEDIUM"
    )

    observed: dict[str, object] = {}
    for name, score in scores.items():
        observed[f"{name}.composite_risk"] = round(score.composite_risk, 4)
        observed[f"{name}.risk_tier"] = score.risk_tier
    observed["tiers_observed"] = sorted({s.risk_tier for s in scores.values()})
    return observed


def eval_rule_signal_used() -> dict:
    """The risk model must consume rule output, not just filing metadata."""
    item = filings.medium_risk()
    real = ml_service.score_risk(item, rule_engine.run_checks(item))
    zeroed = ml_service.score_risk(
        item,
        RuleEngineOutput(filing_id=item.filing_id, rule_results=[], overall_flag="PASS"),
    )

    assert real.composite_risk > zeroed.composite_risk, (
        f"composite with real rules ({real.composite_risk}) must exceed the no-rules "
        f"case ({zeroed.composite_risk}); the model is ignoring rule_output"
    )
    return {
        "composite_real": round(real.composite_risk, 4),
        "composite_zeroed": round(zeroed.composite_risk, 4),
        "composite_delta": round(real.composite_risk - zeroed.composite_risk, 4),
    }


def eval_score_stability() -> dict:
    """Repeat scoring of the same filing must be exactly reproducible."""
    # Fresh factory call each time, so this also exercises the freshness guarantee in
    # evals/filings.py rather than assuming it.
    runs = [_score("medium_risk") for _ in range(3)]
    tiers = {run.risk_tier for run in runs}
    composites = [run.composite_risk for run in runs]
    variance = statistics.pvariance(composites)

    assert len(tiers) == 1, f"risk_tier varied across 3 runs: {sorted(tiers)}"
    assert variance < 0.001, f"composite_risk variance {variance} exceeds 0.001"
    # Compares composite and tier, never whole RiskScore objects — `scored_at` uses
    # default_factory=datetime.utcnow and differs on every construction.
    return {
        "repetitions": len(runs),
        "risk_tier": runs[0].risk_tier,
        "composite_risk": round(composites[0], 4),
        "composite_variance": round(variance, 12),
    }


def eval_threshold_distribution() -> dict:
    """Record the composite distribution. Recorder only — never asserts.

    `eval_spec.md` §2: the 0.65/0.35 tier cutoffs and the 0.70 confidence cutoff are
    asserted by design rather than fitted. Real calibration needs reviewer-labelled
    outcomes that do not exist yet, so this records a documented starting point.
    """
    composites = [_score(name).composite_risk for name in filings.ALL]
    return {
        "composite_min": round(min(composites), 4),
        "composite_max": round(max(composites), 4),
        "composite_mean": round(statistics.fmean(composites), 4),
    }


CASES = [
    harness.Case(eval_risk_ordering),
    harness.Case(eval_rule_signal_used),
    harness.Case(eval_score_stability),
    harness.Case(eval_threshold_distribution, required=False),
]


if __name__ == "__main__":
    sys.exit(harness.run_suite(SUITE, CASES, harness.parse_args()))
