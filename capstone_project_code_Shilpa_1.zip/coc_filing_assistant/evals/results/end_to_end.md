# Eval report — end_to_end

- schema `1.0` · run `a51f19aa391a41b496d23e6af3e3066e`
- started `2026-08-18T22:34:13.114432+00:00` · duration 113644 ms
- git `cf0fc7e7a380` · python `3.13.12`
- llm deployment `databricks-claude-sonnet-4-6` · embedding `databricks-gte-large-en`

| Case | Outcome | Required | Detail | Observed |
|---|---|---|---|---|
| `eval_all_filings_complete` | PASS | yes | — | low_risk.status=HANDOFF_READY, low_risk.risk_tier=LOW, idempotency.status=HANDOFF_READY, idempotency.risk_tier=MEDIUM, medium_risk.status=HANDOFF_READY, medium_risk.risk_tier=MEDIUM, high_risk.status=HANDOFF_READY, high_risk.risk_tier=HIGH, pipeline_error.status=HANDOFF_READY, pipeline_error.risk_tier=HIGH |
| `eval_correct_queue_routing` | PASS | yes | — | high_risk.review_queue=LEGAL, low_risk.review_queue=OPERATIONS, lightly_flagged_low_risk.review_queue=LEGAL, forced_pipeline_error.review_queue=OPERATIONS, real_filing_pipeline_error.review_queue=LEGAL |
| `eval_audit_trail_complete` | PASS | yes | — | status=HANDOFF_READY, audit_event_count=4, agent_names=['MLService', 'RAGDraft', 'RAGRetrieve', 'RuleEngine'], max_output_summary_len=53 |
| `eval_idempotency` | PASS | yes | — | status=HANDOFF_READY, audit_event_count=4, idempotent_replay=True |

**Counts:** 4 PASS · 0 FAIL · 0 ERROR · 0 SKIP (0 required)
