# Eval report — risk_calibration

- schema `1.0` · run `9aab30a7004344cb9e77c3340b9bc77c`
- started `2026-08-18T22:31:52.378012+00:00` · duration 122 ms
- git `cf0fc7e7a380` · python `3.13.12`
- llm deployment `databricks-claude-sonnet-4-6` · embedding `databricks-gte-large-en`

| Case | Outcome | Required | Detail | Observed |
|---|---|---|---|---|
| `eval_risk_ordering` | PASS | yes | — | low_risk.composite_risk=0.0, low_risk.risk_tier=LOW, idempotency.composite_risk=0.4, idempotency.risk_tier=MEDIUM, medium_risk.composite_risk=0.54, medium_risk.risk_tier=MEDIUM, high_risk.composite_risk=1.0, high_risk.risk_tier=HIGH, pipeline_error.composite_risk=1.0, pipeline_error.risk_tier=HIGH, tiers_observed=['HIGH', 'LOW', 'MEDIUM'] |
| `eval_rule_signal_used` | PASS | yes | — | composite_real=0.54, composite_zeroed=0.04, composite_delta=0.5 |
| `eval_score_stability` | PASS | yes | — | repetitions=3, risk_tier=MEDIUM, composite_risk=0.54, composite_variance=0.0 |
| `eval_threshold_distribution` | PASS | no | — | composite_min=0.0, composite_max=1.0, composite_mean=0.588 |

**Counts:** 4 PASS · 0 FAIL · 0 ERROR · 0 SKIP (0 required)
