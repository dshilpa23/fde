"""Run every eval suite and emit the paste-ready summary.

Exits with the worst code across the three suites, so a single command can gate a
release. `release_rules.md` calls a failing eval a release blocker; this is the process
whose exit status makes that enforceable.

Run: python evals/run_all.py
     python evals/run_all.py --release
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

from evals import eval_end_to_end, eval_rag_quality, eval_risk_calibration, harness

SUITES = (eval_risk_calibration, eval_rag_quality, eval_end_to_end)


def _write_summary(suites: list[str]) -> None:
    """Compose `evals/results/summary.md` from the per-suite JSON artifacts.

    Reads the reports back rather than holding results in memory, so the summary can
    only ever claim what was actually written to disk.

    Args:
        suites: Suite names, in run order.
    """
    envelopes = {}
    for suite in suites:
        path = harness.RESULTS_DIR / f"{suite}.json"
        if path.exists():
            envelopes[suite] = json.loads(path.read_text())
    if not envelopes:
        return

    # One provenance header for the whole run, taken from the first suite. Every suite in
    # a single invocation shares the same commit, interpreter, and deployments.
    first = next(iter(envelopes.values()))["meta"]
    any_development = any(e.get("development_run") for e in envelopes.values())
    lines = ["# Eval summary", ""]
    if any_development:
        # `run_all.py --release` is the actual release gate; this file is generated on
        # every plain run too, and a reviewer who opens it directly should not mistake
        # a mid-sprint SKIP-heavy run for release evidence.
        lines += [harness._DEVELOPMENT_BANNER, ""]
    lines += [
        f"- schema `{first['schema_version']}` · git `{first['git_sha'][:12]}`"
        f"{' **dirty**' if first['git_dirty'] else ''}"
        f" · python `{first['python_version']}`",
        f"- run `{first['started_at']}` · llm `{first['llm_deployment']}`"
        f" · embedding `{first['embedding_deployment']}`",
        "",
        "| Suite | Case | Outcome | Required | Detail |",
        "|---|---|---|---|---|",
    ]
    totals = {"PASS": 0, "FAIL": 0, "ERROR": 0, "SKIP": 0, "required_skip": 0}
    blocks: list[str] = []

    for suite, envelope in envelopes.items():
        counts = envelope["counts"]
        for key in totals:
            totals[key] += counts.get(key, 0)
        for case in envelope["results"]:
            lines.append(
                f"| {harness._escape_md_cell(suite)} | `{harness._escape_md_cell(case['name'])}` "
                f"| {case['outcome']} | {'yes' if case['required'] else 'no'} "
                f"| {harness._escape_md_cell(case['reason'] or '—')} |"
            )
        observed = {
            f"{case['name']}.{k}": v
            for case in envelope["results"]
            for k, v in case["observed"].items()
        }
        if observed:
            blocks.append(f"### {suite} — observed values\n")
            blocks += [
                f"- `{harness._escape_md_cell(k)}` = `{harness._escape_md_cell(v)}`"
                for k, v in observed.items()
            ]
            blocks.append("")

    lines += [
        "",
        f"**Totals:** {totals['PASS']} PASS · {totals['FAIL']} FAIL · "
        f"{totals['ERROR']} ERROR · {totals['SKIP']} SKIP "
        f"({totals['required_skip']} required)",
        "",
        "These are the observed values for `OPERATIONAL_HANDOFF.md`. Copy them from here —",
        "this file is generated from the JSON artifacts, so it cannot drift from what ran.",
        "",
        *blocks,
    ]
    harness.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    (harness.RESULTS_DIR / "summary.md").write_text("\n".join(lines) + "\n")


def _approve_scope(suites: list[str], codes: list[int]) -> int:
    """Approve a baseline for the whole invoked scope, or refuse and write nothing.

    Eligibility is judged across every suite this command ran, not suite by suite. A
    partial approval would enshrine a reference for a run whose other suites never
    executed, which is exactly the incomplete baseline coverage `--release` exists to
    catch.

    Args:
        suites: Suite names in run order.
        codes: Per-suite exit codes from the reporting pass.

    Returns:
        `0` once every suite is written, or `2` when the scope is not eligible.
    """
    if any(code != 0 for code in codes):
        print("\nrefusing --update-baseline: the invoked scope is not fully eligible")
        for suite, code in zip(suites, codes):
            if code != 0:
                print(f"  ineligible: {suite} (exit {code})")
        print("  nothing written — approve a single suite directly if that is the intent")
        return 2

    envelopes = {
        suite: json.loads((harness.RESULTS_DIR / f"{suite}.json").read_text())
        for suite in suites
    }
    # One merge, one atomic write for the whole scope — not one write per suite. A crash
    # partway through a per-suite loop could otherwise leave the baseline half-approved.
    harness.update_baseline_many(
        envelopes, regressions_by_suite={s: e["regressions"] for s, e in envelopes.items()}
    )
    return 0


def main() -> int:
    """Run all suites, write the summary, and return the worst exit code."""
    args = harness.parse_args()
    if args.release and args.update_baseline:
        print("refusing: --release and --update-baseline are contradictory intents")
        return 2

    suites = [module.SUITE for module in SUITES]
    # Captured once, before any suite runs, and shared across all three below — so a
    # suite that generates result/trace artifacts cannot make a later suite in the same
    # invocation see a dirtier tree than the run actually started from.
    provenance = harness.capture_git_provenance()
    # Writes are suppressed in this pass so scope-wide eligibility can be judged once,
    # after every suite has reported, rather than per suite as it finishes.
    codes = [
        harness.run_suite(
            module.SUITE, module.CASES, args,
            allow_baseline_write=False, provenance=provenance,
        )
        for module in SUITES
    ]
    _write_summary(suites)

    if args.update_baseline:
        codes.append(_approve_scope(suites, codes))

    worst = max(codes)
    print(f"\nworst exit code across {len(SUITES)} suites: {worst}")
    return worst


if __name__ == "__main__":
    sys.exit(main())
