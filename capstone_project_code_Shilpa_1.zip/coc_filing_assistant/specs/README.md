# specs/ - Write All 6 Files on Day 1

These specification files must be written BEFORE you implement any code.
A spec is a contract for what you intend to build, not a description of what you built.

Files to create:
- architecture.md       - Full system diagram, data flow, failure modes, production gaps
- rule_engine_spec.md   - All 8+ rules, categories, output schema, tier thresholds
- ml_service_spec.md    - Risk-scoring approach, feature list, and weights
- rag_spec.md           - Collections, query construction, grounding contract, confidence threshold
- safety_spec.md        - All prohibited behaviors, PII fields, human-in-the-loop placement
- eval_spec.md          - 4 RAG cases, risk calibration method, end-to-end correctness

See Section 4.2 of the Implementation Guide for what each file must contain.
