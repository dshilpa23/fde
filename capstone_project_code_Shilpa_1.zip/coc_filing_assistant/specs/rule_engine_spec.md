# rule_engine_spec.md — Rule Catalog, Categories, Output Schema, Role in Risk Scoring

Governs `rule_engine.run_checks(item: COCFilingItem) -> RuleEngineOutput`. Where this file
conflicts with `safety_rules.md`, `safety_rules.md` wins.

## 1. Contract

**Input:** one `COCFilingItem`. **Output:** one `RuleEngineOutput`.

```
RuleEngineOutput(filing_id, rule_results: list[RuleCheckResult], overall_flag, checked_at)
RuleCheckResult(rule_id, category, severity, description, filing_section, evidence)
```

`overall_flag = "FLAG"` if any rule of severity `HIGH` or `MEDIUM` fired, else `"PASS"`.
A `LOW`-only result set is still `PASS`.

**Purity.** No LLM call, no database read, no network, no clock except `checked_at`. The
same `COCFilingItem` must always produce the same `rule_results` in the same order —
`eval_risk_calibration.py`'s stability check depends on it, and an audit trail cannot
defend a check that varies between runs. Raise `RuleEngineError`, never a bare
`Exception`.

**Only triggered rules appear in `rule_results`.** A rule that passes contributes nothing
— the list is findings, not a scorecard. This keeps `AgentEvent.output_summary`
proportional to what actually went wrong.

## 2. Categories

| Category | Prefix | Inspects | What it is looking for |
|---|---|---|---|
| `MISSING_INFO` | `MI-` | `mandatory_sections_present` | A required section absent from the filing entirely |
| `PRIOR_AUTH` | `PA-` | `prior_auth_language` | Missing or non-compliant prior-authorization language |
| `PHARMACY` | `PH-` | `pharmacy_language` | Formulary, drug-tier, or exception-process gaps |
| `EXCLUSION` | `EX-` | `exclusion_clauses` | Exclusion language that is absent, undefined, or unreferenced |
| `NETWORK` | `NW-` | `network_language` | Network adequacy or access gaps (optional 5th category, implemented) |

## 3. Rule catalog — 14 rules

`filing_section` is the `COCFilingItem` field inspected. `evidence` is the quoted trigger
text, truncated to 120 characters, or `""` where the trigger is an *absence* (there is no
text to quote when a section is missing).

### MISSING_INFO

| ID | Severity | Fires when | `filing_section` |
|---|---|---|---|
| MI-001 | HIGH | `"prior_auth"` not in `mandatory_sections_present` | `mandatory_sections_present` |
| MI-002 | HIGH | `"pharmacy"` not in `mandatory_sections_present` | `mandatory_sections_present` |
| MI-003 | MEDIUM | `"grievance"` not in `mandatory_sections_present` | `mandatory_sections_present` |
| MI-004 | MEDIUM | `"network"` not in `mandatory_sections_present` | `mandatory_sections_present` |

`benefits` and `exclusions` are deliberately **not** checked: they are present in all five
fixtures, so a rule on them would never exercise. Add them only alongside a fixture that
omits them.

### PRIOR_AUTH

| ID | Severity | Fires when | `filing_section` |
|---|---|---|---|
| PA-001 | HIGH | `prior_auth_language` empty or `< 50` chars after strip | `prior_auth_language` |
| PA-002 | HIGH | no emergency-care carve-out — none of `emergency`, `emergent` present (case-insensitive) | `prior_auth_language` |
| PA-003 | MEDIUM | no urgent-care carve-out — `urgent` absent | `prior_auth_language` |

PA-002 is HIGH and PA-003 MEDIUM because an emergency carve-out is a regulatory
requirement in every state in scope, whereas urgent-care handling varies.

### PHARMACY

| ID | Severity | Fires when | `filing_section` |
|---|---|---|---|
| PH-001 | HIGH | `pharmacy_language` empty or `< 50` chars after strip | `pharmacy_language` |
| PH-002 | MEDIUM | no formulary-exception process — `exception` absent | `pharmacy_language` |
| PH-003 | MEDIUM | no drug-tier structure — no `tier` followed by a digit, and no `formulary` | `pharmacy_language` |

### EXCLUSION

| ID | Severity | Fires when | `filing_section` |
|---|---|---|---|
| EX-001 | HIGH | `experimental` absent entirely from `exclusion_clauses` | `exclusion_clauses` |
| EX-002 | MEDIUM | no full-list reference — none of `exhibit`, `appendix`, `schedule` present | `exclusion_clauses` |

### NETWORK

| ID | Severity | Fires when | `filing_section` |
|---|---|---|---|
| NW-001 | MEDIUM | adequacy explicitly disclaimed — `not demonstrated`, `not established`, or `pending` present | `network_language` |
| NW-002 | LOW | no measurable standard — no digit anywhere in `network_language` (ratios, mileage, minutes) | `network_language` |

NW-002 is the only `LOW` rule, and exists specifically so `overall_flag` has a case where
a finding is recorded without forcing `FLAG`.

## 4. Known limitation — substring matching is shallow, and deliberately so

Two of the five fixtures show the failure mode plainly:

- `filing_high_risk.pharmacy_language` contains *"No exceptions noted."* — a substring
  test for `exception` **passes**, though the filing is asserting the opposite.
- `filing_high_risk.exclusion_clauses` contains *"Experimental treatments excluded.
  Definition of experimental not provided."* — EX-001 **does not fire**, though the
  definition gap is exactly what a reviewer would flag.

This is accepted, not overlooked. Detecting negation and definitional adequacy is a
language task, and moving it into the rule engine would make the engine non-deterministic
— breaking the property that makes it auditable (`architecture.md` §3). The design
response is layered rather than local: these gaps are what the RAG Evidence Service is
for. It retrieves the regulatory text on experimental-treatment definitions and surfaces
the gap as a `coverage_gap` in the `FilingSummary`, where a human sees it. The rule engine
answers *"is the required language present?"*; the RAG layer answers *"is it adequate?"*

Recorded as a limitation rather than a defect because a reviewer reading a `PASS` on
PH-002 needs to know it means "the word appears," not "an exception process exists."

## 5. How rule results feed risk scoring

The rule engine produces no score. It emits two signals `ml_service.score_risk()` consumes
(`ml_service_spec.md` §2):

- `high_rules` — count of `severity == "HIGH"` results
- `med_rules` — count of `severity == "MEDIUM"` results

`LOW` results are recorded for the reviewer but carry **zero** scoring weight, so NW-002
can never move a tier on its own.

**What HIGH / MEDIUM / LOW mean from rules alone**, before the ML service applies weights:

| Severity | Meaning | Reviewer consequence |
|---|---|---|
| HIGH | A regulator would reject or return the filing for this | Must be fixed before submission |
| MEDIUM | Non-compliant or ambiguous, but arguable | Needs a reviewer judgment call |
| LOW | Worth noting; no compliance consequence | Informational |

**Severity is not routed directly to a risk tier.** `ml_service.py` forbids using rule
severity as a pass-through, and safety rule 8 requires the score to be a signal rather
than a decision. The two stay separate: severity describes *what a regulator would do*;
`composite_risk` describes *how much reviewer effort and SLA exposure this filing
represents*. A filing can carry one HIGH rule and still score MEDIUM.

## 6. Expected behaviour against the five fixtures

Derived by running `run_checks()` against `tests/conftest.py`'s fixtures (superseding an
earlier hand-estimated version of this table produced before any code existed, which was
wrong in 3 of 5 rows). Exact counts are what `eval_risk_calibration.py`'s ordering check
depends on, so a catalog change that alters this table must be re-validated against that
eval.

| Fixture | Rules fired | HIGH | MEDIUM | LOW | `overall_flag` |
|---|---|---|---|---|---|
| `filing_low_risk` | none | 0 | 0 | 0 | `PASS` |
| `filing_medium_risk` | PA-002, PH-002, PH-003, EX-002, NW-002 | 1 | 3 | 1 | `FLAG` |
| `filing_idempotency` | PA-002, PA-003 | 1 | 1 | 0 | `FLAG` |
| `filing_high_risk` | MI-001, MI-002, MI-003, MI-004, PA-002, PA-003, EX-002, NW-001, NW-002 | 3 | 5 | 1 | `FLAG` |
| `filing_pipeline_error` | MI-001, MI-002, MI-003, MI-004, PA-001, PA-002, PA-003, PH-001, PH-002, PH-003, EX-001, EX-002, NW-002 | 6 | 6 | 1 | `FLAG` |

Two corrections from the original estimate worth noting explicitly: `filing_idempotency`
fires PA-002/PA-003 (not PA-002/EX-002/NW-002 — right HIGH/MEDIUM counts, wrong rule IDs),
and `filing_pipeline_error` is 6H/6M, not 6H/4M — PA-002, PA-003, PH-002, and PH-003 all
fire trivially on that fixture's empty-string fields, which the estimate missed.

`filing_low_risk` producing zero findings is the intended `PASS` path — it is the only
fixture that exercises it, so a change that makes any rule fire on it removes the project's
only `PASS` test case.

## Production-grade additions in this spec

§4's explicit limitation statement and §6's fixture-level expectation table go beyond the
catalog the stub docstring asks for. §4 exists because the honest answer to "how do you
know your rules are correct?" is that they detect *presence*, not *adequacy* — and the
architecture compensates deliberately rather than accidentally. §6 exists because the risk
ordering the evals assert is a *consequence* of this catalog; without writing the counts
down, a later rule change silently breaks `eval_risk_calibration.py` with no obvious cause.
