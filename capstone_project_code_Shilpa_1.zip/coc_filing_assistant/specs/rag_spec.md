# rag_spec.md — Retrieval, Grounding, Confidence, Adversarial Content

Governs `rag_service.retrieve()`, `rag_service.draft_summary()`, and the embedding hook
shared by `rag_service.py:42` and `scripts/ingest_documents.py:86`. Where this file
conflicts with `safety_spec.md` or `safety_rules.md`, they win.

## 1. Document collections

Two ChromaDB persistent collections, queried and merged, never conflated:

| Collection | Constant | Content |
|---|---|---|
| Policy | `POLICY_COLLECTION = "coc_policy_docs"` | Insurance policy documents |
| Regulatory | `REGULATORY_COLLECTION = "coc_regulatory"` | State regulatory filing rules |

`ingest_documents.py` ingests both into separate collections in one run (6 documents
total per `README.md` Step 4). They are queried separately and results combined —
policy language and regulatory requirements are different evidence classes, and keeping
them distinct in `EvidenceChunk.collection` lets `FilingSummary` cite each correctly
(`policy_citations` vs `regulatory_citations`).

## 2. Embedding function — the resolved frozen-file conflict

**Adopted reading** (resolving the conflict between `README.md`'s do-not-modify list and
its own Step 4, which requires supplying an embedding implementation; recorded in
`CLAUDE.md` §3): the embedding hook is the *only* permitted edit inside
`scripts/ingest_documents.py`,
and it must be byte-for-byte the same `CompanyEmbeddingFunction` implementation used in
`rag_service.py`. Rationale: constraint #11 in `CLAUDE.md` ("the same embedding function
must serve both ingestion and query — mixing them makes similarity scores meaningless")
is a correctness requirement, not a style preference — cosine distance between vectors
produced by two different embedding models is not interpretable as a similarity score
at all.

**Model tier.** No `DefaultEmbeddingFunction`, no public provider, no local model
runtime — only the org-approved enterprise embedding endpoint via
`ENTERPRISE_LLM_ENDPOINT` / `ENTERPRISE_LLM_API_KEY` / `ENTERPRISE_LLM_DEPLOYMENT`.
Given the corpus is 6 short documents (policy + regulatory), the embedding call volume
and cost are negligible — so **retrieval quality dominates the choice over cost or
latency**. Select the highest-quality embedding tier the approved enterprise endpoint
offers — the larger, higher-dimensional class rather than the smaller/cheaper one —
because retrieval precision directly drives `confidence_score` (§4), and a weak
embedding model raises the false-negative rate on grounded citations, which is a *safety*
regression rather than merely a quality one.

No specific model is named here by design. The endpoint's available deployments come from
the organisation's catalog, not from this spec, and `CLAUDE.md` §4 forbids introducing an
unapproved provider — so the requirement is stated as a capability ("largest available
embedding tier on the approved endpoint") and the concrete deployment name is recorded in
`.env` and in `OPERATIONAL_HANDOFF.md` once confirmed with the trainer/admin. Full
selection reasoning, including the generation-model tier: `production_hardening/model_recommendations.md`.

## 3. Query construction

Build the query string from the fields most likely to name a policy or regulatory
concept, truncated to keep the embedding call bounded and to avoid ever placing a full
filing section into a prompt (`CLAUDE.md` §3 "Stop and ask" list):

```
query = f"{item.prior_auth_language[:200]} {item.pharmacy_language[:200]}"
```

Query each collection independently with this same string (`top_k` per collection,
default 5), then merge: combined list sorted by `similarity_score` descending
(`similarity_score = 1 - distance` for cosine distance). No re-ranking beyond the sort —
a second-stage re-ranker is a documented production gap, not implemented here (corpus of
6 documents doesn't need it; see `architecture.md`).

**Chunking strategy.** Source documents are ingested by `ingest_documents.py` (frozen
except the embedding hook) — chunk boundaries are therefore fixed by that script, not
chosen here. Observed and recorded in `OPERATIONAL_HANDOFF.md` §2: `CHUNK_SIZE = 400`
characters with `CHUNK_OVERLAP = 80` (20%), chunks under 40 characters discarded.
Character-based with no sentence or section awareness, so a chunk can start or end
mid-sentence — this bounds how much context a single `EvidenceChunk` carries into
`draft_summary()`'s prompt, and is the likeliest source of the verbatim-citation
variance documented in `evals/arize/README.md`.

## 4. Grounding contract

Every `PolicyCitation` and every regulatory citation in a `FilingSummary` must reference
a `chunk_text`/`source_doc` pair that appears in the `chunks` list passed into
`draft_summary()` for that call — not merely "a real document somewhere in the corpus."
Verification is a set-membership check against the actual retrieved set, run after
parsing the LLM's response, before `ReviewResult` is constructed.

`confidence_score = verified_citations / total_citations`, clamped to `[0.0, 1.0]` at
the point of computation (defense in depth: clamp again in `supervisor.py` before
placing it on `HandoffPackage`, per `safety_spec.md` §1). A response with zero citations
is `confidence_score = 0.0`, not skipped or treated as N/A.

## 5. Confidence threshold and recommendation

`confidence_score < 0.70` → `ReviewResult.recommendation = FLAG_FOR_HUMAN`. Otherwise
`APPROVE`. `supervisor.run_pipeline()` maps this recommendation directly onto
`HandoffPackage.status`: `FLAG_FOR_HUMAN` → `NEEDS_REVIEW`, `APPROVE` → `HANDOFF_READY`.

**What `NEEDS_REVIEW` actually means — and the naming trap to avoid.** `NEEDS_REVIEW` is
not "this filing needs review and `HANDOFF_READY` filings don't" — every `HandoffPackage`,
regardless of status, sits in a human review queue and is staged, never sent
(`safety_rules.md` rule 1; `architecture.md` §1 diagram, "Human reviewer... reads, edits,
acts"). The status names one specific, narrower thing: whether `draft_summary()`'s
grounding check came back below the 0.70 confidence threshold. `NEEDS_REVIEW` means "the
drafted summary's citations weren't well-grounded enough to trust as written" —
a signal about the *evidence*, not a statement that this filing is somehow more
in-need-of-a-human than a `HANDOFF_READY` one. Worth stating plainly in Q&A rather than
letting the name imply the opposite of what `architecture.md` §1 already guarantees.

**This threshold is asserted, not calibrated** — it is not derived from
reviewer-agreement data because none exists for this build. Recorded as a production
prerequisite in `OPERATIONAL_HANDOFF.md` and as Epic 4 / US-G4 in
`production_hardening/epics_and_stories.md`: before this threshold governs a real
filing, it needs to be validated against a held-out set of filings with known correct
`APPROVE`/`FLAG_FOR_HUMAN` outcomes from actual reviewers, and adjusted to the point that
maximizes agreement (or, more conservatively, minimizes false `APPROVE`s, since a false
`FLAG_FOR_HUMAN` costs reviewer time but a false `APPROVE` costs a compliance miss).

## 6. Adversarial content handling

See `safety_spec.md` §4 for the full adversarial catalog and the structural
(instruction-region vs evidence-region) defense mechanism. This spec's obligation:
`draft_summary()`'s prompt template must place every `chunk_text` value inside the
evidence region only, and the instruction region must be static text authored by this
codebase — no field of `COCFilingItem`, `RuleEngineOutput`, or `EvidenceChunk` is ever
concatenated into the instruction region.

## 7. Error handling

`RAGServiceError` raised only when **both** collections are empty or unreachable
(`rag_service.py` docstring) — one collection returning zero results while the
other succeeds is a degraded-but-valid retrieval, not a failure. `draft_summary()` raises
`RAGServiceError` if the LLM response cannot be parsed into a `FilingSummary` — never
silently returns a partially-populated summary.

## Production-grade additions in this spec

The embedding-model-tier guidance (§2) and the confidence-calibration gap (§5) go beyond
the fixed values stated in the stub docstrings — they explain *why* those
values were chosen and *what would need to change* for a production rollout, addressing
the PDF's mandatory Q&A question "Why did you choose this RAG and agent architecture?"
and "What is needed for production rollout?" Full backlog: `production_hardening/epics_and_stories.md` Epic 4.
