# architecture.md — System Design, Data Flow, Failure Modes, Production Gaps

## 1. System diagram

```
COCFilingItem
      │
      ▼
┌─────────────┐   RuleEngineOutput   ┌─────────────┐   RiskScore   ┌─────────────┐
│ Rule Engine │ ───────────────────▶ │  ML Risk    │ ─────────────▶│ RAG Evidence│
│ (pure, det.)│                      │ (pure math) │               │ retrieve()  │
└─────────────┘                      └─────────────┘               └──────┬──────┘
      │                                     │                             │ EvidenceChunk[]
      │ (attempted regardless of above)     │ (attempted regardless)      ▼
      │                                     │                      ┌─────────────┐
      │                                     │                      │ RAG Evidence│
      │                                     │                      │draft_summary│
      │                                     │                      └──────┬──────┘
      ▼                                     ▼                             ▼
              supervisor.run_pipeline() assembles 4 AgentEvents + HandoffPackage
                                            │
                                            ▼ (status: HANDOFF_READY | NEEDS_REVIEW | PIPELINE_ERROR)
                                    router.route() [called from api.py, not supervisor]
                                            │
                                            ▼ (review_queue: LEGAL|PHARMACY|ACTUARIAL|NETWORK|OPERATIONS)
                                  repository.save_package() — atomic 3-table write
                                            │
                                            ▼
                          Human reviewer (dashboard / review-queue) reads, edits, acts
                                  System never files, sends, or submits.
```

## 2. Data flow — what enters each service, what exits, what is persisted

| Stage | Input | Output | Persisted? |
|---|---|---|---|
| Rule Engine | `COCFilingItem` | `RuleEngineOutput` (list of `RuleCheckResult` + `overall_flag`) | No — only summarized into an `AgentEvent.output_summary` |
| ML Risk | `COCFilingItem`, `RuleEngineOutput` | `RiskScore` | `risk_tier` only (`coc_filings.risk_tier`, `review_queue.risk_tier`) — see note below |
| RAG Retrieve | `COCFilingItem`, `RuleEngineOutput` | `list[EvidenceChunk]` | No — chunks live only in-memory for the pipeline run |
| RAG Draft | above + `RiskScore` + chunks | `FilingSummary`, `ReviewResult` | `confidence_score` only; never `FilingSummary` text |
| Supervisor | all of the above | `HandoffPackage`, `list[AgentEvent]` (4 events) | Handed to `repository.save_package()` |
| Router | `HandoffPackage` | `review_queue: str` | On `coc_filings`/`review_queue` |
| Repository | `HandoffPackage` + `AgentEvent[]` | None (terminal) | 3 tables, 1 transaction |

**`AgentEvent.confidence` per stage.** `domain.py`'s `AgentEvent` carries a
`confidence: Optional[float]` field the stub docstrings for `rule_engine.py`,
`ml_service.py`, and `supervisor.py` never mention — resolved here rather than left to
each caller's guess:

| Stage | `confidence` on `SUCCESS` | Why |
|---|---|---|
| `RuleEngine` | `None` | No probabilistic output — `PASS`/`FLAG` is not a confidence, and encoding it as `1.0`/`0.0` would fabricate a number that isn't there |
| `MLService` | `risk_score.composite_risk` | A real, already-computed confidence-shaped float; leaving it `None` discards the one audit signal this field exists to carry |
| `RAGRetrieve` | `None` | The top `similarity_score` is a distance-derived retrieval score, not confidence in an assertion — conflating the two corrupts any later calibration analysis |
| `RAGDraft` | `review_result.confidence_score` | The one stage that produces an actual grounding-based confidence; clamp again per `safety_spec.md` §1 defense-in-depth before it lands on the event |
| Any stage | `None` on `FAILURE`, regardless of the table above | A failed stage has no confidence, and a placeholder's synthetic value (§4) must never land in the audit trail looking like a measurement |

No full filing text, chunk text, or LLM output text crosses into persistence at any
stage — enforced structurally by giving `repository.save_package()` only scalar fields
to write, never the dataclass objects that carry the free text (`FilingSummary`,
`RuleEngineOutput.rule_results[].evidence`, `EvidenceChunk.chunk_text`).

**What the schema can and cannot hold.** The three tables created in `repository.py`
(frozen) expose exactly these columns:

- `coc_filings`: `filing_id, status, risk_tier, review_queue, confidence_score, error_reason, assembled_at`
- `agent_audit_events`: `id, filing_id, agent_name, input_hash, output_summary, confidence, status, error_message, executed_at`
- `review_queue`: `filing_id, queue_name, status, risk_tier, confidence_score, assembled_at`

There is **no `composite_risk` column anywhere.** The composite score is computed in
`ml_service.score_risk()`, used to derive `risk_tier`, and then survives the run only as
part of the `MLService` `AgentEvent.output_summary` shape description — it is
deliberately not recoverable as a number from the database. If a future requirement needs
the raw score for audit or recalibration, that is a schema change and therefore a
production gap (§6), not something this build can work around.

## 3. Decision rationale — why this sequence, why not parallel, why not one LLM call

**Why sequential, not parallel.** `ml_service.score_risk()` and `rag_service.retrieve()`
both take `rule_output` as an input (their stub signatures in `ml_service.py` and
`rag_service.py`), so a true parallel
fan-out from `COCFilingItem` alone isn't possible without changing what each stage
consumes. The sequence is Rule Engine → ML Risk → RAG Retrieve → RAG Draft; the "run all
three services" safety rule means all three are *attempted unconditionally* per filing,
not that they run concurrently. (A future concurrency improvement — running ML Risk and
RAG Retrieve in parallel once `rule_output` exists, since neither depends on the other —
is captured in `production_hardening/epics_and_stories.md` Epic 5, not implemented here;
it changes nothing about correctness, only latency.)

**Why three services instead of one LLM call.** A single LLM call asked to "check rules,
score risk, and summarize evidence" would collapse three independently-auditable outputs
into one opaque generation, with three consequences that matter for a regulated,
audit-required workflow: (1) the deterministic rule checks would no longer be
deterministic — the same filing could get a different rule-flag on a retry, which an
audit trail can't defend; (2) the risk score would no longer be reproducible or
explainable via fixed feature weights (`ml_service.py`'s documented approach); (3)
non-negotiable safety rule 8 ("ML score must not be the sole reason for routing")
becomes unenforceable if risk-scoring logic is inseparable from the summary-generation
call. Three services means three independently testable, independently auditable
outputs — the LLM's only job is evidence retrieval and grounded summarization, the part
that's actually language-shaped.

**Failure modes and fallback per stage:**

| Stage | Failure mode | Fallback |
|---|---|---|
| Rule Engine | Malformed/empty filing fields | Returns `overall_flag=FLAG` with a `MISSING_INFO` rule result rather than raising, where possible; raises `RuleEngineError` only for truly unprocessable input |
| ML Risk | `RuleEngineOutput` missing expected fields | See §4 Degraded-Input Contract below |
| RAG Retrieve | Both collections empty/unreachable | Raises `RAGServiceError` (single-collection failure is not an error — degraded, not failed) |
| RAG Draft | Unparseable LLM response | Raises `RAGServiceError` — never returns a guessed/partial `FilingSummary` |
| Any stage | Any exception | Supervisor catches per-stage, records `AgentEvent(status=FAILURE)`, continues to the next stage anyway (rule 7), final `HandoffPackage.status = PIPELINE_ERROR` if any stage failed |

## 4. Degraded-input contract

Safety rule 7 requires all three services to run for every filing, but
`ml_service.score_risk(item, rule_output)` and `rag_service.retrieve(item, rule_output)`
both consume `rule_output`. **Adopted contract:** if `rule_engine.run_checks()` raises,
the supervisor constructs a minimal placeholder `RuleEngineOutput` —
`RuleEngineOutput(filing_id=item.filing_id, rule_results=[], overall_flag="FLAG", checked_at=utcnow())`
— and passes that placeholder into `ml_service.score_risk()` and
`rag_service.retrieve()` so "attempt all four calls" is mechanically possible.
`overall_flag="FLAG"` (not `"PASS"`) is deliberate: when the rule engine itself failed,
treat the filing as maximally uncertain rather than defaulting to a clean bill of
health — a failed check must never look like a passed check downstream. The
`RuleEngine` `AgentEvent` for that filing still records `status=FAILURE`, so
`HandoffPackage.status` becomes `PIPELINE_ERROR` regardless of what the placeholder lets
the later stages compute; the placeholder exists purely so those later stages have a
valid input to attempt, satisfying rule 7's "no short-circuiting."

**The same contract extends to stage 2 and stage 3, which this section originally left
undefined.** `rag_service.retrieve(item, rule_output)` needs a `RuleEngineOutput`
regardless of whether `ml_service.score_risk()` succeeded, and
`rag_service.draft_summary(item, rule_output, risk_score, chunks)` needs both a
`RiskScore` and a `chunks` list regardless of whether the two stages before it
succeeded. Rule 7 requires every stage to still be attempted, so the supervisor needs a
placeholder for each.

- **If `ml_service.score_risk()` raises**, the supervisor constructs
  `RiskScore(filing_id=item.filing_id, sla_delay_probability=1.0,
  escalation_probability=1.0, review_effort_score=1.0, composite_risk=1.0,
  risk_tier="HIGH", model_version="unavailable-placeholder", scored_at=utcnow())` and
  passes it to `rag_service.retrieve()`/`draft_summary()`. **A zeroed `RiskScore` is the
  wrong placeholder and must never be used** — `composite_risk=0.0` yields
  `risk_tier="LOW"`, which reads downstream as a clean bill of health on a filing whose
  risk scoring *failed*. The placeholder is the inverse of a clean bill of health, for
  the same reason `overall_flag="FLAG"` is used above rather than `"PASS"`.
  `model_version="unavailable-placeholder"` (never the real `MODEL_VERSION` constant) so
  an auditor reading `agent_audit_events` can never mistake a placeholder row for a real
  scoring run, and so ml_service_spec.md §3's "same `model_version` implies reproducible
  `composite_risk`" invariant is never silently violated. This placeholder is a call
  argument only — it is never written onto `HandoffPackage.risk_score`, which stays
  `None` when `MLService`'s `AgentEvent` is `FAILURE`.
- **If `rag_service.retrieve()` raises**, the supervisor passes `chunks=[]` to
  `draft_summary()` and still calls it — rule 7 leaves no honest alternative, and
  fabricating chunks would be worse than any status outcome. This is not a special
  case to suppress: zero chunks means every citation the model attempts is
  unverifiable, so `confidence_score` computes to `0.0` and
  `ReviewResult.recommendation = FLAG_FOR_HUMAN` through the *same* grounding logic
  `rag_spec.md` §4 already defines for zero citations — no new branch, no new rule.
  `draft_summary()` must not raise merely because `chunks` is empty; the evidence region
  of its prompt states plainly that no evidence was retrieved rather than presenting an
  empty section the model could misread as "nothing to cite against, therefore nothing
  to flag." `HandoffPackage.status` is `PIPELINE_ERROR` regardless (the `RAGRetrieve`
  `AgentEvent` is `FAILURE`), so nothing downstream is misled by the `RAGDraft` stage
  legitimately reporting `SUCCESS` with `confidence_score=0.0`.

In both cases the placeholder's job is narrow: make the next call possible, never make
a failure look like success. The `AgentEvent` for the failed stage is what carries the
signal (`status=FAILURE`, `HandoffPackage.status=PIPELINE_ERROR`) — the placeholder value
itself is deliberately never trusted as a real measurement, and per §2's
`AgentEvent.confidence` table, a `FAILURE` event never reports a `confidence` value —
only a real measurement does.

## 5. Integration accommodation — route-on-persist in `Repository.save_package()`

**This is an accommodation to the frozen starter's call order, not the ideal production
boundary.** It is documented here rather than left implicit because it deliberately
couples persistence to routing.

**The conflict.** The provided starter contains two incompatible orderings:

| Source | Ordering it encodes | Status |
|---|---|---|
| `tests/test_repository_audit.py` (provided) | `run_pipeline()` → `route()` → `save_package()` — six places set `package.review_queue = route(package)` before saving | Provided test |
| `service.process()` → `api.py` (both frozen) | `run_pipeline()` → `save_package()` → `route()` — persistence happens first | Frozen runtime |
| `supervisor.py` docstring (provided) | "`HandoffPackage.review_queue` must be None from this function" | Provided constraint |

On the real API path the package therefore reached `save_package()` with
`review_queue=None`, and requirement 3 of `save_package()`'s own contract ("insert one
row into `review_queue` **if** `package.review_queue is not None`") meant that table was
never written. `GET /review-queue` and `GET /dashboard` rendered empty after successful
filings — a mandatory end-to-end behaviour silently absent, while the suite stayed green
because the provided tests route by hand first.

**The repair.** `repository._ensure_review_queue()` calls the existing pure
`router.route()` when — and only when — `package.review_queue` is still `None`, before
the first `conn.execute()` so it never runs inside the open transaction. An
already-routed queue is preserved untouched.

**Why this and not the alternatives.** `api.py` and `service.py` are frozen, so the
correct fix (route before persisting, inside `service.process()`) is unavailable. Having
`supervisor.run_pipeline()` route would contradict a provided docstring constraint,
`project_rules.md`'s "it must not set `review_queue`", and a provided test. That leaves
`save_package()` as the only reachable non-frozen point in the frozen call chain.

**What this costs, stated plainly.** `repository.py` now imports `router.py`, so
persistence depends on routing. Two call sites can now invoke `route()` — here and
`api.py`. That is tolerable only because `route()` is a pure, deterministic function of
the package: both sites compute the same queue, no routing *policy* is duplicated
(`router.py` remains its sole owner), and `api.py`'s existing
`if result.review_queue is None` guard leaves the already-persisted value alone. In a
build where `service.py` were editable, routing would move there and this accommodation
would be deleted.

## 6. Production gaps — what would need to change before this runs on real filings

| Gap | Why it's a gap | Severity if unaddressed |
|---|---|---|
| SQLite, single file, WAL mode | No real concurrent-writer story; two simultaneous `POST /filings/process` calls risk lock contention at production volume ("tens of thousands of filings annually") | High at scale — becomes Postgres, see `production_hardening/epics_and_stories.md` Epic 5 |
| `confidence_score < 0.70` threshold is asserted, not calibrated | No ground-truth reviewer-agreement data exists yet to validate the cutoff | High — a miscalibrated threshold either floods reviewers with false flags or lets low-confidence summaries through as `APPROVE` |
| No authN/authZ on API endpoints | `api.py` is frozen in this build; a production deployment needs a gateway (OAuth2/mTLS) in front of it | High — this is a healthcare compliance system; unauthenticated access is unacceptable |
| No observability/tracing beyond audit rows | Audit rows answer "what happened to filing X" but not "is the pipeline healthy right now" (latency, error rate, throughput) | Medium — operational blindness, not a safety failure per se |
| No red-team regression gate in CI | The adversarial catalog in `safety_spec.md` §4 is tested manually today; nothing prevents a future change from silently reintroducing an injection vulnerability | Medium — regression risk grows as the codebase changes |
| No embedding/retrieval drift monitoring | If the policy/regulatory corpus is updated in production, nothing detects retrieval quality degrading over time | Medium — silent accuracy decay |

Full backlog with acceptance criteria for closing each of these:
`production_hardening/epics_and_stories.md`. Two items from this list are the minimum
required in `OPERATIONAL_HANDOFF.md`'s "production prerequisites" section.

## Production-grade additions in this spec

§3's explicit rationale for 3-services-not-1-LLM-call and sequential-not-parallel, and
§6's gap table, are the direct answers to the mandatory Q&A questions ("Why did you
choose this RAG and agent architecture?", "What is needed before this solution can move
to a production rollout?") — captured here rather than only in a slide, so the design
record and the defense are the same document.
