# ml_service_spec.md — Risk Dimensions, Features, Weights, Composite, Tier Thresholds

Governs `ml_service.score_risk(item: COCFilingItem, rule_output: RuleEngineOutput) ->
RiskScore`. Where this file conflicts with `safety_rules.md`, `safety_rules.md` wins.

## 1. What the model predicts, and what it is not

Three dimensions, each a float in `[0.0, 1.0]`, plus a weighted composite and a tier:

| Field | Predicts | Reviewer question it answers |
|---|---|---|
| `sla_delay_probability` | Filing misses its review SLA | "Will this be late?" |
| `escalation_probability` | Filing gets escalated beyond first-line review | "Will this need a specialist?" |
| `review_effort_score` | Relative reviewer time required | "How long will this take?" |
| `composite_risk` | Weighted combination of the three | "Where does this sit in the queue?" |
| `risk_tier` | `HIGH` / `MEDIUM` / `LOW` from `composite_risk` | "Does this jump the queue?" |

**This is not a trained model, and that is a design decision.** `ml_service.py` mandates a
documented feature-weighted calculation: no fitted estimator, no serialized artifact, no
randomness. Three reasons, in order of weight:

1. **Auditability.** A regulator asking "why was this filing scored HIGH in March?" gets a
   traceable answer — these features, these weights, this arithmetic. A fitted model's
   answer depends on which snapshot was deployed that month.
2. **Reproducibility.** `eval_risk_calibration.py` requires the same filing to produce an
   identical `risk_tier` and `composite_risk` variance below `0.001` across runs. A
   retrained estimator breaks that by construction.
3. **No training data exists.** The package ships five synthetic filings and no labels.
   Fitting anything on five unlabeled examples would produce a model with the *appearance*
   of rigor and none of the substance.

`model_version = "feature-weighted-v1.0"`. Bump it whenever a weight or feature changes —
it is the only handle an auditor has on which arithmetic produced a stored `risk_tier`.

## 2. Feature definitions

Six features, three from `rule_output` and three from the filing itself.

| # | Feature | Definition | Source |
|---|---|---|---|
| 1 | `high_rules` | Count of `rule_results` with `severity == "HIGH"` | `rule_output` |
| 2 | `med_rules` | Count of `rule_results` with `severity == "MEDIUM"` | `rule_output` |
| 3 | `flagged` | `1` if `overall_flag == "FLAG"` else `0` | `rule_output` |
| 4 | `sections` | `len(mandatory_sections_present)`, capped at 8 | `item` |
| 5 | `sections_missing` | `8 - sections` | derived |
| 6 | `filing_type_weight` | `NEW` → `1.0`, `AMENDMENT` → `0.6`, `RENEWAL` → `0.3` | `item.filing_type` |

`LOW`-severity rules are excluded by design (`rule_engine_spec.md` §5) so an informational
finding can never move a tier.

**Why 8 is the section cap.** Eight is the full set of mandatory sections a complete filing
carries (`filing_low_risk` in `conftest.py` lists exactly eight). `sections_missing` is
therefore a real completeness measure, not an arbitrary scale.

**Why `filing_type_weight` is ordered that way.** A `NEW` filing has no prior approved
version to diff against, so every section is novel review surface. An `AMENDMENT` changes a
subset. A `RENEWAL` is mostly unchanged text. This is the one feature drawn from filing
metadata rather than rule findings, and it exists so two filings with identical rule
outcomes are not scored identically when one is a fresh submission and the other a renewal.

## 3. Weights and the composite formula

```python
sla_delay     = min(1.0, high_rules * 0.30 + med_rules * 0.10)
escalation    = min(1.0, high_rules * 0.35 + sections_missing * 0.05)
review_effort = min(1.0, (high_rules + med_rules) * 0.15)

composite     = sla_delay * 0.40 + escalation * 0.40 + review_effort * 0.20
```

Every dimension is clamped to `1.0` before it enters the composite, so `composite_risk`
cannot exceed `1.0`. It also cannot fall below `0.0` — all terms are non-negative — but
clamp both ends explicitly rather than relying on that.

**Why these weights.**

- `sla_delay` and `escalation` carry `0.40` each, `review_effort` only `0.20`: the first two
  are outcomes with external consequences (a missed regulatory deadline, a specialist
  pulled in), while effort is an internal cost. Queue position should be driven by
  consequence, not by workload.
- `high_rules` dominates `med_rules` (`0.30` vs `0.10` on SLA) because a HIGH rule means a
  regulator would return the filing — that is the delay, not a contributor to it.
- `escalation` is the only dimension reading `sections_missing`, at a deliberately small
  `0.05`: a structurally incomplete filing is more likely to need a specialist, but
  missing sections already surface as HIGH `MI-` rules, so weighting them heavily here
  would double-count the same signal.
- `review_effort` treats HIGH and MEDIUM equally at `0.15` — a reviewer's time is spent per
  finding, roughly regardless of severity.

**`filing_type_weight` is defined but not yet in the formula.** It is specified so the
feature set is complete and the intent is recorded, but adding it now would shift the
composite values in §5 that `eval_risk_calibration.py`'s ordering check depends on, with no
data to justify the shift. Introducing it is a `v1.1` change gated on Epic 4's calibration
data (`production_hardening/epics_and_stories.md`), not a v1.0 omission.

## 4. Tier thresholds

```
composite_risk >= 0.65  →  HIGH
composite_risk >= 0.35  →  MEDIUM
composite_risk <  0.35  →  LOW
```

Fixed by the `ml_service.py` docstring. Like the `0.70` confidence cutoff in
`rag_spec.md` §5, these are **asserted, not calibrated** — no reviewer-labeled outcome data
exists to fit them. Recorded as a production gap (`architecture.md` §5) with an exit
criterion in Epic 4: re-derive both cutoffs from observed SLA-breach and escalation rates
per tier once delayed ground truth is captured.

**Severity is never a pass-through to tier.** `ml_service.py` forbids it explicitly, and it
would collapse two different questions into one (`rule_engine_spec.md` §5). A single HIGH
rule on an otherwise complete filing scores `0.31` — `LOW` — and that is correct: one
fixable language gap on a complete renewal is not a queue-jumping emergency.

## 5. Expected values for the five fixtures

Derived by applying §2–§4 to the rule counts in `rule_engine_spec.md` §6, re-verified
against `run_checks()` executed for real (Task 1, `plan.md` US-3) rather than the
hand-estimated counts this table originally used. This is the table
`eval_risk_calibration.py` asserts against; changing a weight or a rule means re-deriving
it.

| Fixture | `high` | `med` | `missing` | `sla` | `esc` | `effort` | `composite` | tier |
|---|---|---|---|---|---|---|---|---|
| `filing_low_risk` | 0 | 0 | 0 | 0.00 | 0.00 | 0.00 | **0.00** | LOW |
| `filing_idempotency` | 1 | 1 | 2 | 0.40 | 0.45 | 0.30 | **0.40** | MEDIUM |
| `filing_medium_risk` | 1 | 3 | 2 | 0.60 | 0.45 | 0.60 | **0.54** | MEDIUM |
| `filing_high_risk` | 3 | 5 | 6 | 1.00 | 1.00 | 1.00 | **1.00** | HIGH |
| `filing_pipeline_error` | 6 | 6 | 8 | 1.00 | 1.00 | 1.00 | **1.00** | HIGH |

`filing_pipeline_error`'s `med` corrected from an originally-estimated `4` to the verified
`6` (`rule_engine_spec.md` §6: PA-002, PA-003, PH-002, PH-003 all trivially fire on that
fixture's empty-string fields). `high`, `missing`, and every other row are unchanged from
the original estimate — the verified rule counts matched it exactly. The correction does
not move `composite` or `tier`: `sla`, `esc`, and `effort` were already at their
`min(1.0, …)` ceiling under the old `med=4`, so a higher `med` has no further effect.

This satisfies all three checks in `eval_spec.md` §2:

- **Ordering** — `1.00 > 0.54 > 0.00` for high / medium / low, and `filing_high_risk` is
  `HIGH`, `filing_low_risk` is `LOW`.
- **Rule-signal use** — `filing_medium_risk` at `0.54` versus the same filing with zero
  rules flagged at **`0.04`** proves the score consumes `rule_output` rather than filing
  metadata only. That `0.04` comes from `sections_missing` alone (2 missing sections ×
  `0.05` = `0.10` on the `escalation` dimension), carried through the `0.40` composite
  weight on `escalation`: `0.10 * 0.40 = 0.04`. `0.10` is the pre-weighting escalation
  value, not the composite — a prior version of this line quoted the escalation figure
  directly and skipped the weighting step. Verified live by
  `evals/eval_risk_calibration.py::eval_rule_signal_used` (`plan.md` EVAL-B):
  `composite_real=0.54`, `composite_zeroed=0.04`, `composite_delta=0.50`.
- **Stability** — pure arithmetic over integer counts, so repeated scoring is bit-identical
  and variance is exactly `0.0`, not merely under `0.001`.

Note that `filing_high_risk` and `filing_pipeline_error` both saturate at `1.00`. That is
acceptable — they are not required to be distinguishable from each other, and
`filing_pipeline_error` is expected to end as `PIPELINE_ERROR` on a different code path
anyway. It does mean the scale has no headroom above eight findings; recorded as a
calibration input for Epic 4 rather than fixed by inventing a wider scale now.

## 6. What "calibrated" means here, and the AUC question

The guide asks what AUC threshold is acceptable. **AUC does not apply to this service, and
reporting one would be misleading.** AUC measures how well a classifier's scores rank
positives above negatives against *known labels*; there are no labels here, no
classification, and no held-out set — five synthetic filings with no reviewer outcomes.

Calibration is instead demonstrated by the three properties in `eval_spec.md` §2 —
monotonic ordering across fixtures, provable consumption of the rule signal, and exact
reproducibility. Those are the claims this build can actually support.

The honest statement for `OPERATIONAL_HANDOFF.md`: *this score is a documented, reproducible
heuristic that ranks filings consistently; it is not validated against real outcomes, and
must not be presented to reviewers as a probability with predictive accuracy behind it.*
AUC becomes the right metric once Epic 4 captures reviewer decisions as delayed ground
truth — at which point the correct move is likely to replace this heuristic with a fitted
model, not to compute AUC for a hand-weighted formula.

## 7. Error handling

Raise `MLServiceError` on unexpected failure — never a bare `Exception`. Missing or
malformed `rule_output` is handled by `architecture.md` §4's degraded-input contract: the
supervisor supplies a placeholder `RuleEngineOutput` with `overall_flag="FLAG"` and empty
`rule_results`, which scores `high=0, med=0` and therefore `composite = sections_missing *
0.05 * 0.40`. That deliberately produces a *low* score for a filing whose rule engine
failed — the score is meaningless in that case, and the `PIPELINE_ERROR` status plus the
`FAILURE` `AgentEvent` are what carry the signal, not the number.

## Production-grade additions in this spec

§5's fixture-level derivation and §6's rejection of AUC go beyond what the stub docstring
asks for. §5 exists because the eval assertions are downstream of these weights — writing
the numbers down makes a future weight change a visible decision instead of a silent eval
break. §6 exists because answering "what AUC threshold?" with a number would be the wrong
answer confidently given; naming why the metric doesn't apply, and what replaces it, is the
defensible one.
