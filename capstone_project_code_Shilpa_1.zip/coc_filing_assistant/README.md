# COC Filing Readiness Assistant - Final Capstone

Healthcare FDE Program | Session 13 | Version 2.0
Submission: Shilpa, Cohort 1

Assesses whether a payer's Certificate of Coverage (COC) filing is ready to be submitted
to a state regulator. Each filing gets three independent assessments — deterministic
compliance rules, a reproducible risk score, and a retrieval-grounded evidence summary —
then one package is staged for a human reviewer and assigned to the review queue best
equipped to resolve it.

**The system never files, sends, or submits anything.** `HANDOFF_READY` means staged for
human review. There is no email client, no outbound POST, and no notification path in the
codebase — that is structural, not a policy assertion.

---

## What is implemented, what is designed only, what is simulated

This section is the honest inventory. Anything not listed as **implemented** is not
running code.

### Implemented and verified (real code, real tests, observed results)

| Component | What actually runs |
|---|---|
| Rule Engine (`rule_engine.py`) | 14 deterministic rules across 5 categories. Pure Python — no model, no I/O. |
| ML Risk Service (`ml_service.py`) | Feature-weighted composite risk score and tier assignment. Deterministic and reproducible. See the caveat below — this is a deliberate design choice, not a shortcut. |
| RAG Evidence (`rag_service.py`) | Live retrieval from two ChromaDB collections plus a real generation call to the approved enterprise LLM endpoint. Every citation is verified as a verbatim substring of a chunk actually retrieved for that call. |
| Supervisor (`supervisor.py`) | Orchestration only. All four service calls attempted for every filing — no short-circuiting, even at HIGH risk. |
| Router (`router.py`) | Deterministic fixed-priority routing: LEGAL › PHARMACY › ACTUARIAL › NETWORK › OPERATIONS. Pure function of the handoff package. |
| Repository (`repository.py`) | Atomic three-table SQLite write. The audit table is append-only, enforced by SQLite triggers rather than by convention. |
| Inbound access control (`secured_app.py`) | Every endpoint except `/health`, `/docs` and `/openapi.json` requires an `X-API-Key` header matching `COC_API_KEY`, compared with `secrets.compare_digest`. An unset key **fails closed** — the app refuses the request rather than serving it unprotected. Implemented as an external ASGI wrapper because `api.py` is frozen. |
| Human review gate | `HANDOFF_READY` is blocked whenever any `AgentEvent` reports `FAILURE`. Filings are staged into a review queue; a human makes the filing decision. |
| PII and content guardrails | Audit rows carry no patient identifiers, no filing-section text, and no LLM output; `output_summary` is capped at 200 characters. Named tests assert each of these. |
| Prompt-injection defence | Structural. Raw filing free-text is not passed to the generation prompt; retrieved chunk text is confined to a separate, escaped evidence message. 6 adversarial/red-team cases pass with `injection_followed_count=0`. |
| Test suite | 203 tests passing, 95.42% coverage against an 80% gate. |
| Eval harness | 3 suites, 21 cases, compared against a human-approved baseline. 21 PASS / 0 FAIL / 0 ERROR / 0 SKIP. |
| Observability (`observability.py`, `evals/arize/`) | OpenTelemetry spans on every pipeline stage, written locally and — when Arize credentials are present — exported to Arize. Live-verified end to end. **This layer gates nothing**; the deterministic harness is the sole release gate. |
| Streamlit demo UI (`../coc_demo_ui/`) | A real client of the real API. It calls `POST /filings/process` unmodified; nothing is mocked. |

### Designed and documented, deliberately not built

| Item | Where it is specified | Why not built |
|---|---|---|
| Postgres persistence | `CLAUDE.md` §4, `specs/architecture.md`, `OPERATIONAL_HANDOFF.md` §5 | SQLite is single-writer with no DR story. Correct for production, out of scope for a single-user capstone. |
| Per-caller identity, roles, rotation, revocation | `OPERATIONAL_HANDOFF.md` §5 | A shared-secret header **is** implemented (see above), but it is authentication only. There is no way to identify one caller from another, grant differing permissions, rotate without a coordinated restart, or revoke a single caller. A real deployment needs an authenticated gateway. |
| Reviewer-labelled threshold calibration | `specs/ml_service_spec.md`, `OPERATIONAL_HANDOFF.md` §5–6 | No labelled outcome data exists, so the 0.70 confidence threshold and the 0.35/0.65 tier boundaries are documented and reproducible but **not fitted**. This is also why no AUC, Brier score, or ECE is reported — see appendix slide 12 of the deck. |
| Rate limiting, cost ceilings, SBOM, CI/CD gates | `OPERATIONAL_HANDOFF.md` §5 | Named production prerequisites, not capstone deliverables. |
| Controlled rollout (shadow → assisted → production) | `OPERATIONAL_HANDOFF.md` §7 | A five-phase plan on paper. No phase beyond Phase 0 has been executed. |

### Simulated or synthetic

| Item | Nature |
|---|---|
| All filing payloads (`demo_payloads/*.json`) | Synthetic. No real member, patient, or payer filing data exists anywhere in this package. |
| Policy and regulatory corpus (`data/`) | 6 synthetic documents across 2 ChromaDB collections. |
| The reviewer | There is no reviewer application, no authentication, and no reviewer workflow. The system **recommends** a queue and stages a package; the act of human review is out of scope. |
| The regulator | No integration of any kind. Nothing in this system can reach one. |

### One caveat worth reading before judging the ML component

`ml_service.py` does not train a model. It computes a documented feature-weighted score,
so identical filings always score identically. A fitted estimator would make the same
filing score differently across retrains, which an audit trail cannot defend. This is a
recorded architectural decision (`CLAUDE.md` §4), not an unfinished task.

---

## Setup

### Step 1: Create the Python environment
```bash
python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
```

### Step 2: Configure credentials
```bash
cp .env.example .env
```
Then set the approved enterprise AI endpoint, deployment, and credentials in `.env`.
`.env` is git-ignored and is **not** included in the submission zip; `.env.example`
documents every variable with placeholder values. There are no other credentials
anywhere in this package.

Optional: setting `ARIZE_API_KEY` and `ARIZE_SPACE_ID` additionally exports traces to
Arize. Leaving them unset changes nothing — tracing continues local-only, with no error.

### Step 3: Initialize the database
```bash
python scripts/init_db.py
```
Expected: `Database initialized: coc_filings.db`

### Step 4: Ingest documents into ChromaDB
```bash
python scripts/ingest_documents.py
```
Expected: 6 documents across 2 collections (`coc_policy_docs`, `coc_regulatory`).
Uses the same approved enterprise embedding function as `rag_service.py` — mixing
embedding functions between ingestion and query makes similarity scores meaningless.

### Step 5: Run the test suite
```bash
python -m pytest --cov=coc_filing_assistant --cov-report=term-missing --cov-fail-under=80 -q
```
Expected: **203 passed**, `Total coverage: 95.42%`.

### Step 6: Run the evals
```bash
python evals/run_all.py --release
```
Expected: **21 PASS · 0 FAIL · 0 ERROR · 0 SKIP**, exit 0. A failing eval is a release
blocker even when pytest is green.

---

## Running the service

```bash
uvicorn coc_filing_assistant.secured_app:secured --reload --port 8000
```

This is the **secured** entrypoint and requires `COC_API_KEY` to be set; it refuses to
serve a request without one. `uvicorn coc_filing_assistant.api:app` still works and is
still unauthenticated — use it only when you deliberately want the bare app.

```bash
curl -s localhost:8000/filings                                  # 401
curl -s -H "X-API-Key: $COC_API_KEY" localhost:8000/filings     # 200
```

API docs: http://localhost:8000/docs (open) · Dashboard: http://localhost:8000/dashboard
(protected — a browser tab cannot send a custom header, so view the review queue through
the Streamlit UI below, which sends it for you).

Optional Streamlit demo UI (a real client of the API above, from the repository root):

```bash
streamlit run coc_demo_ui/app.py
```

It defaults to `http://localhost:8000`; the API base URL is editable in its sidebar.
It reads `COC_API_KEY` from its own environment and attaches the header on every
call, so run it from a shell where that variable is set.
Requirements are in `coc_demo_ui/requirements-streamlit.txt`. This UI is a demo client
only — it is not part of the service and nothing in `src/` depends on it.

---

## Where the evidence lives

| Evidence | File |
|---|---|
| Observed test, eval, and live-API results | `OPERATIONAL_HANDOFF.md` §0–4 |
| Production prerequisites and known limitations | `OPERATIONAL_HANDOFF.md` §5–6 |
| Release eval detail per case | `evals/results/summary.md` and `evals/results/*.json` |
| Observability design, judge semantics, and disclosed findings | `evals/arize/README.md` |
| Arize trace exported live from the platform | `evals/arize/screenshots/` |
| Release verification terminal capture | `evals/results/screenshots/release_verification.png` |
| Access control, before and after (observed) | `evals/results/screenshots/access_control.png` |
| Live demo screenshots | `../coc_demo_ui/docs/demo_screens/` |

---

## Files that must not be modified

- `src/coc_filing_assistant/domain.py`
- `src/coc_filing_assistant/service.py`
- `src/coc_filing_assistant/api.py`
- `src/coc_filing_assistant/repository.py` (read functions only — `save_package()` is implemented here)
- `tests/conftest.py`
- `scripts/init_db.py`
- `scripts/ingest_documents.py` (except the embedding hook, which `README` Step 4 requires)
- `.claude/rules/safety_rules.md`

---

## Submission files

- `capstone_project_code_Shilpa_1.zip`
- `capstone_presentation_Shilpa_1.pptx`
- `capstone_video_Shilpa_1.mp4`

The zip excludes `.venv/`, `__pycache__/`, `*.db`, `vector_store/`, and `.env`.

---

## Note on audit.py

The previous version of the starter package listed `audit.py` as a separate file. In V2
the audit log lives inside `repository.py`. There is no separate `audit.py`.
