# Calibrate Learnings — coc_filing_assistant

Staging area for behavioral observations from this project. Entries get folded into
`CLAUDE.md` or `.claude/rules/*.md` once they've shown repetition or are high-confidence
on their own. Nothing here is a standing rule until promoted.

## 2026-08-17

- **Verify grep matches for context before counting them.** During plan.md's stub-count
  reconciliation, `NotImplementedError` at `rag_service.py:42` was initially counted as a
  live stub; it's a docstring/comment example inside the embedding-hook block. User
  correction: only count matches confirmed as executable code. Candidate addition to
  `project_rules.md`'s `## Verification` section — not yet promoted, holding per user's
  "only here" scoping instruction.
  Occurrences: 1

- **Don't cite an invented requirement as a completion gap.** EVAL-B (risk/ML
  calibration) was marked PARTIAL over a standalone rule-engine eval case that the spec
  never actually required — the 4 existing risk-calibration cases plus
  `eval_rule_signal_used` plus `test_rule_engine.py`'s 11/11 tests already satisfy the
  real requirement. User correction: check the exact documented scope before flagging
  something as missing; an unrequested addition is optional, not a gap.
  Occurrences: 1

- **Doc-only commit prefix.** User requested commit message "Docs:" for a plan.md/spec
  correction that wasn't an implementation task. CLAUDE.md §3's commit standard
  ("Task N: implement X") only covers task commits. One occurrence — not promoting yet;
  watch for a repeat before documenting a convention for non-task doc commits.
  Occurrences: 1
