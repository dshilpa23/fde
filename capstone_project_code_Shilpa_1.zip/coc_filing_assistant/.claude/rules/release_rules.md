# Release Rules

> Cross-check this checklist against Section 10 of the Final Capstone Implementation
> Guide (`Final_Capstone_COC_Filing_Readiness_Assistant.pdf`) before submitting. The
> items below are derived from this repository — `README.md`, `specs/README.md`,
> `safety_rules.md`, and the eval scripts — and may not be the guide's complete list.

## Release checklist

**Design artefacts**

- [ ] `CLAUDE.md` complete, all five sections, no placeholder comments remaining
- [ ] All six specs written: `architecture.md`, `rule_engine_spec.md`,
      `ml_service_spec.md`, `rag_spec.md`, `safety_spec.md`, `eval_spec.md`
- [ ] `project_rules.md`, `testing_rules.md`, `release_rules.md` written
- [ ] `safety_rules.md` unmodified — verify with `git diff --stat`
- [ ] Both open decisions in `LEARNER_TASK_MAP.md` resolved and recorded in the named spec

**Implementation**

- [ ] Zero `NotImplementedError` remaining in `src/` — verify with
      `grep -rc NotImplementedError src/`
- [ ] Embedding hook supplied, and identical in `rag_service.py` and
      `scripts/ingest_documents.py`
- [ ] `python scripts/init_db.py` → `Database initialized: coc_filings.db`
- [ ] `python scripts/ingest_documents.py` → 6 documents across 2 collections
- [ ] No frozen file modified apart from the permitted embedding hook

**Tests and evals**

- [ ] `python -m pytest -m baseline -q` → 15 passed
- [ ] `python -m pytest -q` → all passed
- [ ] `python -m pytest --cov=coc_filing_assistant --cov-fail-under=80 -q` passes
- [ ] All three eval scripts run and report no `FAIL` or `ERROR`:
      `eval_rag_quality.py`, `eval_risk_calibration.py`, `eval_end_to_end.py`
- [ ] Every safety test in `testing_rules.md` present and passing

**Service**

- [ ] `uvicorn coc_filing_assistant.api:app --port 8000` starts clean
- [ ] `GET /health` reports non-zero `policy_chunks` and `regulatory_chunks`
- [ ] `GET /dashboard` renders the review queue with real rows
- [ ] All 8 endpoints respond

**Deliverables**

- [ ] `OPERATIONAL_HANDOFF.md` filled in with observed results, not predictions
- [ ] Three files named exactly per `README.md`:
      `capstone_project_code_[YourName]_[CohortID].zip`,
      `capstone_presentation_[YourName]_[CohortID].pptx`,
      `capstone_video_[YourName]_[CohortID].mp4`
- [ ] Zip excludes `.venv/`, `__pycache__/`, `*.db`, `vector_store/`, `.env`
- [ ] `.env` is **not** in the zip; `.env.example` is
- [ ] Presentation and video claims match the code as built — no described feature that
      does not exist, no threshold quoted that differs from the implementation

## Safety stop conditions

Stop, fix, and retest the full suite before submitting if any of the following is true.
None of these may be waived, documented as a known issue, or deferred.

1. Any code path can file, send, submit, or notify. The service stages only.
2. Any row in `agent_audit_events` contains a patient identifier, filing-section text,
   or LLM output — or any `output_summary` exceeds 200 characters.
3. The adversarial-chunk test fails, or instruction text inside a chunk changes pipeline
   behaviour.
4. A `FilingSummary` citation cannot be traced to a retrieved `EvidenceChunk`.
5. `confidence_score` can leave `[0.0, 1.0]`.
6. `HANDOFF_READY` can be set while any `AgentEvent` has `status=FAILURE`.
7. Any service is skipped for any filing.
8. The ML risk score alone determines routing.
9. `safety_rules.md` has been modified.
10. Baseline tests fail.

## Demo requirements

5–7 minutes, live, no pre-recorded terminal output.

1. **One filing end to end.** `POST /filings/process` with a real filing. Show the
   returned `status`, `risk_tier`, `confidence_score`, and `review_queue`.
2. **Three services visible.** Show that all three ran — rule results, risk score, and
   retrieved evidence — for that same filing.
3. **Grounding.** Open the drafted summary and trace at least one citation back to the
   source document it came from.
4. **Audit trail.** `GET /audit-log` showing four events for the filing, with short
   summaries and no PII.
5. **Review queue.** `GET /dashboard` showing the filing in its assigned queue, and a
   one-sentence explanation of why that queue and not another.
6. **A safety behaviour.** Either the adversarial chunk being ignored, or a low-confidence
   filing forced to `NEEDS_REVIEW`. Show the mechanism, not just the outcome.
7. **Idempotency.** Resubmit the same `filing_id`; show `idempotent_replay=True` and an
   unchanged audit count.

Rehearse against a clean database. A demo that depends on pre-seeded state is a failed
demo.

## Operational handoff requirements

`OPERATIONAL_HANDOFF.md` must contain:

- **Observed eval results** — actual output from all three eval scripts, pasted, with the
  date of the run. Per filing: `status`, `risk_tier`, `confidence_score`, assigned queue.
  Predicted or hand-written results are a rubric failure.
- **Test results** — the real `pytest --cov` summary including the coverage table and
  total percentage.
- **At least two production prerequisites** — what must be true before this runs on real
  filings. Be specific and name the gap, not the category. Candidates grounded in this
  build: SQLite has no concurrent-writer story and must become Postgres; the confidence
  threshold of 0.70 is asserted rather than calibrated against reviewer agreement; there
  is no ground-truth loop, so no way to detect the risk score drifting; secrets are
  file-based with no rotation.
- **Known limitations** — anything the tests do not pin. State it plainly; an
  undisclosed gap found by a reviewer is worse than a disclosed one.
- **Rollback** — how to revert a release and what happens to filings already staged in
  the review queue.
