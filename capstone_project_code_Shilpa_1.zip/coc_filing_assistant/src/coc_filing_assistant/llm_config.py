"""LLM and ChromaDB configuration.

Task 7: get_llm_client(). Implemented against Databricks Model Serving
(`POST {workspace}/serving-endpoints/{name}/invocations`) via plain httpx -
requirements.txt ships no LLM SDK and project_rules.md forbids adding one.
See specs/rag_spec.md §2 for the embedding-tier rationale and
production_hardening/model_recommendations.md for the model-selection matrix
this endpoint name was chosen from.

All constants below are provided - do not change variable names.

Read .env.example for required environment variables.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from types import SimpleNamespace

import httpx
from dotenv import load_dotenv

# ChromaDB paths and collection names - provided, do not change
CHROMA_PATH = str(Path(__file__).parent.parent.parent / "vector_store")
POLICY_COLLECTION = "coc_policy_docs"
REGULATORY_COLLECTION = "coc_regulatory"

load_dotenv()

# Gateway paths like ".../ai-gateway/mlflow/v1/chat/completions" 400 on this
# workspace - Databricks Model Serving is called at the workspace root.
_RETRYABLE_STATUS = {429, 500, 502, 503, 504}


def _to_namespace(obj):
    """dict/list -> SimpleNamespace tree so callers can use attribute access
    (`response.choices[0].message.content`) exactly like an OpenAI SDK response,
    without adding an SDK dependency.
    """
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: _to_namespace(v) for k, v in obj.items()})
    if isinstance(obj, list):
        return [_to_namespace(v) for v in obj]
    return obj


class _RetryingChatCompletions:
    """Implements `.create(model=..., messages=..., ...)` over a raw serving
    endpoint invocation, with bounded retry on transient gateway errors.

    Kept separate from rag_service.py deliberately (module boundary,
    project_rules.md): this class only knows how to *call* the endpoint. What
    a failure means for the pipeline - raising RAGServiceError, recording an
    AgentEvent - is decided by the caller, not here.
    """

    def __init__(self, endpoint: str, api_key: str, timeout: float = 60.0,
                 max_retries: int = 3, backoff: float = 1.5):
        self._client = httpx.Client(
            base_url=endpoint.rstrip("/"),
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            timeout=timeout,
        )
        self._max_retries = max_retries
        self._backoff = backoff

    def create(self, *, model: str, messages: list[dict], max_tokens: int = 1024,
               temperature: float | None = None, response_format: dict | None = None,
               **kwargs):
        payload: dict = {"messages": messages, "max_tokens": max_tokens}
        if temperature is not None:
            payload["temperature"] = temperature
        if response_format is not None:
            payload["response_format"] = response_format
        payload.update(kwargs)

        last_exc: Exception | None = None
        for attempt in range(self._max_retries + 1):
            try:
                resp = self._client.post(f"/serving-endpoints/{model}/invocations", json=payload)
                if resp.status_code in _RETRYABLE_STATUS and attempt < self._max_retries:
                    time.sleep(self._backoff * (attempt + 1))
                    continue
                resp.raise_for_status()
                return _to_namespace(resp.json())
            except (httpx.TransportError, httpx.HTTPStatusError) as exc:
                last_exc = exc
                if attempt == self._max_retries:
                    raise
                time.sleep(self._backoff * (attempt + 1))
        raise last_exc  # pragma: no cover - unreachable, satisfies type checkers


def get_llm_client():
    """Return a client for the organisation-approved enterprise AI endpoint.

    Reads ENTERPRISE_LLM_ENDPOINT, ENTERPRISE_LLM_API_KEY and
    ENTERPRISE_LLM_DEPLOYMENT from the environment (.env, via python-dotenv)
    and returns a thin httpx-backed adapter over Databricks Model Serving.

    The returned client supports:
      client.chat.completions.create(model=..., messages=..., ...)
        -> object with .choices[0].message.content

    `model=` should be ENTERPRISE_LLM_DEPLOYMENT (the serving endpoint name),
    not a vendor model id - Databricks Model Serving keys invocations by
    endpoint name.

    Returns:
        An object exposing `.chat.completions.create(...)`.

    Raises:
        RuntimeError: if ENTERPRISE_LLM_ENDPOINT, ENTERPRISE_LLM_API_KEY, or
            ENTERPRISE_LLM_DEPLOYMENT is not set - fail fast rather than
            construct a client that can only error later, deep inside
            rag_service.py.
    """
    endpoint = os.environ.get("ENTERPRISE_LLM_ENDPOINT")
    api_key = os.environ.get("ENTERPRISE_LLM_API_KEY")
    deployment = os.environ.get("ENTERPRISE_LLM_DEPLOYMENT")
    if not endpoint or not api_key or not deployment:
        raise RuntimeError(
            "ENTERPRISE_LLM_ENDPOINT, ENTERPRISE_LLM_API_KEY and "
            "ENTERPRISE_LLM_DEPLOYMENT must be set.\n"
            "Copy .env.example to .env and configure the approved endpoint first."
        )
    completions = _RetryingChatCompletions(endpoint, api_key)
    return SimpleNamespace(chat=SimpleNamespace(completions=completions))
