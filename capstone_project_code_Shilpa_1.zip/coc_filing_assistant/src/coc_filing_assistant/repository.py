"""Persistence layer - SQLite storage for filings and audit events.

IMPORTANT: audit.py has been merged into this file (V2 change).
All audit event persistence is implemented inside save_package().
Do not create a separate audit.py file.

PROVIDED (do not modify):
  DB_PATH, get_connection(), init_db(),
  find_by_filing_id(), get_audit_events(), list_filings(), list_review_queue()

LEARNER TASK (Task 6): Implement save_package().

Note: audit.py has been merged into this file. All audit event
persistence happens inside save_package() - no separate audit.py needed.

Read before starting:
  - specs/safety_spec.md  (PII prohibition and audit constraints)
  - .claude/rules/safety_rules.md
  - tests/test_repository_audit.py
  - Section 5.4 of the Implementation Guide (audit trail requirements)
"""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

from coc_filing_assistant import observability, router
from coc_filing_assistant.domain import HandoffPackage, AgentEvent, PersistenceError

DB_PATH = Path("coc_filings.db")


# ---------------------------------------------------------------------------
# Provided - do not modify
# ---------------------------------------------------------------------------

def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(db_path: Path = DB_PATH) -> None:
    """Create tables and append-only triggers. Safe to call multiple times."""
    conn = get_connection(db_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS coc_filings (
            filing_id       TEXT PRIMARY KEY,
            status          TEXT NOT NULL,
            risk_tier       TEXT,
            review_queue    TEXT,
            confidence_score REAL,
            error_reason    TEXT,
            assembled_at    TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS agent_audit_events (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            filing_id       TEXT NOT NULL,
            agent_name      TEXT NOT NULL,
            input_hash      TEXT NOT NULL,
            output_summary  TEXT NOT NULL,
            confidence      REAL,
            status          TEXT NOT NULL,
            error_message   TEXT,
            executed_at     TEXT NOT NULL,
            FOREIGN KEY (filing_id) REFERENCES coc_filings(filing_id)
        );

        CREATE TABLE IF NOT EXISTS review_queue (
            filing_id       TEXT PRIMARY KEY,
            queue_name      TEXT NOT NULL,
            status          TEXT NOT NULL,
            risk_tier       TEXT,
            confidence_score REAL,
            assembled_at    TEXT NOT NULL
        );

        CREATE TRIGGER IF NOT EXISTS no_update_agent_audit
        BEFORE UPDATE ON agent_audit_events
        BEGIN
            SELECT RAISE(ABORT, 'audit events are append-only');
        END;

        CREATE TRIGGER IF NOT EXISTS no_delete_agent_audit
        BEFORE DELETE ON agent_audit_events
        BEGIN
            SELECT RAISE(ABORT, 'audit events are append-only');
        END;
    """)
    conn.commit()
    conn.close()


def find_by_filing_id(
    filing_id: str, db_path: Path = DB_PATH
) -> Optional[dict]:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM coc_filings WHERE filing_id = ?", (filing_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_audit_events(
    filing_id: str, db_path: Path = DB_PATH
) -> list[dict]:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM agent_audit_events WHERE filing_id = ? ORDER BY executed_at",
        (filing_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_filings(db_path: Path = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM coc_filings ORDER BY assembled_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_review_queue(db_path: Path = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM review_queue ORDER BY assembled_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# LEARNER TASK - implement save_package()
# ---------------------------------------------------------------------------

_MAX_OUTPUT_SUMMARY_LEN = 200


def _truncate_summary(text: str) -> str:
    """safety_spec.md §2: hard cap at 200 chars, truncate with an explicit
    marker rather than silently cutting mid-word. supervisor.py already
    truncates before constructing AgentEvent - this re-truncates defensively
    at the persistence boundary too, the same clamp-at-every-boundary pattern
    used for confidence_score elsewhere in this codebase."""
    text = text or ""
    if len(text) <= _MAX_OUTPUT_SUMMARY_LEN:
        return text
    return text[: _MAX_OUTPUT_SUMMARY_LEN - 1] + "…"


def _confidence_score(package: HandoffPackage) -> Optional[float]:
    if package.review_result is not None:
        return package.review_result.confidence_score
    return None


def _ensure_review_queue(package: HandoffPackage) -> None:
    """Route-on-persist, but only when the caller has not already routed.

    An integration accommodation to the frozen starter call order, not the ideal
    production boundary (`architecture.md` §6). Frozen `service.process()` calls
    `save_package()` *before* frozen `api.py` calls `router.route()`, so on the API
    path `package.review_queue` is still `None` at write time and the `review_queue`
    table would never receive a row — leaving `/review-queue` and `/dashboard` empty.
    The provided `test_repository_audit.py` tests, by contrast, route before saving,
    so the starter's own tests and its runtime ordering disagree.

    Routing *policy* is not duplicated here: this delegates to the same pure
    `router.route()` that `api.py` calls, so `router.py` remains the sole owner of
    queue-selection rules. Because `route()` is deterministic, the queue persisted
    here is identical to the one `api.py` would compute afterwards, and `api.py`'s
    own `if result.review_queue is None` guard then leaves this value untouched.

    Called before the first `conn.execute()`, so it never runs inside the open
    transaction.

    Args:
        package: The package about to be persisted. Mutated in place only when its
            `review_queue` is `None`; an already-routed queue is preserved as-is.
    """
    if package.review_queue is None:
        package.review_queue = router.route(package)


def save_package(
    package: HandoffPackage,
    agent_events: list[AgentEvent],
    db_path: Path = DB_PATH,
) -> None:
    """Atomically persist a HandoffPackage and all AgentEvents.

    Requirements:
      1. Insert ONE row into coc_filings for the package.
      2. Insert ONE row into agent_audit_events per AgentEvent.
      3. Insert ONE row into review_queue if package.review_queue is not None.
         `_ensure_review_queue()` routes first when the caller left it unset, so on
         the frozen API path this row is now always written — see that helper for
         why the accommodation exists.
      4. All three inserts must happen in a SINGLE transaction.
         If any insert fails, roll back everything.
      5. Strip PII: output_summary in agent_audit_events must never contain
         patient name, DOB, phone, email, or full document text.
         Truncate output_summary to 200 characters maximum.
      6. Do not store filing_summary or rule_output text in the database.
         Store only scalar metadata (status, risk_tier, confidence_score).

    Args:
        package: The assembled HandoffPackage from the supervisor. Its `review_queue`
            is set in place when `None` (see `_ensure_review_queue()`); an
            already-routed queue is preserved.
        agent_events: List of AgentEvent objects from the pipeline.
        db_path: Path to the SQLite database file.

    Raises:
        PersistenceError: If the database write fails for any reason.
    """
    tracer = observability.get_tracer(__name__)
    conn = get_connection(db_path)
    try:
        with observability.traced_stage(
            tracer, "Repository.save_package",
            status=package.status, audit_event_count=len(agent_events),
        ) as span:
            # Before the first execute(), so routing never runs inside the
            # open transaction.
            _ensure_review_queue(package)
            _write_package(conn, package, agent_events)
            span.set_attribute("review_queue", package.review_queue or "none")
    except Exception as exc:
        conn.rollback()
        raise PersistenceError(
            f"Failed to save package for filing {package.filing_id}: {exc}"
        ) from exc
    finally:
        conn.close()


def _write_package(
    conn: sqlite3.Connection, package: HandoffPackage, agent_events: list[AgentEvent]
) -> None:
    """The atomic three-table write itself, unchanged from the original US-9
    logic - factored out only so `save_package()` can wrap it in a span."""
    risk_tier = package.risk_score.risk_tier if package.risk_score else None
    confidence_score = _confidence_score(package)

    # Only scalar metadata ever crosses into persistence here - never
    # package.filing_summary or package.rule_output themselves, which
    # carry the free text this table must not hold (requirement 6).
    conn.execute(
        "INSERT INTO coc_filings "
        "(filing_id, status, risk_tier, review_queue, confidence_score, "
        "error_reason, assembled_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            package.filing_id, package.status, risk_tier,
            package.review_queue, confidence_score, package.error_reason,
            package.assembled_at.isoformat(),
        ),
    )

    for event in agent_events:
        conn.execute(
            "INSERT INTO agent_audit_events "
            "(filing_id, agent_name, input_hash, output_summary, confidence, "
            "status, error_message, executed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                event.filing_id, event.agent_name, event.input_hash,
                _truncate_summary(event.output_summary), event.confidence,
                event.status, event.error_message,
                event.executed_at.isoformat(),
            ),
        )

    if package.review_queue is not None:
        conn.execute(
            "INSERT INTO review_queue "
            "(filing_id, queue_name, status, risk_tier, confidence_score, "
            "assembled_at) VALUES (?, ?, ?, ?, ?, ?)",
            (
                package.filing_id, package.review_queue, package.status,
                risk_tier, confidence_score, package.assembled_at.isoformat(),
            ),
        )

    conn.commit()
