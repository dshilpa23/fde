"""FastAPI transport layer - 8 endpoints. Provided complete.

Do not modify this file. All business logic lives in the service layer.
"""
from __future__ import annotations
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from coc_filing_assistant import repository, service, router as queue_router
from coc_filing_assistant.domain import COCFilingItem

app = FastAPI(title="COC Filing Readiness Assistant", version="1.0.0")


class FilingRequest(BaseModel):
    filing_id: str
    filing_type: str
    payer_name: str
    plan_type: str
    state: str
    effective_date: str
    prior_auth_language: str
    pharmacy_language: str
    exclusion_clauses: str
    network_language: str
    benefit_summary: str
    mandatory_sections_present: list[str]
    submitted_by: str

    model_config = {"extra": "forbid"}  # 422 on forbidden fields


@app.on_event("startup")
def startup():
    repository.init_db()


@app.get("/health")
def health():
    try:
        import chromadb
        pc = chromadb.PersistentClient(
            path=__import__("coc_filing_assistant.llm_config",
                            fromlist=["CHROMA_PATH"]).CHROMA_PATH
        )
        policy_count = pc.get_collection("coc_policy_docs").count()
        reg_count = pc.get_collection("coc_regulatory").count()
    except Exception:
        policy_count, reg_count = 0, 0
    return {
        "status": "ok",
        "version": "1.0.0",
        "policy_chunks": policy_count,
        "regulatory_chunks": reg_count,
    }


@app.post("/filings/process")
def process_filing(req: FilingRequest):
    item = COCFilingItem(**req.model_dump())
    result = service.process(item)
    # Assign review queue if not already set (idempotent replay won't have one)
    if not result.idempotent_replay and result.review_queue is None:
        result.review_queue = queue_router.route(result)
    return {
        "filing_id": result.filing_id,
        "status": result.status,
        "review_queue": result.review_queue,
        "risk_tier": result.risk_score.risk_tier if result.risk_score else None,
        "confidence_score": (
            result.filing_summary.confidence_score
            if result.filing_summary else None
        ),
        "error_reason": result.error_reason,
        "assembled_at": result.assembled_at.isoformat(),
        "idempotent_replay": result.idempotent_replay,
    }


@app.get("/filings")
def list_filings():
    return repository.list_filings()


@app.get("/filings/{filing_id}")
def get_filing(filing_id: str):
    row = repository.find_by_filing_id(filing_id)
    if not row:
        raise HTTPException(status_code=404, detail="Filing not found")
    row["audit_events"] = repository.get_audit_events(filing_id)
    return row


@app.get("/audit-log")
def audit_log():
    conn = repository.get_connection()
    rows = conn.execute(
        "SELECT * FROM agent_audit_events ORDER BY executed_at"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/review-queue")
def review_queue():
    return repository.list_review_queue()


@app.get("/risk-report")
def risk_report():
    filings = repository.list_filings()
    high = [f for f in filings if f.get("risk_tier") == "HIGH"]
    medium = [f for f in filings if f.get("risk_tier") == "MEDIUM"]
    low = [f for f in filings if f.get("risk_tier") == "LOW"]
    errors = [f for f in filings if f.get("status") == "PIPELINE_ERROR"]
    return {
        "total": len(filings),
        "HIGH": len(high),
        "MEDIUM": len(medium),
        "LOW": len(low),
        "PIPELINE_ERROR": len(errors),
        "high_risk_filings": [f["filing_id"] for f in high],
    }


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    filings = repository.list_review_queue()
    rows = ""
    for f in filings:
        status = f.get("status", "-")
        color = {
            "HANDOFF_READY": "#d4edda",
            "NEEDS_REVIEW": "#fff3cd",
        }.get(status, "#f8d7da")
        tier = f.get("risk_tier", "-")
        score = (
            f"{f.get('confidence_score', 0):.2f}"
            if f.get("confidence_score") else "-"
        )
        queue = f.get("queue_name", "-")
        rows += (
            f'<tr style="background:{color}">'
            f'<td>{status}</td>'
            f'<td>{f["filing_id"]}</td>'
            f'<td>{tier}</td>'
            f'<td>{score}</td>'
            f'<td>{queue}</td>'
            f'<td>{f["assembled_at"][:19]}</td>'
            f'</tr>'
        )
    placeholder = (
        '<tr><td colspan=6>No filings yet. '
        'POST to /filings/process first.</td></tr>'
    )
    return f"""
    <html><head><title>COC Filing Dashboard</title></head><body>
    <h2>COC Filing Readiness - Review Queue</h2>
    <table border="1" cellpadding="6">
    <tr>
      <th>Status</th><th>Filing ID</th><th>Risk Tier</th>
      <th>Confidence</th><th>Queue</th><th>Assembled At</th>
    </tr>
    {rows or placeholder}
    </table></body></html>
    """
