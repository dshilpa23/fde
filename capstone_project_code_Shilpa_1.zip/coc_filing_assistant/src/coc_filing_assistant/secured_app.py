"""Inbound access control for the frozen FastAPI app.

`api.py` is on the do-not-modify list (`CLAUDE.md` §3, `project_rules.md`), so no
middleware can be registered inside it. This module wraps the frozen `app` object from
the outside instead: it changes no frozen file, adds no dependency (Starlette ships with
FastAPI), and closes US-S3 in `production_hardening/epics_and_stories.md`, which was
recorded as blocked for exactly this reason.

Run the secured application instead of the bare one::

    uvicorn coc_filing_assistant.secured_app:secured --port 8000

Every request must carry ``X-API-Key`` matching the ``COC_API_KEY`` environment
variable. `OPEN_PATHS` below is the only exception.

What this is, precisely
-----------------------
A single shared secret. It authenticates *that the caller knows the key* and nothing
more. It is **not** authorization: there is no per-caller identity, no role, no
revocation of one caller without rotating for all, and no rotation mechanism. A real
deployment needs an authenticated gateway — see `OPERATIONAL_HANDOFF.md` §5, which
states the remaining gap rather than treating this module as closing it.

Note the direction. `ENTERPRISE_LLM_API_KEY` is an *outbound* credential authenticating
this service to Databricks. This is the *inbound* control, and the two are unrelated: a
valid Databricks token never granted anyone access to these endpoints.
"""
from __future__ import annotations

import os
import secrets

from dotenv import load_dotenv
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

from coc_filing_assistant.api import app

load_dotenv()

API_KEY_HEADER = "x-api-key"

#: Paths reachable without a key. `/health` is a liveness probe and reveals only chunk
#: counts. `/docs` and `/openapi.json` travel together — the docs page cannot render
#: without the schema — and expose the API's shape, not its data. Every path that
#: returns filing data, including `/dashboard` and `/audit-log`, is protected.
OPEN_PATHS = frozenset({"/health", "/docs", "/openapi.json"})


def _expected_key() -> str:
    """Return the configured inbound API key.

    Read at call time rather than import time so tests can monkeypatch the environment,
    matching how `llm_config.get_llm_client()` reads its credentials.

    Returns:
        The value of `COC_API_KEY`.

    Raises:
        RuntimeError: if `COC_API_KEY` is unset or empty. This fails closed on purpose.
            An unset key that silently disabled the check would be worse than having no
            check at all, because the deployment would look protected.
    """
    key = os.environ.get("COC_API_KEY")
    if not key:
        raise RuntimeError(
            "COC_API_KEY must be set to run the secured application.\n"
            "Copy .env.example to .env and set an inbound API key first.\n"
            "Refusing to start unauthenticated: a missing key fails closed, never open."
        )
    return key


def _is_authorized(scope: Scope) -> bool:
    """Check a request's `X-API-Key` header against the configured key.

    Args:
        scope: The ASGI connection scope for an `http` request.

    Returns:
        True if the header is present and matches.
    """
    presented = ""
    for raw_name, raw_value in scope.get("headers", []):
        if raw_name.decode("latin-1").lower() == API_KEY_HEADER:
            presented = raw_value.decode("latin-1")
            break
    # compare_digest, not ==, so comparison time does not depend on how many leading
    # characters a guess got right.
    return secrets.compare_digest(presented, _expected_key())


class ApiKeyMiddleware:
    """Pure-ASGI middleware rejecting requests without a valid `X-API-Key`.

    Implemented at the ASGI layer rather than with `BaseHTTPMiddleware` so that
    `lifespan` messages pass through to the wrapped application untouched — `api.py`
    registers a startup hook that calls `repository.init_db()`, and swallowing it would
    leave the database with no tables.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            # lifespan and websocket traffic is not an access-controlled request.
            await self.app(scope, receive, send)
            return

        if scope.get("path") in OPEN_PATHS or _is_authorized(scope):
            await self.app(scope, receive, send)
            return

        # The body names the header but never the expected value, and says nothing about
        # whether the key was absent or merely wrong.
        response = JSONResponse(
            status_code=401,
            content={"detail": "Missing or invalid X-API-Key header."},
        )
        await response(scope, receive, send)


def _declare_security_scheme() -> None:
    """Advertise the API-key scheme in the OpenAPI document.

    `/docs` is deliberately open, but Swagger UI only offers an **Authorize** box — and
    only attaches the header to *Try it out* — when the schema declares a security
    scheme. Without this, every request sent from the docs page would come back 401 and
    the API's own documentation would be unusable against the API.

    Done by mutating the generated schema from outside rather than by passing arguments
    to `FastAPI(...)`, because `api.py` is frozen. Setting `app.openapi_schema` also
    makes FastAPI serve this cached document instead of regenerating it.
    """
    schema = app.openapi()
    schema.setdefault("components", {})["securitySchemes"] = {
        "ApiKeyAuth": {"type": "apiKey", "in": "header", "name": "X-API-Key"}
    }
    schema["security"] = [{"ApiKeyAuth": []}]
    app.openapi_schema = schema


_declare_security_scheme()

secured: ASGIApp = ApiKeyMiddleware(app)
