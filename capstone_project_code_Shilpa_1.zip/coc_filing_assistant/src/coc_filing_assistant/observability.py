"""Observability layer - OpenTelemetry tracing, exported to Arize and to a
sanitized local JSONL file.

Supplementary layer only (see `evals/arize/README.md`). Never gates a release,
never changes pipeline behavior, and degrades to local-only tracing with no
error when Arize credentials are absent - a reviewer without Arize access still
gets the full trace record from `evals/arize/traces.jsonl`.

Safety: only ever attach short, non-free-text attributes to a span (see
`SAFE_SCALAR_MAX_LEN` and `safe_attrs()`). The same prohibitions
`safety_rules.md` rule 2 puts on `agent_audit_events` apply here - no PII, no
filing-section text, no LLM prompt/response text, no credentials. `safe_attrs()`
is the only place span attributes are constructed by call sites, so that
constraint is enforced once rather than trusted at every call site.
"""
from __future__ import annotations

import json
import os
import re
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan, TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ARIZE_DIR = REPO_ROOT / "evals" / "arize"
TRACES_PATH = ARIZE_DIR / "traces.jsonl"

SERVICE_NAME = "coc-filing-assistant"

# Hard cap on any single attribute value. Generously above an identifier or a
# short status string, far below anything that could be a filing excerpt or an
# LLM response fragment - the same reasoning `safety_rules.md` rule 2 applies to
# `output_summary` (200 chars), applied here to span attributes.
SAFE_SCALAR_MAX_LEN = 200

_LABELLED_SECRET_RE = re.compile(
    r"(?i)\b(authorization|bearer|api[-_]?key|token|secret|password)\b\s*[:=]\s*\S+"
)
_BARE_TOKEN_RE = re.compile(r"[A-Za-z0-9+/=_-]{20,}")


def _sanitize_scalar(value: object) -> object:
    """Truncate/redact one attribute value. Never raises on odd input."""
    if value is None or isinstance(value, (bool, int, float)):
        return value
    text = str(value)
    text = _LABELLED_SECRET_RE.sub(r"\1=[redacted]", text)
    text = _BARE_TOKEN_RE.sub("[redacted-token]", text)
    text = " ".join(text.split())
    if len(text) > SAFE_SCALAR_MAX_LEN:
        text = text[: SAFE_SCALAR_MAX_LEN - 1] + "…"
    return text


def safe_attrs(**kwargs: object) -> dict[str, object]:
    """Build a sanitized, OTel-safe attribute dict for `start_as_current_span`.

    Every value is truncated to `SAFE_SCALAR_MAX_LEN` and redacted for the same
    labelled-credential / bare-token patterns `evals/harness.py` uses for eval
    artifacts. Lists of scalars are sanitized element-wise (OTel accepts
    homogeneous sequences); anything else is stringified first. `None` values
    are dropped - OTel attributes must not be `None`.
    """
    out: dict[str, object] = {}
    for key, value in kwargs.items():
        if value is None:
            continue
        if isinstance(value, (list, tuple, set)):
            out[key] = [_sanitize_scalar(v) for v in value]
        else:
            out[key] = _sanitize_scalar(value)
    return out


class _SanitizedJSONLExporter(SpanExporter):
    """Appends one sanitized JSON line per finished span to `traces.jsonl`.

    Independent of whether Arize export is configured - this exporter always
    runs, so local reproducible evidence exists even for a reviewer with no
    Arize account (see `evals/arize/README.md`). Attributes are already
    sanitized by `safe_attrs()` at the call site; this exporter re-applies the
    same scalar sanitizer defensively rather than trusting every caller.
    """

    def __init__(self, path: Path = TRACES_PATH) -> None:
        self._path = path
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def export(self, spans: "list[ReadableSpan]") -> SpanExportResult:
        try:
            with open(self._path, "a", encoding="utf-8") as fh:
                for span in spans:
                    fh.write(json.dumps(self._to_record(span)) + "\n")
        except OSError:
            return SpanExportResult.FAILURE
        return SpanExportResult.SUCCESS

    def _to_record(self, span: "ReadableSpan") -> dict:
        ctx = span.get_span_context()
        start_ns = span.start_time or 0
        end_ns = span.end_time or start_ns
        attributes = {
            k: _sanitize_scalar(v) if not isinstance(v, (list, tuple)) else [
                _sanitize_scalar(x) for x in v
            ]
            for k, v in dict(span.attributes or {}).items()
        }
        return {
            "trace_id": format(ctx.trace_id, "032x") if ctx else None,
            "span_id": format(ctx.span_id, "016x") if ctx else None,
            "parent_span_id": (
                format(span.parent.span_id, "016x") if span.parent else None
            ),
            "name": span.name,
            "start_time_ns": start_ns,
            "end_time_ns": end_ns,
            "duration_ms": round((end_ns - start_ns) / 1_000_000, 3),
            "status_code": span.status.status_code.name if span.status else "UNSET",
            "attributes": attributes,
        }

    def shutdown(self) -> None:  # pragma: no cover - nothing to release
        return None

    def force_flush(self, timeout_millis: int = 30000) -> bool:  # pragma: no cover
        return True


_provider: TracerProvider | None = None


def _build_provider() -> TracerProvider:
    """Configure the process-wide TracerProvider once. Idempotent by caller."""
    resource = Resource.create({
        "service.name": SERVICE_NAME,
        "arize.project.name": os.environ.get("ARIZE_PROJECT_NAME", SERVICE_NAME),
    })
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(SimpleSpanProcessor(_SanitizedJSONLExporter()))

    api_key = os.environ.get("ARIZE_API_KEY")
    space_id = os.environ.get("ARIZE_SPACE_ID")
    if api_key and space_id:
        # Deferred import: only touch the OTLP/gRPC exporter when credentials
        # are actually present, so an environment with the package installed
        # but no Arize account never opens a network channel.
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter,
        )

        endpoint = os.environ.get("ARIZE_OTLP_ENDPOINT", "otlp.arize.com:443")
        # Arize's collector rejects a span with INVALID_ARGUMENT ("trace export
        # requires project routing") unless one of a specific set of signals names
        # the project - verified live (see evals/arize/README.md "Arize live
        # verification"). The `arize.project.name` resource attribute set below is
        # not what Arize's receiver actually checks; the `x-project-name` OTLP
        # header is, so it is sent both ways rather than relying on the resource
        # attribute alone.
        exporter = OTLPSpanExporter(
            endpoint=endpoint,
            headers={
                "space_id": space_id,
                "api_key": api_key,
                "x-project-name": os.environ.get("ARIZE_PROJECT_NAME", SERVICE_NAME),
            },
        )
        provider.add_span_processor(BatchSpanProcessor(exporter))
    return provider


def _ensure_provider() -> TracerProvider:
    global _provider
    if _provider is None:
        _provider = _build_provider()
    return _provider


def get_tracer(module_name: str) -> trace.Tracer:
    """Return a tracer backed by the process-wide provider.

    Safe to call from any module without argument-threading a tracer between
    layers - child spans nest automatically under whatever span is `current`
    (e.g. a stage span opened inside `supervisor.run_pipeline()`'s own span).

    Args:
        module_name: Conventionally `__name__` of the calling module.

    Returns:
        An OTel `Tracer`. Arize export is active only when `ARIZE_API_KEY` and
        `ARIZE_SPACE_ID` are set; otherwise spans are still created and written
        to the local sanitized JSONL file, just never sent externally.
    """
    return trace.get_tracer(module_name, tracer_provider=_ensure_provider())


@contextmanager
def traced_stage(
    tracer: trace.Tracer, span_name: str, **attributes: object
) -> Iterator[trace.Span]:
    """Open a span, record only sanitized attributes, and mark failure honestly.

    On an exception, the span is marked ERROR and the attribute records only
    the exception *type name* - matching `safety_spec.md` §6's "never the
    exception's str() if that string could contain filing content." The
    exception itself still propagates; this never changes pipeline behavior.

    Args:
        tracer: Tracer from `get_tracer()`.
        span_name: Span name, e.g. "RuleEngine.run_checks".
        attributes: Pre-sanitized attributes (pass through `safe_attrs()`).

    Yields:
        The open span, so the caller can add attributes discovered mid-stage
        (e.g. `span.set_attributes(safe_attrs(risk_tier=score.risk_tier))`).
    """
    with tracer.start_as_current_span(span_name, attributes=safe_attrs(**attributes)) as span:
        try:
            yield span
        except Exception as exc:
            span.set_status(trace.StatusCode.ERROR)
            span.set_attribute("error.type", type(exc).__name__)
            raise
