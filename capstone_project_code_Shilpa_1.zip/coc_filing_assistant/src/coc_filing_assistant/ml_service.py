"""ML Risk Service - calibrated risk scoring for COC filing items.

LEARNER TASK: Implement the score_risk() function.

Read before starting:
  - specs/ml_service_spec.md  (your spec - you write this on Day 1)
  - .claude/rules/safety_rules.md
  - tests/test_ml_service.py
  - Section 2.7.2 of the Implementation Guide (risk-scoring approach)

Function to implement:
  score_risk(item: COCFilingItem, rule_output: RuleEngineOutput) -> RiskScore

CHOOSE ONE IMPLEMENTATION APPROACH and document it in ml_service_spec.md:

  Use the approved risk-scoring approach from your specification:
    - Extract features from COCFilingItem and RuleEngineOutput
    - Apply a reproducible, documented scoring implementation
    - Produce probabilities for sla_delay, escalation, review_effort
    - Compute composite_risk as a weighted sum (document weights in spec)

  Define numeric features from the filing and rule results, then apply
  documented weights to produce scores between 0.0 and 1.0. This is the
  required reproducible scoring approach for the capstone.

Risk tier thresholds (same for both options):
  composite_risk >= 0.65  ->  HIGH
  composite_risk >= 0.35  ->  MEDIUM
  composite_risk <  0.35  ->  LOW

Starter scaffold for the required feature-weighted approach (adapt to your design):

  def score_risk(item, rule_output):
      high_rules  = sum(1 for r in rule_output.rule_results if r.severity == "HIGH")
      med_rules   = sum(1 for r in rule_output.rule_results if r.severity == "MEDIUM")
      sections    = len(item.mandatory_sections_present)

      # Document these weights in ml_service_spec.md
      sla_delay     = min(1.0, high_rules * 0.3 + med_rules * 0.1)
      escalation    = min(1.0, high_rules * 0.35 + (8 - min(sections, 8)) * 0.05)
      review_effort = min(1.0, (high_rules + med_rules) * 0.15)
      composite     = sla_delay * 0.4 + escalation * 0.4 + review_effort * 0.2
      tier = "HIGH" if composite >= 0.65 else "MEDIUM" if composite >= 0.35 else "LOW"

      return RiskScore(
          filing_id=item.filing_id,
          sla_delay_probability=sla_delay,
          escalation_probability=escalation,
          review_effort_score=review_effort,
          composite_risk=composite,
          risk_tier=tier,
          model_version="feature-weighted-v1.0",
      )

Constraints:
  - Do not use rule severity as a direct pass-through to risk tier.
  - The model must be reproducible: same inputs -> same outputs always.
  - Raise MLServiceError (not a generic Exception) on unexpected failure.

Step 1: Write specs/ml_service_spec.md (Day 1, before coding).
Step 2: Document the feature definitions and weights in ml_service_spec.md.
Step 3: Implement score_risk().
Step 4: Run: python -m pytest tests/test_ml_service.py -v
"""
from __future__ import annotations
from coc_filing_assistant import observability
from coc_filing_assistant.domain import (
    COCFilingItem,
    RuleEngineOutput,
    RiskScore,
    MLServiceError,
)


MODEL_VERSION = "feature-weighted-v1.0"
SECTION_CAP = 8


def score_risk(item: COCFilingItem, rule_output: RuleEngineOutput) -> RiskScore:
    """Score the risk of a COC filing item.

    Implements the feature-weighted formula in ml_service_spec.md §2-4: six
    features (three from rule_output, three from the filing) feed three
    clamped dimensions, which combine into a weighted composite and tier.
    LOW-severity rule findings are excluded by design so an informational
    finding can never move a tier (rule_engine_spec.md §5).

    Args:
        item: The COC filing item.
        rule_output: Output from the rule engine for this filing.

    Returns:
        RiskScore with three dimensions and a composite risk tier.

    Raises:
        MLServiceError: If scoring fails unexpectedly.
    """
    tracer = observability.get_tracer(__name__)
    try:
        with observability.traced_stage(tracer, "MLService.score_risk") as span:
            high_rules = sum(1 for r in rule_output.rule_results if r.severity == "HIGH")
            med_rules = sum(1 for r in rule_output.rule_results if r.severity == "MEDIUM")
            sections = min(len(item.mandatory_sections_present), SECTION_CAP)
            sections_missing = SECTION_CAP - sections

            sla_delay = min(1.0, high_rules * 0.30 + med_rules * 0.10)
            escalation = min(1.0, high_rules * 0.35 + sections_missing * 0.05)
            review_effort = min(1.0, (high_rules + med_rules) * 0.15)

            composite = sla_delay * 0.40 + escalation * 0.40 + review_effort * 0.20
            composite = max(0.0, min(1.0, composite))

            if composite >= 0.65:
                tier = "HIGH"
            elif composite >= 0.35:
                tier = "MEDIUM"
            else:
                tier = "LOW"

            span.set_attributes(observability.safe_attrs(
                risk_tier=tier,
                composite_risk=round(composite, 4),
                model_version=MODEL_VERSION,
            ))
            return RiskScore(
                filing_id=item.filing_id,
                sla_delay_probability=sla_delay,
                escalation_probability=escalation,
                review_effort_score=review_effort,
                composite_risk=composite,
                risk_tier=tier,
                model_version=MODEL_VERSION,
            )
    except Exception as exc:
        raise MLServiceError(f"Failed to score filing {item.filing_id}: {exc}") from exc
