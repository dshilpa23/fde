"""Supervisor Orchestrator - runs all three services in sequence.

LEARNER TASK: Implement run_pipeline().

Read before starting:
  - specs/architecture.md  (your spec - write this on Day 1)
  - specs/safety_spec.md
  - .claude/rules/safety_rules.md
  - domain.py  (study AgentEvent, HandoffPackage, and all error types)
  - tests/test_supervisor.py
  - Section 2.7.4 of the Implementation Guide

Function to implement:
  run_pipeline(item: COCFilingItem) -> tuple[HandoffPackage, list[AgentEvent]]

What it must do:
  1. Call rule_engine.run_checks(item)                           -> RuleEngineOutput
  2. Call ml_service.score_risk(item, rule_output)               -> RiskScore
  3. Call rag_service.retrieve(item, rule_output)                -> list[EvidenceChunk]
  4. Call rag_service.draft_summary(item, rule_output, risk, chunks)
                                                                 -> tuple[FilingSummary, ReviewResult]
  5. Assemble a HandoffPackage with the correct status.
  6. Return (HandoffPackage, list[AgentEvent]).

Status transition rules:
  - All services complete + ReviewResult.recommendation == APPROVE
      -> status = HANDOFF_READY
  - All services complete + ReviewResult.recommendation == FLAG_FOR_HUMAN
      -> status = NEEDS_REVIEW
  - Any service raises ANY exception
      -> status = PIPELINE_ERROR
         error_reason = str(exception)
         Return whatever was assembled so far. Do not crash.

AgentEvent format (one per service call):
  agent_name:     "RuleEngine" | "MLService" | "RAGRetrieve" | "RAGDraft"
  input_hash:     hashlib.sha256(item.filing_id.encode()).hexdigest()[:16]
  output_summary: SHORT description only - max 200 chars, no full text, no PII
    Good example: "8 rules checked, 3 flagged HIGH, overall_flag=FLAG"
    Bad example:  "Prior auth language states that all cardiovascular procedures..."
  status:         "SUCCESS" or "FAILURE"
  error_message:  None on success; str(exception) on failure

Critical constraints:
  - All four service calls must be attempted for every filing.
    Do not short-circuit based on earlier results.
  - supervisor.py must not contain business logic from the services.
    It orchestrates - it does not check rules or compute risk itself.
  - Never set HANDOFF_READY if any service raised an exception.
  - HandoffPackage.review_queue must be None from this function.
    Routing is done by router.py, called from api.py after run_pipeline().

Step 1: Write specs/architecture.md (Day 1, before coding).
Step 2: Implement run_pipeline() with correct status transitions.
Step 3: Run: python -m pytest tests/test_supervisor.py -v
"""
from __future__ import annotations
import hashlib
from coc_filing_assistant import observability
from coc_filing_assistant.domain import (
    COCFilingItem,
    HandoffPackage,
    AgentEvent,
    RuleEngineOutput,
    RiskScore,
)
from coc_filing_assistant import rule_engine, ml_service, rag_service

_MAX_SUMMARY_LEN = 200


def _short_summary(text: str) -> str:
    """safety_spec.md §2: cap at 200 chars, truncate with an explicit marker
    rather than silently cutting mid-word."""
    if len(text) <= _MAX_SUMMARY_LEN:
        return text
    return text[: _MAX_SUMMARY_LEN - 1] + "…"


def _input_hash(filing_id: str) -> str:
    return hashlib.sha256(filing_id.encode()).hexdigest()[:16]


def _degraded_rule_output(item: COCFilingItem) -> RuleEngineOutput:
    """architecture.md §4: overall_flag="FLAG", never "PASS" - a failed check
    must never look downstream like a passed one."""
    return RuleEngineOutput(filing_id=item.filing_id, rule_results=[], overall_flag="FLAG")


def _degraded_risk_score(item: COCFilingItem) -> RiskScore:
    """architecture.md §4: saturated, never zeroed - composite_risk=0.0 would
    read as risk_tier="LOW", a clean bill of health on a filing whose risk
    scoring failed. model_version marks this a placeholder, never the real
    MODEL_VERSION, so it can never be mistaken for a measurement."""
    return RiskScore(
        filing_id=item.filing_id,
        sla_delay_probability=1.0,
        escalation_probability=1.0,
        review_effort_score=1.0,
        composite_risk=1.0,
        risk_tier="HIGH",
        model_version="unavailable-placeholder",
    )


def run_pipeline(
    item: COCFilingItem,
) -> tuple[HandoffPackage, list[AgentEvent]]:
    """Orchestrate the full 4-step filing assessment pipeline.

    Args:
        item: The COC filing item to process.

    Returns:
        Tuple of (HandoffPackage, list[AgentEvent]).
        HandoffPackage.review_queue is always None here - set by router.

    Never raises: all exceptions are caught and produce PIPELINE_ERROR.
    """
    input_hash = _input_hash(item.filing_id)
    tracer = observability.get_tracer(__name__)
    # Root span for the whole pipeline. Each stage below opens its own span
    # inside rule_engine.py/ml_service.py/rag_service.py; OTel nests those as
    # children automatically under whichever span is "current" when a stage
    # call is made from within this `with` block - no tracer needs to be
    # threaded between modules for that to happen.
    with observability.traced_stage(
        tracer, "Supervisor.run_pipeline", filing_id_hash=input_hash
    ) as span:
        package, events = _run_stages(item, input_hash)
        span.set_attributes(observability.safe_attrs(
            status=package.status,
            audit_event_count=len(events),
            agent_names=sorted({e.agent_name for e in events}),
        ))
        return package, events


def _run_stages(
    item: COCFilingItem, input_hash: str
) -> tuple[HandoffPackage, list[AgentEvent]]:
    """The four-stage sequence itself, unchanged from the original US-7 logic -
    factored out only so `run_pipeline()` can wrap it in one root span."""
    events: list[AgentEvent] = []

    # Stage 1: Rule Engine
    try:
        rule_output = rule_engine.run_checks(item)
        high = sum(1 for r in rule_output.rule_results if r.severity == "HIGH")
        med = sum(1 for r in rule_output.rule_results if r.severity == "MEDIUM")
        events.append(AgentEvent(
            agent_name="RuleEngine", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(
                f"{len(rule_output.rule_results)} rules flagged ({high} HIGH, "
                f"{med} MEDIUM), overall_flag={rule_output.overall_flag}"
            ),
            confidence=None, status="SUCCESS", error_message=None,
        ))
    except Exception as exc:
        rule_output = _degraded_rule_output(item)
        events.append(AgentEvent(
            agent_name="RuleEngine", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(f"Rule engine failed: {type(exc).__name__}"),
            confidence=None, status="FAILURE", error_message=str(exc),
        ))

    # Stage 2: ML Risk - always attempted, even if stage 1 failed (rule 7)
    try:
        risk_score = ml_service.score_risk(item, rule_output)
        events.append(AgentEvent(
            agent_name="MLService", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(
                f"risk_tier={risk_score.risk_tier}, composite={risk_score.composite_risk:.2f}"
            ),
            confidence=risk_score.composite_risk, status="SUCCESS", error_message=None,
        ))
    except Exception as exc:
        risk_score = _degraded_risk_score(item)
        events.append(AgentEvent(
            agent_name="MLService", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(f"ML risk scoring failed: {type(exc).__name__}"),
            confidence=None, status="FAILURE", error_message=str(exc),
        ))

    # Stage 3: RAG Retrieve - always attempted, even if stages 1/2 failed (rule 7)
    try:
        chunks = rag_service.retrieve(item, rule_output)
        events.append(AgentEvent(
            agent_name="RAGRetrieve", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(f"{len(chunks)} evidence chunks retrieved"),
            confidence=None, status="SUCCESS", error_message=None,
        ))
    except Exception as exc:
        chunks = []
        events.append(AgentEvent(
            agent_name="RAGRetrieve", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(f"Evidence retrieval failed: {type(exc).__name__}"),
            confidence=None, status="FAILURE", error_message=str(exc),
        ))

    # Stage 4: RAG Draft - always attempted, even if stages 1/2/3 failed (rule 7)
    filing_summary = None
    review_result = None
    try:
        filing_summary, review_result = rag_service.draft_summary(item, rule_output, risk_score, chunks)
        confidence = max(0.0, min(1.0, review_result.confidence_score))
        events.append(AgentEvent(
            agent_name="RAGDraft", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(
                f"confidence={confidence:.2f}, recommendation={review_result.recommendation}"
            ),
            confidence=confidence, status="SUCCESS", error_message=None,
        ))
    except Exception as exc:
        events.append(AgentEvent(
            agent_name="RAGDraft", filing_id=item.filing_id, input_hash=input_hash,
            output_summary=_short_summary(f"Summary drafting failed: {type(exc).__name__}"),
            confidence=None, status="FAILURE", error_message=str(exc),
        ))

    failed_events = [e for e in events if e.status == "FAILURE"]
    if failed_events:
        # Rule 6: HANDOFF_READY is never set when any AgentEvent has FAILURE.
        status = "PIPELINE_ERROR"
        error_reason = "; ".join(f"{e.agent_name}: {e.error_message}" for e in failed_events)
    elif review_result.recommendation == "APPROVE":
        status = "HANDOFF_READY"
        error_reason = None
    else:
        status = "NEEDS_REVIEW"
        error_reason = None

    def _event_ok(name: str) -> bool:
        return any(e.agent_name == name and e.status == "SUCCESS" for e in events)

    package = HandoffPackage(
        filing_id=item.filing_id,
        rule_output=rule_output if _event_ok("RuleEngine") else None,
        risk_score=risk_score if _event_ok("MLService") else None,
        filing_summary=filing_summary if _event_ok("RAGDraft") else None,
        review_result=review_result if _event_ok("RAGDraft") else None,
        status=status,
        error_reason=error_reason,
        review_queue=None,
    )
    return package, events
