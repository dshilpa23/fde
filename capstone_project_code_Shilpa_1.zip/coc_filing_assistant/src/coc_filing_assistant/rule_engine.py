"""Rule Engine - deterministic compliance checks on COC filing items.

LEARNER TASK: Implement the run_checks() function.

Read before starting:
  - specs/rule_engine_spec.md  (your spec - you write this on Day 1)
  - .claude/rules/safety_rules.md
  - tests/test_rule_engine.py
  - Section 2.7.1 of the Implementation Guide (rule examples)

Function to implement:
  run_checks(item: COCFilingItem) -> RuleEngineOutput

What it must do:
  1. Run all rules defined in your rule_engine_spec.md across 4 categories:
       MISSING_INFO  - mandatory sections absent from the filing
       PRIOR_AUTH    - problematic or missing prior-auth language
       PHARMACY      - formulary, drug tier, or exception process issues
       EXCLUSION     - exclusion clause gaps or non-compliant language
     Optional 5th category:
       NETWORK       - network adequacy or access issues

  2. For each triggered rule, produce a RuleCheckResult with:
       rule_id       - unique identifier, e.g. "MI-001", "PA-002"
       category      - one of the categories above
       severity      - HIGH | MEDIUM | LOW
       description   - plain-English description of the issue
       filing_section - which field was inspected
       evidence      - quoted text that triggered the rule, or empty string

  3. Set overall_flag to FLAG if any HIGH or MEDIUM rule fired, else PASS.
  4. Return a RuleEngineOutput.

Minimum 8 rules required across 4 categories. Example rules (adapt to your spec):

  MISSING_INFO rules:
    MI-001: Flag if "prior_auth" not in mandatory_sections_present (HIGH)
    MI-002: Flag if "pharmacy" not in mandatory_sections_present (HIGH)
    MI-003: Flag if "grievance" not in mandatory_sections_present (MEDIUM)

  PRIOR_AUTH rules:
    PA-001: Flag if prior_auth_language is empty or < 50 chars (HIGH)
    PA-002: Flag if "emergency" not mentioned in prior_auth_language (HIGH)
    PA-003: Flag if "urgent" not mentioned in prior_auth_language (MEDIUM)

  PHARMACY rules:
    PH-001: Flag if pharmacy_language is empty or < 50 chars (HIGH)
    PH-002: Flag if "exception" not in pharmacy_language (MEDIUM)
    PH-003: Flag if no tier mention ("tier 1", "tier 2", etc.) in pharmacy_language (MEDIUM)

  EXCLUSION rules:
    EX-001: Flag if "experimental" not defined in exclusion_clauses (HIGH)
    EX-002: Flag if "Exhibit A" or "appendix" not referenced in exclusion_clauses (MEDIUM)

Constraints:
  - Rules must be deterministic. Same input always produces same output.
  - Do not call any LLM or external service from this function.
  - Do not read from the database inside this function.
  - Raise RuleEngineError (not a generic Exception) on unexpected failure.

Step 1: Write specs/rule_engine_spec.md listing your 8+ rules (Day 1).
Step 2: Implement run_checks() using your spec.
Step 3: Run: python -m pytest tests/test_rule_engine.py -v
"""
from __future__ import annotations

import re

from coc_filing_assistant import observability
from coc_filing_assistant.domain import (
    COCFilingItem,
    RuleCheckResult,
    RuleEngineOutput,
    RuleEngineError,
)

# 12-rule catalog per specs/rule_engine_spec.md §3. Evidence is truncated to
# 120 chars (spec §3); "" where the trigger is an absence, since there is no
# span to quote for "this word does not appear anywhere."
_EVIDENCE_MAX = 120


def _check_missing_info(item: COCFilingItem) -> list[RuleCheckResult]:
    sections = item.mandatory_sections_present
    catalog = (
        ("MI-001", "prior_auth", "HIGH", "Prior authorization section is missing from the filing."),
        ("MI-002", "pharmacy", "HIGH", "Pharmacy section is missing from the filing."),
        ("MI-003", "grievance", "MEDIUM", "Grievance section is missing from the filing."),
        ("MI-004", "network", "MEDIUM", "Network section is missing from the filing."),
    )
    return [
        RuleCheckResult(
            rule_id=rule_id,
            category="MISSING_INFO",
            severity=severity,
            description=description,
            filing_section="mandatory_sections_present",
            evidence="",
        )
        for rule_id, section_name, severity, description in catalog
        if section_name not in sections
    ]


def _check_prior_auth(item: COCFilingItem) -> list[RuleCheckResult]:
    results: list[RuleCheckResult] = []
    text = item.prior_auth_language
    stripped = text.strip()
    lowered = text.lower()

    if len(stripped) < 50:
        results.append(RuleCheckResult(
            rule_id="PA-001", category="PRIOR_AUTH", severity="HIGH",
            description="Prior authorization language is missing or too short to be meaningful.",
            filing_section="prior_auth_language",
            evidence=stripped[:_EVIDENCE_MAX],  # short-but-present text IS the trigger; quote it
        ))
    if "emergency" not in lowered and "emergent" not in lowered:
        results.append(RuleCheckResult(
            rule_id="PA-002", category="PRIOR_AUTH", severity="HIGH",
            description="No emergency-care carve-out found in prior authorization language.",
            filing_section="prior_auth_language", evidence="",
        ))
    if "urgent" not in lowered:
        results.append(RuleCheckResult(
            rule_id="PA-003", category="PRIOR_AUTH", severity="MEDIUM",
            description="No urgent-care carve-out found in prior authorization language.",
            filing_section="prior_auth_language", evidence="",
        ))
    return results


def _check_pharmacy(item: COCFilingItem) -> list[RuleCheckResult]:
    results: list[RuleCheckResult] = []
    text = item.pharmacy_language
    stripped = text.strip()
    lowered = text.lower()

    if len(stripped) < 50:
        results.append(RuleCheckResult(
            rule_id="PH-001", category="PHARMACY", severity="HIGH",
            description="Pharmacy language is missing or too short to be meaningful.",
            filing_section="pharmacy_language",
            evidence=stripped[:_EVIDENCE_MAX],
        ))
    if "exception" not in lowered:
        results.append(RuleCheckResult(
            rule_id="PH-002", category="PHARMACY", severity="MEDIUM",
            description="No formulary-exception process mentioned in pharmacy language.",
            filing_section="pharmacy_language", evidence="",
        ))
    if not re.search(r"tier\s*\d", lowered) and "formulary" not in lowered:
        results.append(RuleCheckResult(
            rule_id="PH-003", category="PHARMACY", severity="MEDIUM",
            description="No drug-tier structure or formulary reference found in pharmacy language.",
            filing_section="pharmacy_language", evidence="",
        ))
    return results


def _check_exclusion(item: COCFilingItem) -> list[RuleCheckResult]:
    results: list[RuleCheckResult] = []
    lowered = item.exclusion_clauses.lower()

    if "experimental" not in lowered:
        results.append(RuleCheckResult(
            rule_id="EX-001", category="EXCLUSION", severity="HIGH",
            description="Exclusion clauses do not mention experimental treatments.",
            filing_section="exclusion_clauses", evidence="",
        ))
    if not any(term in lowered for term in ("exhibit", "appendix", "schedule")):
        results.append(RuleCheckResult(
            rule_id="EX-002", category="EXCLUSION", severity="MEDIUM",
            description="No full exclusion-list reference (Exhibit/Appendix/Schedule) found.",
            filing_section="exclusion_clauses", evidence="",
        ))
    return results


def _check_network(item: COCFilingItem) -> list[RuleCheckResult]:
    results: list[RuleCheckResult] = []
    text = item.network_language
    lowered = text.lower()

    disclaimer = next(
        (d for d in ("not demonstrated", "not established", "pending") if d in lowered), None
    )
    if disclaimer:
        idx = lowered.find(disclaimer)
        results.append(RuleCheckResult(
            rule_id="NW-001", category="NETWORK", severity="MEDIUM",
            description="Network adequacy is explicitly disclaimed rather than demonstrated.",
            filing_section="network_language",
            evidence=text[idx:idx + _EVIDENCE_MAX],  # the disclaiming phrase IS the trigger; quote it
        ))
    if not re.search(r"\d", text):
        results.append(RuleCheckResult(
            rule_id="NW-002", category="NETWORK", severity="LOW",
            description="No measurable network-adequacy standard (ratio, mileage, minutes) found.",
            filing_section="network_language", evidence="",
        ))
    return results


def run_checks(item: COCFilingItem) -> RuleEngineOutput:
    """Run all compliance rules against a COC filing item.

    Pure and deterministic (specs/rule_engine_spec.md §1): no LLM call, no
    database read, no network, no clock except checked_at. Only triggered
    rules appear in rule_results - a passing rule contributes nothing.

    Args:
        item: The COC filing item to check.

    Returns:
        RuleEngineOutput containing all triggered RuleCheckResults.
        overall_flag is FLAG if any HIGH or MEDIUM rule fired, else PASS -
        a LOW-only result set is still PASS.

    Raises:
        RuleEngineError: If the rule engine cannot process the item.
    """
    tracer = observability.get_tracer(__name__)
    try:
        with observability.traced_stage(tracer, "RuleEngine.run_checks") as span:
            rule_results: list[RuleCheckResult] = [
                *_check_missing_info(item),
                *_check_prior_auth(item),
                *_check_pharmacy(item),
                *_check_exclusion(item),
                *_check_network(item),
            ]
            overall_flag = (
                "FLAG" if any(r.severity in ("HIGH", "MEDIUM") for r in rule_results) else "PASS"
            )
            category_counts: dict[str, int] = {}
            for r in rule_results:
                category_counts[r.category] = category_counts.get(r.category, 0) + 1
            span.set_attributes(observability.safe_attrs(
                rule_count=len(rule_results),
                overall_flag=overall_flag,
                fired_categories=sorted(category_counts),
                high_rule_count=sum(1 for r in rule_results if r.severity == "HIGH"),
                med_rule_count=sum(1 for r in rule_results if r.severity == "MEDIUM"),
            ))
            return RuleEngineOutput(
                filing_id=item.filing_id,
                rule_results=rule_results,
                overall_flag=overall_flag,
            )
    except RuleEngineError:
        raise
    except Exception as exc:  # noqa: BLE001 - convert to the domain-specific error
        raise RuleEngineError(f"Rule engine failed for filing {item.filing_id}: {exc}") from exc
