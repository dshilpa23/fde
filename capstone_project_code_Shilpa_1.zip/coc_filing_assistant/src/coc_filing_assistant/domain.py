"""Typed domain objects for the COC Filing Readiness Assistant.

All objects are provided and complete. Do not modify this file.
Learners implement logic in rule_engine.py, ml_service.py, rag_service.py,
supervisor.py, router.py, repository.py, and audit.py.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------

@dataclass
class COCFilingItem:
    filing_id: str
    filing_type: str            # NEW | AMENDMENT | RENEWAL
    payer_name: str
    plan_type: str              # HMO | PPO | EPO | POS | HDHP
    state: str                  # two-letter state code, e.g. "TX"
    effective_date: str         # ISO date string, e.g. "2025-01-01"
    prior_auth_language: str    # extracted text block from filing
    pharmacy_language: str      # extracted text block from filing
    exclusion_clauses: str      # extracted text block from filing
    network_language: str       # extracted text block from filing
    benefit_summary: str        # extracted text block from filing
    mandatory_sections_present: list[str]   # list of section IDs found
    submitted_by: str           # analyst name or ID


# ---------------------------------------------------------------------------
# Rule Engine outputs
# ---------------------------------------------------------------------------

@dataclass
class RuleCheckResult:
    rule_id: str
    category: str       # MISSING_INFO | PRIOR_AUTH | PHARMACY | EXCLUSION | NETWORK
    severity: str       # HIGH | MEDIUM | LOW
    description: str
    filing_section: str
    evidence: str       # quoted text that triggered the rule, or empty string


@dataclass
class RuleEngineOutput:
    filing_id: str
    rule_results: list[RuleCheckResult]
    overall_flag: str   # PASS | FLAG
    checked_at: datetime = field(default_factory=datetime.utcnow)


# ---------------------------------------------------------------------------
# ML Risk Service outputs
# ---------------------------------------------------------------------------

@dataclass
class RiskScore:
    filing_id: str
    sla_delay_probability: float    # 0.0 - 1.0
    escalation_probability: float   # 0.0 - 1.0
    review_effort_score: float      # 0.0 - 1.0
    composite_risk: float           # 0.0 - 1.0 (weighted composite)
    risk_tier: str                  # HIGH | MEDIUM | LOW
    model_version: str
    scored_at: datetime = field(default_factory=datetime.utcnow)


# ---------------------------------------------------------------------------
# RAG Evidence Service outputs
# ---------------------------------------------------------------------------

@dataclass
class EvidenceChunk:
    chunk_text: str
    source_doc: str
    collection: str     # POLICY | REGULATORY
    page_number: int
    similarity_score: float


@dataclass
class PolicyCitation:
    source_doc: str
    collection: str
    excerpt: str
    relevance: str      # one-line note on why this section applies


@dataclass
class FilingSummary:
    filing_id: str
    executive_summary: str
    flagged_issues: list[str]
    policy_citations: list[PolicyCitation]
    regulatory_citations: list[PolicyCitation]
    coverage_gaps: list[str]
    recommended_actions: list[str]
    confidence_score: float
    drafted_by: str = "RAGService/v1.0"


@dataclass
class ReviewResult:
    confidence_score: float
    ungrounded_claims: list[str]
    recommendation: str     # APPROVE | FLAG_FOR_HUMAN


# ---------------------------------------------------------------------------
# Supervisor / Handoff
# ---------------------------------------------------------------------------

@dataclass
class AgentEvent:
    agent_name: str
    filing_id: str
    input_hash: str
    output_summary: str     # SHORT description only, no full text, no PII
    confidence: Optional[float]
    status: str             # SUCCESS | FAILURE
    error_message: Optional[str]
    executed_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class HandoffPackage:
    filing_id: str
    rule_output: Optional[RuleEngineOutput]
    risk_score: Optional[RiskScore]
    filing_summary: Optional[FilingSummary]
    review_result: Optional[ReviewResult]
    status: str             # HANDOFF_READY | NEEDS_REVIEW | PIPELINE_ERROR
    error_reason: Optional[str]
    review_queue: Optional[str]     # LEGAL | PHARMACY | ACTUARIAL | NETWORK | OPERATIONS
    assembled_at: datetime = field(default_factory=datetime.utcnow)
    idempotent_replay: bool = False


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class RuleEngineError(Exception):
    """Raised when the rule engine cannot process a filing item."""
    pass


class MLServiceError(Exception):
    """Raised when the ML risk service cannot score a filing item."""
    pass


class RAGServiceError(Exception):
    """Raised when the RAG service cannot retrieve or draft for a filing item."""
    pass


class PersistenceError(Exception):
    """Raised when a database write fails."""
    pass
