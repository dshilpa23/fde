"""Application service - idempotency gate and coordination.

Provided complete. Do not move pipeline logic here.
"""
from __future__ import annotations
from pathlib import Path
from coc_filing_assistant.domain import COCFilingItem, HandoffPackage
from coc_filing_assistant import supervisor, repository


def process(item: COCFilingItem, db_path: Path = repository.DB_PATH) -> HandoffPackage:
    """Run the full pipeline or return the stored result if already processed."""
    repository.init_db(db_path)

    existing = repository.find_by_filing_id(item.filing_id, db_path)
    if existing:
        return HandoffPackage(
            filing_id=existing["filing_id"],
            rule_output=None,
            risk_score=None,
            filing_summary=None,
            review_result=None,
            status=existing["status"],
            error_reason=existing.get("error_reason"),
            review_queue=existing.get("review_queue"),
            assembled_at=__import__("datetime").datetime.fromisoformat(
                existing["assembled_at"]
            ),
            idempotent_replay=True,
        )

    package, agent_events = supervisor.run_pipeline(item)
    repository.save_package(package, agent_events, db_path)
    return package
