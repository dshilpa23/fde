"""Human Review Queue Router - assigns filings to the correct review queue.

LEARNER TASK: Implement route().

Read before starting:
  - specs/architecture.md  (section on routing logic)
  - Final Capstone Implementation Guide - Section 5.3 (routing matrix)
  - tests/test_router.py

Function to implement:
  route(package: HandoffPackage) -> str

What it must do:
  1. Inspect the HandoffPackage: rule_output, risk_score, and status.
  2. Return exactly one of these queue names (uppercase string):
       "LEGAL"       - prior-auth language issues or exclusion clause gaps
       "PHARMACY"    - pharmacy / formulary issues
       "ACTUARIAL"   - HIGH risk score or benefit calculation concerns
       "NETWORK"     - network adequacy issues
       "OPERATIONS"  - missing mandatory sections, very low RAG confidence,
                       or PIPELINE_ERROR
  3. When multiple triggers fire, use the priority order documented in
     your architecture.md spec. Legal > Pharmacy > Actuarial > Network > Operations.
  4. For PIPELINE_ERROR status, always return "OPERATIONS".
  5. For NEEDS_REVIEW with no specific rule category, return "OPERATIONS".

Routing logic must:
  - Be deterministic: same package always routes to same queue.
  - Not call any external service or LLM.
  - Not raise exceptions for valid HandoffPackage inputs.

Step 1: Document your routing matrix in architecture.md (Day 1).
Step 2: Implement route().
Step 3: Run: python -m pytest tests/test_router.py -v
"""
from __future__ import annotations
from coc_filing_assistant import observability
from coc_filing_assistant.domain import HandoffPackage

# Priority order: LEGAL > PHARMACY > ACTUARIAL > NETWORK > OPERATIONS.
# ACTUARIAL has no rule category of its own in this build (rule_engine_spec.md
# §2 defines only MISSING_INFO/PRIOR_AUTH/PHARMACY/EXCLUSION/NETWORK) - its
# trigger is risk_tier alone, checked in priority order below.
_LEGAL_CATEGORIES = {"PRIOR_AUTH", "EXCLUSION"}
_PHARMACY_CATEGORIES = {"PHARMACY"}
_NETWORK_CATEGORIES = {"NETWORK"}


def route(package: HandoffPackage) -> str:
    """Assign a HandoffPackage to a human review queue.

    Args:
        package: The assembled handoff package from the supervisor.

    Returns:
        Queue name: "LEGAL" | "PHARMACY" | "ACTUARIAL" | "NETWORK" | "OPERATIONS"
    """
    tracer = observability.get_tracer(__name__)
    with observability.traced_stage(tracer, "Router.route", status=package.status) as span:
        queue = _resolve_queue(package)
        span.set_attribute("review_queue", queue)
        return queue


def _resolve_queue(package: HandoffPackage) -> str:
    """Pure routing decision, unchanged from the original US-8 logic - factored
    out only so `route()` can wrap it in a span."""
    if package.status == "PIPELINE_ERROR":
        # safety_spec.md §6: PIPELINE_ERROR maps to OPERATIONS unconditionally -
        # Operations is the queue of record for anything the system could not
        # reason about, not a silent drop, regardless of whatever partial
        # rule/risk data happens to exist on the package.
        return "OPERATIONS"

    categories: set[str] = set()
    if package.rule_output is not None:
        categories = {r.category for r in package.rule_output.rule_results}

    if categories & _LEGAL_CATEGORIES:
        return "LEGAL"
    if categories & _PHARMACY_CATEGORIES:
        return "PHARMACY"
    if package.risk_score is not None and package.risk_score.risk_tier == "HIGH":
        # safety_spec.md §7: risk_tier legitimately participates in queue
        # SELECTION (never in the HANDOFF_READY/NEEDS_REVIEW status decision,
        # which supervisor.py already resolved before this function runs) -
        # and a rule-driven queue above always outranks it, per the same section.
        return "ACTUARIAL"
    if categories & _NETWORK_CATEGORIES:
        return "NETWORK"

    # Fallback: MISSING_INFO category, very-low-confidence NEEDS_REVIEW with no
    # specific rule category, or nothing else matched - Operations is the
    # queue of record (docstring items 2, 5).
    return "OPERATIONS"
