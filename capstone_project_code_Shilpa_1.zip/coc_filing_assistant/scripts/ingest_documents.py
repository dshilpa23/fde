"""Ingest all documents into ChromaDB - run once before starting implementation.

Usage:
    python scripts/ingest_documents.py

Creates two ChromaDB collections:
    coc_policy_docs   - insurer policy documents (3 files)
    coc_regulatory    - regulatory rules documents (3 files)

Run this before running any tests or starting the API.
Expected output: 6 documents ingested into 2 collections.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from coc_filing_assistant.llm_config import CHROMA_PATH, POLICY_COLLECTION, REGULATORY_COLLECTION

POLICY_DIR = Path(__file__).parent.parent / "data" / "policy_documents"
REGULATORY_DIR = Path(__file__).parent.parent / "data" / "regulatory_rules"

CHUNK_SIZE = 400
CHUNK_OVERLAP = 80


def chunk_text(text: str) -> list[str]:
    chunks, start = [], 0
    while start < len(text):
        end = start + CHUNK_SIZE
        chunks.append(text[start:end].strip())
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return [c for c in chunks if len(c) > 40]


def ingest_collection(client, collection_name: str, source_dir: Path, ef) -> int:
    try:
        client.delete_collection(collection_name)
        print(f"  Cleared existing collection: {collection_name}")
    except Exception:
        pass

    collection = client.create_collection(name=collection_name, embedding_function=ef)

    files = sorted(source_dir.glob("*.txt"))
    if not files:
        print(f"ERROR: No .txt files found in {source_dir}")
        sys.exit(1)

    total = 0
    for f in files:
        text = f.read_text(encoding="utf-8")
        chunks = chunk_text(text)
        ids, docs, metas = [], [], []
        for i, chunk in enumerate(chunks):
            page = 1
            for line in chunk.split("\n"):
                if line.strip().startswith("PAGE "):
                    try:
                        page = int(line.strip().split()[1])
                    except (IndexError, ValueError):
                        pass
            ids.append(f"{f.stem}_{i:04d}")
            docs.append(chunk)
            metas.append({"source": f.name, "page": page, "collection": collection_name})

        collection.add(documents=docs, metadatas=metas, ids=ids)
        total += len(chunks)
        print(f"    {f.name}: {len(chunks)} chunks")

    return total


def ingest():
    import chromadb

    # Embedding hook (the only permitted edit in this frozen file - CLAUDE.md §3):
    # import the real implementation from rag_service.py rather than redefining it
    # here, so ingestion and query are guaranteed to use the identical embedding
    # function (constraint 11) by construction, not by copy-paste discipline.
    from coc_filing_assistant.rag_service import CompanyEmbeddingFunction

    print(f"\nChromaDB path: {CHROMA_PATH}")
    ef = CompanyEmbeddingFunction()
    client = chromadb.PersistentClient(path=CHROMA_PATH)

    print(f"\nIngesting policy documents into '{POLICY_COLLECTION}':")
    policy_chunks = ingest_collection(client, POLICY_COLLECTION, POLICY_DIR, ef)

    print(f"\nIngesting regulatory documents into '{REGULATORY_COLLECTION}':")
    reg_chunks = ingest_collection(client, REGULATORY_COLLECTION, REGULATORY_DIR, ef)

    print(f"\nIngestion complete:")
    print(f"  {POLICY_COLLECTION}: {policy_chunks} chunks")
    print(f"  {REGULATORY_COLLECTION}: {reg_chunks} chunks")
    print(f"\nNext step: python -m pytest -m baseline -q")


if __name__ == "__main__":
    ingest()
