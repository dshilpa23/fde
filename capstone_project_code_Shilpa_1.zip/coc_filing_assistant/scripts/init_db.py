"""Initialize the SQLite database. Run once during setup.

Usage:
    python scripts/init_db.py

Creates coc_filings.db with all tables and append-only triggers.
Safe to run multiple times - uses CREATE TABLE IF NOT EXISTS.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from coc_filing_assistant.repository import init_db, DB_PATH

if __name__ == "__main__":
    init_db()
    print(f"Database initialized: {DB_PATH.resolve()}")
    print("Tables created: coc_filings, agent_audit_events, review_queue")
    print("Triggers created: no_update_agent_audit, no_delete_agent_audit")
