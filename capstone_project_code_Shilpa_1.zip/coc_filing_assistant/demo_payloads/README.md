# demo_payloads — paste-ready request bodies for the live demo

Five request bodies for `POST /filings/process`, shaped for pasting into the Swagger UI
at `http://localhost:8000/docs` during a live demo so a recording never depends on typing
a twelve-field JSON body by hand.

## What these are

- **Entirely synthetic.** Every value is invented test data.
- **Input-only demo copies**, generated from the authoritative fixtures in
  `evals/filings.py`. That module is the single source of truth; these files are derived
  artifacts and must never be edited by hand.
- **No real member, patient, or production COC data.** None. This project's scope
  statement (`OPERATIONAL_HANDOFF.md` §0) and `safety_rules.md` both exclude real
  patient data, and the unit of work is a filing document rather than a person.

## Regenerating

```bash
python demo_payloads/generate.py
git diff --exit-code demo_payloads/   # no diff => committed copies match the fixtures
```

`tests/test_demo_payloads.py` enforces the same equality in the test suite, so a fixture
change cannot silently leave a stale payload behind to break a recording.

## Naming caution — `FILING-ERR-001`

`FILING-ERR-001` comes from the fixture builder named `pipeline_error()`. **The name
describes the fixture's intent, not a runtime outcome.** Submitted normally through the
API it does *not* produce `PIPELINE_ERROR`: it fires thirteen legitimate rule findings,
scores `risk_tier=HIGH`, completes all four stages successfully, and returns
`HANDOFF_READY` routed to `LEGAL`.

It is also this suite's deliberately **sparse** payload — the "empty-field item" required
by `testing_rules.md` — with an empty `mandatory_sections_present` and seven blank string
fields. That sparseness is the point: it is what makes every `MISSING_INFO` rule fire.
`tests/test_demo_payloads.py` pins `FILING-ERR-001` as the only payload allowed to be
sparse, so a generator bug that blanked a different fixture would still fail the suite.

A real `PIPELINE_ERROR` requires an actual stage failure, which the eval suite produces
by forcing one (`eval_end_to_end.eval_correct_queue_routing` patches `rule_engine.run_checks`
to raise). Do not present this payload as an error case on camera — see `DEMO_SCRIPT.md`,
which uses `FILING-HIGH-001` as the exception/escalated-review case instead.

## The five payloads

| File | Observed outcome via `POST /filings/process` |
|---|---|
| `FILING-LOW-001.json` | `HANDOFF_READY` · `LOW` · `OPERATIONS` — no rule categories fire |
| `FILING-HIGH-001.json` | `HANDOFF_READY` · `HIGH` · `LEGAL` — 9 rules fire, 3 HIGH; the exception/escalated-review case |
| `FILING-MED-001.json` | `HANDOFF_READY` · `MEDIUM` |
| `FILING-ERR-001.json` | `HANDOFF_READY` · `HIGH` · `LEGAL` — see the naming caution above |
| `FILING-IDEM-001.json` | `HANDOFF_READY` · `MEDIUM` — used for the idempotent-replay step |

Confidence scores are deliberately omitted from this table: they vary run to run within
the documented citation-grounding tolerance (`0.714` and `0.857` both observed for
`FILING-LOW-001` against the 0.70 gate). Quote the number the demo actually shows.
