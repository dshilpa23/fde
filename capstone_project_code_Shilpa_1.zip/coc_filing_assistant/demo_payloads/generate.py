"""Regenerate the paste-ready demo payloads from the authoritative fixtures.

The JSON files beside this script are *derived artifacts*. `evals/filings.py` is the
single source of truth for fixture content; these are input-only copies shaped for
pasting into the Swagger UI at `/docs` during a live demo, so a recording never depends
on typing a twelve-field request body by hand.

Field order follows `FilingRequest` in `api.py`, which is what the endpoint validates
against (`model_config = {"extra": "forbid"}`, so an unexpected key returns 422).

Run: python demo_payloads/generate.py
Then: git diff --exit-code demo_payloads/   # no diff => committed copies are current
"""
from __future__ import annotations

import dataclasses
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent
sys.path.insert(0, str(REPO_ROOT / "src"))
sys.path.insert(0, str(REPO_ROOT))

from evals import filings  # noqa: E402  (after sys.path setup)

# Fixture builder -> output filename. Keyed by the fixture's own filing_id so the file
# name matches what a viewer sees in the response and on the dashboard.
FIXTURES = (
    filings.high_risk,
    filings.medium_risk,
    filings.low_risk,
    filings.pipeline_error,
    filings.idempotency,
)


def payload_for(builder) -> dict:
    """Return the request body for one fixture, as `POST /filings/process` expects it."""
    return dataclasses.asdict(builder())


def main() -> int:
    """Write one pretty-printed JSON payload per fixture. Returns an exit code."""
    written = []
    for builder in FIXTURES:
        payload = payload_for(builder)
        path = HERE / f"{payload['filing_id']}.json"
        path.write_text(json.dumps(payload, indent=2) + "\n")
        written.append(path.name)
    for name in written:
        print(f"wrote demo_payloads/{name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
