# Model Recommendations

Two independent questions, kept separate on purpose: which model runs *inside the
product* (chat/embeddings for the RAG service), and which Claude model/agent should be
used *to build and harden the product* (this backlog and the eventual Tasks 1–7b).

## 1. Runtime models — the product's chat and embedding models

**Hard constraint, unchanged from `CLAUDE.md` §4/§2 (constraint 11):** only the
org-approved enterprise AI endpoint, via `ENTERPRISE_LLM_ENDPOINT` /
`ENTERPRISE_LLM_API_KEY` / `ENTERPRISE_LLM_DEPLOYMENT`. No public model provider, no
local runtime, no `DefaultEmbeddingFunction`. The same embedding function must serve
ingestion and query.

**I do not have your actual UAIS/AI-Dojo approved model catalog.** The recommendations
below are tiers with reasoning, flagged explicitly as pending confirmation — see
`uais_open_ai_connector_skill` for how to actually reach the enterprise gateway and
discover what's on it.

### Chat/generation model (`draft_summary()`)

Recommend the **highest-capability instruction-following tier available on the
approved endpoint** (an Azure OpenAI-class `gpt-4.1`/`gpt-4o`-tier model, or whatever
the enterprise catalog's frontier-equivalent is), not a smaller/cheaper tier. Reasoning:

- **Grounding fidelity matters more than throughput here.** This is a low-volume,
  high-stakes generation task (one summary per filing, filings arrive at a rate a human
  team currently reviews in 3–5 business days — not a chat-scale QPS workload). The
  cost difference between tiers is immaterial at this volume; the accuracy difference
  in citation grounding is not.
- **Injection resistance correlates with model capability.** The structural defense in
  `safety_spec.md` §4 (region separation) is the primary control and works regardless
  of model choice, but a more capable model is measurably better at not being confused
  by adversarial phrasing even inside a clearly-labeled "untrusted evidence" region —
  defense in depth, not the only control.
- **Parseable structured output.** `draft_summary()` must parse the LLM's response into
  a `FilingSummary` reliably; frontier-tier models have materially better structured/
  JSON-mode output reliability, reducing `RAGServiceError` "unparseable response" rates.

### Embedding model (`retrieve()` + `ingest_documents.py`)

Recommend a **large/high-dimensional embedding tier** (an `text-embedding-3-large`-class
model if the endpoint is Azure OpenAI-backed, or the enterprise catalog's equivalent
top-quality tier), not a smaller/cheaper embedding model. Reasoning:

- The corpus is 6 documents. Embedding cost and latency are negligible at this scale
  regardless of tier — there's no cost argument for a cheaper model here.
- Retrieval precision directly drives `confidence_score` (`rag_spec.md` §4), which
  directly drives `APPROVE` vs `FLAG_FOR_HUMAN`. A weaker embedding model that misses a
  relevant policy chunk doesn't just produce a worse summary — it produces a
  false-negative on grounding, which is a **safety regression**, not a quality one.
- Must be the same model for both ingestion and query (constraint 11) — pick once,
  document it in `OPERATIONAL_HANDOFF.md`, and never let ingestion and query drift onto
  different deployments of "the same model" (e.g., a version bump on one side only).

**Action item before this becomes concrete:** confirm the actual UAIS-approved model
names against this reasoning, then record the confirmed names (not "the enterprise
endpoint," the actual deployment name) in `OPERATIONAL_HANDOFF.md`.

### Cost/latency budget estimate (per filing, order-of-magnitude, unconfirmed pricing)

- Retrieval: 1 embedding call on a ~400-character query string (two 200-char fields
  concatenated per `rag_spec.md` §3) — trivially small, sub-second, negligible cost at
  any tier.
- Generation: 1 chat completion with a prompt containing rule results, risk tier, and
  up to `2 × top_k` (default 10) retrieved chunks — likely low-thousands of input
  tokens, a few hundred output tokens for a structured `FilingSummary`. At frontier-tier
  pricing this is cents per filing, not dollars — immaterial next to the 3–5
  business-day human review cost it replaces. Flagged as an estimate; replace with real
  numbers once the enterprise endpoint's actual pricing is confirmed.

## 2. Build-time models — which Claude model/agent executes each piece of work

This extends the table already in `coc_filing_assistant/LEARNER_TASK_MAP.md` (which
covers Tasks 1–7b) rather than replacing it. Same underlying principle: **safety-
critical or adversarial-judgment work → Opus 5; mechanical, fully-specified work →
Sonnet 5.**

| Work item | Model | Specialized agent/skill | Why |
|---|---|---|---|
| Security threat modeling (Epic 1, US-S2/S3) | Opus 5 (xhigh) | `secure-agent-repo-auditor` skill, `drzero:security` agent | Adversarial reasoning about attack surfaces is exactly the failure mode Opus 5 is reserved for in `LEARNER_TASK_MAP.md` (matches its Task 3b/4/6 rationale) |
| Red-team catalog design (Epic 3) | Opus 5 (xhigh) | `secure-agent-repo-auditor` skill | Designing adversarial test cases that generalize (not just pattern-match one phrasing) needs the same subtle judgment as prompt-injection defense itself |
| RAG architecture/embedding decisions (Epic 4) | Sonnet 5 for scaffolding, Opus 5 for the calibration-plan judgment call | `intelligent-rag-architect` skill | The skill already encodes RAG-specific structured decision-making; Opus 5 only needed where a judgment call (not a lookup) is required |
| Observability design (Epic 2) | Sonnet 5 | `ai-dlc:nfr-analyst` agent | Logging conventions and metrics definitions are mechanical once the pattern is set |
| Infra/scaling design (Epic 5) | Sonnet 5 for scaffolding, `drzero:database`/`drzero:infrastructure` agents for detailed design | — | Well-trodden migration patterns (SQLite→Postgres), not novel judgment |
| Compliance/retention policy (Epic 5, US-D3) | Opus 5 | `drzero:compliance` agent | Regulatory record-keeping requirements interact with legal risk, not just engineering |
| This backlog itself (PRD, epics, HTML) | Sonnet 5 | — | Documentation synthesis from already-gathered facts; no adversarial or safety-critical judgment required |

**Note on effort, carried over from `LEARNER_TASK_MAP.md`:** in the Claude Code app,
effort already defaults to `xhigh`; the lever actually available is model choice, not a
per-request effort dial. Where this table says "Opus 5 (xhigh)," it's naming the
directional intent for contexts (harness or API) where effort is an exposed parameter.
