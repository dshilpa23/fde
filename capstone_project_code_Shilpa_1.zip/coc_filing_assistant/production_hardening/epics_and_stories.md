# Epics & User Stories — Production Hardening Backlog

Status legend: **spec-now** = content already folded into `coc_filing_assistant/specs/`
in this pass. **roadmap** = requires infra/dependency/data outside graded scope; not
implemented, blocker named explicitly.

Each story: ID · story · acceptance criteria (Given/When/Then) · status · recommended
executing agent/model (see `model_recommendations.md` for the full rationale).

---

## Epic 1 — Security & Access Control

**US-S1 — Secrets hygiene audit**
As a security reviewer, I want confirmation that no credential ever reaches source
control or the audit trail, so that a leaked repo or leaked audit export can't leak
credentials too.
- Given `.env.example` and `.gitignore`, when audited, then `.env` is git-ignored, `.env.example` contains only placeholder values, and no `ENTERPRISE_LLM_API_KEY`-shaped string appears anywhere in `src/`, `tests/`, or `agent_audit_events` rows.
- Given the submission zip step in `release_rules.md`, when packaged, then `.env` is excluded and `.env.example` is included.
- Status: **spec-now** (verification checklist, no code change needed — already required by `release_rules.md`).
- Agent/model: Sonnet 5, mechanical checklist verification.

**US-S2 — Prompt-injection structural defense**
As a compliance owner, I want chunk text structurally incapable of being interpreted as
an instruction, so that rule 4 of `safety_rules.md` is enforced by design, not by hoping
the model behaves.
- Given a generation prompt template, when built, then retrieved chunk text is placed only in a clearly delimited "untrusted evidence" region, never in the instruction region, and no field of `COCFilingItem`/`RuleEngineOutput`/`EvidenceChunk` is concatenated into the instruction region.
- Given the 5-case adversarial catalog (direct override, role-play jailbreak, citation spoofing, unicode obfuscation, multi-chunk split), when each runs, then `HANDOFF_READY` is never set on chunk content alone and `recommendation` is computed from real grounding math.
- Status: **spec-now** (`safety_spec.md` §4, `rag_spec.md` §6) — implementation happens when Task 3b (`draft_summary()`) is built against this spec.
- Agent/model: Opus 5, xhigh — adversarial reasoning and subtle prompt-construction judgment (matches `LEARNER_TASK_MAP.md`'s existing rationale for Task 3b).

**US-S3 — API authentication and authorization**
As a security reviewer, I want every endpoint gated by an authenticated, authorized
caller, so that filing data and audit history aren't reachable by anyone who can reach
the network.
- Given a production deployment, when a request lacks a valid token, then it is rejected before reaching `api.py` logic.
- Given a valid token, when the caller's role doesn't include the endpoint's required scope (e.g. only Operations can hit `/dashboard`'s write paths, if any are added), then the request is rejected with 403.
- Status: **roadmap** — blocked by `api.py` being a frozen file in the graded repo (no middleware can be added there) and by no gateway/OAuth2 infra being provisioned.
- Agent/model: `drzero:security` agent + `secure-agent-repo-auditor` skill for the design; `ai-dlc:infrastructure-design-agent` for the gateway topology once infra exists.

**US-S4 — Least-privilege data access**
As a DBA, I want the service's database role scoped to only the operations it performs
(insert/select on 3 tables, no DDL, no cross-schema access), so that a compromised
application credential can't be used to read or modify unrelated data.
- Given a production Postgres instance, when the service connects, then it uses a role with `INSERT`/`SELECT` on `coc_filings`, `agent_audit_events`, `review_queue` only, and no `DROP`/`ALTER` grants.
- Status: **roadmap** — no Postgres instance exists yet (depends on Epic 5).
- Agent/model: `drzero:database` agent, `drzero:secrets` agent for credential provisioning.

---

## Epic 2 — Observability & Audit

**US-O1 — Structured logging conventions**
As an SRE, I want every service call to emit a structured log line keyed by
`input_hash` (never PII), so that I can trace a filing's path through the pipeline
without touching the audit table.
- Given a pipeline run, when each of the 4 stages executes, then it emits one structured log entry (stdlib `logging`, JSON-formatted) containing `filing_id_hash`, `stage`, `status`, `duration_ms` — never raw filing content.
- Given a log line, when inspected, then it contains no field present in the safety_spec.md §2 prohibited-PII list.
- Status: **spec-now** — convention documented in `rag_spec.md`/`architecture.md`; implemented when Tasks 1–6 are built, using only the stdlib `logging` module already implicitly available (no new dependency).
- Agent/model: Sonnet 5, mechanical.

**US-O2 — Per-stage latency and outcome metrics**
As an SRE, I want p50/p95 latency and success/failure counts per stage, so that I can
detect a degrading stage before it produces a backlog of `PIPELINE_ERROR` filings.
- Given N pipeline runs, when aggregated, then per-stage latency percentiles and error rates are computable from the structured logs in US-O1 without a new backend.
- Status: **spec-now** as a log-derivable capability; a real-time dashboard/alerting backend is **roadmap** (new dependency: Prometheus/Dynatrace/equivalent).
- Agent/model: `ai-dlc:nfr-analyst` for the metrics design; `dynatrace-platform:dynatrace-ops` skill if/when a Dynatrace tenant is the target.

**US-O3 — Distributed tracing**
As an SRE, I want a trace ID that follows a filing across all 4 stages plus the DB
write, so that I can visualize the full request lifecycle in an APM tool.
- Given a request enters `/filings/process`, when it completes, then a single trace spans Rule Engine → ML Risk → RAG Retrieve → RAG Draft → Repository, viewable in the APM backend.
- Status: **roadmap** — requires a tracing SDK (new dependency, disallowed in graded repo) and an APM backend.
- Agent/model: `drzero:monitoring` agent.

**US-O4 — Dashboard completeness indicator**
As an Operations Lead, I want `/dashboard` to visibly flag any filing whose audit trail
doesn't have exactly 4 events, so that an incomplete pipeline run is never silently
mistaken for a clean one.
- Given a filing with fewer than 4 audit events, when `/dashboard` renders, then that filing is visually flagged as incomplete.
- Status: **roadmap** if `/dashboard`'s rendering lives inside frozen `api.py`; **spec-now** (documented requirement) regardless, so the learner knows to check where dashboard templating actually lives before deciding feasibility.
- Agent/model: Sonnet 5.

---

## Epic 3 — Red-Team & Adversarial Resilience

**US-R1 — Expanded adversarial test catalog**
As a security reviewer, I want more than one adversarial-chunk phrasing tested, so that
the injection defense is proven structural, not a string-match coincidence.
- Given the 5 cases in `safety_spec.md` §4, when each runs against `draft_summary()`, then all 5 pass with the same required outcomes (no chunk-driven `HANDOFF_READY`, `recommendation` from real grounding math).
- Status: **spec-now** (`safety_spec.md` §4, `eval_spec.md` §1) — test implementation happens alongside Task 3b.
- Agent/model: Opus 5 — adversarial-input design benefits from the same judgment used for Task 3b/4/6 in `LEARNER_TASK_MAP.md`.

**US-R2 — OWASP threat-model mapping**
As a security reviewer, I want this system's design mapped against a recognized
taxonomy (OWASP LLM Top 10 / OWASP Agentic Top 10), so that gaps are identified against
an external standard, not just internal intuition.
- Given the pipeline architecture, when mapped, then each applicable OWASP category has an explicit "mitigated / partially mitigated / not applicable / gap" verdict with a one-line justification.
- Status: **spec-now** as a documented mapping (see `gap_analysis.html` Security section); produced using the `secure-agent-repo-auditor` skill's taxonomy.
- Agent/model: `secure-agent-repo-auditor` skill, Opus 5.

**US-R3 — CI red-team regression gate**
As a maintainer, I want the adversarial catalog to run automatically on every change to
`rag_service.py`, so that a future refactor can't silently reintroduce an injection
vulnerability.
- Given a pull request touching `rag_service.py`, when CI runs, then the 5-case adversarial suite from US-R1 executes and blocks merge on any failure.
- Status: **roadmap** — no CI pipeline exists in the graded repo scope.
- Agent/model: `drzero:devops` agent.

**US-R4 — Citation fabrication stress test**
As a compliance owner, I want the grounding check stress-tested against a corpus
deliberately engineered to tempt fabrication (near-miss but wrong citations), so that
`confidence_score` degrades correctly under harder-than-baseline conditions.
- Given a retrieval set containing plausible-but-wrong chunks (same topic, wrong source document), when `draft_summary()` runs, then any citation not in the actual retrieved set drives `confidence_score` down per the grounding formula, never silently accepted.
- Status: **spec-now** — extends `eval_spec.md` §1; runs in `evals/eval_rag_quality.py`, no new dependency.
- Agent/model: Sonnet 5 for the harness scaffold, Opus 5 to design the near-miss corpus.

---

## Epic 4 — RAG Quality & Retrieval Architecture

**US-G1 — Embedding model tier selection**
As the RAG service owner, I want a documented, reasoned choice of embedding-model tier
(not just "the enterprise endpoint"), so that retrieval precision is a deliberate
decision, not a default.
- Given the 6-document corpus and negligible embedding volume, when selecting a tier, then the decision favors retrieval quality over cost/latency and is recorded with rationale in `model_recommendations.md`.
- Status: **spec-now** (`rag_spec.md` §2, `model_recommendations.md`).
- Agent/model: `intelligent-rag-architect` skill.

**US-G2 — Chunking strategy review**
As the RAG service owner, I want the actual chunk size/overlap produced by
`ingest_documents.py` documented and assessed, so that `draft_summary()`'s prompt
context is a known quantity, not a surprise discovered during debugging.
- Given `scripts/ingest_documents.py` has run, when the resulting chunks are inspected, then their size/overlap/count is recorded in `OPERATIONAL_HANDOFF.md` and assessed against whether a single `EvidenceChunk` carries enough context for a citation to be meaningful.
- Status: **spec-now** (documented in `rag_spec.md` §3) — actual numbers only knowable after Task 7b runs.
- Agent/model: Sonnet 5.

**US-G3 — Retrieval evaluation harness (precision/recall)**
As the RAG service owner, I want measured precision@k/recall@k against a labeled query
set, so that retrieval quality is a number I track, not an assumption.
- Given a hand-labeled set of 5–10 filing-field → expected-document pairs, when `retrieve()` runs each, then precision@5 and recall@5 are computed and reported.
- Status: **spec-now** (`eval_spec.md` §1) — implemented as `eval_retrieval_precision_recall()` in `evals/eval_rag_quality.py`, no new dependency.
- Agent/model: `intelligent-rag-architect` skill for eval design, Sonnet 5 for the script.

**US-G4 — Confidence threshold calibration**
As the RAG service owner, I want the `0.70` confidence cutoff validated against actual
reviewer agreement, so that the threshold reflects measured accuracy rather than an
asserted default.
- Given a set of filings with known correct human-reviewer outcomes (APPROVE vs FLAG_FOR_HUMAN), when the threshold is swept, then the value maximizing agreement (or minimizing false-APPROVE rate, whichever is prioritized) replaces `0.70`.
- Status: **roadmap** — no labeled reviewer-outcome dataset exists yet; this is a data-collection dependency, not an engineering one.
- Agent/model: `ai-dlc:nfr-analyst` once data exists.

**US-G5 — Embedding/retrieval drift monitoring**
As the RAG service owner, I want scheduled re-evaluation of retrieval quality as the
corpus grows, so that silent accuracy decay is caught before it accumulates.
- Given a scheduled job, when it runs periodically, then it re-executes US-G3's precision/recall harness against the current corpus and alerts on regression beyond a defined tolerance.
- Status: **roadmap** — requires a scheduler and alerting infra not present in the graded repo.
- Agent/model: `drzero:monitoring` agent.

---

## Epic 5 — Data & Infrastructure Scaling

**US-D1 — SQLite → Postgres migration plan**
As a platform engineer, I want a concrete migration plan from SQLite to Postgres, so
that the "tens of thousands of filings annually" volume doesn't hit a single-writer
lock-contention wall.
- Given the current 3-table schema, when migrated, then the same schema (plus indexes appropriate to production query patterns) exists in Postgres, with a rollback plan documented.
- Status: **roadmap** — already flagged as a known gap in `CLAUDE.md` §4; no Postgres instance provisioned.
- Agent/model: `drzero:database` agent.

**US-D2 — Concurrent-writer story**
As a platform engineer, I want the persistence layer to handle concurrent
`save_package()` calls correctly, so that simultaneous filing submissions don't corrupt
or lose audit rows.
- Given N concurrent `save_package()` calls, when they execute, then each atomic 3-table transaction completes independently with no lost writes and no partial audit rows.
- Status: **roadmap** — depends on US-D1 (Postgres) for real multi-writer support; SQLite's WAL mode is a graded-scope mitigation, not a production one.
- Agent/model: `drzero:database` agent.

**US-D3 — Audit retention and backup/DR**
As a compliance owner, I want the append-only audit table backed by real backup/DR and
a defined retention policy, so that a regulator's "why was this filed" question is
answerable years later, not just today.
- Given a defined retention period (e.g., matching state regulatory record-keeping requirements), when backups run, then audit data is recoverable to any point within that period.
- Status: **roadmap** — requires backup infrastructure and a retention-policy decision from compliance stakeholders, not an engineering-only decision.
- Agent/model: `drzero:compliance` agent.

---

## Epic 6 — Model & Agent Governance

**US-M1 — Build-time model/agent selection matrix**
As the engineer building this system with Claude Code, I want a documented mapping of
which Claude model and which specialized agent/skill should execute each hardening
story, so that safety-critical work consistently gets the highest-judgment model and
mechanical work doesn't waste it.
- Given each story in this backlog, when assigned, then it names a specific Claude model (Sonnet 5 or Opus 5) and, where applicable, a specific skill/agent, with a one-line reason — extending, not replacing, the existing table in `LEARNER_TASK_MAP.md`.
- Status: **spec-now** — this document (see agent/model line on every story above) plus `model_recommendations.md`.
- Agent/model: Sonnet 5 (this is the mechanical bookkeeping task itself).

**US-M2 — Runtime chat/embedding model recommendation**
As the RAG service owner, I want a reasoned recommendation for which tier of chat and
embedding model to configure via `ENTERPRISE_LLM_*`, so that the model choice is a
documented decision defensible in the Q&A segment, not a default nobody chose.
- Given the constraint of org-approved-endpoint-only, when a model tier is recommended, then it states the reasoning (grounding fidelity, injection resistance, retrieval precision) and explicitly flags that it is pending confirmation against the real UAIS/enterprise catalog.
- Status: **spec-now** (`model_recommendations.md`).
- Agent/model: Sonnet 5, using the `uais_open_ai_connector_skill` reference for how the enterprise endpoint is actually reached.

**US-M3 — Cost/latency budget per pipeline run**
As the product owner, I want an estimated cost and latency budget for one filing's
pipeline run (1 embedding call for retrieval + 1 generation call for the summary), so
that scaling to "tens of thousands of filings annually" has a known cost order of
magnitude before it's built.
- Given typical filing field lengths (~200 chars per query field, corpus of 6 docs), when estimated, then a per-filing token/cost/latency estimate is documented, flagged as an estimate pending real enterprise-endpoint pricing.
- Status: **spec-now** (`model_recommendations.md`).
- Agent/model: Sonnet 5.
