# Architecture — Current State vs Target State

## Current state (graded capstone scope)

```
                    ┌────────────────────────────────────────┐
                    │   Single FastAPI process (uvicorn)      │
                    │   coc_filing_assistant.api:app          │
                    │                                          │
  HTTP, no auth ───▶│  /filings/process  /filings  /filings/id │
                    │  /audit-log  /review-queue  /risk-report │
                    │  /health  /dashboard                     │
                    │                                          │
                    │  Rule Engine → ML Risk → RAG → Supervisor│
                    │  → Router → Repository                   │
                    └───────────┬──────────────┬───────────────┘
                                │              │
                        ┌───────▼─────┐  ┌─────▼──────┐
                        │ SQLite file │  │ ChromaDB    │
                        │ (WAL mode)  │  │ (local,     │
                        │ 1 process   │  │ persistent  │
                        │             │  │ client)     │
                        └─────────────┘  └─────────────┘
                                │
                        Enterprise LLM/embedding endpoint
                        (org-approved, via env vars)
```

Single process, single writer, no gateway, no auth, no metrics/tracing backend, no CI
red-team gate. Correct and sufficient for a graded, single-operator, 5-filing
demonstration.

## Target state (production rollout)

```
        ┌──────────────┐      ┌─────────────────────────────────────┐
Client ▶│ API Gateway  │─────▶│ FastAPI service (N replicas)          │
        │ OAuth2/mTLS  │      │ same pipeline logic, stateless        │
        │ rate limit   │      └───┬───────────────┬───────────────┬──┘
        └──────────────┘          │               │               │
                                   ▼               ▼               ▼
                          ┌───────────────┐ ┌─────────────┐ ┌─────────────┐
                          │ Postgres       │ │ Vector store │ │ Observability│
                          │ (managed,      │ │ (managed or  │ │ stack:       │
                          │ multi-writer,  │ │ scaled       │ │ logs+metrics │
                          │ backup/DR)     │ │ ChromaDB/    │ │ +traces,     │
                          │ audit table    │ │ pgvector)    │ │ alerting     │
                          │ append-only,   │ └─────────────┘ └─────────────┘
                          │ WORM retention)│
                          └───────────────┘
                                   │
                          Enterprise LLM/embedding endpoint
                          (same contract, higher throughput tier)
                                   │
                          CI: red-team regression gate
                          (runs the adversarial catalog on every PR)
```

## Gap matrix

| Capability | Current | Target | Blocking constraint | Epic |
|---|---|---|---|---|
| AuthN/AuthZ | None | OAuth2/mTLS at gateway | `api.py` frozen in graded repo; no gateway infra provisioned | 1 |
| Prompt-injection defense | Structural region separation (spec-level) | Same + CI-gated regression | None — implementable now via spec | 1, 3 |
| Secrets | `.env` file, no rotation | Managed secret store with rotation | No secrets backend provisioned | 1 |
| Observability | Audit rows only | Structured logs + metrics + traces + alerting | New dependency (tracing SDK, metrics backend) | 2 |
| Red-team | Manual eval script | CI-gated automated regression suite | CI pipeline not in graded scope | 3 |
| Embedding model | Enterprise endpoint, tier TBD | Same endpoint, confirmed high-quality tier | Pending confirmation of actual approved catalog | 4, 6 |
| Confidence threshold | Asserted (0.70) | Calibrated against reviewer agreement | No labeled reviewer-outcome dataset exists | 4 |
| Persistence | SQLite, single writer | Postgres, multi-writer, backup/DR | New infra | 5 |
| Retrieval drift | Not monitored | Scheduled precision/recall re-evaluation | No scheduler/monitoring infra | 4 |

Every "target" cell that requires new infrastructure or a new dependency is a `roadmap`
story in `epics_and_stories.md`, not something implemented in this pass — consistent
with the graded repo's own constraints (no new dependencies, frozen `api.py`).
