# PRD — COC Filing Readiness Assistant: Production Hardening Initiative

Status: Draft backlog (BMAD-style). Companion to the graded capstone in
`coc_filing_assistant/`. This document does not modify, gate, or replace anything in the
graded repo — it answers the capstone's own Q4 ("what's needed before production
rollout?") with a structured backlog instead of a single slide bullet.

## 1. Problem statement

The capstone builds a triage pipeline that is correct-by-construction for a graded,
single-user, 5-synthetic-filing environment: local SQLite, local ChromaDB, no auth, no
observability stack, an asserted (not calibrated) confidence threshold, and a manually
run adversarial test. None of that is wrong for the assignment — `README.md` explicitly
freezes `api.py`, forbids new dependencies, and scores "a smaller solution that runs
end-to-end and is honestly described" above an ambitious but partial build. But a real
deployment against "tens of thousands of filings annually" (`CLAUDE.md` §1) run by
UnitedHealth Group, in a system whose outputs route to Legal, Pharmacy, Actuarial,
Network, and Operations reviewers, needs security, observability, and adversarial
resilience the graded scope doesn't require.

## 2. Users

The same 5 downstream review queues (Legal, Pharmacy, Actuarial, Network, Operations)
as end consumers of the system's output, plus two groups the graded build doesn't
surface: **Platform/SRE** (needs the system to be observable and recoverable) and
**Security/Compliance** (needs the system defensible against adversarial input and
auditable at the access-control level, not just the data level).

## 3. Success metrics (for the hardening initiative, not the capstone grade)

- Every Epic-3 (red-team) story has a passing regression test before any epic is marked done.
- Every `roadmap` story has a named blocking constraint (frozen file, new dependency, or missing infra) — no roadmap item is vague.
- The 4 specs modified in `coc_filing_assistant/specs/` (safety, rag, architecture, eval) pass a read-through against `specs/README.md`'s required contents with zero gaps.
- `gap_analysis.html` is reviewable by someone who has not read this PRD and answers, on its own, all 6 mandatory Q&A questions from the Implementation Guide's Section 8.

## 4. Non-goals

- Not re-litigating any of the 8 rules in `safety_rules.md` — they are frozen and
  already correct; this initiative only extends enforcement (e.g., a richer adversarial
  test catalog), never weakens or reinterprets them.
- Not implementing the 7 graded build tasks (Tasks 1–7b in `LEARNER_TASK_MAP.md`) —
  that's the separate Day 2–3 effort with its own model-selection guidance already
  documented there.
- Not standing up real infrastructure (Postgres, an auth gateway, a tracing backend) —
  those are `roadmap` stories with named blockers, not deliverables of this pass.

## 5. Scope: 6 epics

See `epics_and_stories.md` for full user stories with acceptance criteria. Summary:

1. **Security & Access Control** — secrets hygiene, prompt-injection hardening, authN/authZ (roadmap), least-privilege data access (roadmap).
2. **Observability & Audit** — structured logging conventions, per-stage metrics, tracing (roadmap), dashboard completeness.
3. **Red-Team & Adversarial Resilience** — expanded adversarial catalog, OWASP threat-model mapping, CI red-team gate (roadmap).
4. **RAG Quality & Retrieval** — embedding model tier, chunking, retrieval eval harness, confidence calibration plan (roadmap data need), drift monitoring (roadmap).
5. **Data & Infrastructure Scaling** — SQLite→Postgres (roadmap), concurrency (roadmap), audit retention/DR (roadmap).
6. **Model & Agent Governance** — build-time Claude model/agent matrix, runtime chat/embedding model tier, cost/latency budget.

## 6. Sequencing

Phase 0 (this pass): spec-now stories land as content inside the 4 modified specs plus
this backlog. Phase 1 (Day 2–3 of the capstone, separate effort): implement Tasks 1–7b
against the now-hardened specs. Phase 2 (post-capstone, if this becomes a real
initiative): roadmap stories, each gated on the infra/dependency named in its acceptance
criteria.
