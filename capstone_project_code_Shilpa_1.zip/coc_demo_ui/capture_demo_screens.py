"""Recapture the Streamlit demo screens against a live API + app.

Dev-only helper — it is not imported by the service and playwright is deliberately
NOT added to requirements.txt (`project_rules.md`: no new dependencies). It runs
against the playwright already present in the local .venv.

    python coc_demo_ui/capture_demo_screens.py --port 8511 --api http://localhost:8000 \
        --out coc_demo_ui/docs/demo_screens

Reset the database first (`python scripts/init_db.py` against a removed
coc_filings.db) so the review queue and audit tables show only the filings this
run submits.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

WIDTH = 1400
# Streamlit scrolls inside its own container, so page.screenshot(full_page=True)
# only ever yields the viewport. A tall viewport is the reliable way to get the
# whole page in one image.
HEIGHT = 5200


def click_button(page, label: str) -> None:
    page.get_by_role("button", name=label, exact=False).first.click()


def settle(page, seconds: float = 2.0) -> None:
    """Streamlit reruns are websocket-driven; poll until the status widget clears."""
    deadline = time.time() + 120
    time.sleep(1.0)
    while time.time() < deadline:
        running = page.locator('[data-testid="stStatusWidget"]').count()
        if running == 0:
            break
        time.sleep(1.0)
    time.sleep(seconds)


def select_scenario(page, label: str) -> None:
    """Streamlit's selectbox filters as you type; typing + Enter is the stable path."""
    box = page.locator('[data-testid="stSelectbox"] input').first
    box.click()
    box.type(label[:12], delay=40)
    page.wait_for_timeout(600)
    box.press("Enter")
    settle(page)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8511)
    ap.add_argument("--out", required=True)
    ap.add_argument("--api", default=None, help="Override the app's API base URL")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    url = f"http://localhost:{args.port}"

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": WIDTH, "height": HEIGHT})
        page.goto(url, wait_until="networkidle")
        settle(page, 3.0)

        if args.api:
            box = page.get_by_role("textbox", name="API base URL").first
            box.fill(args.api)
            box.press("Enter")
            settle(page, 2.0)

        page.screenshot(path=str(out / "01_landing.png"), full_page=True)
        print("captured 01_landing")

        # Low risk -> OPERATIONS
        select_scenario(page, "Low Risk")
        click_button(page, "Submit once")
        settle(page, 3.0)
        page.screenshot(path=str(out / "02_low_risk_result.png"), full_page=True)
        print("captured 02_low_risk_result")

        # High risk -> LEGAL
        select_scenario(page, "High Risk / Legal Review")
        click_button(page, "Submit once")
        settle(page, 3.0)
        page.screenshot(path=str(out / "03_high_risk_result.png"), full_page=True)
        print("captured 03_high_risk_result")

        # Evidence + rules expanders, still on the high-risk result
        for name in ("Evidence & Grounding", "Rules & Risk"):
            try:
                page.locator('[data-testid="stExpander"] summary', has_text=name).first.click(
                    timeout=10000
                )
                settle(page, 1.0)
            except Exception as exc:  # noqa: BLE001
                print(f"could not expand {name!r}: {exc}", file=sys.stderr)
        page.screenshot(path=str(out / "05_evidence_rules_expanded.png"), full_page=True)
        print("captured 05_evidence_rules_expanded")

        # Idempotency
        select_scenario(page, "Idempotency")
        click_button(page, "Run idempotency demo")
        settle(page, 3.0)
        page.screenshot(path=str(out / "04_idempotency_demo.png"), full_page=True)
        print("captured 04_idempotency_demo")

        browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
