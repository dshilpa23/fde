# COC Filing Readiness Assistant — Demo Transcript

**Date:** 2026-08-18
**App under test:** `coc_demo_ui/app.py` (Streamlit UI) → `POST /filings/process` on the FastAPI backend at `http://localhost:8000`
**Session note:** Captured against a second instance on port 8511 (`.claude/launch.json` → `coc-demo-ui-docs`) so the demo session already running on port 8501 was left untouched.
**Data:** Synthetic demo fixtures only — no real member/patient data.

---

## 1. Landing screen

The app opens with the connection panel confirming the backend is reachable (`API reachable — v1.0.0`, `policy_chunks=19 · regulatory_chunks=25`), a synthetic-data disclaimer, a scenario picker (`Low Risk`, `Medium Risk`, `High Risk / Legal Review`, `Idempotency`, `Sparse / Empty-Field Fixture`), and an editable JSON filing payload that feeds the real `/filings/process` endpoint unmodified.

Four static callouts frame the product promise: **No auto-filing**, **Grounded evidence**, **Deterministic routing**, **Human owns the final decision**.

![Landing screen](demo_screens/01_landing.png)

---

## 2. Scenario: Low Risk → Submit once

Loaded the default **Low Risk** fixture (`FILING-LOW-001`, BlueCross BlueShield PPO renewal, IL) and clicked **Submit once → /filings/process**.

**Executive Outcome:**

| Field | Value |
|---|---|
| Status | `HANDOFF_READY` |
| Risk tier | — (not surfaced at this summary level) |
| Confidence | — |
| Review queue | — |
| Idempotent replay | **YES** |

Note: `idempotent_replay = YES` on the very first click — this fixture had already been submitted in a prior run and the persisted audit log short-circuited to the cached result. This is expected behavior for a fixture-based demo, not a bug.

**Pipeline / Tool Execution** (each stage reports Observed/SUCCESS):
- **Rule Engine** — 14 rules across 5 categories checked → 0 rules flagged (0 HIGH, 0 MEDIUM), `overall_flag=PASS`
- **Risk Service** — feature-weighted, not a trained classifier → `risk_tier=LOW`, `composite=0.00`
- **RAG Retrieval** — 10 evidence chunks retrieved from the approved ChromaDB policy/regulatory collections
- **RAG Draft** — enterprise LLM endpoint → `confidence=0.86`, `recommendation=APPROVE`

**Handoff package assembled:**
- **Router** — fixed priority LEGAL > PHARMACY > ACTUARIAL > NETWORK > OPERATIONS → routed to `OPERATIONS`
- **Repository/Audit** — atomic 3-table SQLite write, append-only audit log → 4 audit event(s) persisted
- **Human Review** — queued for a reviewer in the assigned queue; no auto-filing

Below the fold, the app also shows (collapsed by default) **Evidence & Grounding**, **Rules & Risk**, and **Raw API Response** expanders, plus three live tables: **Human Review Queue**, **Persisted Filings**, and **Audit Trail** (48 total events across the demo's history at capture time).

![Low Risk result — full pipeline, queues, and audit trail](demo_screens/02_low_risk_result.png)

---

## 3. Scenario: High Risk / Legal Review → Submit once

Switched the scenario selector to **High Risk / Legal Review** (`FILING-HIGH-001`, Centene Corporation HMO, TX — "Prior authorization required for all specialist visits", Tier 3 step therapy with no exceptions noted) and submitted.

**Executive Outcome:**

| Field | Value |
|---|---|
| Status | `HANDOFF_READY` |
| Review queue | **LEGAL** |
| Idempotent replay | **YES** |

**Pipeline differences vs. Low Risk:**
- **Rule Engine** — 9 rules flagged (3 HIGH, 5 MEDIUM), `overall_flag=FLAG`
- **Risk Service** — `risk_tier=HIGH`, `composite=1.00`
- **RAG Retrieval / Draft** — 10 evidence chunks, `confidence=1.00`, `recommendation=APPROVE`
- **Router** — with LEGAL as the fixed top priority and rule flags present, the filing routed to the **LEGAL** queue (contrast with Low Risk → OPERATIONS)

This is the clearest side-by-side proof point for the demo: identical pipeline, same deterministic router logic, different queue outcome driven entirely by rule/risk signals — no manual branching in the UI.

![High Risk result — routed to LEGAL queue](demo_screens/03_high_risk_result.png)

---

## 4. Evidence & Rules detail (expanded)

Expanded the **Evidence & Grounding** and **Rules & Risk** panels on the High Risk result to show what the UI does and does not disclose:

- **Evidence & Grounding**: states that raw filing excerpts are used for retrieval embeddings, but raw filing free text is *not* passed to the LLM generation prompt. Grounding confidence score is shown as `—`. Per-source citation text and coverage gaps are computed by the pipeline but intentionally **not returned/displayed** ("Not shown — ... not exposed by the API") to avoid fabricating data not actually returned by the backend.
- **Rules & Risk**: Rule Engine finding summary (`9 rules flagged (3 HIGH, 5 MEDIUM), overall_flag=FLAG`) and Risk tier/composite (`Tier —`, `Composite (audit confidence) 1.0`) are shown, but per-rule detail (rule_id / category / severity per finding) is likewise marked **"Not shown"** since the API doesn't expose it.

This is a deliberate transparency design choice worth calling out in the demo narrative: the UI never invents detail the API didn't actually return.

![Evidence & Grounding and Rules & Risk expanded, showing explicit "not shown" transparency notes](demo_screens/05_evidence_rules_expanded.png)

---

## 5. Idempotency demo (submit twice)

Clicked **Run idempotency demo (submit twice)** against the High Risk fixture. The app submits the same `filing_id` twice and diffs the results side by side.

**Result banner:**
> Idempotency verified for `FILING-HIGH-001`: `idempotent_replay` went `True → True`; audit events for this filing stayed at 4 (no new events on replay).

| | 1st submit (fresh id) | 2nd submit (same id) |
|---|---|---|
| Status | HANDOFF_READY | HANDOFF_READY |
| Review queue | LEGAL | LEGAL |
| Idempotent replay | YES | YES |

Both submissions produced the identical `HANDOFF_READY` outcome and the audit trail did not grow — confirming the backend does not double-process or double-file a resubmitted filing_id.

![Idempotency demo — two submissions, identical outcome, no duplicate audit events](demo_screens/04_idempotency_demo.png)

---

## 6. Persistent state observed during this session

The **Human Review Queue**, **Persisted Filings**, and **Audit Trail** tables are live views over SQLite state that accumulates across runs (not reset between scenarios). At capture time the audit trail showed 48 total events spanning prior demo/test runs (`DEMO-TRANSCRIPT-CHECK`, `DEMO-READINESS-CHECK`, `DEMO-RECOVERY-CHECK-001`, `FILING-MED-001`, `DEMO-IDEM-VERIFY-001/002`, `DEMO-EDITED-003/004`, plus this session's `FILING-LOW-001` and `FILING-HIGH-001`). Several of the older synthetic entries show `status=PIPELINE_ERROR` — pre-existing fixture rows from earlier test/demo iterations, unrelated to this session's two clean `HANDOFF_READY` runs.

---

## Summary

| Scenario | Rules flagged | Risk tier | Recommendation | Review queue | Idempotent |
|---|---|---|---|---|---|
| Low Risk (`FILING-LOW-001`) | 0 (PASS) | LOW | APPROVE (0.86 confidence) | OPERATIONS | Yes |
| High Risk / Legal (`FILING-HIGH-001`) | 9 — 3 HIGH, 5 MEDIUM (FLAG) | HIGH | APPROVE (1.00 confidence) | LEGAL | Yes (verified via 2x submit, no duplicate audit events) |

The demo shows an end-to-end, human-in-the-loop filing triage pipeline (Rule Engine → Risk Service → RAG Retrieval → RAG Draft → Router → Repository/Audit → Human Review) that never auto-files, grounds its draft summary in retrieved policy/regulatory evidence, routes deterministically by risk/category, and is provably idempotent on resubmission — while being explicit in the UI about which underlying details it does *not* expose.
