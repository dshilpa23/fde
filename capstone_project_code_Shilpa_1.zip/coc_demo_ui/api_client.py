"""Thin HTTP client over the existing FastAPI service.

This module never reimplements rule/risk/RAG/routing/persistence logic — it only
calls the released endpoints in coc_filing_assistant/src/coc_filing_assistant/api.py
and returns their JSON responses (or a typed error) unmodified.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

import requests

DEFAULT_TIMEOUT = 45.0
API_KEY_HEADER = "X-API-Key"


class ApiError(Exception):
    """Raised for any API call failure. Message is safe to show to a user."""


@dataclass
class ApiResult:
    ok: bool
    data: Any = None
    error: str | None = None


def _auth_headers() -> dict[str, str]:
    """Return the inbound auth header when COC_API_KEY is configured.

    Read from the environment at call time, matching how the service reads its own
    credentials. Absent key means no header, which is correct against an API running
    without the secured wrapper.
    """
    key = os.environ.get("COC_API_KEY")
    return {API_KEY_HEADER: key} if key else {}


def _request(method: str, base_url: str, path: str, **kwargs) -> ApiResult:
    url = base_url.rstrip("/") + path
    # Merge rather than overwrite: a caller-supplied headers= must not be dropped,
    # and passing headers twice would raise TypeError.
    headers = {**_auth_headers(), **kwargs.pop("headers", {})}
    try:
        resp = requests.request(
            method, url, timeout=DEFAULT_TIMEOUT, headers=headers, **kwargs
        )
    except requests.exceptions.ConnectionError:
        return ApiResult(
            ok=False,
            error=(
                "API unavailable. Start it with: "
                "uvicorn coc_filing_assistant.secured_app:secured --port 8000 "
                "(run from the coc_filing_assistant directory, with COC_API_KEY set)."
            ),
        )
    except requests.exceptions.Timeout:
        return ApiResult(ok=False, error="Request timed out talking to the API.")
    except requests.exceptions.RequestException as exc:
        return ApiResult(ok=False, error=f"Request failed: {exc.__class__.__name__}")

    if resp.status_code >= 400:
        try:
            detail = resp.json().get("detail", resp.text)
        except ValueError:
            detail = resp.text
        if resp.status_code == 401:
            return ApiResult(
                ok=False,
                error=(
                    "401 from the API: set COC_API_KEY in the environment this app "
                    "runs in, matching the key the service was started with."
                ),
            )
        return ApiResult(ok=False, error=f"API returned {resp.status_code}: {detail}")

    try:
        return ApiResult(ok=True, data=resp.json())
    except ValueError:
        return ApiResult(ok=False, error="API returned a non-JSON response.")


def health(base_url: str) -> ApiResult:
    return _request("GET", base_url, "/health")


def process_filing(base_url: str, payload: dict) -> ApiResult:
    return _request("POST", base_url, "/filings/process", json=payload)


def list_filings(base_url: str) -> ApiResult:
    return _request("GET", base_url, "/filings")


def get_filing(base_url: str, filing_id: str) -> ApiResult:
    return _request("GET", base_url, f"/filings/{filing_id}")


def audit_log(base_url: str) -> ApiResult:
    return _request("GET", base_url, "/audit-log")


def review_queue(base_url: str) -> ApiResult:
    return _request("GET", base_url, "/review-queue")


def risk_report(base_url: str) -> ApiResult:
    return _request("GET", base_url, "/risk-report")
