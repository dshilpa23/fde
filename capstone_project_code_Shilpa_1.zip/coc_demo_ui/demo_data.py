"""Loads the committed synthetic demo payloads. Read-only — never edits the fixtures."""
from __future__ import annotations

import json
from pathlib import Path

PAYLOADS_DIR = (
    Path(__file__).resolve().parent.parent
    / "coc_filing_assistant"
    / "demo_payloads"
)

# label -> filename. Order matches the requested selector layout.
FIXTURES: dict[str, str] = {
    "Low Risk": "FILING-LOW-001.json",
    "Medium Risk": "FILING-MED-001.json",
    "High Risk / Legal Review": "FILING-HIGH-001.json",
    "Idempotency": "FILING-IDEM-001.json",
    "Sparse / Empty-Field Fixture": "FILING-ERR-001.json",
}

FIXTURE_NOTES: dict[str, str] = {
    "Low Risk": "No rule categories fire; richest filing text. Expect HANDOFF_READY / LOW / OPERATIONS.",
    "Medium Risk": "Some rules fire at MEDIUM severity. Expect HANDOFF_READY / MEDIUM.",
    "High Risk / Legal Review": "9 rules fire (3 HIGH). Expect HANDOFF_READY / HIGH / LEGAL.",
    "Idempotency": "Submit twice to observe idempotent_replay=True with no new audit events.",
    "Sparse / Empty-Field Fixture": (
        "Sparse/blank fields, not a pipeline failure. The demo_payloads README explicitly "
        "warns not to present this as an error case."
    ),
}


def load_fixture(label: str) -> dict:
    filename = FIXTURES[label]
    path = PAYLOADS_DIR / filename
    with open(path, "r") as f:
        return json.load(f)
