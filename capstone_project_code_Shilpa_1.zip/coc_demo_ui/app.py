"""COC Filing Readiness Assistant — Streamlit demo UI.

Presentation layer only. Every business fact shown here comes from a live HTTP
call to the existing FastAPI service (see api_client.py) — this file never
computes a risk score, rule result, retrieval, or routing decision itself.
"""
from __future__ import annotations

import json

import streamlit as st

import api_client as api
import demo_data

st.set_page_config(
    page_title="COC Filing Readiness Assistant",
    page_icon="\U0001F4CB",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Styling
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    .block-container { padding-top: 2rem; max-width: 1180px; }
    .synthetic-badge {
        display: inline-block; background: #eef2ff; color: #3730a3;
        border: 1px solid #c7d2fe; border-radius: 999px;
        padding: 4px 14px; font-size: 0.82rem; font-weight: 600;
    }
    .principle-card {
        background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
        padding: 14px 16px; text-align: center; height: 100%;
    }
    .principle-card h4 { margin: 0 0 4px 0; font-size: 0.95rem; color: #0f172a; }
    .outcome-card {
        border-radius: 12px; padding: 18px 20px; border: 1px solid #e2e8f0;
        background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    .outcome-label { font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.04em;
        color: #64748b; font-weight: 600; margin-bottom: 6px; }
    .outcome-value { font-size: 1.5rem; font-weight: 700; color: #0f172a; }
    .badge { display: inline-block; padding: 3px 12px; border-radius: 999px;
        font-weight: 700; font-size: 0.85rem; }
    .badge-ready { background: #d4edda; color: #14532d; }
    .badge-review { background: #fff3cd; color: #713f12; }
    .badge-error { background: #f8d7da; color: #7f1d1d; }
    .human-gate { border-radius: 12px; padding: 16px 20px; margin-top: 6px;
        background: #f0fdf4; border: 1px solid #bbf7d0; color: #14532d; font-weight: 600; }
    .stage-band { border: 1px dashed #94a3b8; border-radius: 14px; padding: 14px;
        margin-bottom: 14px; }
    .stage-band-title { font-weight: 700; color: #334155; margin-bottom: 8px; }
    .stage-card { border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 14px;
        background: white; margin-bottom: 8px; }
    .stage-name { font-weight: 700; color: #0f172a; }
    .stage-desc { color: #64748b; font-size: 0.85rem; margin-bottom: 6px; }
    .tag { display: inline-block; font-size: 0.72rem; font-weight: 700;
        padding: 2px 8px; border-radius: 6px; margin-right: 6px; }
    .tag-observed { background: #dbeafe; color: #1e3a8a; }
    .tag-arch { background: #ede9fe; color: #4c1d95; }
    .tag-gap { background: #fee2e2; color: #7f1d1d; }
    .success-pill { color: #15803d; font-weight: 700; }
    .fail-pill { color: #b91c1c; font-weight: 700; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
_DEFAULT_FIXTURE = next(iter(demo_data.FIXTURES.keys()))

if "active_fixture" not in st.session_state:
    st.session_state.active_fixture = _DEFAULT_FIXTURE
if "payload_editor" not in st.session_state:
    st.session_state.payload_editor = json.dumps(
        demo_data.load_fixture(_DEFAULT_FIXTURE), indent=2
    )
if "last_responses" not in st.session_state:
    st.session_state.last_responses = []  # list of {"label", "data", "error"}
if "last_filing_id" not in st.session_state:
    st.session_state.last_filing_id = None
if "last_filing_detail" not in st.session_state:
    st.session_state.last_filing_detail = None
if "queue_data" not in st.session_state:
    st.session_state.queue_data = None
if "audit_data" not in st.session_state:
    st.session_state.audit_data = None
if "persisted_filings" not in st.session_state:
    st.session_state.persisted_filings = None


def reset_demo():
    st.session_state.last_responses = []
    st.session_state.last_filing_id = None
    st.session_state.last_filing_detail = None
    st.session_state.payload_editor = json.dumps(
        demo_data.load_fixture(st.session_state.active_fixture), indent=2
    )


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### Connection")
    base_url = st.text_input("API base URL", value="http://localhost:8000")

    health_result = api.health(base_url)
    if health_result.ok:
        st.success(f"API reachable — v{health_result.data.get('version', '?')}", icon="✅")
        st.caption(
            f"policy_chunks={health_result.data.get('policy_chunks')} · "
            f"regulatory_chunks={health_result.data.get('regulatory_chunks')}"
        )
    else:
        st.error(health_result.error, icon="🚫")

    st.markdown("---")
    st.markdown(
        '<span class="synthetic-badge">Synthetic demo data — no real member/patient data</span>',
        unsafe_allow_html=True,
    )

    st.markdown("---")
    st.markdown("### 1. Load a scenario")
    fixture_label = st.selectbox("Synthetic filing", list(demo_data.FIXTURES.keys()))
    st.caption(demo_data.FIXTURE_NOTES[fixture_label])

    # Reseed the editor when the scenario changes — must happen before the
    # text_area with this key is instantiated below.
    if fixture_label != st.session_state.active_fixture:
        st.session_state.active_fixture = fixture_label
        st.session_state.payload_editor = json.dumps(
            demo_data.load_fixture(fixture_label), indent=2
        )

    st.markdown("### 2. Filing payload (editable)")
    st.caption(
        "Edit any field and submit — this goes through the real "
        "`POST /filings/process` endpoint unmodified, so rule/risk/RAG results "
        "reflect exactly what you typed."
    )
    st.text_area("Filing JSON", key="payload_editor", height=280, label_visibility="collapsed")

    if st.button("Reset to fixture defaults", use_container_width=True):
        st.session_state.payload_editor = json.dumps(
            demo_data.load_fixture(fixture_label), indent=2
        )
        st.rerun()

    submit_once_clicked = st.button(
        "Submit once → /filings/process", type="primary", use_container_width=True
    )
    submit_twice_clicked = st.button(
        "Run idempotency demo (submit twice)", use_container_width=True
    )

    st.markdown("---")
    st.markdown("### Demo controls")
    st.caption(
        "Queue, persisted filings, and the audit trail refresh automatically below — "
        "use the ↻ buttons next to each table for an explicit refresh."
    )
    if st.button("Clear / Reset Demo", use_container_width=True):
        reset_demo()
        st.rerun()

# ---------------------------------------------------------------------------
# Handle actions
# ---------------------------------------------------------------------------
if submit_once_clicked or submit_twice_clicked:
    try:
        payload = json.loads(st.session_state.payload_editor)
        responses = []
        submissions = 2 if submit_twice_clicked else 1
        for i in range(submissions):
            result = api.process_filing(base_url, payload)
            label = (
                "1st submit (fresh id)" if i == 0 and submit_twice_clicked
                else "2nd submit (same id)" if i == 1
                else "Submission"
            )
            responses.append({
                "label": label,
                "data": result.data if result.ok else None,
                "error": None if result.ok else result.error,
            })
        st.session_state.last_responses = responses
        last_ok = next((r["data"] for r in reversed(responses) if r["data"]), None)
        if last_ok:
            st.session_state.last_filing_id = last_ok.get("filing_id")
            detail = api.get_filing(base_url, st.session_state.last_filing_id)
            st.session_state.last_filing_detail = detail.data if detail.ok else None
    except json.JSONDecodeError as exc:
        st.session_state.last_responses = [
            {"label": "Payload error", "data": None, "error": f"Invalid JSON in filing payload: {exc}"}
        ]

# Queue, audit, and persisted-filings views auto-refresh on every rerun so
# "what's in queue" is always current without requiring a click.
if health_result.ok:
    q = api.review_queue(base_url)
    if q.ok:
        st.session_state.queue_data = q.data
    a = api.audit_log(base_url)
    if a.ok:
        st.session_state.audit_data = a.data
    f = api.list_filings(base_url)
    if f.ok:
        st.session_state.persisted_filings = f.data

# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.title("COC Filing Readiness Assistant")
st.markdown(
    "##### AI-assisted regulatory filing triage — human decision required"
)

cols = st.columns(4)
principles = [
    ("No auto-filing", "The system stages a package for review. It never files, sends, or submits."),
    ("Grounded evidence", "Draft summaries are built from retrieved policy and regulatory evidence."),
    ("Deterministic routing", "The same package always routes to the same review queue."),
    ("Human owns the final decision", "HANDOFF_READY means ready for review — not filed."),
]
for c, (title, desc) in zip(cols, principles):
    c.markdown(
        f'<div class="principle-card"><h4>{title}</h4>'
        f'<span style="font-size:0.8rem;color:#64748b">{desc}</span></div>',
        unsafe_allow_html=True,
    )

st.markdown("---")

tab_demo, tab_how = st.tabs(["Live Demo", "How It Works"])

# ---------------------------------------------------------------------------
# TAB 1 — Live Demo
# ---------------------------------------------------------------------------
def _render_outcome_cards(label, response):
    status = response.get("status")
    badge_class = {
        "HANDOFF_READY": "badge-ready",
        "NEEDS_REVIEW": "badge-review",
    }.get(status, "badge-error")

    if label:
        st.markdown(f"**{label}**")

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        st.markdown(
            f'<div class="outcome-card"><div class="outcome-label">Status</div>'
            f'<span class="badge {badge_class}">{status}</span></div>',
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            f'<div class="outcome-card"><div class="outcome-label">Risk Tier</div>'
            f'<div class="outcome-value">{response.get("risk_tier") or "—"}</div></div>',
            unsafe_allow_html=True,
        )
    with c3:
        conf = response.get("confidence_score")
        st.markdown(
            f'<div class="outcome-card"><div class="outcome-label">Confidence</div>'
            f'<div class="outcome-value">{f"{conf:.2f}" if conf is not None else "—"}</div></div>',
            unsafe_allow_html=True,
        )
    with c4:
        st.markdown(
            f'<div class="outcome-card"><div class="outcome-label">Review Queue</div>'
            f'<div class="outcome-value">{response.get("review_queue") or "—"}</div></div>',
            unsafe_allow_html=True,
        )
    with c5:
        replay = response.get("idempotent_replay")
        st.markdown(
            f'<div class="outcome-card"><div class="outcome-label">Idempotent Replay</div>'
            f'<div class="outcome-value">{"YES" if replay else "no"}</div></div>',
            unsafe_allow_html=True,
        )

    if status == "HANDOFF_READY":
        st.markdown(
            '<div class="human-gate">HANDOFF_READY = ready for human review, not filed.</div>',
            unsafe_allow_html=True,
        )
    elif response.get("error_reason"):
        st.warning(f"error_reason: {response['error_reason']}")


with tab_demo:
    responses = st.session_state.last_responses
    response = None

    if not responses:
        st.info(
            "Edit the filing payload in the sidebar (or leave the fixture as-is) and click "
            "**Submit once** or **Run idempotency demo** to begin."
        )
    else:
        for r in responses:
            if r["error"]:
                st.error(f"{r['label']}: {r['error']}" if r["label"] else r["error"])

        ok_responses = [r for r in responses if r["data"]]

        if len(ok_responses) == 2:
            r1, r2 = ok_responses[0]["data"], ok_responses[1]["data"]
            detail = st.session_state.last_filing_detail or {}
            audit_count = len(detail.get("audit_events", []))
            st.success(
                f"Idempotency verified for `{r1.get('filing_id')}`: `idempotent_replay` went "
                f"{r1.get('idempotent_replay')} → {r2.get('idempotent_replay')}; "
                f"audit events for this filing stayed at {audit_count} (no new events on replay)."
            )

        st.subheader("Executive Outcome")
        if ok_responses:
            outcome_cols = st.columns(len(ok_responses))
            for col, r in zip(outcome_cols, ok_responses):
                with col:
                    _render_outcome_cards(r["label"] if len(ok_responses) > 1 else None, r["data"])

        response = ok_responses[-1]["data"] if ok_responses else None

        st.markdown("&nbsp;")

    if response is not None:

        # -------------------------------------------------------------
        # Pipeline view
        # -------------------------------------------------------------
        st.subheader("Pipeline / Tool Execution")

        detail = st.session_state.last_filing_detail or {}
        audit_events = detail.get("audit_events", []) if detail else []
        events_by_agent = {e.get("agent_name"): e for e in audit_events}

        stage_specs = [
            ("RuleEngine", "Rule Engine", "Deterministic Python checks over 14 rules across 5 categories."),
            ("MLService", "Risk Service", "Deterministic feature-weighted score — not a trained classifier."),
            ("RAGRetrieve", "RAG Retrieval", "Retrieves evidence from approved ChromaDB policy/regulatory collections."),
            ("RAGDraft", "RAG Draft", "Grounded summary drafted via the enterprise LLM endpoint."),
        ]

        st.markdown(
            '<div class="stage-band"><div class="stage-band-title">'
            'Supervisor <span class="tag tag-arch">Architecture/design explanation</span>'
            '<br><span style="font-weight:400;font-size:0.85rem;color:#64748b">'
            'Orchestrates the four services below for every filing; not itself an AgentEvent '
            'in the API response.</span></div>',
            unsafe_allow_html=True,
        )

        stage_cols = st.columns(4)
        for col, (agent_key, display_name, desc) in zip(stage_cols, stage_specs):
            ev = events_by_agent.get(agent_key)
            with col:
                if ev:
                    status_pill = (
                        f'<span class="success-pill">SUCCESS</span>' if ev.get("status") == "SUCCESS"
                        else f'<span class="fail-pill">{ev.get("status")}</span>'
                    )
                    conf_val = ev.get("confidence")
                    conf_str = f"{conf_val:.2f}" if isinstance(conf_val, (int, float)) else "—"
                    col.markdown(
                        f'<div class="stage-card">'
                        f'<div class="stage-name">{display_name}</div>'
                        f'<div class="stage-desc">{desc}</div>'
                        f'<span class="tag tag-observed">Observed</span> {status_pill}'
                        f'<div style="margin-top:6px;font-size:0.85rem">{ev.get("output_summary", "—")}</div>'
                        f'<div style="margin-top:4px;font-size:0.8rem;color:#64748b">Confidence: {conf_str}</div>'
                        f'<div style="margin-top:4px;font-size:0.78rem;color:#94a3b8">'
                        f'Duration: not exposed by current API</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
                else:
                    col.markdown(
                        f'<div class="stage-card">'
                        f'<div class="stage-name">{display_name}</div>'
                        f'<div class="stage-desc">{desc}</div>'
                        f'<span class="tag tag-gap">No audit event found</span>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown(
            '<div style="text-align:center;color:#94a3b8;font-size:1.3rem;margin:4px 0;">↓ handoff package assembled ↓</div>',
            unsafe_allow_html=True,
        )

        post_cols = st.columns(3)
        with post_cols[0]:
            st.markdown(
                f'<div class="stage-card">'
                f'<div class="stage-name">Router</div>'
                f'<div class="stage-desc">Fixed priority: LEGAL &gt; PHARMACY &gt; ACTUARIAL &gt; NETWORK &gt; OPERATIONS '
                f'<span class="tag tag-arch">Architecture context</span></div>'
                f'<span class="tag tag-observed">Observed</span> queue = '
                f'<b>{response.get("review_queue") or "—"}</b>'
                f'</div>',
                unsafe_allow_html=True,
            )
        with post_cols[1]:
            audit_count = len(audit_events)
            st.markdown(
                f'<div class="stage-card">'
                f'<div class="stage-name">Repository / Audit</div>'
                f'<div class="stage-desc">Atomic 3-table SQLite write; append-only audit log.</div>'
                f'<span class="tag tag-observed">Observed</span> {audit_count} audit event(s) persisted'
                f'</div>',
                unsafe_allow_html=True,
            )
        with post_cols[2]:
            st.markdown(
                f'<div class="stage-card">'
                f'<div class="stage-name">Human Review</div>'
                f'<div class="stage-desc">A reviewer in the assigned queue makes the final decision.'
                f' See Review Queue below. <span class="tag tag-arch">Architecture context</span></div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        st.markdown("&nbsp;")

        # -------------------------------------------------------------
        # Evidence & Grounding
        # -------------------------------------------------------------
        with st.expander("Evidence & Grounding"):
            st.markdown(
                "> Raw filing excerpts are used for retrieval embeddings, but raw filing "
                "free-text is **not** passed to the LLM generation prompt."
            )
            conf = response.get("confidence_score")
            st.metric("Grounding confidence (confidence_score)", f"{conf:.2f}" if conf is not None else "—")
            st.markdown(
                '<span class="tag tag-gap">Not shown</span> Retrieved source names, citation text, '
                "and coverage gaps are computed by the pipeline but are not persisted or returned by "
                "any API endpoint in this build — they are not displayed here to avoid fabricating data.",
                unsafe_allow_html=True,
            )

        # -------------------------------------------------------------
        # Rules & Risk
        # -------------------------------------------------------------
        with st.expander("Rules & Risk"):
            rule_ev = events_by_agent.get("RuleEngine")
            risk_ev = events_by_agent.get("MLService")
            rc1, rc2 = st.columns(2)
            with rc1:
                st.markdown("**Rule Engine finding (audit summary)**")
                st.write(rule_ev.get("output_summary") if rule_ev else "—")
            with rc2:
                st.markdown("**Risk tier / composite**")
                st.write(f"Tier: {response.get('risk_tier') or '—'}")
                st.write(
                    f"Composite (audit confidence): "
                    f"{risk_ev.get('confidence') if risk_ev and risk_ev.get('confidence') is not None else '—'}"
                )
            st.caption("Risk and grounding confidence are independent signals.")
            st.markdown(
                '<span class="tag tag-gap">Not shown</span> Per-rule detail (rule_id / category / '
                "severity per finding) is not exposed by the API — only the aggregate summary string above is.",
                unsafe_allow_html=True,
            )

        st.markdown("&nbsp;")

        with st.expander("Raw API Response"):
            for r in ok_responses:
                if len(ok_responses) > 1:
                    st.markdown(f"**{r['label']}**")
                st.json(r["data"])
            if detail:
                st.markdown("**`GET /filings/{filing_id}`**")
                st.json(detail)

    # -------------------------------------------------------------
    # Human review queue — auto-refreshes every rerun, no click required
    # -------------------------------------------------------------
    hq_head, hq_refresh = st.columns([5, 1])
    hq_head.subheader("Human Review Queue")
    if hq_refresh.button("↻ refresh", key="hrq_refresh"):
        st.rerun()
    st.caption("The system recommends where a filing should be reviewed. A human makes the final filing decision.")
    queue_data = st.session_state.queue_data
    if queue_data is None:
        st.caption("Waiting for the API — check the connection status in the sidebar.")
    elif len(queue_data) == 0:
        st.info("No filings in the review queue yet (GET /review-queue is empty).")
    else:
        highlight_id = st.session_state.last_filing_id
        rows = sorted(queue_data, key=lambda r: r.get("filing_id") != highlight_id)
        st.dataframe(rows, use_container_width=True, hide_index=True)

    # -------------------------------------------------------------
    # All persisted filings — broader view than the review queue alone,
    # includes PIPELINE_ERROR rows that never reach a queue.
    # -------------------------------------------------------------
    pf_head, pf_refresh = st.columns([5, 1])
    pf_head.subheader("Persisted Filings")
    if pf_refresh.button("↻ refresh", key="pf_refresh"):
        st.rerun()
    st.caption("Every filing persisted via `GET /filings`, most-recent first.")
    persisted = st.session_state.persisted_filings
    if persisted is None:
        st.caption("Waiting for the API — check the connection status in the sidebar.")
    elif len(persisted) == 0:
        st.info("No filings processed yet.")
    else:
        highlight_id = st.session_state.last_filing_id
        rows = sorted(persisted, key=lambda r: r.get("filing_id") != highlight_id)
        st.dataframe(rows, use_container_width=True, hide_index=True)

    # -------------------------------------------------------------
    # Audit trail — auto-refreshes every rerun, no click required
    # -------------------------------------------------------------
    st.subheader("Audit Trail")
    audit_data = st.session_state.audit_data
    if audit_data is None:
        st.caption("Waiting for the API — check the connection status in the sidebar.")
    elif len(audit_data) == 0:
        st.info("No audit events recorded yet.")
    else:
        highlight_id = st.session_state.last_filing_id
        with st.expander(f"Audit events (this filing first, {len(audit_data)} total)", expanded=True):
            rows = sorted(audit_data, key=lambda r: r.get("filing_id") != highlight_id)
            display_cols = ["filing_id", "agent_name", "status", "executed_at", "output_summary", "confidence"]
            table = [{k: r.get(k) for k in display_cols} for r in rows]
            st.dataframe(table, use_container_width=True, hide_index=True)

# ---------------------------------------------------------------------------
# TAB 2 — How It Works
# ---------------------------------------------------------------------------
with tab_how:
    st.subheader("Architecture")

    diagram_svg = (
        '<svg viewBox="0 0 900 300" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;">'
        '<rect x="20" y="20" width="500" height="120" rx="12" fill="none" stroke="#94a3b8" stroke-dasharray="6,4"/>'
        '<text x="30" y="15" font-size="13" fill="#334155" font-weight="700">Supervisor (orchestration only)</text>'
        '<g font-size="12" fill="#0f172a">'
        '<rect x="35" y="45" width="105" height="70" rx="8" fill="#eef2ff" stroke="#c7d2fe"/>'
        '<text x="45" y="75" font-weight="700">Rule Engine</text>'
        '<text x="45" y="95" font-size="10" fill="#475569">deterministic</text>'
        '<rect x="155" y="45" width="105" height="70" rx="8" fill="#eef2ff" stroke="#c7d2fe"/>'
        '<text x="165" y="75" font-weight="700">Risk Service</text>'
        '<text x="165" y="95" font-size="10" fill="#475569">feature-weighted</text>'
        '<rect x="275" y="45" width="105" height="70" rx="8" fill="#eef2ff" stroke="#c7d2fe"/>'
        '<text x="285" y="70" font-weight="700">RAG</text>'
        '<text x="285" y="85" font-weight="700">Retrieval</text>'
        '<text x="285" y="100" font-size="10" fill="#475569">ChromaDB</text>'
        '<rect x="395" y="45" width="105" height="70" rx="8" fill="#eef2ff" stroke="#c7d2fe"/>'
        '<text x="405" y="70" font-weight="700">RAG Draft</text>'
        '<text x="405" y="90" font-size="10" fill="#475569">enterprise LLM</text>'
        '</g>'
        '<text x="560" y="90" font-size="20" fill="#94a3b8">&#8594;</text>'
        '<g font-size="12" fill="#0f172a">'
        '<rect x="595" y="45" width="90" height="70" rx="8" fill="#f1f5f9" stroke="#cbd5e1"/>'
        '<text x="605" y="75" font-weight="700">Router</text>'
        '<text x="605" y="95" font-size="10" fill="#475569">deterministic</text>'
        '<rect x="710" y="45" width="90" height="70" rx="8" fill="#f1f5f9" stroke="#cbd5e1"/>'
        '<text x="716" y="70" font-weight="700">Repository</text>'
        '<text x="716" y="85" font-weight="700">/ Audit</text>'
        '<text x="716" y="100" font-size="10" fill="#475569">SQLite</text>'
        '</g>'
        '<text x="807" y="90" font-size="20" fill="#94a3b8">&#8594;</text>'
        '<rect x="820" y="45" width="65" height="70" rx="8" fill="#f0fdf4" stroke="#bbf7d0"/>'
        '<text x="828" y="72" font-size="12" font-weight="700" fill="#14532d">Human</text>'
        '<text x="828" y="88" font-size="12" font-weight="700" fill="#14532d">Review</text>'
        '<text x="30" y="175" font-size="11" fill="#64748b">'
        'FastAPI (transport) &#183; ChromaDB (2 collections: coc_policy_docs, coc_regulatory)'
        '</text>'
        '<text x="30" y="195" font-size="11" fill="#64748b">'
        'SQLite (coc_filings.db, WAL, append-only audit triggers)'
        '</text>'
        '<text x="30" y="215" font-size="11" fill="#64748b">'
        'Enterprise embedding + LLM endpoints (approved gateway; not a public model provider)'
        '</text>'
        '<text x="30" y="235" font-size="11" fill="#64748b">'
        'OpenTelemetry / Arize &#8212; supplementary observability, never gates a release'
        '</text>'
        '</svg>'
    )
    st.markdown(diagram_svg, unsafe_allow_html=True)

    st.markdown(
        "> Raw filing excerpts are used for retrieval embeddings, but raw filing free-text "
        "is not passed to the LLM generation prompt."
    )
    st.markdown(
        "> ML/risk service is deterministic feature-weighted scoring, not a trained classifier. "
        "The same filing always scores identically."
    )

    col_impl, col_gap = st.columns(2)
    with col_impl:
        st.markdown("#### Implemented & verified")
        st.markdown(
            "- 8 FastAPI endpoints (`/health`, `/filings/process`, `/filings`, "
            "`/filings/{id}`, `/audit-log`, `/review-queue`, `/risk-report`, `/dashboard`)\n"
            "- Deterministic rule engine (14 rules, 5 categories)\n"
            "- Feature-weighted risk score (`ml_service.py`) — reproducible, not a trained model\n"
            "- ChromaDB dual-collection retrieval via the enterprise embedding endpoint\n"
            "- RAG draft via the enterprise LLM endpoint, with grounding checks\n"
            "- Deterministic router (fixed queue priority)\n"
            "- Atomic 3-table SQLite persistence\n"
            "- Append-only audit log\n"
            "- OpenTelemetry export (local + optional Arize)"
        )
    with col_gap:
        st.markdown("#### Production hardening required")
        st.markdown(
            "- Authentication / authorization on the API\n"
            "- Production datastore — SQLite has no concurrent-writer story; needs Postgres\n"
            "- CI/CD and dependency governance\n"
            "- Rate limiting\n"
            "- Threshold/confidence calibration against real reviewer outcomes "
            "(0.35 / 0.65 tier boundaries and the 0.70 confidence gate are documented "
            "design choices, not calibrated ones)\n"
            "- Compliance approval before processing real filings"
        )

    st.markdown("---")
    st.caption(
        "Swagger UI (`/docs`) and the built-in `/dashboard` HTML view remain available "
        "as a fallback demo path directly against the FastAPI service."
    )
