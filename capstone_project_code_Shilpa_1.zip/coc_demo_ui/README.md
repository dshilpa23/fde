# COC Filing Readiness Assistant — Streamlit Demo UI

Presentation layer only. This app never reimplements rule logic, risk scoring,
RAG, routing, or persistence — it calls the existing FastAPI service
(`coc_filing_assistant/src/coc_filing_assistant/api.py`) over HTTP and displays
what it returns.

Nothing under `coc_filing_assistant/` is modified by this directory.

## Launch

1. Start the released API (from the `coc_filing_assistant/` directory):

   ```bash
   cd ../coc_filing_assistant
   uvicorn coc_filing_assistant.api:app --reload --port 8000
   ```

2. In a separate terminal, install and start the demo UI:

   ```bash
   cd coc_demo_ui
   pip install -r requirements-streamlit.txt
   streamlit run app.py
   ```

3. Open the URL Streamlit prints (usually `http://localhost:8501`).

## Fallback demo path

If the Streamlit app has any issue mid-demo, fall back to:

- Swagger UI: `http://localhost:8000/docs`
- Built-in dashboard: `http://localhost:8000/dashboard`

## What this UI intentionally does not show

The following exist inside the pipeline but are not returned by any API
endpoint, so the UI labels them as gaps rather than fabricating values:

- Per-stage duration/latency
- Retrieved evidence chunk text, source names, or similarity scores
- Citation text, executive summary, coverage gaps, recommended actions
- Structured per-rule detail (only an aggregate `output_summary` string survives to the audit log)
